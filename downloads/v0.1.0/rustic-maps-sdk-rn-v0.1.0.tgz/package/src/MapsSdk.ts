/**
 * The package-owned `MapsSdk` proxy.
 *
 * The generated JSI bindings construct their own native SDK object, and there
 * is no way to import that foreign handle into a native view. A native
 * `<MapView>` therefore has to use the SDK object the package owns and proxy
 * every SDK call through its module — otherwise two provider registries and
 * two SQLite tile caches exist in one process. This module is that proxy:
 * one native `MapsSdk` per process, created by the package's native module,
 * with the contract's provider-credential, search and diagnostics members
 * exposed under typed names.
 *
 * The proxy deliberately does not import the generated bindings at module
 * scope: the package entry's bindings install their own Rust crate and run
 * the generated checksum gate at import time, which the package's native
 * runtime does not need.
 */

import { NativeModules } from 'react-native';

import type {
  BoundingBox,
  DistanceMatrix,
  GeographicCoordinate,
  Place,
  ProviderFailureDiagnostic,
  Route,
  RouteOptions,
  TileCacheTerms,
  TrafficFlowData,
  TrafficIncident,
  TransportationMode,
} from './generated/rustic_maps';

// The record types the proxy answers are re-exported beside it, so a
// consumer imports one module for the SDK handle and its answer shapes.
export type {
  DistanceMatrix,
  DistanceMatrixEntry,
  Route,
  RouteOptions,
  TrafficFlowData,
  TrafficIncident,
  TransportationMode,
} from './generated/rustic_maps';

/** One runtime provider credential's honest outcome. */
export interface ProviderCredentialResult {
  /** Whether the credential registered. */
  isApplied: boolean;
  /** The verbatim refusal detail (empty when the credential applied). */
  detailText: string;
}

/** One runtime SDK registration's honest outcome (a credential or a base map). */
export interface SdkRegistrationResult {
  /** Whether the registration applied. */
  isApplied: boolean;
  /** The verbatim refusal detail (empty when the registration applied). */
  detailText: string;
}

/**
 * A raster image format the base-map contract serves, by the generated
 * enum's zero-based JavaScript ordinal: `0` is PNG, `1` is JPEG.
 */
export type UrlTemplateRasterImageFormat = 0 | 1;

/**
 * A pixel resolution the base-map contract serves, by the generated enum's
 * ordinal: `0` is standard, `1` is retina (the `@2x` form).
 */
export type UrlTemplateTileResolution = 0 | 1;

/**
 * One provider-neutral base-map tile source (the contract's
 * `UrlTemplateRasterTileSource`): a web-mercator XYZ raster tileset addressed
 * by a `{z}/{x}/{y}` URL template. The values come from the integrator's
 * shared provider registry, never from this package.
 */
export interface UrlTemplateRasterTileSource {
  /** The `{z}/{x}/{y}` URL template the tileset publishes. */
  urlTemplate: string;
  /** The tileset's name, used verbatim in every diagnostic it raises. */
  sourceName: string;
  /** Lowest zoom level the tileset serves. */
  minimumZoomLevel: number;
  /** Highest zoom level the tileset serves. */
  maximumZoomLevel: number;
  /** The image format the tileset serves. */
  imageFormat: UrlTemplateRasterImageFormat;
  /** The pixel resolution the tileset serves. */
  tileResolution: UrlTemplateTileResolution;
  /** The `User-Agent` every tile request carries; empty sends none. */
  userAgent: string;
}

/**
 * One provider-neutral vector base-map source (the contract's
 * `UrlTemplateVectorTileSource`, M22): a web-mercator XYZ vector tileset
 * addressed by a `{z}/{x}/{y}` URL template, painted with one of the SDK's
 * committed styles. The values come from the integrator's shared provider
 * registry, never from this package.
 */
export interface UrlTemplateVectorTileSource {
  /** The `{z}/{x}/{y}` URL template the tileset publishes. */
  urlTemplate: string;
  /** The tileset's name, used verbatim in every diagnostic it raises. */
  sourceName: string;
  /** The attribution line the tileset's terms (and its style's design) require. */
  attributionText: string;
  /** The committed style id the base paints with. */
  styleId: string;
  /** Lowest zoom level the tileset serves. */
  minimumZoomLevel: number;
  /** Highest zoom level the tileset serves. */
  maximumZoomLevel: number;
}

/**
 * The vector base source's status readback (the contract's
 * `VectorTileSourceStatus`, M22): what the view draws a styled base with and
 * what its last resolved frame achieved.
 */
export interface VectorTileSourceStatus {
  isConfigured: boolean;
  styleId: string;
  sourceName: string;
  attributionText: string;
  maximumZoomLevel: number;
  drawnTileCount: number;
  failedTileCount: number;
  lastFailureDetail?: string | null;
}

/** The native module surface the proxy calls. */
interface MapsSdkNativeModule {
  initialize(): Promise<void>;
  getCompiledVersion(): Promise<string>;
  defaultProviderKey(): Promise<string>;
  setProviderCredential(
    providerKey: string,
    credential: string,
  ): Promise<ProviderCredentialResult>;
  setProviderCredentialWithTileCache(
    providerKey: string,
    credential: string,
  ): Promise<ProviderCredentialResult>;
  registerUrlTemplateRasterTileSource(
    sourceJson: string,
  ): Promise<SdkRegistrationResult>;
  restoreCredentialedBaseMap(providerKey: string): Promise<SdkRegistrationResult>;
  search(queryText: string, searchBoundaryJson: string | null): Promise<string>;
  suggest(queryText: string, searchBoundaryJson: string | null): Promise<string>;
  forwardGeocode(addressText: string): Promise<string>;
  calculateRoute(
    waypointsJson: string,
    routeOptionsJson: string,
  ): Promise<string>;
  reverseGeocode(coordinateJson: string): Promise<string>;
  calculateDistanceMatrix(
    originsJson: string,
    destinationsJson: string,
    transportationMode: number,
  ): Promise<string>;
  fetchTrafficIncidents(boundingBoxJson: string): Promise<string>;
  fetchTrafficFlow(boundingBoxJson: string): Promise<string>;
  tileCacheTerms(): Promise<string>;
  setTileCacheTimeToLive(timeToLiveSeconds: number): Promise<void>;
  latestProviderFailureDiagnostics(): Promise<string>;
  diagnosticsLines(): Promise<string[]>;
}

/** The package's native module, or null when the native half is absent. */
function nativeModuleOrNull(): MapsSdkNativeModule | null {
  return (
    (NativeModules as Record<string, MapsSdkNativeModule | undefined>)
      .MapsSdkNative ?? null
  );
}

/** Decodes the native JSON answer into typed records. */
function parseRecords<RecordType>(encodedRecords: string): Array<RecordType> {
  return JSON.parse(encodedRecords) as Array<RecordType>;
}

/** The one package-owned SDK handle every `MapsSdk` value proxies. */
let sharedSdk: MapsSdk | null = null;

/**
 * The package-owned SDK root. There is one native instance per process; every
 * `MapsSdk` value is a handle to it, so repeated construction never opens a
 * second provider registry or tile cache.
 */
export class MapsSdk {
  private constructor() {}

  /**
   * Starts the package's native SDK keyless (a no-key state is first-class)
   * and answers its handle. The native start also applies the launch-argument
   * automation credential seam (Android `providerApiKey`/`providerKey`
   * intent extras, iOS `PROVIDER_API_KEY`/`PROVIDER_KEY` environment
   * variables) through the public registration path; the injection is never
   * persisted and never logged.
   */
  static async create(): Promise<MapsSdk> {
    if (sharedSdk !== null) {
      return sharedSdk;
    }
    const module = nativeModuleOrNull();
    if (module !== null) {
      await module.initialize();
    }
    sharedSdk = new MapsSdk();
    return sharedSdk;
  }

  /** Whether the package's native half is present (jest renders without it). */
  static isAvailable(): boolean {
    return nativeModuleOrNull() !== null;
  }

  /** Starts the native SDK if `create` has not run yet; idempotent. */
  async initialize(): Promise<void> {
    await nativeModuleOrNull()?.initialize();
  }

  /** The compiled SDK version, read through the package's native runtime. */
  async getCompiledVersion(): Promise<string> {
    return (await nativeModuleOrNull()?.getCompiledVersion()) ?? '';
  }

  /**
   * The provider key a launch-injected credential targets when the injection
   * names none: the provider the registration dispatch serves.
   */
  async defaultProviderKey(): Promise<string> {
    return (await nativeModuleOrNull()?.defaultProviderKey()) ?? '';
  }

  /** Registers one runtime provider credential (no tile cache). */
  async setProviderCredential(
    providerKey: string,
    credential: string,
  ): Promise<ProviderCredentialResult> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return { isApplied: false, detailText: 'the native SDK is unavailable' };
    }
    return module.setProviderCredential(providerKey, credential);
  }

  /**
   * Registers one runtime provider credential with the tile cache wrapped
   * around the raster-tile contract (the offline-maps demo shape).
   */
  async setProviderCredentialWithTileCache(
    providerKey: string,
    credential: string,
  ): Promise<ProviderCredentialResult> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return { isApplied: false, detailText: 'the native SDK is unavailable' };
    }
    return module.setProviderCredentialWithTileCache(providerKey, credential);
  }

  /**
   * Registers one provider-neutral base map (M9's native base-map switch):
   * the raster-tile slot is replaced — a tile-cache installation with it —
   * and the credential-registered contracts (geocoding, routing, search,
   * traffic) keep serving whichever base map is active. A malformed
   * template, a blank source name or an inverted zoom range is refused
   * verbatim; the previously serving source stays installed.
   */
  async registerUrlTemplateRasterTileSource(
    source: UrlTemplateRasterTileSource,
  ): Promise<SdkRegistrationResult> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return { isApplied: false, detailText: 'the native SDK is unavailable' };
    }
    return module.registerUrlTemplateRasterTileSource(JSON.stringify(source));
  }

  /**
   * Re-registers the applied provider credential so its raster-tile slot —
   * and the tile cache installed with it — serves the base map again: the
   * switch back from a credential-less source. The credential never leaves
   * the native runtime; JavaScript only names the provider. Refuses honestly
   * when no credential has been applied in this session.
   */
  async restoreCredentialedBaseMap(
    providerKey: string,
  ): Promise<SdkRegistrationResult> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return { isApplied: false, detailText: 'the native SDK is unavailable' };
    }
    return module.restoreCredentialedBaseMap(providerKey);
  }

  /** Full provider search results for a settled query. */
  async search(
    queryText: string,
    searchBoundary?: BoundingBox | null,
  ): Promise<Place[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<Place>(
      await module.search(
        queryText,
        searchBoundary === undefined || searchBoundary === null
          ? null
          : JSON.stringify(searchBoundary),
      ),
    );
  }

  /** Fast completion candidates while the user types. */
  async suggest(
    queryText: string,
    searchBoundary?: BoundingBox | null,
  ): Promise<Place[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<Place>(
      await module.suggest(
        queryText,
        searchBoundary === undefined || searchBoundary === null
          ? null
          : JSON.stringify(searchBoundary),
      ),
    );
  }

  /** Resolves a free-form address text into candidate places. */
  async forwardGeocode(addressText: string): Promise<Place[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<Place>(await module.forwardGeocode(addressText));
  }

  /**
   * Calculates a route through the ordered waypoints with the given options;
   * the route answers the total distance and duration, the geometry's
   * bounding box and one leg per waypoint pair.
   */
  async calculateRoute(
    waypoints: ReadonlyArray<GeographicCoordinate>,
    routeOptions: RouteOptions,
  ): Promise<Route> {
    const module = nativeModuleOrNull();
    if (module === null) {
      throw new Error('the native SDK is unavailable');
    }
    return JSON.parse(
      await module.calculateRoute(
        JSON.stringify(waypoints),
        JSON.stringify(routeOptions),
      ),
    ) as Route;
  }

  /**
   * Calculates the contract's travel-time matrix for every origin-destination
   * pair (M31). The native side parses the JSON and answers the generated
   * `DistanceMatrix` record.
   */
  async calculateDistanceMatrix(
    origins: ReadonlyArray<GeographicCoordinate>,
    destinations: ReadonlyArray<GeographicCoordinate>,
    transportationMode: TransportationMode,
  ): Promise<DistanceMatrix> {
    const module = nativeModuleOrNull();
    if (module === null) {
      throw new Error('the native SDK is unavailable');
    }
    return JSON.parse(
      await module.calculateDistanceMatrix(
        JSON.stringify(origins),
        JSON.stringify(destinations),
        transportationMode,
      ),
    ) as DistanceMatrix;
  }

  /** Fetches traffic incidents intersecting the bounding box (M31). */
  async fetchTrafficIncidents(boundingBox: BoundingBox): Promise<TrafficIncident[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<TrafficIncident>(
      await module.fetchTrafficIncidents(JSON.stringify(boundingBox)),
    );
  }

  /** Fetches per-segment traffic flow inside the bounding box (M31). */
  async fetchTrafficFlow(boundingBox: BoundingBox): Promise<TrafficFlowData[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<TrafficFlowData>(
      await module.fetchTrafficFlow(JSON.stringify(boundingBox)),
    );
  }

  /** Resolves a coordinate into candidate places describing that position. */
  async reverseGeocode(coordinate: {
    latitude: number;
    longitude: number;
  }): Promise<Place[]> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    return parseRecords<Place>(
      await module.reverseGeocode(JSON.stringify(coordinate)),
    );
  }

  /** The installed raster-tile cache's effective terms. */
  async tileCacheTerms(): Promise<TileCacheTerms | null> {
    const module = nativeModuleOrNull();
    if (module === null) {
      return null;
    }
    // JSON carries the u64 fields as numbers; the contract type keeps bigint.
    const parsedTerms = JSON.parse(await module.tileCacheTerms()) as {
      effectiveTimeToLiveSeconds: number;
      providerTermsCeilingSeconds?: number;
      defaultTimeToLiveSeconds: number;
    };
    const providerTermsCeilingSeconds =
      parsedTerms.providerTermsCeilingSeconds;
    return {
      effectiveTimeToLiveSeconds: BigInt(parsedTerms.effectiveTimeToLiveSeconds),
      providerTermsCeilingSeconds:
        providerTermsCeilingSeconds === undefined
          ? undefined
          : BigInt(providerTermsCeilingSeconds),
      defaultTimeToLiveSeconds: BigInt(parsedTerms.defaultTimeToLiveSeconds),
    };
  }

  /** Overrides the installed tile cache's time-to-live, in seconds. */
  async setTileCacheTimeToLive(timeToLiveSeconds: number): Promise<void> {
    await nativeModuleOrNull()?.setTileCacheTimeToLive(timeToLiveSeconds);
  }

  /** The retained provider-failure diagnostics, oldest first. */
  async latestProviderFailureDiagnostics(): Promise<
    ProviderFailureDiagnostic[]
  > {
    const module = nativeModuleOrNull();
    if (module === null) {
      return [];
    }
    const parsedDiagnostics = parseRecords<{
      timestampMillisecondsSinceEpoch: number;
      failureClassification: ProviderFailureDiagnostic['failureClassification'];
      providerContractName: string;
      providerMethodName: string;
      failureDetail: string;
    }>(await module.latestProviderFailureDiagnostics());
    return parsedDiagnostics.map(diagnostic => ({
      ...diagnostic,
      timestampMillisecondsSinceEpoch: BigInt(
        diagnostic.timestampMillisecondsSinceEpoch,
      ),
    }));
  }

  /** The SDK's read-only diagnostics lines (version, cache, provider state). */
  async diagnosticsLines(): Promise<string[]> {
    return (await nativeModuleOrNull()?.diagnosticsLines()) ?? [];
  }
}

/** The shared package SDK handle (created lazily by `MapsSdk.create`). */
export const mapsSdk = {
  create: MapsSdk.create,
  isAvailable: MapsSdk.isAvailable,
};
