#import "MapsSdkNativeModule.h"

#import <React/RCTUtils.h>

#import "MapsSdkRn-Swift.h"

namespace {
/// The promise rejection code every package failure carries.
NSString *const MapsSdkNativeFailureCode = @"MapsSdkNativeFailure";

/// The view-not-found rejection detail.
NSString *const MapsSdkNativeViewNotFoundText =
    @"the native MapView was not found";
} // namespace

@implementation MapsSdkNativeModule

RCT_EXPORT_MODULE(MapsSdkNative)

- (dispatch_queue_t)methodQueue {
  return dispatch_get_main_queue();
}

+ (BOOL)requiresMainQueueSetup {
  return YES;
}

- (instancetype)init {
  if (self = [super init]) {
    __weak MapsSdkNativeModule *weakSelf = self;
    MapsSdkNativeEventChannel.sink = ^(NSDictionary<NSString *, id> *payload) {
      MapsSdkNativeModule *strongSelf = weakSelf;
      if (strongSelf) {
        [strongSelf sendEventWithName:MapsSdkNativeEventChannel.eventName
                                 body:payload];
      }
    };
  }
  return self;
}

- (void)dealloc {
  MapsSdkNativeEventChannel.sink = nil;
}

- (NSArray<NSString *> *)supportedEvents {
  return @[ MapsSdkNativeEventChannel.eventName ];
}

- (void)startObserving {
  // The sink is installed at construction; the emitter only delivers while a
  // JavaScript listener is present, which React Native tracks through these
  // hooks.
}

- (void)stopObserving {
}

// ---------------------------------------------------------------------------
// SDK lifecycle and contract proxy
// ---------------------------------------------------------------------------

RCT_EXPORT_METHOD(initialize
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  NSError *startupError = nil;
  BOOL started = [[MapsSdkNativeRuntime shared]
      ensureStartedAndReturnError:&startupError];
  if (!started) {
    reject(MapsSdkNativeFailureCode,
           startupError.localizedDescription ?: @"the SDK did not start",
           startupError);
    return;
  }
  resolve(nil);
}

RCT_EXPORT_METHOD(getCompiledVersion
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] compiledVersion]);
}

RCT_EXPORT_METHOD(defaultProviderKey
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] defaultProviderKey]);
}

RCT_EXPORT_METHOD(setProviderCredential
                  : (NSString *)providerKey credential
                  : (NSString *)credential resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared]
      setProviderCredentialWithProviderKey:providerKey
                                credential:credential
                            withTileCache:NO]);
}

RCT_EXPORT_METHOD(setProviderCredentialWithTileCache
                  : (NSString *)providerKey credential
                  : (NSString *)credential resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared]
      setProviderCredentialWithProviderKey:providerKey
                                credential:credential
                            withTileCache:YES]);
}

RCT_EXPORT_METHOD(registerUrlTemplateRasterTileSource
                  : (NSString *)sourceJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  NSError *registrationError = nil;
  BOOL registered = [[MapsSdkNativeRuntime shared]
      registerUrlTemplateRasterTileSourceJSON:sourceJson
                                       error:&registrationError];
  if (registered) {
    resolve(@{ @"isApplied" : @YES, @"detailText" : @"" });
  } else {
    reject(MapsSdkNativeFailureCode,
           registrationError.localizedDescription,
           registrationError);
  }
}

RCT_EXPORT_METHOD(restoreCredentialedBaseMap
                  : (NSString *)providerKey resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared]
      restoreCredentialedBaseMapWithProviderKey:providerKey]);
}

RCT_EXPORT_METHOD(search
                  : (NSString *)queryText searchBoundaryJson
                  : (NSString *_Nullable)searchBoundaryJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared] searchJSONWithQueryText:queryText
                                            boundaryJSON:searchBoundaryJson
                                              completion:^(NSString *result,
                                                           NSError *error) {
                                                if (result != nil) {
                                                  resolve(result);
                                                } else {
                                                  reject(MapsSdkNativeFailureCode,
                                                         error.localizedDescription,
                                                         error);
                                                }
                                              }];
}

RCT_EXPORT_METHOD(suggest
                  : (NSString *)queryText searchBoundaryJson
                  : (NSString *_Nullable)searchBoundaryJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared] suggestJSONWithQueryText:queryText
                                             boundaryJSON:searchBoundaryJson
                                               completion:^(NSString *result,
                                                            NSError *error) {
                                                 if (result != nil) {
                                                   resolve(result);
                                                 } else {
                                                   reject(MapsSdkNativeFailureCode,
                                                          error.localizedDescription,
                                                          error);
                                                 }
                                               }];
}

RCT_EXPORT_METHOD(forwardGeocode
                  : (NSString *)addressText resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared] forwardGeocodeJSONWithAddressText:addressText
                                                        completion:^(NSString *result,
                                                                     NSError *error) {
                                                          if (result != nil) {
                                                            resolve(result);
                                                          } else {
                                                            reject(MapsSdkNativeFailureCode,
                                                                   error.localizedDescription,
                                                                   error);
                                                          }
                                                        }];
}

RCT_EXPORT_METHOD(calculateRoute
                  : (NSString *)waypointsJson routeOptionsJson
                  : (NSString *)routeOptionsJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared]
      calculateRouteJSONWithWaypointsJson:waypointsJson
                       routeOptionsJson:routeOptionsJson
                            completion:^(NSString *result, NSError *error) {
                              if (result != nil) {
                                resolve(result);
                              } else {
                                reject(MapsSdkNativeFailureCode,
                                       error.localizedDescription,
                                       error);
                              }
                            }];
}

RCT_EXPORT_METHOD(reverseGeocode
                  : (NSString *)coordinateJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared] reverseGeocodeJSONWithCoordinateJSON:coordinateJson
                                                           completion:^(NSString *result,
                                                                        NSError *error) {
                                                             if (result != nil) {
                                                               resolve(result);
                                                             } else {
                                                               reject(MapsSdkNativeFailureCode,
                                                                      error.localizedDescription,
                                                                      error);
                                                             }
                                                           }];
}

/// Calculates the contract's distance matrix (M31).
RCT_EXPORT_METHOD(calculateDistanceMatrix
                  : (NSString *)originsJson destinationsJson
                  : (NSString *)destinationsJson transportationMode
                  : (double)transportationMode resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared]
      calculateDistanceMatrixJSONWithOriginsJson:originsJson
                                destinationsJson:destinationsJson
                        transportationModeOrdinal:(NSInteger)transportationMode
                                      completion:^(NSString *result, NSError *error) {
                                        if (result != nil) {
                                          resolve(result);
                                        } else {
                                          reject(MapsSdkNativeFailureCode,
                                                 error.localizedDescription,
                                                 error);
                                        }
                                      }];
}

/// Fetches the incidents intersecting a bounding box (M31).
RCT_EXPORT_METHOD(fetchTrafficIncidents
                  : (NSString *)boundingBoxJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared]
      fetchTrafficIncidentsJSONWithBoundingBoxJson:boundingBoxJson
                                        completion:^(NSString *result, NSError *error) {
                                          if (result != nil) {
                                            resolve(result);
                                          } else {
                                            reject(MapsSdkNativeFailureCode,
                                                   error.localizedDescription,
                                                   error);
                                          }
                                        }];
}

/// Fetches per-segment traffic flow inside a bounding box (M31).
RCT_EXPORT_METHOD(fetchTrafficFlow
                  : (NSString *)boundingBoxJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  [[MapsSdkNativeRuntime shared]
      fetchTrafficFlowJSONWithBoundingBoxJson:boundingBoxJson
                                   completion:^(NSString *result, NSError *error) {
                                     if (result != nil) {
                                       resolve(result);
                                     } else {
                                       reject(MapsSdkNativeFailureCode,
                                              error.localizedDescription,
                                              error);
                                     }
                                   }];
}

RCT_EXPORT_METHOD(tileCacheTerms
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  NSError *termsError = nil;
  NSString *terms = [[MapsSdkNativeRuntime shared]
      tileCacheTermsJSONAndReturnError:&termsError];
  if (terms != nil) {
    resolve(terms);
  } else {
    reject(MapsSdkNativeFailureCode, termsError.localizedDescription, termsError);
  }
}

RCT_EXPORT_METHOD(setTileCacheTimeToLive
                  : (double)timeToLiveSeconds resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  NSError *timeToLiveError = nil;
  BOOL applied = [[MapsSdkNativeRuntime shared]
      setTileCacheTimeToLive:timeToLiveSeconds
                       error:&timeToLiveError];
  if (applied) {
    resolve(nil);
  } else {
    reject(MapsSdkNativeFailureCode,
           timeToLiveError.localizedDescription,
           timeToLiveError);
  }
}

RCT_EXPORT_METHOD(latestProviderFailureDiagnostics
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  NSError *diagnosticsError = nil;
  NSString *diagnostics = [[MapsSdkNativeRuntime shared]
      latestProviderFailureDiagnosticsJSONAndReturnError:&diagnosticsError];
  if (diagnostics != nil) {
    resolve(diagnostics);
  } else {
    reject(MapsSdkNativeFailureCode,
           diagnosticsError.localizedDescription,
           diagnosticsError);
  }
}

RCT_EXPORT_METHOD(diagnosticsLines
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] diagnosticsLines]);
}

// ---------------------------------------------------------------------------
// Device positioning
// ---------------------------------------------------------------------------

RCT_EXPORT_METHOD(startDeviceLocation
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve(@([[MapsSdkNativeRuntime shared] startDeviceLocation]));
}

RCT_EXPORT_METHOD(stopDeviceLocation
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve(@([[MapsSdkNativeRuntime shared] stopDeviceLocation]));
}

RCT_EXPORT_METHOD(latestDeviceFix
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] latestDeviceFixJSON]);
}

RCT_EXPORT_METHOD(deviceLocationSmoothedCourseDegrees
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] deviceLocationSmoothedCourseDegrees]);
}

RCT_EXPORT_METHOD(deviceLocationSourceStatus
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  resolve([[MapsSdkNativeRuntime shared] deviceLocationSourceStatusName]);
}

// ---------------------------------------------------------------------------
// MapView imperative calls (addressed by the view identifier)
// ---------------------------------------------------------------------------

- (MapsSdkMapHostView *)hostViewForIdentifier:(NSString *)viewIdentifier {
  return [MapsSdkMapHostView findWithViewIdentifier:viewIdentifier];
}

RCT_EXPORT_METHOD(setCamera
                  : (NSString *)viewIdentifier cameraJson
                  : (NSString *)cameraJson) {
  [[self hostViewForIdentifier:viewIdentifier] setCameraJSON:cameraJson];
}

RCT_EXPORT_METHOD(animateCamera
                  : (NSString *)viewIdentifier cameraJson
                  : (NSString *)cameraJson durationMilliseconds
                  : (double)durationMilliseconds) {
  [[self hostViewForIdentifier:viewIdentifier]
      animateCameraJSON:cameraJson
      durationMilliseconds:durationMilliseconds];
}

RCT_EXPORT_METHOD(fitBounds
                  : (NSString *)viewIdentifier boundingBoxJson
                  : (NSString *)boundingBoxJson edgeInsetsJson
                  : (NSString *)edgeInsetsJson maximumZoomLevel
                  : (double)maximumZoomLevel) {
  [[self hostViewForIdentifier:viewIdentifier]
      fitBoundsJSON:boundingBoxJson
      edgeInsetsJson:edgeInsetsJson
      maximumZoomLevel:maximumZoomLevel];
}

RCT_EXPORT_METHOD(panByScreenPixels
                  : (NSString *)viewIdentifier deltaXPixels
                  : (double)deltaXPixels deltaYPixels
                  : (double)deltaYPixels isGestureDriven
                  : (BOOL)isGestureDriven) {
  [[self hostViewForIdentifier:viewIdentifier]
      panByScreenPixelsWithDeltaXPixels:deltaXPixels
                           deltaYPixels:deltaYPixels
                        isGestureDriven:isGestureDriven];
}

RCT_EXPORT_METHOD(zoomByLevels
                  : (NSString *)viewIdentifier deltaZoomLevels
                  : (double)deltaZoomLevels) {
  [[self hostViewForIdentifier:viewIdentifier]
      zoomByLevelsWithDeltaZoomLevels:deltaZoomLevels];
}

RCT_EXPORT_METHOD(addOverlay
                  : (NSString *)viewIdentifier overlayIdentifier
                  : (NSString *)overlayIdentifier overlayJson
                  : (NSString *)overlayJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView addOverlayJSON:overlayIdentifier
                          overlayJson:overlayJson]));
}

RCT_EXPORT_METHOD(updateOverlay
                  : (NSString *)viewIdentifier overlayIdentifier
                  : (NSString *)overlayIdentifier overlayJson
                  : (NSString *)overlayJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView updateOverlayJSON:overlayIdentifier
                             overlayJson:overlayJson]));
}

RCT_EXPORT_METHOD(removeOverlay
                  : (NSString *)viewIdentifier overlayIdentifier
                  : (NSString *)overlayIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView removeOverlayWithOverlayIdentifier:overlayIdentifier]));
}

RCT_EXPORT_METHOD(setOverlays
                  : (NSString *)viewIdentifier overlaysJson
                  : (NSString *)overlaysJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView setOverlaysJSON:overlaysJson]));
}

RCT_EXPORT_METHOD(clearOverlays
                  : (NSString *)viewIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView clearOverlays]));
}

RCT_EXPORT_METHOD(setLocationIndicator
                  : (NSString *)viewIdentifier stateJson
                  : (NSString *)stateJson styleJson
                  : (NSString *)styleJson) {
  [[self hostViewForIdentifier:viewIdentifier]
      setLocationIndicatorJSON:stateJson
                     styleJson:styleJson];
}

RCT_EXPORT_METHOD(clearLocationIndicator
                  : (NSString *)viewIdentifier) {
  [[self hostViewForIdentifier:viewIdentifier] clearLocationIndicator];
}

RCT_EXPORT_METHOD(retryAttach
                  : (NSString *)viewIdentifier) {
  [[self hostViewForIdentifier:viewIdentifier] retryAttach];
}

RCT_EXPORT_METHOD(setVectorTileSource
                  : (NSString *)viewIdentifier sourceJson
                  : (NSString *)sourceJson resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView setVectorTileSourceJSON:sourceJson]));
}

RCT_EXPORT_METHOD(clearVectorTileSource
                  : (NSString *)viewIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve(@([hostView clearVectorTileSource]));
}

RCT_EXPORT_METHOD(getVectorTileSourceStatus
                  : (NSString *)viewIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve([hostView vectorTileSourceStatusJSON]);
}

RCT_EXPORT_METHOD(reloadRasterTileSource
                  : (NSString *)viewIdentifier) {
  [[self hostViewForIdentifier:viewIdentifier] reloadRasterTileSource];
}

RCT_EXPORT_METHOD(setRenderingPaused
                  : (NSString *)viewIdentifier paused
                  : (BOOL)paused) {
  [[self hostViewForIdentifier:viewIdentifier] setRenderingPaused:paused];
}

RCT_EXPORT_METHOD(getCamera
                  : (NSString *)viewIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve([hostView getCameraJSON]);
}

RCT_EXPORT_METHOD(groundMetersPerScreenPixel
                  : (NSString *)viewIdentifier resolve
                  : (RCTPromiseResolveBlock)resolve reject
                  : (RCTPromiseRejectBlock)reject) {
  MapsSdkMapHostView *hostView =
      [self hostViewForIdentifier:viewIdentifier];
  if (hostView == nil) {
    reject(MapsSdkNativeFailureCode, MapsSdkNativeViewNotFoundText, nil);
    return;
  }
  resolve([hostView groundMetersPerScreenPixel]);
}

@end
