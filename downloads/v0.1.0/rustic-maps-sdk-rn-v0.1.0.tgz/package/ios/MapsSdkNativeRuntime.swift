import Foundation

/// The package's one native `MapSdk` on iOS.
///
/// The generated JSI bindings construct their own native SDK, and a foreign
/// handle cannot be imported into a native view; a second `MapSdk` in the same
/// process would open a second provider registry and a second SQLite tile
/// cache. The package therefore creates the SDK here once, every `<MapView>`
/// draws from it, and the package module proxies the contract calls through it
/// (`docs/PublicApiV2.md` §11).
@objc(MapsSdkNativeRuntime)
public final class MapsSdkNativeRuntime: NSObject {

    /// The plugin's one runtime instance.
    @objc public static let shared = MapsSdkNativeRuntime()

    /// The provider key the registration dispatch serves today.
    @objc public static let mapquestProviderKey = "mapquest"

    /// The tile cache's file inside the host app's caches directory.
    private static let tileCacheDatabaseFileName = "rustic-maps-tile-cache.sqlite"

    /// The tile cache's named byte budget (the demo's 16 MiB budget).
    private static let tileCacheAbsoluteMaximumBytes: UInt64 = 16_777_216

    /// The empty-credential refusal (the credential is never logged).
    private static let emptyCredentialText = "the provider credential is empty"

    /// The unsupported-provider refusal template.
    private static let unsupportedProviderTemplate = "provider '%@' is not supported"

    /// The not-started refusal.
    private static let sdkNotStartedText = "the SDK has not started"

    /// The missing-cache-directory refusal.
    private static let cacheDirectoryUnavailableText =
        "the app cache directory is unavailable"

    /// The refusal for a provider without a credential-based base map.
    private static let noCredentialedBaseMapTemplate =
        "provider '%@' has no credential-based base map on this platform"

    /// The refusal when no credential is remembered for the restore.
    private static let noAppliedCredentialText =
        "no provider credential is applied; set one in Settings before selecting its base map"

    /// The native SDK, or nil before the first successful start.
    public private(set) var mapSdk: MapSdk?

    private var cacheDirectoryURL: URL?
    /// Whether a runtime credential registered (the diagnostics line reads it).
    @objc public private(set) var isProviderCredentialApplied = false

    /// The applied credential, retained in native memory only so a base-map
    /// switch can re-register its raster slot (it never crosses to
    /// JavaScript). Mirror of the Compose facade's `appliedMapQuestCredential`.
    private var appliedProviderCredential: String?

    /// The installed cache's state line (read by the diagnostics sheet).
    @objc public private(set) var tileCacheStateText = "Cache not registered"

    private override init() {
        super.init()
    }

    /// Builds the SDK keyless on first call; later calls are a no-op.
    @objc public func ensureStarted() throws {
        guard mapSdk == nil else {
            applyLaunchInjectedCredentialFromEnvironment()
            return
        }
        let constructedSdk = MapSdk()
        mapSdk = constructedSdk
        MapsSdkMapHostView.attachSdkToLiveHostViews(constructedSdk)
        cacheDirectoryURL = FileManager.default.urls(
            for: .cachesDirectory,
            in: .userDomainMask
        ).first
        applyLaunchInjectedCredentialFromEnvironment()
    }

    /// The automation credential seam: launch-environment variables supply a
    /// runtime credential and an optional provider key for local/CI UI
    /// automation. The injection goes through the public registration path,
    /// is never persisted by the injection and never logged.
    private func applyLaunchInjectedCredentialFromEnvironment() {
        let environment = ProcessInfo.processInfo.environment
        guard let runtimeCredential = environment["PROVIDER_API_KEY"],
              !runtimeCredential.isEmpty
        else {
            return
        }
        let runtimeProviderKey = environment["PROVIDER_KEY"].flatMap { providerKey in
            providerKey.isEmpty ? nil : providerKey
        } ?? Self.mapquestProviderKey
        _ = setProviderCredential(
            providerKey: runtimeProviderKey,
            credential: runtimeCredential,
            withTileCache: true
        )
    }

    /// Registers one runtime provider credential, optionally with the disk
    /// tile cache. The provider dispatch is one arm per provider.
    @objc public func setProviderCredential(
        providerKey: String,
        credential: String,
        withTileCache: Bool
    ) -> [String: Any] {
        guard let sdk = mapSdk else {
            return credentialResult(isApplied: false, detailText: Self.sdkNotStartedText)
        }
        guard !credential.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return credentialResult(isApplied: false, detailText: Self.emptyCredentialText)
        }
        guard providerKey == Self.mapquestProviderKey else {
            return credentialResult(
                isApplied: false,
                detailText: String(format: Self.unsupportedProviderTemplate, providerKey)
            )
        }
        if !withTileCache {
            do {
                try sdk.setProviderCredential(credential: credential)
                appliedProviderCredential = credential
                isProviderCredentialApplied = true
                tileCacheStateText = "Cache not registered"
                return credentialResult(isApplied: true, detailText: "")
            } catch {
                return credentialResult(
                    isApplied: false,
                    detailText: Self.failureText(error)
                )
            }
        }
        guard let cacheDirectoryURL else {
            return credentialResult(
                isApplied: false,
                detailText: Self.cacheDirectoryUnavailableText
            )
        }
        let cacheDatabasePath = cacheDirectoryURL
            .appendingPathComponent(Self.tileCacheDatabaseFileName)
            .path
        do {
            try sdk.setProviderCredentialWithTileCache(
                mapquestApiKey: credential,
                tileCacheDatabasePath: cacheDatabasePath,
                tileCacheAbsoluteMaximumBytes: Self.tileCacheAbsoluteMaximumBytes
            )
            appliedProviderCredential = credential
            isProviderCredentialApplied = true
            tileCacheStateText = "Cache registered: \(cacheDatabasePath)"
            return credentialResult(isApplied: true, detailText: "")
        } catch {
            return credentialResult(
                isApplied: false,
                detailText: Self.failureText(error)
            )
        }
    }

    /// The compiled SDK version.
    @objc public func compiledVersion() -> String {
        getSdkCompiledVersion()
    }

    /// Registers one provider-neutral base map (M9's native base-map switch).
    /// The SDK validates the whole declaration before the raster-tile slot
    /// moves, so a refusal throws verbatim and the previously serving source
    /// stays installed.
    @objc public func registerUrlTemplateRasterTileSourceJSON(
        _ sourceJSON: String
    ) throws {
        guard let sdk = mapSdk else {
            throw MapsSdkNativeRuntimeError.sdkNotStarted
        }
        guard
            let sourceDictionary = MapsSdkNativeJson.dictionary(from: sourceJSON),
            let source = MapsSdkNativeJson.urlTemplateRasterTileSource(
                from: sourceDictionary
            )
        else {
            throw MapsSdkNativeRuntimeError.invalidTileSourceDeclaration
        }
        try sdk.registerUrlTemplateRasterTileSource(source: source)
    }

    /// Re-registers the applied credential so its raster-tile slot serves the
    /// base map again — the switch back from a credential-less source. The
    /// re-registration repeats the credential the running session already
    /// holds (native memory only) and installs the tile cache with it, exactly
    /// as the original registration did; a credential-less switch had dropped
    /// both. Refuses honestly when no credential has been applied.
    @objc public func restoreCredentialedBaseMap(
        providerKey: String
    ) -> [String: Any] {
        guard providerKey == Self.mapquestProviderKey else {
            return credentialResult(
                isApplied: false,
                detailText: String(
                    format: Self.noCredentialedBaseMapTemplate,
                    providerKey
                )
            )
        }
        guard let credential = appliedProviderCredential else {
            return credentialResult(
                isApplied: false,
                detailText: Self.noAppliedCredentialText
            )
        }
        return setProviderCredential(
            providerKey: providerKey,
            credential: credential,
            withTileCache: true
        )
    }

    /// The provider key a launch-injected credential targets by default.
    @objc public func defaultProviderKey() -> String {
        Self.mapquestProviderKey
    }

    /// Read-only diagnostics lines for the package's diagnostics surface.
    @objc public func diagnosticsLines() -> [String] {
        var lines: [String] = []
        lines.append("SDK version: \(compiledVersion())")
        lines.append(
            isProviderCredentialApplied
                ? "Provider credential: applied"
                : "Provider credential: not configured (keyless)"
        )
        lines.append(tileCacheStateText)
        if let sdk = mapSdk, let terms = try? sdk.rasterTileCacheTerms() {
            lines.append(
                "Tile cache terms: effective \(terms.effectiveTimeToLiveSeconds)s, default \(terms.defaultTimeToLiveSeconds)s"
            )
        }
        return lines
    }

    /// The installed raster-tile cache's effective terms as JSON.
    @objc public func tileCacheTermsJSON() throws -> String {
        guard let sdk = mapSdk else { throw MapsSdkNativeRuntimeError.sdkNotStarted }
        return MapsSdkNativeJson.tileCacheTermsJSON(try sdk.rasterTileCacheTerms())
    }

    /// Overrides the installed tile cache's time-to-live, in seconds.
    @objc public func setTileCacheTimeToLive(_ timeToLiveSeconds: Double) throws {
        guard let sdk = mapSdk else { throw MapsSdkNativeRuntimeError.sdkNotStarted }
        try sdk.setRasterTileCacheTimeToLive(
            timeToLiveSeconds: UInt64(timeToLiveSeconds)
        )
    }

    /// The retained provider-failure diagnostics as JSON.
    @objc public func latestProviderFailureDiagnosticsJSON() throws -> String {
        guard let sdk = mapSdk else { throw MapsSdkNativeRuntimeError.sdkNotStarted }
        return MapsSdkNativeJson.providerFailureDiagnosticsJSON(
            sdk.latestProviderFailureDiagnostics()
        )
    }

    /// Full provider search results for a settled query, as JSON.
    @objc public func searchJSON(
        queryText: String,
        boundaryJSON: String?,
        completion: @escaping (String?, Error?) -> Void
    ) {
        runPlaceSearch(
            boundaryJSON: boundaryJSON,
            completion: completion
        ) { sdk, boundary in
            try await sdk.search(queryText: queryText, searchBoundary: boundary)
        }
    }

    /// Fast completion candidates while the user types, as JSON.
    @objc public func suggestJSON(
        queryText: String,
        boundaryJSON: String?,
        completion: @escaping (String?, Error?) -> Void
    ) {
        runPlaceSearch(
            boundaryJSON: boundaryJSON,
            completion: completion
        ) { sdk, boundary in
            try await sdk.suggest(queryText: queryText, searchBoundary: boundary)
        }
    }

    /// Resolves a free-form address text into candidate places, as JSON.
    @objc public func forwardGeocodeJSON(
        addressText: String,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard let sdk = mapSdk else {
            completion(nil, MapsSdkNativeRuntimeError.sdkNotStarted)
            return
        }
        Task { @MainActor in
            do {
                let places = try await sdk.forwardGeocode(addressText: addressText)
                completion(MapsSdkNativeJson.placesJSON(places), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    /// Calculates a route through the ordered waypoints, as JSON.
    @objc public func calculateRouteJSON(
        waypointsJson: String,
        routeOptionsJson: String,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard let sdk = mapSdk else {
            completion(nil, MapsSdkNativeRuntimeError.sdkNotStarted)
            return
        }
        guard
            let waypointDictionaries = MapsSdkNativeJson.dictionaryArray(
                from: waypointsJson
            ),
            let routeOptionsDictionary = MapsSdkNativeJson.dictionary(
                from: routeOptionsJson
            ),
            let routeOptions = MapsSdkNativeJson.routeOptions(
                from: routeOptionsDictionary
            )
        else {
            completion(nil, MapsSdkNativeRuntimeError.invalidRouteRequest)
            return
        }
        let waypoints = MapsSdkNativeJson.coordinates(
            from: waypointDictionaries
        )
        Task { @MainActor in
            do {
                let route = try await sdk.calculateRoute(
                    waypoints: waypoints,
                    routeOptions: routeOptions
                )
                completion(MapsSdkNativeJson.routeJSON(route), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    /// Resolves a coordinate into candidate places, as JSON.
    @objc public func reverseGeocodeJSON(
        coordinateJSON: String,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard
            let sdk = mapSdk,
            let coordinateDictionary = MapsSdkNativeJson.dictionary(from: coordinateJSON),
            let latitude = coordinateDictionary["latitude"] as? NSNumber,
            let longitude = coordinateDictionary["longitude"] as? NSNumber
        else {
            completion(nil, MapsSdkNativeRuntimeError.sdkNotStarted)
            return
        }
        let coordinate = GeographicCoordinate(
            latitude: latitude.doubleValue,
            longitude: longitude.doubleValue
        )
        Task { @MainActor in
            do {
                let places = try await sdk.reverseGeocode(coordinate: coordinate)
                completion(MapsSdkNativeJson.placesJSON(places), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    /// Calculates the contract's distance matrix, as JSON (M31).
    @objc public func calculateDistanceMatrixJSON(
        originsJson: String,
        destinationsJson: String,
        transportationModeOrdinal: Int,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard
            let sdk = mapSdk,
            let originDictionaries = MapsSdkNativeJson.dictionaryArray(from: originsJson),
            let destinationDictionaries = MapsSdkNativeJson.dictionaryArray(
                from: destinationsJson
            ),
            let transportationMode = MapsSdkNativeJson.transportationMode(
                fromOrdinal: transportationModeOrdinal
            )
        else {
            completion(nil, MapsSdkNativeRuntimeError.invalidRouteRequest)
            return
        }
        let origins = MapsSdkNativeJson.coordinates(from: originDictionaries)
        let destinations = MapsSdkNativeJson.coordinates(from: destinationDictionaries)
        Task { @MainActor in
            do {
                let distanceMatrix = try await sdk.calculateDistanceMatrix(
                    origins: origins,
                    destinations: destinations,
                    transportationMode: transportationMode
                )
                completion(MapsSdkNativeJson.distanceMatrixJSON(distanceMatrix), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    /// Fetches traffic incidents intersecting a bounding box, as JSON (M31).
    @objc public func fetchTrafficIncidentsJSON(
        boundingBoxJson: String,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard
            let sdk = mapSdk,
            let boundingBoxDictionary = MapsSdkNativeJson.dictionary(from: boundingBoxJson),
            let boundingBox = MapsSdkNativeJson.boundingBox(from: boundingBoxDictionary)
        else {
            completion(nil, MapsSdkNativeRuntimeError.invalidBoundingBoxRequest)
            return
        }
        Task { @MainActor in
            do {
                let incidents = try await sdk.fetchTrafficIncidents(boundingBox: boundingBox)
                completion(MapsSdkNativeJson.trafficIncidentsJSON(incidents), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    /// Fetches per-segment traffic flow inside a bounding box, as JSON (M31).
    @objc public func fetchTrafficFlowJSON(
        boundingBoxJson: String,
        completion: @escaping (String?, Error?) -> Void
    ) {
        guard
            let sdk = mapSdk,
            let boundingBoxDictionary = MapsSdkNativeJson.dictionary(from: boundingBoxJson),
            let boundingBox = MapsSdkNativeJson.boundingBox(from: boundingBoxDictionary)
        else {
            completion(nil, MapsSdkNativeRuntimeError.invalidBoundingBoxRequest)
            return
        }
        Task { @MainActor in
            do {
                let flowObservations = try await sdk.fetchTrafficFlow(boundingBox: boundingBox)
                completion(MapsSdkNativeJson.trafficFlowJSON(flowObservations), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    private func runPlaceSearch(
        boundaryJSON: String?,
        completion: @escaping (String?, Error?) -> Void,
        search: @escaping (MapSdk, BoundingBox?) async throws -> [Place]
    ) {
        guard let sdk = mapSdk else {
            completion(nil, MapsSdkNativeRuntimeError.sdkNotStarted)
            return
        }
        let boundary = currentSearchBoundary(from: boundaryJSON)
        Task { @MainActor in
            do {
                let places = try await search(sdk, boundary)
                completion(MapsSdkNativeJson.placesJSON(places), nil)
            } catch {
                completion(nil, error)
            }
        }
    }

    private func currentSearchBoundary(from boundaryJSON: String?) -> BoundingBox? {
        guard
            let boundaryJSON,
            let dictionary = MapsSdkNativeJson.dictionary(from: boundaryJSON)
        else {
            return nil
        }
        return MapsSdkNativeJson.boundingBox(from: dictionary)
    }

    private func credentialResult(
        isApplied: Bool,
        detailText: String
    ) -> [String: Any] {
        ["isApplied": isApplied, "detailText": detailText]
    }

    private static func failureText(_ error: Error) -> String {
        (error as NSError).localizedDescription
    }
}

/// A package-runtime failure that is not a typed SDK error.
public enum MapsSdkNativeRuntimeError: LocalizedError {
    case sdkNotStarted
    case invalidTileSourceDeclaration
    case invalidRouteRequest
    case invalidBoundingBoxRequest

    public var errorDescription: String? {
        switch self {
        case .sdkNotStarted:
            return "the SDK has not started"
        case .invalidTileSourceDeclaration:
            return "the base-map tile source declaration is malformed"
        case .invalidRouteRequest:
            return "the route request is malformed"
        case .invalidBoundingBoxRequest:
            return "the bounding box request is malformed"
        }
    }
}
