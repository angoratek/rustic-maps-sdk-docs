package com.mapssdkrn

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

/**
 * The React Native package registration for the typed `<MapView>` component
 * and its `MapsSdkNative` module.
 *
 * The class deliberately does not end in `Package`: the React Native
 * autolinker discovers the generated ubrn `MapsSdkRnPackage` by that filename
 * pattern, and the generated library keeps exactly that one autolinked entry.
 * Hosts register this companion package beside it:
 *
 * ```kotlin
 * PackageList(this).packages.apply {
 *   add(com.mapssdkrn.MapsSdkRnPackage())
 *   add(com.mapssdkrn.MapsSdkMapHost())
 * }
 * ```
 */
class MapsSdkMapHost : ReactPackage {

    override fun createNativeModules(
        reactContext: ReactApplicationContext,
    ): List<NativeModule> = listOf(MapsSdkNativeModule(reactContext))

    override fun createViewManagers(
        reactContext: ReactApplicationContext,
    ): List<ViewManager<*, *>> = listOf(MapsSdkMapViewManager())
}
