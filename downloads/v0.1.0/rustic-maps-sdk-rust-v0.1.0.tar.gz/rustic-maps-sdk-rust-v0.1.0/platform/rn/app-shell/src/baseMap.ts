/**
 * The pure decisions of the reference application's base-map switch (M9's
 * native base-map switch): which registry descriptors the settings sheet
 * offers, whether each can serve yet, which one is serving, and what one
 * row's act registers. The screen owns the effectful half (the SDK call and
 * the map view's reload); this module stays free of React and native imports
 * so jest can pin every decision without a native side.
 *
 * The rows come from the shared provider registry, so a second base map is a
 * descriptor entry and nothing here changes.
 */

import type {
  UrlTemplateRasterImageFormat,
  UrlTemplateRasterTileSource,
  UrlTemplateTileResolution,
  UrlTemplateVectorTileSource,
} from 'maps-sdk-rn/MapsSdk';

import type {
  KeylessBaseMapDeclaration,
  ProviderCredentialDescriptor,
  VectorStyleDescriptor,
} from './providerRegistry';

/** The lowest zoom level every registry raster base map declares (zoom 0). */
export const baseMapMinimumZoomLevel = 0;

/**
 * The highest zoom level assumed when a descriptor omits one (the artifact's
 * own default): the source then serves zoom 0 only rather than an invented
 * ceiling.
 */
const baseMapDefaultMaximumZoomLevel = 0;

/** The contract's PNG image-format ordinal (generated `RasterImageFormat.Png`). */
const rasterImageFormatPng: UrlTemplateRasterImageFormat = 0;

/** The contract's standard-resolution ordinal (`RasterTileResolution.Standard`). */
const rasterTileResolutionStandard: UrlTemplateTileResolution = 0;

/**
 * One offered base map: the registry descriptor and whether it can serve
 * now. A credential provider is offered before its key is applied and stays
 * not servable (the row names what it needs) until then.
 */
export interface BaseMapChoice {
  descriptor: ProviderCredentialDescriptor;
  /** Whether the SDK can serve this source in the current session. */
  isServable: boolean;
}

/** What one base-map row's act registers. */
export type BaseMapRegistrationPlan =
  | { kind: 'urlTemplate'; source: UrlTemplateRasterTileSource }
  | { kind: 'credentialedRestore'; providerKey: string };

/** Whether the SDK registers this provider on React Native today. */
function isRegistrationAvailable(
  descriptor: ProviderCredentialDescriptor,
): boolean {
  return descriptor.registration_available?.react_native === true;
}

/**
 * Whether the descriptor serves its own base map without a credential: a
 * registry descriptor that publishes a `{z}/{x}/{y}` raster URL template and
 * has a React Native registration arm. The provider-neutral URL-template
 * registration serves it, so no credential is involved.
 */
function offersCredentiallessBaseMap(
  descriptor: ProviderCredentialDescriptor,
): boolean {
  return (
    isRegistrationAvailable(descriptor) &&
    typeof descriptor.raster_url_template === 'string' &&
    descriptor.raster_url_template.trim() !== ''
  );
}

/** Whether the descriptor is a credential provider with a registration arm. */
function isCredentialProvider(
  descriptor: ProviderCredentialDescriptor,
): boolean {
  return (
    isRegistrationAvailable(descriptor) &&
    typeof descriptor.credential_label === 'string' &&
    descriptor.credential_label.trim() !== ''
  );
}

/**
 * The base maps the settings surface offers, in registry order: every
 * descriptor that publishes a credential-less raster source (always
 * servable), and every credential provider (offered before its key is
 * applied, servable only once that key is in `appliedProviderKeys`). A
 * descriptor with no React Native registration arm is omitted.
 */
export function baseMapChoices(
  descriptors: readonly ProviderCredentialDescriptor[],
  appliedProviderKeys: ReadonlySet<string>,
): BaseMapChoice[] {
  const choices: BaseMapChoice[] = [];
  for (const descriptor of descriptors) {
    if (offersCredentiallessBaseMap(descriptor)) {
      choices.push({ descriptor, isServable: true });
    } else if (isCredentialProvider(descriptor)) {
      choices.push({
        descriptor,
        isServable: appliedProviderKeys.has(descriptor.provider_key),
      });
    }
  }
  return choices;
}

/**
 * The base map actually serving the map: the user's selection while it can
 * still serve, otherwise the first servable choice. Null when nothing can
 * serve — a keyless session whose registry declares no credential-less
 * source — and the band then claims no provider at all.
 */
export function activeBaseMap(
  choices: readonly BaseMapChoice[],
  selectedProviderKey: string | null,
): ProviderCredentialDescriptor | null {
  const servableChoices = choices.filter(choice => choice.isServable);
  if (selectedProviderKey !== null) {
    const selected = servableChoices.find(
      choice => choice.descriptor.provider_key === selectedProviderKey,
    );
    if (selected !== undefined) {
      return selected.descriptor;
    }
  }
  return servableChoices.length > 0 ? servableChoices[0].descriptor : null;
}

/**
 * The registration one base-map row performs: the URL-template record the
 * SDK's provider-neutral registration takes (a raster source with no vendor
 * code), or — for a credentialed descriptor — the marker that its credential
 * must be re-applied instead. The `User-Agent` is the reference application's
 * own, formatted from the shared artifact and passed in by the call site.
 */
export function baseMapRegistrationPlan(
  descriptor: ProviderCredentialDescriptor,
  userAgentText: string,
): BaseMapRegistrationPlan {
  const urlTemplate = descriptor.raster_url_template;
  if (typeof urlTemplate === 'string' && urlTemplate.trim() !== '') {
    return {
      kind: 'urlTemplate',
      source: {
        urlTemplate,
        sourceName: descriptor.provider_key,
        minimumZoomLevel: baseMapMinimumZoomLevel,
        maximumZoomLevel:
          descriptor.maximum_zoom_level ?? baseMapDefaultMaximumZoomLevel,
        imageFormat: rasterImageFormatPng,
        tileResolution: rasterTileResolutionStandard,
        userAgent: userAgentText,
      },
    };
  }
  return { kind: 'credentialedRestore', providerKey: descriptor.provider_key };
}

/**
 * One offered styled vector base (M22): a registry descriptor's vector
 * tileset painted with one of the committed styles the same descriptor lists.
 */
export interface VectorBaseMapChoice {
  descriptor: ProviderCredentialDescriptor;
  style: VectorStyleDescriptor;
}

/**
 * The styled vector bases the settings sheet offers, in registry order and
 * style order: every descriptor publishing a vector tileset URL template plus
 * a `vector_styles` list contributes one row per style. The SDK serves these
 * through the shipped map view's additive vector base member on both native
 * platforms, so no registration arm gates them.
 */
export function vectorBaseMapChoices(
  descriptors: readonly ProviderCredentialDescriptor[],
): VectorBaseMapChoice[] {
  const choices: VectorBaseMapChoice[] = [];
  for (const descriptor of descriptors) {
    const vectorUrlTemplate = descriptor.url_template;
    if (typeof vectorUrlTemplate !== 'string' || vectorUrlTemplate.trim() === '') {
      continue;
    }
    for (const style of descriptor.vector_styles ?? []) {
      choices.push({ descriptor, style });
    }
  }
  return choices;
}

/** One choice's stable identity (`provider/style`), the value its row carries. */
export function vectorBaseChoiceKey(choice: VectorBaseMapChoice): string {
  return `${choice.descriptor.provider_key}/${choice.style.style_id}`;
}

/**
 * The registry's declared keyless styled base (owner ruling 2026-10-31, PRD §6
 * item 18), resolved among the offered vector choices. Null when the registry
 * declares none, or when the declaration names a provider/style this build
 * does not offer — the keyless start then keeps the credential-less raster
 * source rather than installing nothing.
 */
export function keylessVectorBaseChoice(
  descriptors: readonly ProviderCredentialDescriptor[],
  declared: KeylessBaseMapDeclaration | null | undefined,
): VectorBaseMapChoice | null {
  if (
    declared === null ||
    declared === undefined ||
    declared.provider_key.trim() === '' ||
    declared.style_id.trim() === ''
  ) {
    return null;
  }
  return (
    vectorBaseMapChoices(descriptors).find(
      choice =>
        choice.descriptor.provider_key === declared.provider_key &&
        choice.style.style_id === declared.style_id,
    ) ?? null
  );
}

/** The consumer-facing name the base-map row shows for one choice. */
export function vectorBaseChoiceLabel(choice: VectorBaseMapChoice): string {
  return `${choice.descriptor.display_name} · ${choice.style.display_name}`;
}

/**
 * The attribution line a styled vector base must carry: the style's own
 * design line, falling back to the provider's general line when the style
 * declares none.
 */
export function vectorBaseAttributionText(choice: VectorBaseMapChoice): string {
  const styleAttribution = choice.style.attribution_text;
  if (typeof styleAttribution === 'string' && styleAttribution.trim() !== '') {
    return styleAttribution;
  }
  return choice.descriptor.attribution_text;
}

/**
 * The record one styled-vector-base row installs on the shipped map view
 * (M22): the descriptor's vector tileset, the chosen committed style id, the
 * style's attribution line and the descriptor's zoom ceiling.
 */
export function vectorBaseSource(
  choice: VectorBaseMapChoice,
): UrlTemplateVectorTileSource {
  return {
    urlTemplate: choice.descriptor.url_template ?? '',
    sourceName: choice.descriptor.provider_key,
    attributionText: vectorBaseAttributionText(choice),
    styleId: choice.style.style_id,
    minimumZoomLevel: baseMapMinimumZoomLevel,
    maximumZoomLevel:
      choice.descriptor.maximum_zoom_level ?? baseMapDefaultMaximumZoomLevel,
  };
}
