/**
 * The reference application's remembered choices: one versioned record of the
 * explicit selections the shell restores on the next launch. Transient state
 * (the camera pose, an open sheet, the current route result) and the provider
 * credential are never part of this record; the credential keeps its own
 * opt-in store.
 *
 * The record crosses to the native side as a single JSON string through the
 * demo bridge module. A record written by an incompatible version is ignored
 * as a whole, an unknown key is ignored, and an invalid value falls back to
 * that field's default rather than failing the whole restore.
 */

import {
  defaultThemeChoice,
  themeChoiceFromStoredValue,
  type ThemeChoice,
} from './theme';

/** The record shape this build writes and reads. */
export const referenceAppPreferencesVersion = 1;

/**
 * The playback speed multipliers the drawer offers and the record may carry.
 * The native hosts validate the same set before rebuilding a walker.
 */
export const simulatedTripSpeedMultiplierChoices: readonly number[] = [1, 2, 4, 8];

/**
 * One remembered base map: a registry provider key plus the committed vector
 * style id, or a null style id for the provider's raster source.
 */
export interface RememberedBaseMap {
  providerKey: string;
  styleId: string | null;
}

/** The last texts the plan flow held: both fields and the last search query. */
export interface RememberedSearchTexts {
  origin: string;
  destination: string;
  lastQuery: string;
}

/**
 * The explicit choices the shell remembers across launches. Every field has a
 * default so a partial or older record restores what it can.
 */
export interface ReferenceAppPreferences {
  version: typeof referenceAppPreferencesVersion;
  themeChoice: ThemeChoice;
  baseMap: RememberedBaseMap | null;
  /** The selected demo plan's bundled trace name, or null for the default plan. */
  demoPlanAssetName: string | null;
  /** The selected overlay scene keys, in artifact order. */
  selectedSceneKeys: string[];
  cameraPresetId: string | null;
  speedMultiplier: number;
  search: RememberedSearchTexts;
}

/** The record of a device that never chose or of a reset. */
export function defaultReferenceAppPreferences(): ReferenceAppPreferences {
  return {
    version: referenceAppPreferencesVersion,
    themeChoice: defaultThemeChoice,
    baseMap: null,
    demoPlanAssetName: null,
    selectedSceneKeys: [],
    cameraPresetId: null,
    speedMultiplier: simulatedTripSpeedMultiplierChoices[0],
    search: { origin: '', destination: '', lastQuery: '' },
  };
}

/** Whether a parsed JSON value is an object with named fields. */
function isJsonObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** A trimmed non-empty string, or null for anything else. */
function nonEmptyString(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }
  const trimmedText = value.trim();
  return trimmedText === '' ? null : trimmedText;
}

/** A remembered text field, preserving the entered text exactly. */
function textFromValue(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

/**
 * The remembered base map a stored value names, or null when it names none.
 * The provider key is required; a missing style id means the raster source.
 */
function rememberedBaseMapFromValue(value: unknown): RememberedBaseMap | null {
  if (!isJsonObject(value)) {
    return null;
  }
  const providerKey = nonEmptyString(value.providerKey);
  if (providerKey === null) {
    return null;
  }
  return { providerKey, styleId: nonEmptyString(value.styleId) };
}

/** The selected scene keys of a stored value: strings only, de-duplicated. */
function sceneKeysFromValue(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }
  const sceneKeys: string[] = [];
  for (const candidate of value) {
    const sceneKey = nonEmptyString(candidate);
    if (sceneKey !== null && !sceneKeys.includes(sceneKey)) {
      sceneKeys.push(sceneKey);
    }
  }
  return sceneKeys;
}

/** One of the offered speed multipliers, or the default pace. */
function speedMultiplierFromValue(value: unknown): number {
  return (
    simulatedTripSpeedMultiplierChoices.find(choice => choice === value) ??
    simulatedTripSpeedMultiplierChoices[0]
  );
}

/**
 * The record a stored JSON string names, or null when nothing was stored, the
 * string is not JSON, or it was written by an incompatible version. Unknown
 * keys are ignored and each invalid field falls back to its default.
 */
export function referenceAppPreferencesFromStoredValue(
  storedValue: string | null | undefined,
): ReferenceAppPreferences | null {
  if (typeof storedValue !== 'string' || storedValue.trim() === '') {
    return null;
  }
  let parsedValue: unknown;
  try {
    parsedValue = JSON.parse(storedValue);
  } catch {
    return null;
  }
  if (
    !isJsonObject(parsedValue) ||
    parsedValue.version !== referenceAppPreferencesVersion
  ) {
    return null;
  }
  const defaults = defaultReferenceAppPreferences();
  const storedSearch = isJsonObject(parsedValue.search) ? parsedValue.search : {};
  return {
    version: referenceAppPreferencesVersion,
    themeChoice: themeChoiceFromStoredValue(
      typeof parsedValue.themeChoice === 'string'
        ? parsedValue.themeChoice
        : null,
    ),
    baseMap: rememberedBaseMapFromValue(parsedValue.baseMap),
    demoPlanAssetName: nonEmptyString(parsedValue.demoPlanAssetName),
    selectedSceneKeys: sceneKeysFromValue(parsedValue.selectedSceneKeys),
    cameraPresetId: nonEmptyString(parsedValue.cameraPresetId),
    speedMultiplier: speedMultiplierFromValue(parsedValue.speedMultiplier),
    search: {
      origin: textFromValue(storedSearch.origin),
      destination: textFromValue(storedSearch.destination),
      lastQuery: textFromValue(storedSearch.lastQuery),
    },
  };
}
