/**
 * The per-capability provider section's decisions
 * (docs/design/ProviderSelectionPerCapability.md): the rows follow the SDK's stable
 * order, a capability with no installed provider reads "Not configured", the
 * picker is limited to registry descriptors that serve the capability and
 * register on React Native, a selection passes the applied credential for a
 * credentialed provider and an empty string for a keyless one, and a refusal
 * shows the SDK's message verbatim without moving the serving provider.
 */

import { ProviderContract } from 'maps-sdk-rn/src/generated/rustic_maps.ts';
import type { ProviderRegistration } from 'maps-sdk-rn/MapsSdk';

import {
  applyCapabilityProviderSelection,
  buildCapabilityProviderRows,
  capabilityDisplayName,
  capabilityRegistryName,
  capabilityServingStatusText,
  isReadOnlyCapability,
  type CapabilityProviderGateway,
} from '../src/capabilityProviderState';
import type { ProviderCredentialDescriptor } from '../src/providerRegistry';
import { appStrings } from '../src/theme';

/** One registry descriptor with the fields the section reads. */
function descriptor(overrides: Partial<ProviderCredentialDescriptor>): ProviderCredentialDescriptor {
  return {
    provider_key: 'test-provider',
    display_name: 'Test Provider',
    credential_label: '',
    served_contracts: [],
    registration_available: {
      android: true,
      ios: true,
      react_native: true,
      wasm: true,
    },
    attribution_text: '',
    settings_hint: '',
    ...overrides,
  };
}

const fullServiceProvider = descriptor({
  provider_key: 'full-service',
  display_name: 'Full Service',
  credential_label: 'API key',
  served_contracts: ['geocoding', 'routing', 'raster_tiles'],
});
const keylessRouter = descriptor({
  provider_key: 'test-router',
  display_name: 'Test Router',
  served_contracts: ['routing'],
});
const nativeUnavailableRouter = descriptor({
  provider_key: 'other-router',
  display_name: 'Other Router',
  served_contracts: ['routing'],
  registration_available: {
    android: true,
    ios: true,
    react_native: false,
    wasm: true,
  },
});
const keylessRasterSource = descriptor({
  provider_key: 'test-raster',
  display_name: 'Test Raster',
  served_contracts: ['raster_tiles'],
});

/** One registration entry with every field the row reads. */
function registration(overrides: Partial<ProviderRegistration>): ProviderRegistration {
  return {
    contract: ProviderContract.Geocoding,
    providerKey: '',
    displayName: '',
    registered: false,
    ...overrides,
  };
}

test('rows follow the SDK readback order and say Not configured honestly', () => {
  const rows = buildCapabilityProviderRows(
    [
      registration({ contract: ProviderContract.Routing }),
      registration({
        contract: ProviderContract.Geocoding,
        providerKey: 'full-service',
        displayName: 'Full Service',
        registered: true,
      }),
    ],
    [fullServiceProvider, keylessRouter],
    () => null,
  );

  expect(rows.map(row => row.contract)).toEqual([
    ProviderContract.Routing,
    ProviderContract.Geocoding,
  ]);
  expect(rows[0].servingProviderKey).toBeNull();
  expect(capabilityServingStatusText(rows[0])).toBe(
    appStrings.capabilityProviderNotConfiguredText,
  );
  expect(capabilityServingStatusText(rows[1])).toBe('Full Service');
});

test('the picker offers only descriptors that serve the capability and register on React Native', () => {
  const rows = buildCapabilityProviderRows(
    [registration({ contract: ProviderContract.Routing })],
    [fullServiceProvider, keylessRouter, nativeUnavailableRouter],
    () => null,
  );

  expect(rows[0].choices.map(choice => choice.providerKey)).toEqual([
    'full-service',
    'test-router',
  ]);
});

test('the tile capabilities are read-only and name the layer control', () => {
  expect(isReadOnlyCapability(ProviderContract.RasterTiles)).toBe(true);
  expect(isReadOnlyCapability(ProviderContract.VectorTiles)).toBe(true);
  expect(isReadOnlyCapability(ProviderContract.Routing)).toBe(false);

  const rows = buildCapabilityProviderRows(
    [
      registration({
        contract: ProviderContract.RasterTiles,
        providerKey: 'test-raster',
        displayName: 'Test Raster',
        registered: true,
      }),
    ],
    [keylessRasterSource],
    () => null,
  );
  expect(rows[0].isReadOnly).toBe(true);
  expect(rows[0].choices).toEqual([]);
  expect(rows[0].readOnlyNoteText).toBe(
    appStrings.capabilityProviderReadOnlyNoteText,
  );
});

test('capability names derive from the contract enum, not a hardcoded table', () => {
  expect(capabilityRegistryName(ProviderContract.Geocoding)).toBe('geocoding');
  expect(capabilityRegistryName(ProviderContract.DistanceMatrix)).toBe(
    'distance_matrix',
  );
  expect(capabilityRegistryName(ProviderContract.OfflineRouting)).toBe(
    'offline_routing',
  );
  expect(capabilityDisplayName(ProviderContract.DistanceMatrix)).toBe(
    'Distance matrix',
  );
  expect(capabilityDisplayName(ProviderContract.TrafficFlow)).toBe(
    'Traffic flow',
  );
});

test('a selection passes the applied credential for a credentialed provider', async () => {
  const configureProvider = jest.fn(async () => undefined);
  const gateway: CapabilityProviderGateway = { configureProvider };
  const rows = buildCapabilityProviderRows(
    [registration({ contract: ProviderContract.Routing })],
    [fullServiceProvider, keylessRouter],
    providerKey => (providerKey === 'full-service' ? 'stored-key' : null),
  );

  const outcome = await applyCapabilityProviderSelection({
    gateway,
    row: rows[0],
    providerKey: 'full-service',
    appliedCredential: providerKey =>
      providerKey === 'full-service' ? 'stored-key' : null,
  });

  expect(outcome).toEqual({
    isApplied: true,
    detailText: '',
    providerKey: 'full-service',
  });
  expect(configureProvider).toHaveBeenCalledWith(
    ProviderContract.Routing,
    'full-service',
    'stored-key',
  );
});

test('a keyless provider receives an empty credential', async () => {
  const configureProvider = jest.fn(async () => undefined);
  const rows = buildCapabilityProviderRows(
    [registration({ contract: ProviderContract.Routing })],
    [keylessRouter],
    () => null,
  );

  await applyCapabilityProviderSelection({
    gateway: { configureProvider },
    row: rows[0],
    providerKey: 'test-router',
    appliedCredential: () => null,
  });

  expect(configureProvider).toHaveBeenCalledWith(
    ProviderContract.Routing,
    'test-router',
    '',
  );
});

test('a credentialed provider without an applied key reports the reason without calling the SDK', async () => {
  const configureProvider = jest.fn(async () => undefined);
  const rows = buildCapabilityProviderRows(
    [registration({ contract: ProviderContract.Routing })],
    [fullServiceProvider],
    () => null,
  );
  expect(rows[0].choices[0].requiredCredentialLabel).toBe('API key');

  const outcome = await applyCapabilityProviderSelection({
    gateway: { configureProvider },
    row: rows[0],
    providerKey: 'full-service',
    appliedCredential: () => null,
  });

  expect(outcome.isApplied).toBe(false);
  expect(outcome.detailText).toBe(
    appStrings.capabilityProviderNeedsCredentialTemplate.replace(
      '{credential}',
      'API key',
    ),
  );
  expect(configureProvider).not.toHaveBeenCalled();
});

test('a refusal shows the SDK message verbatim and leaves the serving provider', async () => {
  const registrations = [
    registration({
      contract: ProviderContract.Routing,
      providerKey: 'full-service',
      displayName: 'Full Service',
      registered: true,
    }),
  ];
  const rows = buildCapabilityProviderRows(
    registrations,
    [fullServiceProvider, keylessRouter],
    () => 'stored-key',
  );
  const gateway: CapabilityProviderGateway = {
    configureProvider: jest.fn(async () => {
      throw new Error('provider credential is refused');
    }),
  };

  const outcome = await applyCapabilityProviderSelection({
    gateway,
    row: rows[0],
    providerKey: 'test-router',
    appliedCredential: () => null,
  });

  expect(outcome.isApplied).toBe(false);
  expect(outcome.detailText).toBe('provider credential is refused');
  // A fresh readback still names the previously serving provider.
  const refreshedRows = buildCapabilityProviderRows(
    registrations,
    [fullServiceProvider, keylessRouter],
    () => 'stored-key',
  );
  expect(capabilityServingStatusText(refreshedRows[0])).toBe('Full Service');
});

test('a provider the registry does not offer is refused with its reason', async () => {
  const configureProvider = jest.fn(async () => undefined);
  const rows = buildCapabilityProviderRows(
    [registration({ contract: ProviderContract.Routing })],
    [keylessRouter],
    () => null,
  );

  const outcome = await applyCapabilityProviderSelection({
    gateway: { configureProvider },
    row: rows[0],
    providerKey: 'unknown-provider',
    appliedCredential: () => null,
  });

  expect(outcome.isApplied).toBe(false);
  expect(outcome.detailText).toBe(
    appStrings.capabilityProviderNotOfferedTemplate.replace(
      '{provider}',
      'unknown-provider',
    ),
  );
  expect(configureProvider).not.toHaveBeenCalled();
});
