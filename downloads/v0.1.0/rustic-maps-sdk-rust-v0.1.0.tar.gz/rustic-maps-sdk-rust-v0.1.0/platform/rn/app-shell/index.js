/**
 * The reference application's entry point: the generated Rust bindings
 * install their JSI crate into Hermes at import time, so the app registers
 * with that import inside a guard (an emulator without the TurboModule must
 * reach the shell's honest failure states, not a red screen).
 */

import { AppRegistry } from 'react-native';
import { name as appName } from './app.json';

// The runtime bring-up probe: logged before anything else requires React
// Native so it observes the bare Hermes globals.
// eslint-disable-next-line @typescript-eslint/no-require-imports
require('./src/runtimeProbe');

// The generated `maps-sdk-rn` root entry deliberately stays unrequired in
// this shell: its module scope installs the generated bindings and runs the
// whole checksum gate, and this workspace's pinned uniffi (0.32.2) disagrees
// with the pinned ubrn generator (0.31.0-6) on 22 of the 53 checksum items,
// so that entry always throws at initialization. The shell imports only the
// package's hand-written deep entries (`maps-sdk-rn/MapView` and
// `maps-sdk-rn/MapsSdk`), which carry the native module seam and never run
// the generated gate.

import App from './App';

AppRegistry.registerComponent(appName, () => App);