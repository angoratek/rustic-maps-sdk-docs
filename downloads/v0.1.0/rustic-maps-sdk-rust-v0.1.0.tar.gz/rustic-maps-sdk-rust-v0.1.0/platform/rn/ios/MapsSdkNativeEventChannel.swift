import Foundation

/// The package's single native-to-JavaScript view event channel.
///
/// The native module installs the sink (its `RCTEventEmitter`); every host
/// view emits one named event carrying its JavaScript-side identifier, the
/// event name and the event's own fields, so the component can filter events
/// for its own view.
@objc(MapsSdkNativeEventChannel)
public final class MapsSdkNativeEventChannel: NSObject {

    /// The named event the JavaScript component subscribes to.
    @objc public static let eventName = "MapsSdkMapViewEvent"

    /// The module's emitter, or nil before the module initialized.
    @objc public static var sink: (([String: Any]) -> Void)?

    /// Emits one view event with the identifier and name folded in.
    @objc public static func emit(_ payload: [String: Any]) {
        sink?(payload)
    }
}
