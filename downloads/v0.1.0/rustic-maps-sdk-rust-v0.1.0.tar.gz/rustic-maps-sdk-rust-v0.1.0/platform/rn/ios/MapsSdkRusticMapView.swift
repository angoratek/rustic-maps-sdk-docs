//! Pod copy of `platform/ios/Sources/MapNativeCoreUI/MapView.swift` (the
//! `MapsSdkRusticMapView` widget), renamed to leave the generated binding's
//! `MapView` type unambiguous inside the package module. The two copies are
//! kept in sync by the iOS packaging slice; the SwiftPM package and this pod
//! intentionally expose the same widget.
//! The lifecycle-aware iOS map view shipped in the `MapNativeCoreUI`
//! package (M17): it owns the Metal-backed surface, the surface-pointer
//! handoff, the `CADisplayLink` frame pump, resize, the camera value store
//! and animation, gestures, the overlay and location-layer bookkeeping and
//! the delegate callbacks. The application owns only its widgets and its
//! own camera intent.
//!
//! ## Drawing
//!
//! There is deliberately no SDK-internal render loop: this view pumps
//! explicit frames from a `CADisplayLink` and follows the documented
//! idle-settled discipline (`docs/PublicApiV2.md` §10):
//!
//! 1. resize when the capped pixel extent changed, never every frame;
//! 2. ask `isFrameSettled`; when it answers true the pump pauses entirely
//!    instead of burning frames on an unchanged, fully presented view;
//! 3. otherwise draw with at most one draw in flight
//!    (`RenderingSurfaceUnavailable` retries on the next tick);
//! 4. report statistics, readiness and failures.
//!
//! The pump resumes on a camera set or animation, a gesture, an overlay or
//! location mutation, a surface attach/resize, window attach or visibility,
//! `setRenderingPaused(false)`, `retryAttach` and a one-second watchdog.
//! When only unavailable tiles remain with an unchanged pose, the pump
//! drops to that one-second retry cadence rather than spinning against the
//! provider.
//!
//! ## Lifecycle
//!
//! The display link starts in `didMoveToWindow` when the view gains a
//! window and is invalidated when it loses one; the surface detaches at the
//! same moment. The SwiftUI wrapper calls `teardown()` from
//! `dismantleUIView`. Detaching never happens in `deinit`: the Rust side
//! must release its surface while the Metal layer still exists.

import QuartzCore
import UIKit

/// The camera values a `MapView` reads back from the SDK's anchored
/// camera. The SDK owns the math; this plain value is what the wrapper
/// exposes so an integrator never holds a `MapCamera` handle.
public struct MapsSdkCameraPose: Equatable {
    /// Camera center latitude in decimal degrees.
    public var latitudeDegrees: Double
    /// Camera center longitude in decimal degrees.
    public var longitudeDegrees: Double
    /// Zoom level.
    public var zoomLevel: Double
    /// Bearing in degrees clockwise from true north.
    public var bearingDegrees: Double
    /// Pitch in degrees; zero is top-down.
    public var pitchDegrees: Double

    /// Builds one camera pose.
    public init(
        latitudeDegrees: Double,
        longitudeDegrees: Double,
        zoomLevel: Double,
        bearingDegrees: Double,
        pitchDegrees: Double
    ) {
        self.latitudeDegrees = latitudeDegrees
        self.longitudeDegrees = longitudeDegrees
        self.zoomLevel = zoomLevel
        self.bearingDegrees = bearingDegrees
        self.pitchDegrees = pitchDegrees
    }
}

/// Which `MapView` operation produced a `MapsSdkMapViewFailure`.
public enum MapsSdkMapViewFailurePhase {
    /// Acquiring the surface or attaching it.
    case surface
    /// Reconfiguring an attached surface.
    case resize
    /// Drawing a frame or querying idle settlement.
    case draw
    /// Reading, building or transforming the camera.
    case camera
    /// Pushing the overlay list.
    case overlay
    /// Pushing or clearing the location layer.
    case locationIndicator
    /// Installing, clearing or reading the vector base source.
    case baseMap
    /// Unprojecting a tap.
    case tap
}

/// One refused `MapView` operation carrying its verbatim SDK or platform
/// failure. The wrapper never swallows a failure: every one reaches
/// `MapsSdkMapViewDelegate.mapView(_:didFailWith:)` with the phase it occurred in
/// and the original error, so an app can present the SDK's own message.
public struct MapsSdkMapViewFailure: Error {
    /// The wrapper operation that failed.
    public let phase: MapsSdkMapViewFailurePhase
    /// The verbatim SDK or platform failure.
    public let cause: Error

    /// Builds one failure.
    public init(phase: MapsSdkMapViewFailurePhase, cause: Error) {
        self.phase = phase
        self.cause = cause
    }
}

/// The callbacks a `MapView` delivers on the main thread.
///
/// Every member has an empty default in the protocol extension: an
/// integrator overrides only what it needs.
@MainActor
public protocol MapsSdkMapViewDelegate: AnyObject {
    /// The first frame drew and presented successfully.
    func mapViewDidBecomeReady(_ mapView: MapsSdkRusticMapView)

    /// The camera changed: a set, an animation step, a gesture or a fit.
    ///
    /// - Parameters:
    ///   - camera: the adopted pose.
    ///   - isGestureDriven: true when a pan, pinch or rotate produced the
    ///     change, which is the hook a follow camera uses to break on
    ///     gesture.
    func mapView(
        _ mapView: MapsSdkRusticMapView,
        didChangeCamera camera: MapsSdkCameraPose,
        isGestureDriven: Bool
    )

    /// A tap unprojected onto the ground plane; a miss reports nothing.
    func mapView(
        _ mapView: MapsSdkRusticMapView,
        didClickCoordinate coordinate: GeographicCoordinate
    )

    /// An SDK or platform operation failed; the failure is never swallowed.
    func mapView(_ mapView: MapsSdkRusticMapView, didFailWith failure: MapsSdkMapViewFailure)

    /// One presented frame's tile and overlay accounting.
    func mapView(_ mapView: MapsSdkRusticMapView, didDrawFrame statistics: FrameStatistics)

    /// A frame was skipped because a draw or resize held the render state
    /// (`RenderingSurfaceUnavailable` backpressure); the next tick retries.
    func mapViewDidDeferFrame(_ mapView: MapsSdkRusticMapView)

    /// The pump paused because `isFrameSettled` answered true.
    func mapViewDidSettleFrame(_ mapView: MapsSdkRusticMapView)
}

public extension MapsSdkMapViewDelegate {
    func mapViewDidBecomeReady(_ mapView: MapsSdkRusticMapView) {}
    func mapView(
        _ mapView: MapsSdkRusticMapView,
        didChangeCamera camera: MapsSdkCameraPose,
        isGestureDriven: Bool
    ) {}
    func mapView(
        _ mapView: MapsSdkRusticMapView,
        didClickCoordinate coordinate: GeographicCoordinate
    ) {}
    func mapView(_ mapView: MapsSdkRusticMapView, didFailWith failure: MapsSdkMapViewFailure) {}
    func mapView(_ mapView: MapsSdkRusticMapView, didDrawFrame statistics: FrameStatistics) {}
    func mapViewDidDeferFrame(_ mapView: MapsSdkRusticMapView) {}
    func mapViewDidSettleFrame(_ mapView: MapsSdkRusticMapView) {}
}

/// The Metal-backed, lifecycle-aware map view shipped in the package.
///
/// The layer class is `CAMetalLayer`, so the surface handle the renderer
/// lowers through `SurfaceHandle.iosViewPointer` always carries a Metal
/// layer; the view computes that pointer itself, so user code never does
/// pointer math. The view caps its drawable at the downlevel texture limit
/// while keeping its point size: the rendered pixels scale up to the view
/// without a layout change (an unguarded full-screen buffer on a tall
/// phone is rejected by the downlevel adapter).
///
/// All members are expected on the main thread.
@MainActor
public final class MapsSdkRusticMapView: UIView {
    // MARK: Constants

    /// The maximum drawable pixel extent per axis the wgpu surface
    /// configure accepts on these adapters: `wgpu::Limits::downlevel_defaults()`
    /// sets `max_texture_dimension_2d` to 2048, and a larger surface
    /// buffer is rejected. The view keeps its full point size; only the
    /// Metal layer's drawable is capped, so the drawn pixels scale up to
    /// the view without any layout change.
    private static let maximumDrawableExtentPixels: CGFloat = 2048

    /// The display-scale floor when the trait collection has not reported
    /// a scale yet (the first ticks before the window scales resolve).
    private static let minimumDisplayScale: CGFloat = 1.0

    /// The SDK renderer's default perspective field of view (the
    /// `rustic-maps-rendering` default every shell passes).
    private static let defaultFieldOfViewDegrees: Double = 60.0

    /// One double tap's zoom step (`docs/ReferenceAppUX.md` §5.2): the
    /// gesture zooms exactly one level around the tapped point through the
    /// contract's focal zoom member, the same seam the pinch recognizer
    /// feeds.
    private static let doubleTapZoomStep: Double = 1.0

    /// The cheap idle insurance cadence while the pump is settled, backing
    /// off or retrying an attach: one second.
    private static let watchdogIntervalSeconds: TimeInterval = 1.0

    /// Consecutive unavailable-only, pose-unchanged frames before the pump
    /// drops to the watchdog's one-second retry cadence: a provider that
    /// keeps rejecting tiles must not become a 60 fps retry spin.
    private static let unavailableBackoffFrameCount: Int = 3

    /// The default camera animation duration (`docs/ReferenceAppUX.md`
    /// §5.3's eased move duration).
    public nonisolated static let defaultCameraAnimationDurationMilliseconds: Double = 300

    /// The SDK's maximum zoom level, the default fit-bounds ceiling.
    public nonisolated static let defaultFitBoundsMaximumZoomLevel: Double = 24.0

    /// Milliseconds in one second (the animation duration's unit
    /// conversion).
    private static let millisecondsPerSecond: Double = 1000

    /// The initial pose before any host camera intent.
    public nonisolated(unsafe) static let defaultCameraPose = MapsSdkCameraPose(
        latitudeDegrees: 0,
        longitudeDegrees: 0,
        zoomLevel: 2,
        bearingDegrees: 0,
        pitchDegrees: 0
    )

    // MARK: Public state

    /// The SDK whose registered raster-tile provider the view draws from.
    /// Setting it creates the native view; setting it while attached
    /// rebuilds the native view and re-attaches on the next pump tick.
    /// Nil draws nothing (the black canvas stands).
    public var sdk: MapSdk? {
        didSet {
            if let sdk, let oldValue, sdk === oldValue {
                return
            }
            if sdk == nil && oldValue == nil {
                return
            }
            rebuildNativeMapView()
        }
    }

    /// The callbacks; held weakly so the view never keeps an owner alive.
    public weak var delegate: MapsSdkMapViewDelegate?

    /// Whether touch gestures pan, pinch, rotate and tap the map.
    public var isGestureEnabled: Bool = true {
        didSet {
            for gestureRecognizer in gestureRecognizersList {
                gestureRecognizer.isEnabled = isGestureEnabled
            }
        }
    }

    /// The camera the pump draws with; reads the last adopted pose.
    public var camera: MapsSdkCameraPose { cameraPose }

    /// The render viewport in pixels, or nil before the surface attached.
    /// This is the capped extent the frames render at, not the raw view
    /// extent; gestures and taps scale between the two.
    public var viewportSize: ViewportSize? {
        guard attachedWidthPixels > 0, attachedHeightPixels > 0 else {
            return nil
        }
        return ViewportSize(
            widthPixels: Double(attachedWidthPixels),
            heightPixels: Double(attachedHeightPixels)
        )
    }

    /// The capped physical-pixel extent the drawable is configured to, or
    /// nil before the first laid-out pump tick.
    public var viewportPixelExtent: CGSize? {
        renderPixelExtent == .zero ? nil : renderPixelExtent
    }

    /// The effective drawable scale (points to rendered pixels), clamped
    /// by the downlevel texture limit.
    public var displayScale: CGFloat { renderScale }

    // MARK: Surface and native view state

    private var nativeMapView: MapView?
    /// The vector base source installed before the native view existed; the
    /// native view is rebuilt on every SDK swap, and the contract keeps the
    /// source across detach/attach, so the wrapper re-applies it like the
    /// overlay list.
    private var pendingVectorTileSource: UrlTemplateVectorTileSource?
    private var requiresAttach = false
    private var isAttached = false
    private var attachedWidthPixels = 0
    private var attachedHeightPixels = 0
    private var renderPixelExtent: CGSize = .zero
    private var renderScale: CGFloat = 1

    // MARK: Camera state

    private var cameraPose = MapsSdkRusticMapView.defaultCameraPose
    private var cameraRevision: UInt64 = 0
    private var builtCamera: MapCamera?
    private var builtCameraRevision: UInt64 = .max
    private var cameraAnimation: CameraAnimation?

    // MARK: Overlay and location state

    private var overlayDescriptors: [MapOverlay] = []
    private var overlayDescriptorsByIdentifier: [String: MapOverlay] = [:]
    private var overlayIdentifierOrder: [String] = []
    private var locationIndicatorState: LocationIndicatorState?
    private var locationIndicatorStyle: LocationIndicatorStyle?

    // MARK: Pump state

    private var displayLink: CADisplayLink?
    private var watchdogTimer: Timer?
    private var isDrawInFlight = false
    private var isBackoffActive = false
    private var consecutiveUnavailableOnlyFrames = 0
    private var hasReportedMapReady = false
    private var isRenderingPaused = false
    private var isTornDown = false
    private var gestureRecognizersList: [UIGestureRecognizer] = []

    // MARK: Gesture state

    private var lastPanTranslationPixels: CGPoint = .zero

    // MARK: Construction

    public override class var layerClass: AnyClass { CAMetalLayer.self }

    public override init(frame: CGRect) {
        super.init(frame: frame)
        configureView()
    }

    /// Storyboard/XIB construction: the shipped view is layout-capable from
    /// a nib, unlike the app-side view it replaces.
    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        configureView()
    }

    private func configureView() {
        // The canvas is opaque black under both themes (the renderer's
        // clear color is a Rust-side rendering constant, not a UI token).
        backgroundColor = UIColor.black
        isOpaque = true
        isMultipleTouchEnabled = true
        configureGestures()
    }

    /// The view's raw object address, laid as the unsigned pointer value
    /// the `SurfaceHandle.iosViewPointer` field carries. Computed inside
    /// the view so user code never does pointer math.
    private var iosViewPointerValue: UInt64 {
        let opaquePointer = Unmanaged.passUnretained(self).toOpaque()
        return UInt64(UInt(bitPattern: Int(bitPattern: opaquePointer)))
    }

    /// The view's backing Metal layer (its layer class is `CAMetalLayer`).
    private var metalLayer: CAMetalLayer? {
        layer as? CAMetalLayer
    }

    // MARK: Camera API

    /// Sets the camera immediately; a refused pose reports and keeps the
    /// old one.
    public func setCamera(_ cameraPose: MapsSdkCameraPose) {
        cameraAnimation = nil
        applyCameraPose(cameraPose, isGestureDriven: false)
    }

    /// Eases the camera to `cameraPose` over `durationMilliseconds`,
    /// interpolating latitude, longitude, zoom and pitch linearly and the
    /// bearing along the shortest angular path. A non-positive duration is
    /// an immediate set.
    public func animateCamera(
        _ cameraPose: MapsSdkCameraPose,
        durationMilliseconds: Double = MapsSdkRusticMapView.defaultCameraAnimationDurationMilliseconds
    ) {
        guard let normalizedTarget = normalizedCameraPose(cameraPose) else {
            return
        }
        guard durationMilliseconds > 0 else {
            adoptPose(normalizedTarget, isGestureDriven: false)
            return
        }
        cameraAnimation = CameraAnimation(
            startTime: CACurrentMediaTime(),
            durationSeconds: durationMilliseconds / MapsSdkRusticMapView.millisecondsPerSecond,
            fromPose: self.cameraPose,
            toPose: normalizedTarget
        )
        resumePump(resetBackoff: true)
    }

    /// Frames `boundingBox` inside the viewport's inset region (top-down
    /// and north-up by construction) and adopts the fitted camera. Without
    /// an attached viewport the call changes nothing.
    public func fitBounds(
        boundingBox: BoundingBox,
        edgeInsets: EdgeInsets = MapsSdkRusticMapView.zeroEdgeInsets,
        maximumZoomLevel: Double = MapsSdkRusticMapView.defaultFitBoundsMaximumZoomLevel
    ) {
        guard let viewport = viewportSize else { return }
        do {
            let fittedCamera = try MapCamera.fitBounds(
                boundingBox: boundingBox,
                viewport: viewport,
                edgeInsets: edgeInsets,
                maximumZoomLevel: maximumZoomLevel
            )
            adoptPose(readCameraPose(fittedCamera), isGestureDriven: false)
        } catch {
            reportFailure(phase: .camera, cause: error)
        }
    }

    /// Ground meters represented by one screen pixel at the camera center
    /// (the scale bar's helper), or nil before the surface attached.
    public func groundMetersPerScreenPixel() -> Double? {
        guard let viewport = viewportSize,
              let currentCamera = currentCameraOrNil()
        else {
            return nil
        }
        do {
            return try currentCamera.groundMetersPerScreenPixel(
                viewport: viewport,
                fieldOfViewDegrees: MapsSdkRusticMapView.defaultFieldOfViewDegrees
            )
        } catch {
            reportFailure(phase: .camera, cause: error)
            return nil
        }
    }

    /// Pans by a screen-pixel delta through the contract camera's
    /// `panByScreenPixels` (the programmatic twin of a drag; the
    /// content-follows-pointer convention).
    public func panByScreenPixels(
        deltaXPixels: Double,
        deltaYPixels: Double,
        isGestureDriven: Bool = true
    ) {
        transformCamera(
            panXPixels: deltaXPixels,
            panYPixels: deltaYPixels,
            isGestureDriven: isGestureDriven
        )
    }

    /// Zooms by `deltaZoomLevels` around the viewport's center — the
    /// control cluster's zoom buttons go through the same contract member
    /// as a pinch.
    public func zoomByLevels(deltaZoomLevels: Double) {
        transformCamera(
            zoomLevels: deltaZoomLevels,
            focalPoint: viewportCenterScreenPoint,
            isGestureDriven: false
        )
    }

    /// Rotates the content clockwise by `clockwiseDegrees` around the
    /// viewport center (the content-follows-fingers convention: a
    /// clockwise finger turn turns the content clockwise, which lowers the
    /// bearing).
    public func rotateByDegrees(clockwiseDegrees: Double) {
        rotateCamera(
            clockwiseDegrees: clockwiseDegrees,
            focalPoint: viewportCenterScreenPoint,
            isGestureDriven: true
        )
    }

    // MARK: Overlay API (addressed by caller identifier)

    /// Adds or replaces the overlay held under `identifier`; answers
    /// whether the SDK accepted the list.
    @discardableResult
    public func addOverlay(identifier: String, overlay: MapOverlay) -> Bool {
        if overlayDescriptorsByIdentifier[identifier] == nil {
            overlayIdentifierOrder.append(identifier)
        }
        overlayDescriptorsByIdentifier[identifier] = overlay
        return pushOverlays(orderedOverlayDescriptors)
    }

    /// Replaces an existing overlay under `identifier`; an unknown
    /// identifier answers false and changes nothing (use `addOverlay` for
    /// a new identifier).
    @discardableResult
    public func updateOverlay(identifier: String, overlay: MapOverlay) -> Bool {
        guard overlayDescriptorsByIdentifier[identifier] != nil else {
            return false
        }
        overlayDescriptorsByIdentifier[identifier] = overlay
        return pushOverlays(orderedOverlayDescriptors)
    }

    /// Removes the overlay under `identifier` (an unknown identifier is a
    /// no-op); answers whether the SDK accepted the list.
    @discardableResult
    public func removeOverlay(identifier: String) -> Bool {
        guard overlayDescriptorsByIdentifier.removeValue(forKey: identifier) != nil else {
            return true
        }
        overlayIdentifierOrder.removeAll { $0 == identifier }
        return pushOverlays(orderedOverlayDescriptors)
    }

    /// Replaces the whole overlay list and resets the identifier
    /// bookkeeping: later `addOverlay`/`updateOverlay`/`removeOverlay`
    /// calls start from an empty identifier map.
    @discardableResult
    public func setOverlays(_ overlays: [MapOverlay]) -> Bool {
        overlayDescriptorsByIdentifier.removeAll()
        overlayIdentifierOrder.removeAll()
        return pushOverlays(overlays)
    }

    /// Clears every overlay and the identifier bookkeeping; answers
    /// whether the SDK accepted the list.
    @discardableResult
    public func clearOverlays() -> Bool {
        overlayDescriptorsByIdentifier.removeAll()
        overlayIdentifierOrder.removeAll()
        return pushOverlays([])
    }

    // MARK: Location layer API

    /// Sets the renderer-owned location layer; a refused push reports.
    public func setLocationIndicator(
        state: LocationIndicatorState,
        style: LocationIndicatorStyle
    ) {
        locationIndicatorState = state
        locationIndicatorStyle = style
        guard let nativeMapView else { return }
        do {
            try nativeMapView.setLocationIndicator(state: state, style: style)
            resumePump(resetBackoff: true)
        } catch {
            reportFailure(phase: .locationIndicator, cause: error)
        }
    }

    /// Clears the location layer; a refused clear reports.
    public func clearLocationIndicator() {
        locationIndicatorState = nil
        locationIndicatorStyle = nil
        guard let nativeMapView else { return }
        nativeMapView.clearLocationIndicator()
        resumePump(resetBackoff: true)
    }

    // MARK: Vector base map API (M22)

    /// Installs a vector base map: a provider-neutral vector tileset painted
    /// with one of the SDK's committed styles, drawn over the raster tiles
    /// and beneath every overlay. The source outlives attach/detach cycles,
    /// so an install before the surface exists is carried into the first
    /// frame. Answers whether the SDK accepted it; a refusal reports through
    /// the delegate and leaves the previously installed base in force.
    @discardableResult
    public func setVectorTileSource(
        _ source: UrlTemplateVectorTileSource
    ) -> Bool {
        let previousVectorTileSource = pendingVectorTileSource
        pendingVectorTileSource = source
        guard let nativeMapView else { return true }
        do {
            try nativeMapView.setVectorTileSource(source: source)
            resumePump(resetBackoff: true)
            return true
        } catch {
            pendingVectorTileSource = previousVectorTileSource
            reportFailure(phase: .baseMap, cause: error)
            return false
        }
    }

    /// Removes the vector base map; answers whether the SDK accepted the
    /// clear.
    @discardableResult
    public func clearVectorTileSource() -> Bool {
        let previousVectorTileSource = pendingVectorTileSource
        pendingVectorTileSource = nil
        guard let nativeMapView else { return true }
        do {
            try nativeMapView.clearVectorTileSource()
            resumePump(resetBackoff: true)
            return true
        } catch {
            pendingVectorTileSource = previousVectorTileSource
            reportFailure(phase: .baseMap, cause: error)
            return false
        }
    }

    /// The vector base source's status, or nil before the native view exists.
    public func vectorTileSourceStatus() -> VectorTileSourceStatus? {
        nativeMapView?.vectorTileSourceStatus()
    }

    // MARK: Lifecycle API

    /// Pauses or resumes drawing explicitly (a host may release the GPU
    /// surface in the background).
    public func setRenderingPaused(_ paused: Bool) {
        guard isRenderingPaused != paused else { return }
        isRenderingPaused = paused
        if paused {
            pausePump()
        } else {
            resumePump(resetBackoff: true)
        }
    }

    /// Retries a failed attach; the error surfaced through
    /// `MapsSdkMapViewDelegate.mapView(_:didFailWith:)`.
    public func retryAttach() {
        guard !isTornDown, nativeMapView != nil else { return }
        requiresAttach = true
        resumePump(resetBackoff: true)
    }

    /// Re-resolves the SDK's raster-tile provider and drops every pooled
    /// tile, so a provider registered after this view attached serves the
    /// next frame. The view holds its provider from the moment it attaches,
    /// and the pooled tiles are keyed by tile coordinate alone, so without
    /// this call a base-map switch leaves the previous imagery on screen
    /// until the camera moves onto unfetched tiles.
    ///
    /// The surface is detached and re-attached internally — the one place a
    /// view resolves its provider — and `tryAttach` restores the stored
    /// overlays and location indicator exactly as after any re-attach, while
    /// the camera pose the wrapper draws with persists across the cycle. A
    /// failure surfaces through `MapsSdkMapViewDelegate.mapView(_:didFailWith:)`.
    public func reloadRasterTileSource() {
        guard !isTornDown, nativeMapView != nil else { return }
        detachSurface()
        requiresAttach = true
        resumePump(resetBackoff: true)
    }

    /// Releases the display link, the watchdog and the native surface.
    /// Called by the SwiftUI wrapper's `dismantleUIView`; the view is not
    /// reusable afterwards.
    public func teardown() {
        guard !isTornDown else { return }
        isTornDown = true
        stopDisplayLink()
        cancelWatchdog()
        detachSurface()
        nativeMapView = nil
        delegate = nil
    }

    // MARK: View lifecycle overrides

    public override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil {
            startDisplayLink()
            resumePump(resetBackoff: true)
        } else {
            stopDisplayLink()
            cancelWatchdog()
            detachSurface()
        }
    }

    /// The layout pass also resumes the pump: a rotated or split-view
    /// resize arrives here before the next display tick, and the tick's
    /// extent check reconfigures the surface.
    public override func layoutSubviews() {
        super.layoutSubviews()
        resumePump(resetBackoff: true)
    }

    // MARK: Frame pump

    private func canPump() -> Bool {
        !isTornDown
            && nativeMapView != nil
            && window != nil
            && !isRenderingPaused
    }

    private func startDisplayLink() {
        guard displayLink == nil else { return }
        let newDisplayLink = CADisplayLink(
            target: self,
            selector: #selector(displayLinkFrameTick)
        )
        // Born paused: a keyless view (no SDK yet) must not tick at the
        // display cadence. `resumePump` unpauses it once the pump can run.
        newDisplayLink.isPaused = true
        newDisplayLink.add(to: .main, forMode: .common)
        displayLink = newDisplayLink
    }

    private func stopDisplayLink() {
        displayLink?.invalidate()
        displayLink = nil
    }

    private func resumePump(resetBackoff: Bool) {
        guard canPump() else { return }
        cancelWatchdog()
        if resetBackoff {
            isBackoffActive = false
            consecutiveUnavailableOnlyFrames = 0
        }
        startDisplayLink()
        displayLink?.isPaused = false
    }

    /// Pauses the tick but keeps the display link alive (the pump's cheap
    /// idle state). Any resume trigger restarts it, and the watchdog
    /// re-checks cheaply.
    private func pausePump() {
        displayLink?.isPaused = true
        scheduleWatchdog()
    }

    private func pauseForSettled() { pausePump() }

    private func pauseForBackoff() { pausePump() }

    private func pauseForRetry() { pausePump() }

    private func scheduleWatchdog() {
        cancelWatchdog()
        let timer = Timer(
            timeInterval: MapsSdkRusticMapView.watchdogIntervalSeconds,
            target: self,
            selector: #selector(watchdogFired),
            userInfo: nil,
            repeats: false
        )
        RunLoop.main.add(timer, forMode: .common)
        watchdogTimer = timer
    }

    private func cancelWatchdog() {
        watchdogTimer?.invalidate()
        watchdogTimer = nil
    }

    @objc private func watchdogFired() {
        resumePump(resetBackoff: false)
    }

    @objc private func displayLinkFrameTick() {
        pumpOneFrame()
    }

    private func pumpOneFrame() {
        guard canPump() else { return }
        guard updateRenderExtent() else { return }
        let pixelExtent = renderPixelExtent
        if requiresAttach {
            tryAttach(pixelExtent: pixelExtent)
            return
        }
        guard isAttached, let nativeMapView else { return }
        if attachedWidthPixels != Int(pixelExtent.width)
            || attachedHeightPixels != Int(pixelExtent.height) {
            tryResize(nativeMapView: nativeMapView, pixelExtent: pixelExtent)
            return
        }
        advanceCameraAnimation()
        guard let camera = currentCameraOrNil() else { return }
        let isSettledNow: Bool
        do {
            isSettledNow = try nativeMapView.isFrameSettled(camera: camera)
        } catch {
            reportFailure(phase: .draw, cause: error)
            pauseForRetry()
            return
        }
        if isSettledNow {
            delegate?.mapViewDidSettleFrame(self)
            pauseForSettled()
            return
        }
        guard !isDrawInFlight else { return }
        isDrawInFlight = true
        let drawnCameraRevision = cameraRevision
        let frameCamera = camera
        Task { @MainActor [weak self] in
            guard let self else { return }
            defer { self.isDrawInFlight = false }
            do {
                let statistics = try await nativeMapView.draw(camera: frameCamera)
                self.handleDrawnFrame(
                    statistics,
                    drawnCameraRevision: drawnCameraRevision
                )
            } catch let sdkError as SdkError {
                if case .RenderingSurfaceUnavailable = sdkError {
                    // Documented backpressure of the serialized-draw rule:
                    // retry next tick.
                    self.consecutiveUnavailableOnlyFrames = 0
                    self.delegate?.mapViewDidDeferFrame(self)
                } else {
                    self.reportFailure(phase: .draw, cause: sdkError)
                    self.pauseForRetry()
                }
            } catch {
                self.reportFailure(phase: .draw, cause: error)
                self.pauseForRetry()
            }
        }
    }

    private func handleDrawnFrame(
        _ statistics: FrameStatistics,
        drawnCameraRevision: UInt64
    ) {
        delegate?.mapView(self, didDrawFrame: statistics)
        if !hasReportedMapReady {
            hasReportedMapReady = true
            delegate?.mapViewDidBecomeReady(self)
        }
        let nothingDeferred = statistics.deferredTileCount == 0
        let somethingUnavailable = statistics.unavailableTileCount > 0
        // "Unchanged pose" is judged against the camera this frame actually
        // drew, not a gesture that landed while the draw awaited tiles.
        let poseUnchanged = drawnCameraRevision == cameraRevision
        if nothingDeferred && somethingUnavailable && poseUnchanged {
            if isBackoffActive {
                pauseForBackoff()
                return
            }
            consecutiveUnavailableOnlyFrames += 1
            if consecutiveUnavailableOnlyFrames >= MapsSdkRusticMapView.unavailableBackoffFrameCount {
                isBackoffActive = true
                pauseForBackoff()
            }
        } else {
            consecutiveUnavailableOnlyFrames = 0
            isBackoffActive = false
        }
    }

    // MARK: Attach / resize / detach

    /// Recomputes the capped drawable extent from the laid-out point size
    /// and the trait collection's scale; false while the view has no
    /// non-zero laid-out extent yet.
    private func updateRenderExtent() -> Bool {
        let laidOutPointExtent = bounds.size
        guard laidOutPointExtent.width > 0, laidOutPointExtent.height > 0 else {
            return false
        }
        let displayScale = max(
            traitCollection.displayScale,
            MapsSdkRusticMapView.minimumDisplayScale
        )
        // The drawable is capped at the adapter's maximum texture
        // dimension: the capped effective scale keeps the aspect and never
        // exceeds the configure validation.
        let cappedDisplayScale = min(
            displayScale,
            MapsSdkRusticMapView.maximumDrawableExtentPixels
                / max(laidOutPointExtent.width, laidOutPointExtent.height)
        )
        let pixelExtent = CGSize(
            width: (laidOutPointExtent.width * cappedDisplayScale).rounded(),
            height: (laidOutPointExtent.height * cappedDisplayScale).rounded()
        )
        guard pixelExtent.width >= 1, pixelExtent.height >= 1 else {
            return false
        }
        renderScale = cappedDisplayScale
        renderPixelExtent = pixelExtent
        metalLayer?.drawableSize = pixelExtent
        return true
    }

    private func tryAttach(pixelExtent: CGSize) {
        guard let nativeMapView else { return }
        let widthPixels = UInt32(pixelExtent.width)
        let heightPixels = UInt32(pixelExtent.height)
        guard widthPixels > 0, heightPixels > 0 else { return }
        let surfaceHandle = SurfaceHandle(
            appkitViewPointer: nil,
            iosViewPointer: iosViewPointerValue,
            androidNativeWindowPointer: nil
        )
        do {
            try nativeMapView.attach(
                surfaceHandle: surfaceHandle,
                widthPixels: widthPixels,
                heightPixels: heightPixels
            )
            attachedWidthPixels = Int(widthPixels)
            attachedHeightPixels = Int(heightPixels)
            requiresAttach = false
            isAttached = true
            applyStoredStateToNativeView()
            resumePump(resetBackoff: true)
        } catch {
            // A failed attach reports, then waits for the watchdog's next
            // retry (a registration may arrive meanwhile) instead of
            // spinning every display tick.
            requiresAttach = true
            reportFailure(phase: .surface, cause: error)
            pauseForRetry()
        }
    }

    private func tryResize(
        nativeMapView: MapView,
        pixelExtent: CGSize
    ) {
        let widthPixels = UInt32(pixelExtent.width)
        let heightPixels = UInt32(pixelExtent.height)
        guard widthPixels > 0, heightPixels > 0 else { return }
        do {
            try nativeMapView.resize(
                widthPixels: widthPixels,
                heightPixels: heightPixels
            )
            attachedWidthPixels = Int(widthPixels)
            attachedHeightPixels = Int(heightPixels)
            applyDevicePixelRatio(to: nativeMapView, failurePhase: .resize)
            resumePump(resetBackoff: true)
        } catch let sdkError as SdkError {
            if case .RenderingSurfaceUnavailable = sdkError {
                // A mid-draw resize is documented backpressure: the next
                // tick retries.
                return
            }
            reportFailure(phase: .resize, cause: sdkError)
            pauseForRetry()
        } catch {
            reportFailure(phase: .resize, cause: error)
            pauseForRetry()
        }
    }

    /// Detaches the platform surface. A view that still owns a native view
    /// (a window detach, not a teardown) re-attaches on the next pump tick
    /// when it returns to a window.
    private func detachSurface() {
        if isAttached {
            nativeMapView?.detach()
            isAttached = false
        }
        requiresAttach = nativeMapView != nil
        attachedWidthPixels = 0
        attachedHeightPixels = 0
    }

    private func rebuildNativeMapView() {
        if isAttached {
            nativeMapView?.detach()
            isAttached = false
        }
        attachedWidthPixels = 0
        attachedHeightPixels = 0
        requiresAttach = false
        hasReportedMapReady = false
        nativeMapView = nil
        guard let sdk, !isTornDown else { return }
        nativeMapView = MapView(mapSdk: sdk)
        requiresAttach = true
        applyStoredStateToNativeView()
        resumePump(resetBackoff: true)
    }

    /// Re-pushes the stored overlays and location layer onto a fresh
    /// native view (the SDK state outlives the view's attach cycles, but a
    /// rebuilt native view starts empty).
    private func applyStoredStateToNativeView() {
        guard let nativeMapView else { return }
        applyDevicePixelRatio(to: nativeMapView, failurePhase: .surface)
        do {
            try nativeMapView.setOverlays(overlayDescriptors: overlayDescriptors)
        } catch {
            reportFailure(phase: .overlay, cause: error)
        }
        if let state = locationIndicatorState,
           let style = locationIndicatorStyle {
            do {
                try nativeMapView.setLocationIndicator(state: state, style: style)
            } catch {
                reportFailure(phase: .locationIndicator, cause: error)
            }
        }
        if let vectorTileSource = pendingVectorTileSource {
            do {
                try nativeMapView.setVectorTileSource(source: vectorTileSource)
            } catch {
                reportFailure(phase: .baseMap, cause: error)
            }
        }
    }

    /// Reports the capped drawable scale to the SDK: the labels and overlay
    /// screen sizes are declared in points, so the surface scales them by the
    /// drawable's device pixels per point. Called whenever the effective scale
    /// is applied — at attach, after a resize and on a rebuilt native view.
    private func applyDevicePixelRatio(
        to nativeMapView: MapView,
        failurePhase: MapsSdkMapViewFailurePhase
    ) {
        do {
            try nativeMapView.setDevicePixelRatio(
                devicePixelRatio: Double(renderScale)
            )
        } catch {
            reportFailure(phase: failurePhase, cause: error)
        }
    }

    // MARK: Camera internals

    private var viewportCenterScreenPoint: ScreenPoint? {
        guard let viewport = viewportSize else { return nil }
        return ScreenPoint(
            x: viewport.widthPixels / 2,
            y: viewport.heightPixels / 2
        )
    }

    private func normalizedCameraPose(_ pose: MapsSdkCameraPose) -> MapsSdkCameraPose? {
        do {
            let camera = try MapCamera(
                center: GeographicCoordinate(
                    latitude: pose.latitudeDegrees,
                    longitude: pose.longitudeDegrees
                ),
                zoomLevel: pose.zoomLevel,
                bearingDegrees: pose.bearingDegrees,
                pitchDegrees: pose.pitchDegrees
            )
            return readCameraPose(camera)
        } catch {
            reportFailure(phase: .camera, cause: error)
            return nil
        }
    }

    private func applyCameraPose(
        _ pose: MapsSdkCameraPose,
        isGestureDriven: Bool
    ) {
        guard let normalized = normalizedCameraPose(pose) else { return }
        adoptPose(normalized, isGestureDriven: isGestureDriven)
    }

    private func readCameraPose(_ camera: MapCamera) -> MapsSdkCameraPose {
        let center = camera.center()
        return MapsSdkCameraPose(
            latitudeDegrees: center.latitude,
            longitudeDegrees: center.longitude,
            zoomLevel: camera.zoomLevel(),
            bearingDegrees: camera.bearingDegrees(),
            pitchDegrees: camera.pitchDegrees()
        )
    }

    private func currentCameraOrNil() -> MapCamera? {
        if builtCameraRevision == cameraRevision, let builtCamera {
            return builtCamera
        }
        do {
            let rebuiltCamera = try MapCamera(
                center: GeographicCoordinate(
                    latitude: cameraPose.latitudeDegrees,
                    longitude: cameraPose.longitudeDegrees
                ),
                zoomLevel: cameraPose.zoomLevel,
                bearingDegrees: cameraPose.bearingDegrees,
                pitchDegrees: cameraPose.pitchDegrees
            )
            builtCamera = rebuiltCamera
            builtCameraRevision = cameraRevision
            return rebuiltCamera
        } catch {
            reportFailure(phase: .camera, cause: error)
            return nil
        }
    }

    private func adoptPose(
        _ pose: MapsSdkCameraPose,
        isGestureDriven: Bool
    ) {
        cameraPose = pose
        cameraRevision &+= 1
        delegate?.mapView(
            self,
            didChangeCamera: pose,
            isGestureDriven: isGestureDriven
        )
        resumePump(resetBackoff: true)
    }

    private func transformCamera(
        panXPixels: Double = 0,
        panYPixels: Double = 0,
        zoomLevels: Double = 0,
        rotateDegrees: Double = 0,
        focalPoint: ScreenPoint? = nil,
        isGestureDriven: Bool = true
    ) {
        guard let viewport = viewportSize else { return }
        var workingCamera: MapCamera?
        do {
            workingCamera = try MapCamera(
                center: GeographicCoordinate(
                    latitude: cameraPose.latitudeDegrees,
                    longitude: cameraPose.longitudeDegrees
                ),
                zoomLevel: cameraPose.zoomLevel,
                bearingDegrees: cameraPose.bearingDegrees,
                pitchDegrees: cameraPose.pitchDegrees
            )
            if panXPixels != 0 || panYPixels != 0 {
                let panned = try workingCamera?.panByScreenPixels(
                    deltaXPixels: panXPixels,
                    deltaYPixels: panYPixels,
                    viewport: viewport,
                    fieldOfViewDegrees: MapsSdkRusticMapView.defaultFieldOfViewDegrees
                )
                workingCamera = panned
            }
            if zoomLevels != 0, let focalPoint {
                let zoomed = try workingCamera?.zoomByLevelsAroundScreenPoint(
                    deltaZoomLevels: zoomLevels,
                    focalPoint: focalPoint,
                    viewport: viewport,
                    fieldOfViewDegrees: MapsSdkRusticMapView.defaultFieldOfViewDegrees
                )
                workingCamera = zoomed
            }
            if rotateDegrees != 0, let focalPoint {
                let rotated = try workingCamera?.rotateByDegreesAroundScreenPoint(
                    deltaBearingDegrees: rotateDegrees,
                    focalPoint: focalPoint,
                    viewport: viewport,
                    fieldOfViewDegrees: MapsSdkRusticMapView.defaultFieldOfViewDegrees
                )
                workingCamera = rotated
            }
            guard let workingCamera else { return }
            adoptPose(
                readCameraPose(workingCamera),
                isGestureDriven: isGestureDriven
            )
        } catch {
            reportFailure(phase: .camera, cause: error)
        }
    }

    private func rotateCamera(
        clockwiseDegrees: Double,
        focalPoint: ScreenPoint?,
        isGestureDriven: Bool
    ) {
        // The content-follows-fingers convention's rotational face: the
        // drag delta arrives clockwise-positive, while the contract's
        // bearing delta adds clockwise to the camera bearing — so the sign
        // flips across the seam and the camera answers the wrapped bearing.
        transformCamera(
            rotateDegrees: -clockwiseDegrees,
            focalPoint: focalPoint,
            isGestureDriven: isGestureDriven
        )
    }

    private func advanceCameraAnimation() {
        guard let animation = cameraAnimation else { return }
        let elapsedSeconds = CACurrentMediaTime() - animation.startTime
        let fraction = min(max(elapsedSeconds / animation.durationSeconds, 0), 1)
        let easedFraction = smoothstepFraction(fraction)
        let nextPose = MapsSdkCameraPose(
            latitudeDegrees: interpolate(
                animation.fromPose.latitudeDegrees,
                animation.toPose.latitudeDegrees,
                easedFraction
            ),
            longitudeDegrees: interpolate(
                animation.fromPose.longitudeDegrees,
                animation.toPose.longitudeDegrees,
                easedFraction
            ),
            zoomLevel: interpolate(
                animation.fromPose.zoomLevel,
                animation.toPose.zoomLevel,
                easedFraction
            ),
            bearingDegrees: interpolateBearingDegrees(
                animation.fromPose.bearingDegrees,
                animation.toPose.bearingDegrees,
                easedFraction
            ),
            pitchDegrees: interpolate(
                animation.fromPose.pitchDegrees,
                animation.toPose.pitchDegrees,
                easedFraction
            )
        )
        if fraction >= 1 {
            cameraAnimation = nil
        }
        adoptPose(nextPose, isGestureDriven: false)
    }

    // MARK: Overlay internals

    private var orderedOverlayDescriptors: [MapOverlay] {
        overlayIdentifierOrder.compactMap { overlayDescriptorsByIdentifier[$0] }
    }

    private func pushOverlays(_ descriptors: [MapOverlay]) -> Bool {
        overlayDescriptors = descriptors
        guard let nativeMapView else { return true }
        do {
            try nativeMapView.setOverlays(overlayDescriptors: descriptors)
            resumePump(resetBackoff: true)
            return true
        } catch {
            reportFailure(phase: .overlay, cause: error)
            return false
        }
    }

    // MARK: Gestures

    private func configureGestures() {
        let panRecognizer = UIPanGestureRecognizer(
            target: self,
            action: #selector(handlePanGesture)
        )
        panRecognizer.maximumNumberOfTouches = 1
        addGestureRecognizer(panRecognizer)

        let pinchRecognizer = UIPinchGestureRecognizer(
            target: self,
            action: #selector(handlePinchGesture)
        )
        addGestureRecognizer(pinchRecognizer)

        let rotationRecognizer = UIRotationGestureRecognizer(
            target: self,
            action: #selector(handleRotationGesture)
        )
        addGestureRecognizer(rotationRecognizer)

        let tapRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(handleTapGesture)
        )
        addGestureRecognizer(tapRecognizer)

        // A double tap zooms; the single tap waits for it to fail so one
        // double tap never also reports a map click.
        let doubleTapRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(handleDoubleTapGesture)
        )
        doubleTapRecognizer.numberOfTapsRequired = 2
        addGestureRecognizer(doubleTapRecognizer)
        tapRecognizer.require(toFail: doubleTapRecognizer)

        panRecognizer.delegate = self
        pinchRecognizer.delegate = self
        rotationRecognizer.delegate = self
        tapRecognizer.delegate = self
        doubleTapRecognizer.delegate = self
        gestureRecognizersList = [
            panRecognizer, pinchRecognizer, rotationRecognizer, tapRecognizer,
            doubleTapRecognizer,
        ]
    }

    /// The render pixel coordinate of one point in the view.
    private func renderPixelPoint(of pointInView: CGPoint) -> ScreenPoint {
        ScreenPoint(
            x: Double(pointInView.x * renderScale),
            y: Double(pointInView.y * renderScale)
        )
    }

    @objc private func handlePanGesture(_ recognizer: UIPanGestureRecognizer) {
        guard isGestureEnabled else { return }
        switch recognizer.state {
        case .began:
            lastPanTranslationPixels = .zero
            resumePump(resetBackoff: true)
        case .changed:
            let translationPixels = CGPoint(
                x: recognizer.translation(in: self).x * renderScale,
                y: recognizer.translation(in: self).y * renderScale
            )
            let deltaXPixels = translationPixels.x - lastPanTranslationPixels.x
            let deltaYPixels = translationPixels.y - lastPanTranslationPixels.y
            lastPanTranslationPixels = translationPixels
            guard deltaXPixels != 0 || deltaYPixels != 0 else { return }
            panByScreenPixels(
                deltaXPixels: Double(deltaXPixels),
                deltaYPixels: Double(deltaYPixels),
                isGestureDriven: true
            )
        case .ended, .cancelled, .failed:
            lastPanTranslationPixels = .zero
        default:
            break
        }
    }

    @objc private func handlePinchGesture(_ recognizer: UIPinchGestureRecognizer) {
        guard isGestureEnabled else { return }
        switch recognizer.state {
        case .began:
            resumePump(resetBackoff: true)
        case .changed:
            let scale = recognizer.scale
            recognizer.scale = 1
            guard scale > 0 else { return }
            let zoomLevels = log2(Double(scale))
            guard zoomLevels != 0 else { return }
            transformCamera(
                zoomLevels: zoomLevels,
                focalPoint: renderPixelPoint(of: recognizer.location(in: self)),
                isGestureDriven: true
            )
        default:
            break
        }
    }

    @objc private func handleRotationGesture(
        _ recognizer: UIRotationGestureRecognizer
    ) {
        guard isGestureEnabled else { return }
        switch recognizer.state {
        case .began:
            resumePump(resetBackoff: true)
        case .changed:
            let rotationRadians = recognizer.rotation
            recognizer.rotation = 0
            let rotationDegrees = Double(rotationRadians) * degreesPerRadian
            guard rotationDegrees != 0 else { return }
            rotateCamera(
                clockwiseDegrees: rotationDegrees,
                focalPoint: renderPixelPoint(of: recognizer.location(in: self)),
                isGestureDriven: true
            )
        default:
            break
        }
    }

    @objc private func handleTapGesture(_ recognizer: UITapGestureRecognizer) {
        guard isGestureEnabled, recognizer.state == .ended else { return }
        guard let viewport = viewportSize,
              let camera = currentCameraOrNil()
        else {
            return
        }
        do {
            let coordinate = try camera.screenToGroundCoordinate(
                screenPoint: renderPixelPoint(of: recognizer.location(in: self)),
                viewport: viewport,
                fieldOfViewDegrees: MapsSdkRusticMapView.defaultFieldOfViewDegrees
            )
            if let coordinate {
                delegate?.mapView(self, didClickCoordinate: coordinate)
            }
        } catch {
            reportFailure(phase: .tap, cause: error)
        }
    }

    @objc private func handleDoubleTapGesture(_ recognizer: UITapGestureRecognizer) {
        guard isGestureEnabled, recognizer.state == .ended else { return }
        transformCamera(
            zoomLevels: MapsSdkRusticMapView.doubleTapZoomStep,
            focalPoint: renderPixelPoint(of: recognizer.location(in: self)),
            isGestureDriven: true
        )
    }

    // MARK: Helpers

    private func reportFailure(phase: MapsSdkMapViewFailurePhase, cause: Error) {
        delegate?.mapView(
            self,
            didFailWith: MapsSdkMapViewFailure(phase: phase, cause: cause)
        )
    }

    /// One eased camera move in flight (the pump advances it every tick).
    private struct CameraAnimation {
        let startTime: CFTimeInterval
        let durationSeconds: Double
        let fromPose: MapsSdkCameraPose
        let toPose: MapsSdkCameraPose
    }

    /// The zero edge insets of `fitBounds`' natural default.
    public nonisolated static let zeroEdgeInsets = EdgeInsets(
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
    )

    /// Radians-to-degrees conversion of the two-finger rotation angle.
    private var degreesPerRadian: Double { 180 / Double.pi }
}

extension MapsSdkRusticMapView: UIGestureRecognizerDelegate {
    /// The pinch and rotation recognizers run together, so a two-finger
    /// move can zoom and turn at once (the map's own gesture algebra
    /// composes both members). The tap pair never recognizes together: the
    /// single tap is required to wait for the double tap to fail (§5.2).
    public func gestureRecognizer(
        _ gestureRecognizer: UIGestureRecognizer,
        shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
    ) -> Bool {
        let tapRecognizers = gestureRecognizersList.filter { recognizer in
            recognizer is UITapGestureRecognizer
        }
        let bothAreTaps = tapRecognizers.contains(gestureRecognizer)
            && tapRecognizers.contains(otherGestureRecognizer)
        return !bothAreTaps
    }
}

/// Linear interpolation between `from` and `to` at `fraction`.
private func interpolate(_ from: Double, _ to: Double, _ fraction: Double) -> Double {
    from + (to - from) * fraction
}

/// The smoothstep ease used by camera animations
/// (`docs/ReferenceAppUX.md` §5.3).
private func smoothstepFraction(_ fraction: Double) -> Double {
    fraction * fraction * (3 - 2 * fraction)
}

/// Wraps an angle in degrees into `[0, 360)`.
private func normalizeDegrees(_ angleDegrees: Double) -> Double {
    let wrapped = angleDegrees.truncatingRemainder(dividingBy: fullCircleDegrees)
    return wrapped < 0 ? wrapped + fullCircleDegrees : wrapped
}

/// Interpolates a bearing along the shortest angular path, so a move from
/// 350° to 10° turns 20° clockwise instead of 340° counter-clockwise.
private func interpolateBearingDegrees(
    _ fromDegrees: Double,
    _ toDegrees: Double,
    _ fraction: Double
) -> Double {
    var deltaDegrees = (toDegrees - fromDegrees)
        .truncatingRemainder(dividingBy: fullCircleDegrees)
    if deltaDegrees > halfCircleDegrees {
        deltaDegrees -= fullCircleDegrees
    } else if deltaDegrees < -halfCircleDegrees {
        deltaDegrees += fullCircleDegrees
    }
    return normalizeDegrees(fromDegrees + deltaDegrees * fraction)
}

/// One full turn in degrees (structural math).
private let fullCircleDegrees: Double = 360

/// Half a turn in degrees (structural math).
private let halfCircleDegrees: Double = 180
