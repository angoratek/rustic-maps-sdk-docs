/**
 * The typed React Native `MapView` component shipped with the package.
 *
 * The native half (Android: the AAR's lifecycle-aware `MapView` widget, iOS:
 * the `MapNativeCoreUI` view compiled into the pod) owns the surface, the
 * frame pump, gestures, the camera value store and animation, the overlay and
 * location-layer bookkeeping and the listener. This component exposes exactly
 * that native shape to JavaScript:
 *
 * - props: the four safe-area inset props (physical pixels), gesture and
 *   render-pause switches, and one callback per native listener method;
 * - imperative calls on the forwarded ref: the camera verbs, the pan/zoom
 *   gesture members, the id-addressed overlay calls, the location layer, the
 *   attach retry and the readbacks;
 * - the callbacks the native listener delivers: map ready, camera changed,
 *   map click, failure, frame statistics, deferred and settled frames.
 *
 * The SDK object is owned by the package's native module (see `MapsSdk.ts`);
 * it is deliberately not a prop, because the generated JSI bindings cannot
 * import a foreign handle and a second `MapSdk` would open a second tile
 * cache. Initialize the package SDK once (`await MapsSdk.create()`) before
 * mounting the view; the view attaches as soon as the SDK is available.
 */

import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import {
  DeviceEventEmitter,
  NativeEventEmitter,
  NativeModules,
  Platform,
  requireNativeComponent,
} from 'react-native';
import type { StyleProp, ViewStyle } from 'react-native';

import type {
  BoundingBox,
  EdgeInsets,
  FrameStatistics,
  GeographicCoordinate,
  LocationIndicatorState,
  LocationIndicatorStyle,
  MapOverlay,
} from './generated/rustic_maps';
import type {
  UrlTemplateVectorTileSource,
  VectorTileSourceStatus,
} from './MapsSdk';

// The record types the component's calls speak are re-exported beside it, so
// a consumer imports one module for the component and its payload shapes.
export type {
  BoundingBox,
  EdgeInsets,
  FrameStatistics,
  GeographicCoordinate,
  LocationIndicatorState,
  LocationIndicatorStyle,
  MapOverlay,
  MapOverlayKind,
  LocationIndicatorVisualKind,
  OverlayColor,
} from './generated/rustic_maps';

/** The camera value the native `MapView` adopts and reads back. */
export interface MapCamera {
  /** Camera center latitude in decimal degrees. */
  latitudeDegrees: number;
  /** Camera center longitude in decimal degrees. */
  longitudeDegrees: number;
  /** Zoom level. */
  zoomLevel: number;
  /** Bearing in degrees clockwise from true north. */
  bearingDegrees: number;
  /** Pitch in degrees; zero is top-down. */
  pitchDegrees: number;
}

/** Which native `MapView` operation produced a `MapViewFailure`. */
export type MapViewFailurePhase =
  | 'surface'
  | 'resize'
  | 'draw'
  | 'camera'
  | 'overlay'
  | 'locationIndicator'
  | 'baseMap'
  | 'tap';

/** One refused native `MapView` operation, carrying its verbatim failure. */
export interface MapViewFailure {
  /** The wrapper operation that failed. */
  phase: MapViewFailurePhase;
  /** The verbatim SDK or platform failure message. */
  message: string;
}

/**
 * The callbacks the native `MapView` listener delivers on the main thread;
 * every one is optional, exactly like the native listener's empty defaults.
 */
export interface MapViewProps {
  /** Layout style; the native view fills its parent by default. */
  style?: StyleProp<ViewStyle>;
  /** Test identifier forwarded to the native view. */
  testID?: string;
  /** Safe-area inset on the top edge, in physical pixels. */
  topBarInsetPixels?: number;
  /** Safe-area inset on the bottom edge, in physical pixels. */
  bottomBarInsetPixels?: number;
  /** Safe-area inset on the left edge, in physical pixels. */
  leftBarInsetPixels?: number;
  /** Safe-area inset on the right edge, in physical pixels. */
  rightBarInsetPixels?: number;
  /** Whether touch gestures pan, pinch and rotate the camera (default true). */
  isGestureEnabled?: boolean;
  /** Pauses or resumes drawing explicitly (default false). */
  isRenderingPaused?: boolean;
  /** The first frame drew and presented successfully. */
  onMapReady?: () => void;
  /** The adopted camera changed: a set, an animation step, a gesture or a fit. */
  onCameraChanged?: (camera: MapCamera, isGestureDriven: boolean) => void;
  /** A tap unprojected onto the ground plane; a miss reports nothing. */
  onMapClick?: (coordinate: GeographicCoordinate) => void;
  /** An SDK or platform operation failed; the failure is never swallowed. */
  onError?: (failure: MapViewFailure) => void;
  /** One presented frame's tile and overlay accounting. */
  onFrameStatistics?: (statistics: FrameStatistics) => void;
  /** A frame was skipped by the serialized-draw backpressure; the next retries. */
  onFrameDeferred?: () => void;
  /** The pump paused because the presented frame is settled. */
  onFrameSettled?: () => void;
}

/** The imperative calls the component forwards to the native view. */
export interface MapViewHandle {
  /** Sets the camera immediately; a refused pose reports through `onError`. */
  setCamera(camera: MapCamera): void;
  /** Eases the camera to the pose over `durationMilliseconds`. */
  animateCamera(camera: MapCamera, durationMilliseconds?: number): void;
  /** Frames the bounds inside the viewport's inset region. */
  fitBounds(
    boundingBox: BoundingBox,
    edgeInsets?: EdgeInsets,
    maximumZoomLevel?: number,
  ): void;
  /** Pans by a screen-pixel delta through the contract camera member. */
  panByScreenPixels(
    deltaXPixels: number,
    deltaYPixels: number,
    isGestureDriven?: boolean,
  ): void;
  /** Zooms by levels around the viewport center through the contract member. */
  zoomByLevels(deltaZoomLevels: number): void;
  /** Adds or replaces the overlay held under `overlayIdentifier`. */
  addOverlay(overlayIdentifier: string, overlay: MapOverlay): Promise<boolean>;
  /** Replaces the overlay held under `overlayIdentifier`. */
  updateOverlay(overlayIdentifier: string, overlay: MapOverlay): Promise<boolean>;
  /** Removes the overlay held under `overlayIdentifier`. */
  removeOverlay(overlayIdentifier: string): Promise<boolean>;
  /** Replaces the whole overlay list (resets the identifier bookkeeping). */
  setOverlays(overlays: ReadonlyArray<MapOverlay>): Promise<boolean>;
  /** Clears every overlay and the identifier bookkeeping. */
  clearOverlays(): Promise<boolean>;
  /** Sets the renderer-owned location layer. */
  setLocationIndicator(
    state: LocationIndicatorState,
    style: LocationIndicatorStyle,
  ): void;
  /** Clears the location layer. */
  clearLocationIndicator(): void;
  /**
   * Installs a styled vector base map (M22): a provider-neutral vector
   * tileset painted with one of the SDK's committed styles, drawn over the
   * raster tiles and beneath every overlay. Resolves `true` once the SDK
   * accepted it; a refusal reports through the view's failure event.
   */
  setVectorTileSource(source: UrlTemplateVectorTileSource): Promise<boolean>;
  /** Removes the vector base map; resolves `true` once the SDK accepted. */
  clearVectorTileSource(): Promise<boolean>;
  /** The vector base source's status readback, or null before the view exists. */
  getVectorTileSourceStatus(): Promise<VectorTileSourceStatus | null>;
  /** Retries a failed surface attach. */
  retryAttach(): void;
  /**
   * Re-resolves the SDK's raster-tile provider and drops every pooled tile,
   * so a provider registered after this view attached serves the next frame.
   * The native view detaches and re-attaches its surface internally and
   * restores its camera, overlays, location indicator and listeners, exactly
   * as after any re-attach.
   */
  reloadRasterTileSource(): void;
  /** Pauses or resumes drawing explicitly. */
  setRenderingPaused(paused: boolean): void;
  /** The last camera the view adopted, or null before the first change. */
  getCamera(): MapCamera | null;
  /** Ground meters represented by one screen pixel, or null before attach. */
  groundMetersPerScreenPixel(): Promise<number | null>;
}

/** One native view event on the package's event channel. */
interface NativeMapViewEvent {
  viewIdentifier: string;
  event: string;
  camera?: MapCamera;
  isGestureDriven?: boolean;
  coordinate?: GeographicCoordinate;
  failurePhase?: MapViewFailurePhase;
  failureMessage?: string;
  statistics?: FrameStatistics;
}

/** The package's native module surface this component uses. */
interface MapsSdkNativeModule {
  setCamera(viewIdentifier: string, cameraJson: string): void;
  animateCamera(
    viewIdentifier: string,
    cameraJson: string,
    durationMilliseconds: number,
  ): void;
  fitBounds(
    viewIdentifier: string,
    boundingBoxJson: string,
    edgeInsetsJson: string,
    maximumZoomLevel: number,
  ): void;
  panByScreenPixels(
    viewIdentifier: string,
    deltaXPixels: number,
    deltaYPixels: number,
    isGestureDriven: boolean,
  ): void;
  zoomByLevels(viewIdentifier: string, deltaZoomLevels: number): void;
  addOverlay(
    viewIdentifier: string,
    overlayIdentifier: string,
    overlayJson: string,
  ): Promise<boolean>;
  updateOverlay(
    viewIdentifier: string,
    overlayIdentifier: string,
    overlayJson: string,
  ): Promise<boolean>;
  removeOverlay(
    viewIdentifier: string,
    overlayIdentifier: string,
  ): Promise<boolean>;
  setOverlays(
    viewIdentifier: string,
    overlaysJson: string,
  ): Promise<boolean>;
  clearOverlays(viewIdentifier: string): Promise<boolean>;
  setLocationIndicator(
    viewIdentifier: string,
    stateJson: string,
    styleJson: string,
  ): void;
  clearLocationIndicator(viewIdentifier: string): void;
  setVectorTileSource(
    viewIdentifier: string,
    sourceJson: string,
  ): Promise<boolean>;
  clearVectorTileSource(viewIdentifier: string): Promise<boolean>;
  getVectorTileSourceStatus(viewIdentifier: string): Promise<string>;
  retryAttach(viewIdentifier: string): void;
  reloadRasterTileSource(viewIdentifier: string): void;
  setRenderingPaused(viewIdentifier: string, paused: boolean): void;
  getCamera(viewIdentifier: string): Promise<string | null>;
  groundMetersPerScreenPixel(viewIdentifier: string): Promise<number | null>;
}

/** The event channel both native halves emit on (one named event). */
const nativeMapViewEventName = 'MapsSdkMapViewEvent';

/** The native view manager's registered component name. */
const nativeMapViewComponentName = 'MapsSdkMapView';

/** The default camera animation duration (`docs/ReferenceAppUX.md` §5.3). */
const defaultCameraAnimationDurationMilliseconds = 300;

/** The SDK's maximum zoom level, the native fit-bounds ceiling. */
const defaultFitBoundsMaximumZoomLevel = 24;

/** No insets, the natural default of `fitBounds`. */
const zeroEdgeInsets: EdgeInsets = { left: 0, top: 0, right: 0, bottom: 0 };

/** The package's native module, or null when the native half is absent. */
const nativeModule: MapsSdkNativeModule | null =
  (NativeModules as Record<string, MapsSdkNativeModule | undefined>)
    .MapsSdkNative ?? null;

/** A stable, process-unique identifier the native view registry keys on. */
let nextViewIdentifier = 0;

function allocateViewIdentifier(): string {
  nextViewIdentifier += 1;
  return `maps-sdk-map-${nextViewIdentifier}`;
}

/** The native component (the view manager creates the native host view). */
const NativeMapView = requireNativeComponent<{
  style?: StyleProp<ViewStyle>;
  testID?: string;
  viewIdentifier: string;
  topBarInsetPixels: number;
  bottomBarInsetPixels: number;
  leftBarInsetPixels: number;
  rightBarInsetPixels: number;
  isGestureEnabled: boolean;
  isRenderingPaused: boolean;
}>(nativeMapViewComponentName);

/**
 * Subscribes to the package's single native view event channel.
 *
 * Android's device-event emitter delivers unconditionally; the iOS
 * `RCTEventEmitter` only emits when a JS listener is registered on the module
 * itself, so the subscription goes through `NativeEventEmitter` there (the
 * same platform split the reference shell already uses).
 */
function subscribeToNativeMapViewEvents(
  handler: (event: NativeMapViewEvent) => void,
): () => void {
  if (Platform.OS === 'ios' && nativeModule !== null) {
    const moduleEmitter = new NativeEventEmitter(
      nativeModule as unknown as {
        addListener(eventName: string): void;
        removeListeners(count: number): void;
      },
    );
    const subscription = moduleEmitter.addListener(
      nativeMapViewEventName,
      handler as (event: unknown) => void,
    );
    return () => subscription.remove();
  }
  const subscription = DeviceEventEmitter.addListener(
    nativeMapViewEventName,
    handler,
  );
  return () => subscription.remove();
}

/**
 * The typed map component. Hold its ref to drive the native view:
 *
 * ```tsx
 * const mapView = useRef<MapViewHandle>(null);
 * await MapsSdk.create();
 * <MapView ref={mapView} onMapReady={() => mapView.current?.setCamera(...)} />
 * ```
 */
export const MapView = forwardRef<MapViewHandle, MapViewProps>(
  function MapView(props, ref): React.JSX.Element {
    const [viewIdentifier] = useState(allocateViewIdentifier);
    const lastCameraRef = useRef<MapCamera | null>(null);
    const propsRef = useRef(props);
    propsRef.current = props;

    useEffect(() => {
      return subscribeToNativeMapViewEvents(nativeEvent => {
        if (nativeEvent.viewIdentifier !== viewIdentifier) {
          return;
        }
        const currentProps = propsRef.current;
        switch (nativeEvent.event) {
          case 'mapReady':
            currentProps.onMapReady?.();
            break;
          case 'cameraChanged':
            if (nativeEvent.camera !== undefined) {
              lastCameraRef.current = nativeEvent.camera;
              currentProps.onCameraChanged?.(
                nativeEvent.camera,
                nativeEvent.isGestureDriven === true,
              );
            }
            break;
          case 'mapClick':
            if (nativeEvent.coordinate !== undefined) {
              currentProps.onMapClick?.(nativeEvent.coordinate);
            }
            break;
          case 'error':
            currentProps.onError?.({
              phase: nativeEvent.failurePhase ?? 'draw',
              message: nativeEvent.failureMessage ?? '',
            });
            break;
          case 'frameStatistics':
            if (nativeEvent.statistics !== undefined) {
              currentProps.onFrameStatistics?.(nativeEvent.statistics);
            }
            break;
          case 'frameDeferred':
            currentProps.onFrameDeferred?.();
            break;
          case 'frameSettled':
            currentProps.onFrameSettled?.();
            break;
          default:
            break;
        }
      });
    }, [viewIdentifier]);

    const applyRenderingPaused = useCallback(
      (paused: boolean) => {
        nativeModule?.setRenderingPaused(viewIdentifier, paused);
      },
      [viewIdentifier],
    );

    // The declarative pause prop mirrors the native property; an explicit
    // handle call wins until the prop changes again.
    useEffect(() => {
      applyRenderingPaused(props.isRenderingPaused === true);
    }, [applyRenderingPaused, props.isRenderingPaused]);

    useImperativeHandle(
      ref,
      (): MapViewHandle => ({
        setCamera(camera) {
          nativeModule?.setCamera(viewIdentifier, JSON.stringify(camera));
        },
        animateCamera(camera, durationMilliseconds) {
          nativeModule?.animateCamera(
            viewIdentifier,
            JSON.stringify(camera),
            durationMilliseconds ?? defaultCameraAnimationDurationMilliseconds,
          );
        },
        fitBounds(boundingBox, edgeInsets, maximumZoomLevel) {
          nativeModule?.fitBounds(
            viewIdentifier,
            JSON.stringify(boundingBox),
            JSON.stringify(edgeInsets ?? zeroEdgeInsets),
            maximumZoomLevel ?? defaultFitBoundsMaximumZoomLevel,
          );
        },
        panByScreenPixels(deltaXPixels, deltaYPixels, isGestureDriven) {
          nativeModule?.panByScreenPixels(
            viewIdentifier,
            deltaXPixels,
            deltaYPixels,
            isGestureDriven ?? true,
          );
        },
        zoomByLevels(deltaZoomLevels) {
          nativeModule?.zoomByLevels(viewIdentifier, deltaZoomLevels);
        },
        addOverlay(overlayIdentifier, overlay) {
          return (
            nativeModule?.addOverlay(
              viewIdentifier,
              overlayIdentifier,
              JSON.stringify(overlay),
            ) ?? Promise.resolve(false)
          );
        },
        updateOverlay(overlayIdentifier, overlay) {
          return (
            nativeModule?.updateOverlay(
              viewIdentifier,
              overlayIdentifier,
              JSON.stringify(overlay),
            ) ?? Promise.resolve(false)
          );
        },
        removeOverlay(overlayIdentifier) {
          return (
            nativeModule?.removeOverlay(viewIdentifier, overlayIdentifier) ??
            Promise.resolve(false)
          );
        },
        setOverlays(overlays) {
          return (
            nativeModule?.setOverlays(
              viewIdentifier,
              JSON.stringify(overlays),
            ) ?? Promise.resolve(false)
          );
        },
        clearOverlays() {
          return (
            nativeModule?.clearOverlays(viewIdentifier) ?? Promise.resolve(false)
          );
        },
        setLocationIndicator(state, style) {
          nativeModule?.setLocationIndicator(
            viewIdentifier,
            JSON.stringify(state),
            JSON.stringify(style),
          );
        },
        clearLocationIndicator() {
          nativeModule?.clearLocationIndicator(viewIdentifier);
        },
        setVectorTileSource(source) {
          return (
            nativeModule?.setVectorTileSource(
              viewIdentifier,
              JSON.stringify(source),
            ) ?? Promise.resolve(false)
          );
        },
        clearVectorTileSource() {
          return (
            nativeModule?.clearVectorTileSource(viewIdentifier) ??
            Promise.resolve(false)
          );
        },
        async getVectorTileSourceStatus() {
          const statusJson =
            (await nativeModule?.getVectorTileSourceStatus(viewIdentifier)) ??
            '{}';
          try {
            const status = JSON.parse(statusJson) as VectorTileSourceStatus;
            return status.isConfigured ? status : null;
          } catch {
            return null;
          }
        },
        retryAttach() {
          nativeModule?.retryAttach(viewIdentifier);
        },
        reloadRasterTileSource() {
          nativeModule?.reloadRasterTileSource(viewIdentifier);
        },
        setRenderingPaused(paused) {
          applyRenderingPaused(paused);
        },
        getCamera() {
          return lastCameraRef.current;
        },
        groundMetersPerScreenPixel() {
          return (
            nativeModule?.groundMetersPerScreenPixel(viewIdentifier) ??
            Promise.resolve(null)
          );
        },
      }),
      [applyRenderingPaused, viewIdentifier],
    );

    return (
      <NativeMapView
        style={props.style}
        testID={props.testID}
        viewIdentifier={viewIdentifier}
        topBarInsetPixels={props.topBarInsetPixels ?? 0}
        bottomBarInsetPixels={props.bottomBarInsetPixels ?? 0}
        leftBarInsetPixels={props.leftBarInsetPixels ?? 0}
        rightBarInsetPixels={props.rightBarInsetPixels ?? 0}
        isGestureEnabled={props.isGestureEnabled !== false}
        isRenderingPaused={props.isRenderingPaused === true}
      />
    );
  },
);

export default MapView;
