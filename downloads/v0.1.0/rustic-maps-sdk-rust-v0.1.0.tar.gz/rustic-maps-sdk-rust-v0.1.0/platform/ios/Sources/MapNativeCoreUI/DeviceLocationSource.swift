import CoreLocation
import RusticMapsSDK

/// Feeds Core Location into the contract's `PositionController`.
///
/// The application owns the authorization prompt (its Info.plist declares
/// `NSLocationWhenInUseUsageDescription`) and calls ``start()`` after the user
/// grants it. The source reports every fix to the controller with the
/// platform's accuracy, course and timestamp; authorization and service
/// failures are reported to the controller and to the optional failure
/// closure, so the controller's state and the UI agree.
///
/// One controller per map session is shared by the location indicator, the
/// follow camera and the navigator, so this source takes it rather than
/// creating one.
public final class DeviceLocationSource: NSObject, CLLocationManagerDelegate {
    /// The controller every fix and failure is reported to.
    public let positionController: PositionController

    /// The platform's location manager.
    private let locationManager = CLLocationManager()

    /// Receives a refused fix's verbatim detail, when the application wants it.
    private let onPositioningFailure: ((String) -> Void)?

    /// Receives every accepted fix, when the application wants to present it.
    private let onFix: ((PositionFix) -> Void)?

    /// Receives a resolved authorization status, so the application can start
    /// the source the visitor asked for once the prompt is answered.
    private let onAuthorizationResolved: ((CLAuthorizationStatus) -> Void)?

    /// Whether the caller has asked for updates. The prompt is answered
    /// asynchronously, so the request outlives the first ``start()``.
    private var wantsUpdates = false

    /// Whether the source is currently updating.
    public private(set) var isActive = false

    /// Builds the source over a controller, without starting it.
    public init(
        positionController: PositionController,
        onPositioningFailure: ((String) -> Void)? = nil,
        onFix: ((PositionFix) -> Void)? = nil,
        onAuthorizationResolved: ((CLAuthorizationStatus) -> Void)? = nil
    ) {
        self.positionController = positionController
        self.onPositioningFailure = onPositioningFailure
        self.onFix = onFix
        self.onAuthorizationResolved = onAuthorizationResolved
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = Self.minimumDistanceMeters
    }

    /// The current authorization status.
    public var authorizationStatus: CLAuthorizationStatus {
        locationManager.authorizationStatus
    }

    /// Asks for when-in-use authorization. The application calls this before
    /// ``start()`` while the status is `.notDetermined`.
    public func requestWhenInUseAuthorization() {
        locationManager.requestWhenInUseAuthorization()
    }

    /// Starts location updates. Answers `false` when the permission is
    /// undetermined (the prompt was requested and the caller should retry
    /// after it resolves), denied or restricted, or when location services are
    /// disabled; the controller records the failure.
    @discardableResult
    public func start() -> Bool {
        wantsUpdates = true
        if isActive {
            return true
        }
        switch locationManager.authorizationStatus {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
            return false
        case .denied, .restricted:
            positionController.sourceFailed(error: .permissionDenied)
            return false
        case .authorizedAlways, .authorizedWhenInUse:
            break
        @unknown default:
            positionController.sourceFailed(error: .unavailable)
            return false
        }
        guard CLLocationManager.locationServicesEnabled() else {
            positionController.sourceFailed(error: .serviceDisabled)
            return false
        }
        locationManager.startUpdatingLocation()
        isActive = true
        return true
    }

    /// Stops location updates; a later ``start()`` resumes the same controller.
    public func stop() {
        wantsUpdates = false
        locationManager.stopUpdatingLocation()
        isActive = false
    }

    /// Starts the updates the visitor asked for once the authorization prompt
    /// resolves, and reports the resolved status to the application. A
    /// permission refusal is reported through the controller's source status.
    public func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        // Core Location reports the current status when the delegate is
        // installed; only a status that answers the caller's request is the
        // application's to act on.
        guard wantsUpdates else { return }
        onAuthorizationResolved?(manager.authorizationStatus)
        guard !isActive else { return }
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            start()
        case .denied, .restricted:
            positionController.sourceFailed(error: .permissionDenied)
        case .notDetermined:
            break
        @unknown default:
            positionController.sourceFailed(error: .unavailable)
        }
    }

    /// Reports one platform fix to the controller.
    public func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        guard let location = locations.last else { return }
        let positionFix = PositionFix(
            coordinate: GeographicCoordinate(
                latitude: location.coordinate.latitude,
                longitude: location.coordinate.longitude
            ),
            horizontalAccuracyMeters: location.horizontalAccuracy >= 0
                ? location.horizontalAccuracy : nil,
            courseHeadingDegrees: location.course >= 0 ? location.course : nil,
            timestampSeconds: location.timestamp.timeIntervalSince1970
        )
        do {
            try positionController.feedFix(fix: positionFix)
            onFix?(positionFix)
        } catch {
            onPositioningFailure?(String(describing: error))
        }
    }

    /// Reports a source failure to the controller.
    public func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        positionController.sourceFailed(error: Self.sourceError(for: error))
        onPositioningFailure?(error.localizedDescription)
    }

    /// Maps a Core Location failure onto the contract's source status.
    private static func sourceError(for error: Error) -> PositionSourceError {
        guard let coreLocationError = error as? CLError else {
            return .unavailable
        }
        switch coreLocationError.code {
        case .denied:
            return .permissionDenied
        case .locationUnknown:
            return .unavailable
        default:
            return .unavailable
        }
    }

    /// The shortest movement between delivered fixes, in meters.
    private static let minimumDistanceMeters: CLLocationDistance = 1
}
