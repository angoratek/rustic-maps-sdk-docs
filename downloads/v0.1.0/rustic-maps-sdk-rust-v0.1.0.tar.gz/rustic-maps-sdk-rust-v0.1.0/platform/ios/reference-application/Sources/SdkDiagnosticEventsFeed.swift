//! The diagnostics sheet's recent-events readout (docs/ReferenceAppUX.md
//! §4.1, round 10): the contract's `SdkDiagnosticEventListener` foreign
//! callback bounded to a main-actor buffer the sheet renders oldest-first.
//! The live Debug stream runs at several events per presented frame, so the
//! buffer's published list refreshes on a slower cadence (§2.4's pane
//! cadence) and the frame pump never waits on the sheet's SwiftUI churn.

import Combine
import Foundation
import RusticMapsSDK

/// The main-actor buffer of recent structured diagnostic events (round 10).
/// Deliveries land in a pending list the cadence merge flushes into the
/// published, capacity-bounded oldest-first list; the events themselves
/// keep flowing (the ring the SDK streams from is the SDK's own).
@MainActor
final class SdkDiagnosticEventsBuffer: ObservableObject {
    /// The oldest-first events of the readout, newest at the end.
    @Published private(set) var events: [LogEvent] = []

    /// The deliveries since the last cadence merge (the un-published side).
    private var pendingEvents: [LogEvent] = []

    /// The repeating merge timer (armed by the feed's start; a 2 Hz
    /// main-actor tick, never on the SDK's producer threads).
    private var refreshTimer: Timer?

    private var capacity: Int {
        ReferenceApplicationConfiguration.diagnosticsEventsBufferedCapacity
    }

    init() {}

    /// Arms the cadence merge (idempotent: the sheet's every open calls
    /// this; the first call owns the one timer).
    func startRefreshCadence() {
        guard refreshTimer == nil else { return }
        let scheduledRefreshTimer = Timer.scheduledTimer(
            withTimeInterval:
                ReferenceApplicationConfiguration
                    .diagnosticsEventsRefreshCadenceSeconds,
            repeats: true
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.mergePendingEvents()
            }
        }
        refreshTimer = scheduledRefreshTimer
    }

    /// Merges the pending deliveries into the published list (one SwiftUI
    /// change per tick, the pending list capacity-trimmed first so a whole
    /// cadence of floods past the capacity never accumulates in the
    /// published list).
    private func mergePendingEvents() {
        guard !pendingEvents.isEmpty else { return }
        events.append(contentsOf: pendingEvents)
        pendingEvents.removeAll()
        if events.count > capacity {
            events.removeFirst(events.count - capacity)
        }
    }

    func clear() {
        pendingEvents.removeAll()
        events = []
    }

    /// Records one delivered event (live or flushed), dropping the oldest
    /// past the capacity at the next merge.
    func record(event: LogEvent) {
        pendingEvents.append(event)
    }
}

/// The main-actor hop of the contract's diagnostic listener: the FFI
/// delivers fire-and-forget on whatever thread produced the event; the hop
/// moves the copy into the buffer (the listener never blocks the producer —
/// the fire-and-forget contract's one rule).
final class MainActorDiagnosticEventListener: SdkDiagnosticEventListener {
    /// The buffer the events land in (appended oldest-first).
    private weak var buffer: SdkDiagnosticEventsBuffer?

    init(buffer: SdkDiagnosticEventsBuffer) {
        self.buffer = buffer
    }

    func onDiagnosticEvent(event: LogEvent) {
        let forwardedEvent = event
        Task { @MainActor [weak self] in
            self?.buffer?.record(event: forwardedEvent)
        }
    }
}