//! The round-10 map-control support values (docs/ReferenceAppUX.md §4.2,
//! §5.3): the scale bar's readout and the §2.4 1-2-3-5-10 distance ladder
//! over `ground_meters_per_screen_pixel`, the compass tap's bearing ease
//! the frame pump runs, the course-median smoothing of the follow camera,
//! and the pre-trip camera snapshot the follow camera restores after.

import CoreGraphics
import Foundation
import MapNativeCoreUI

/// The scale bar's readout for one drawn camera: the clean ladder distance
/// and the pixel width it renders at.
struct ScaleBarReadout: Equatable {
    /// The bar's labeled distance, in meters (a 1-2-3-5-10-ladder value).
    let distanceMeters: Double
    /// The bar's rendered width in pixels — the honest width the distance
    /// measures at the camera (never clamped into the target range).
    let barWidthPixels: CGFloat
}

/// The scale-bar formatting over the contract's
/// `ground_meters_per_screen_pixel` helper (§4.2): the largest 1-2-3-5-10
/// ladder distance whose pixel width fits the §2.4 width range's maximum,
/// falling back to a clean low-ladder scale when the camera sits far off
/// the range (the ladder covers the whole zoom range; the fallback is the
/// honest floor at extreme zooms).
enum ScaleBarLadderFormatting {
    /// The 1-2-3-5-10 distance ladder's base multipliers (§2.4).
    private static let distanceLadderMultipliers: [Double] = [1, 2, 3, 5, 10]

    /// The decade exponents the ladder's multipliers scale across — 10⁻²…10⁹
    /// meters, the Compose and web mirror's same scan range (every usable
    /// zoom the camera clamps to fits inside it).
    private static let distanceLadderDecadeRange: ClosedRange<Int> = -2...9

    /// The meters in one kilometer (the phrase boundary).
    private static let kilometersThresholdMeters: Double = 1000

    /// Picks the ladder readout for one camera: `groundMetersPerPixel` per
    /// the contract helper's value at the drawn camera and the §2.4
    /// pixel-width target range. The largest ladder distance whose width
    /// does not exceed the maximum is chosen when its width also reaches the
    /// minimum; a non-finite or non-positive ground answer, or a width below
    /// the minimum, selects nothing (the bar then renders no bar rather than
    /// an invented distance — the Compose/RN mirror's rule).
    static func readout(
        groundMetersPerPixel: Double,
        minimumWidthPixels: CGFloat,
        maximumWidthPixels: CGFloat
    ) -> ScaleBarReadout? {
        guard groundMetersPerPixel.isFinite, groundMetersPerPixel > 0 else {
            return nil
        }
        let maximumDistanceMeters = Double(maximumWidthPixels) * groundMetersPerPixel
        // The largest ladder candidate at or under the range's maximum; the
        // ladder is ascending by construction (multipliers × decades).
        guard let chosenDistanceMeters = ladderCandidatesMeters().last(where: {
            $0 <= maximumDistanceMeters
        }) else {
            return nil
        }
        let barWidthPixels = CGFloat(chosenDistanceMeters / groundMetersPerPixel)
        guard barWidthPixels >= minimumWidthPixels else {
            return nil
        }
        return ScaleBarReadout(
            distanceMeters: chosenDistanceMeters,
            barWidthPixels: barWidthPixels
        )
    }

    /// The bar's label phrase: whole meters below the kilometer boundary,
    /// whole rounded kilometers at and above it (the Android/RN/web mirrors'
    /// same label rule).
    static func phrase(forDistanceMeters distanceMeters: Double) -> String {
        if distanceMeters < kilometersThresholdMeters {
            return "\(Int(distanceMeters)) m"
        }
        let distanceKilometers = distanceMeters / kilometersThresholdMeters
        return "\(Int(distanceKilometers.rounded())) km"
    }

    /// The ladder's distances in meters, ascending: {1,2,3,5,10} × decades.
    private static func ladderCandidatesMeters() -> [Double] {
        var candidates: [Double] = []
        for decadeExponent in distanceLadderDecadeRange {
            let decadeScale = pow(10, Double(decadeExponent))
            candidates.append(
                contentsOf: distanceLadderMultipliers.map { $0 * decadeScale }
            )
        }
        return candidates.sorted()
    }
}

/// The bearing a camera carries modulo the full turn, wrapped into the
/// [0, 360) range the camera constructor takes (structural math).
func wrappedBearingDegrees(_ bearingDegrees: Double) -> Double {
    let fullTurnDegrees: Double = 360
    var wrappedBearing = bearingDegrees.truncatingRemainder(dividingBy: fullTurnDegrees)
    if wrappedBearing < 0 {
        wrappedBearing += fullTurnDegrees
    }
    return wrappedBearing
}

/// The pre-trip camera snapshot (§5.3: the framing camera is the pre-trip
/// state, the follow camera the in-trip state; the follow camera is
/// "applied at trip start, restored after").
struct PreTripCameraSnapshot {
    /// The camera values the trip's start interrupted (a fitted framing's
    /// readback is part of these values).
    let cameraValues: ReferenceCameraValues
    /// The selected camera preset the trip interrupted.
    let selectedPresetIdentifier: String?
    /// The 2D/3D pitch mode the trip interrupted (trips start on 3D, §5.3).
    let isThreeDimensionalPitchEnabled: Bool
}

/// The course-follow smoothing (§5.3): the camera's bearing follows the
/// circular median of the last `window` course-over-ground samples, so GPS
/// jitter never swings the camera and a window straddling north resolves
/// correctly (the Compose/RN/web mirror's same rule — a sorted middle value
/// would average 350° and 10° into the wrong direction).
enum CourseFollowSmoothing {
    /// The full circle's degree sweep (structural math).
    private static let fullCircleDegrees: Double = 360
    /// The shortest-way wrap boundary (structural math).
    private static let halfCircleDegrees: Double = 180

    /// The circular median of the smoothing window's samples: the sample
    /// minimizing the sum of shortest angular distances to the rest of the
    /// window, or nil for an empty window.
    static func medianCourseHeadingDegrees(of courses: [Double]) -> Double? {
        guard !courses.isEmpty else { return nil }
        func angularDistanceDegrees(_ firstDegrees: Double, _ secondDegrees: Double) -> Double {
            let absoluteDifference = abs(firstDegrees - secondDegrees)
                .truncatingRemainder(dividingBy: fullCircleDegrees)
            return absoluteDifference > halfCircleDegrees
                ? fullCircleDegrees - absoluteDifference
                : absoluteDifference
        }
        return courses.min { candidateDegrees, otherCandidateDegrees in
            let candidateDistance = courses.reduce(0) { partialDistance, otherDegrees in
                partialDistance + angularDistanceDegrees(candidateDegrees, otherDegrees)
            }
            let otherDistance = courses.reduce(0) { partialDistance, otherDegrees in
                partialDistance + angularDistanceDegrees(otherCandidateDegrees, otherDegrees)
            }
            return candidateDistance < otherDistance
        }
    }
}