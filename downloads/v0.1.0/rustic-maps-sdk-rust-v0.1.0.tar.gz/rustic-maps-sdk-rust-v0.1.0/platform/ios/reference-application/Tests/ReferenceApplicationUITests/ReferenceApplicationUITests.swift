//! The XCUITest suite of the SwiftUI reference application (round 13):
//! the iOS analogue of the Android suite's Espresso coverage
//! (`ReferenceApplicationAndroidTest.kt`) over the same demo-machinery
//! surfaces — the readiness ladder at the peek home sheet, the demo-plan
//! chip row's planned-route demo with the §5.1 fit contract, the trace
//! replay's recorded banner and the verbatim exit restore, the simulated
//! trip's speed/pause/resume playback and its held arrival, the offline
//! card's registered tile cache with the live tile accounting, and the
//! base-map menu's styled vector base with the labels its styles draw.
//!
//! The driving rule mirrors the Android suite: no state is ever forced —
//! the state moves through the application's own launch-argument demo
//! automation (`ReferenceApplicationLaunchAutomation.swift`, the same
//! user-path methods the sheet's controls call) and XCUITest's own taps
//! and drags, and the assertions read the exact lines the accessibility
//! tree renders (docs/ReferenceAppUX.md §1/§4/§6/§7). Determinism rules:
//! every await is a poll on the rendered tree with a named timeout (never
//! a screenshot wait), no test touches the network (the recorded fixtures
//! and the bundled shared demo artifact are the data), and no test logs a
//! host-local configuration value.

import MapNativeCoreUI
import XCTest

/// The condition polls' default bound (the generic assertion settle; a
/// default argument cannot reference the suite's covariant `Self`, so the
/// value lives at file scope).
private let defaultAssertionTimeoutSeconds: TimeInterval = 15

/// The round-13 XCUITest suite over the reference application's demo
/// machinery.
final class ReferenceApplicationUITests: XCTestCase {

    // MARK: The suite's named constants

    /// The plan chip's accessibility identifier (plan-unique).
    private static func planChipIdentifier(forScenarioName scenarioName: String) -> String {
        "demo-plan-chip-" + scenarioName
    }

    /// A plan chip's info affordance identifier (plan-unique).
    private static func planInfoAffordanceIdentifier(forScenarioName scenarioName: String) -> String {
        "demo-plan-info-" + scenarioName
    }

    /// The picker's plan scenarios (the committed recorded traces; the
    /// fixture metadata's own names).
    private static let planScenarioNames = [
        "sacramento_clean_walk",
        "sacramento_deviation_recovery",
        "sacramento_deviation_reroute",
    ]
    /// The artifact's own navigation demo trace scenario (the
    /// default-selected plan).
    private static let artifactPlanScenarioName = "sacramento_clean_walk"
    /// The diverted plan scenarios (the non-default selections).
    private static let divertedPlanScenarioNames = [
        "sacramento_deviation_recovery", "sacramento_deviation_reroute",
    ]
    /// The reroute plan's scenario name (the info affordance's asserted
    /// plan).
    private static let divertedRerouteScenarioName = "sacramento_deviation_reroute"
    /// The recovery plan's scenario name.
    private static let divertedRecoveryScenarioName = "sacramento_deviation_recovery"
    /// The reroute plan's description the info affordance reveals (the
    /// application's fixed string).
    private static let divertedReroutePlanDescription =
        "Replays a walk that steps off the line; a replacement route is applied once the guidance freezes."

    /// The §5.1 fitted camera's north-up readback row (the fit contract's
    /// zeroed bearing).
    private static let fittedBearingReadback = "bearing 0.0°"
    /// The §5.1 fitted camera's top-down readback row (the fit contract's
    /// zeroed pitch).
    private static let fittedPitchReadback = "pitch 0.0°"
    /// The zero overlay-triangles readback (no overlay geometry drew).
    private static let zeroOverlayTrianglesReadback = "overlay triangles 0"
    /// The diagnostics tiles block's overlay-triangles row prefix.
    private static let overlayTrianglesRowPrefix = "overlay triangles"

    /// The camera readback row prefixes (the diagnostics Camera block's
    /// fixed row order).
    private static let cameraReadbackRowPrefixes = [
        "center", "zoom", "bearing", "pitch",
    ]
    /// The camera readback rows' indexes in the fixed order.
    private static let bearingRowIndex = 2
    private static let pitchRowIndex = 3
    /// The zoom readback row's index (the `zoom <levels>` row).
    private static let zoomRowIndex = 1
    /// The diagnostics sheet's confirmed-tap count row prefix.
    private static let mapTapCountRowPrefix = "map taps "
    /// One double tap's zoom step (`docs/ReferenceAppUX.md` §5.2).
    private static let doubleTapZoomStep: Double = 1.0
    /// The zoom comparison's tolerance: the readback renders two decimals,
    /// so half the last rendered digit is the honest bound.
    private static let cameraZoomReadoutTolerance: Double = 0.005
    /// The map tap point's normalized offsets (the middle of the map at 35%
    /// of its height, clear of the chip row and the bottom dock).
    private static let mapTapHorizontalFraction: CGFloat = 0.5
    private static let mapTapVerticalFraction: CGFloat = 0.35

    /// The offline card's cache line prefix (§4.1's honest line).
    private static let offlineCacheStatePrefix = "Tile caching offline: "
    /// The named byte budget the registration phrases (16 MiB =
    /// 16777216 bytes).
    private static let cacheBudgetPhrase = "(16 MiB budget)"
    /// The demo's named tile-cache database file (the application's own
    /// constant, inside the caches directory — never the bundle, never
    /// git).
    private static let tileCacheDatabaseFileName = "tile-cache.db"
    /// The offline card's live tile line prefix (§4.1's honest line).
    private static let offlineTileLinePrefix = "Tiles last frame: "
    /// The live tile line's requested-count label (the accounting's first
    /// number).
    private static let offlineTileRequestedLabel = "requested "
    /// The offline card's line before the first drawn frame (the live
    /// line's negation).
    private static let offlineTileNoFrameYetText = "has not drawn yet"
    /// The offline card's group label (§4.2).
    private static let offlineMapsGroupLabelText = "Offline maps"
    /// The offline card's route control (§2.5 `offline.plan_route_action`).
    private static let offlineRouteButtonIdentifier = "offline-route-button"
    /// The offline route summary's title (§2.5).
    private static let offlineRouteTitleText = "Offline demo route"
    /// The offline route summary's honesty note (§2.5).
    private static let offlineRouteNoteText =
        "Planned offline from a recorded test graph, not live data."
    /// The routing-grid fixture's two-segment route distance and duration (the
    /// facts the wasm seam's test pins: two 111 m residential segments at
    /// 13.32 s each, formatted by the summary).
    private static let offlineRouteDistanceText = "222 m"
    private static let offlineRouteDurationText = "27 s"

    /// The half sheet's content scroll view (the scroll-into-view helper's
    /// container).
    private static let halfSheetContentIdentifier = "home-sheet-half-content"

    /// The condition poll's cadence (seconds).
    private static let pollIntervalSeconds: TimeInterval = 0.25
    /// The element settles' bound (an act's rendered consequence).
    private static let settleTimeoutSeconds: TimeInterval = 10
    /// The turn banner's delivery bound (the replay's first instruction).
    private static let bannerDeliveryTimeoutSeconds: TimeInterval = 20
    /// The readiness ladder's settle bound on the simulator's graphics
    /// stack (the Android suite's minutes-scaled honest rule; the
    /// simulator's Metal stack settles far sooner in practice).
    private static let emulatorFirstReadyTimeoutSeconds: TimeInterval = 120
    /// The first drawn frame's bound (the ladder's ready can precede it).
    private static let firstFrameDrawnTimeoutSeconds: TimeInterval = 120
    /// The scroll-into-view helper's drag count bound.
    private static let maximumScrollAttempts = 12
    /// The sheet grabber's fold drag distance (points; the sheet's own
    /// fold threshold in the design's platform glue is 24).
    private static let sheetFoldDragPoints: CGFloat = 40

    /// The §5.1 direction tests' launch-argument keys (the application's
    /// demo-automation flags: the pan and rotation demos drive the drag
    /// and rotation gestures' own user-path methods).
    private static let launchArgumentGesturePanDemo = "DemoGesturePanContent"
    private static let launchArgumentTwoFingerRotateDemo = "DemoGestureRotateContent"

    /// The launch-argument key that starts a route-following trip over the
    /// selected demo plan's committed route (the contract's shared walker,
    /// network-free — the playback suite's seam).
    private static let launchArgumentRouteFollowingJourney = "DemoStartRouteFollowingJourney"

    /// The playback suite's named values: the fastest offered chip, the
    /// arrival's settle bound, and the window a paused reading must hold
    /// still.
    private static let fastestSpeedMultiplier = 8
    private static let arrivalTimeoutSeconds: TimeInterval = 30
    private static let pausedReadingStabilitySeconds: TimeInterval = 2

    /// The launch preset's camera (the shared artifact's fixture center —
    /// the model's initial camera values). The direction assertions read
    /// against it.
    private static let launchCameraCenterLatitudeDegrees = 38.5766
    private static let launchCameraCenterLongitudeDegrees = -121.4944

    /// The pan demo's minimum camera-center westward move (degrees of
    /// longitude): the demo's 100-point drag trips ~300 physical pixels at
    /// the launch camera's zoom, whose longitude move renders far above
    /// the readback's six-decimal rendering.
    private static let panDemoMinimumLongitudeMoveDegrees = 0.001
    /// A pure-rightward drag's latitude standstill tolerance (the mirrored
    /// pixel keeps the Mercator latitude; only round-trip noise remains).
    private static let panDragLatitudeStandstillToleranceDegrees = 1e-6
    /// The rotate demo's drawn bearing readback: a 45° clockwise finger
    /// turn must lower the launch 0.0° bearing to its 315.0° reflection
    /// (content follows the fingers; the §5.1 direction contract).
    private static let rotatedContentFollowBearingReadback = "bearing 315.0°"

    /// The launch-argument keys the suite drives state with (the
    /// application's documented demo-automation flags, `-key value` form
    /// — the argument domain's boolean keys need the explicit value).
    private static let launchArgumentSheetHalfState = "DemoSetSheetHalf"

    /// The launch-argument key that opens the application on a base map by
    /// provider key (the application's documented `-DemoBaseMap
    /// <provider-key>` flag — the styled-base case selects the registry's
    /// credential-less demo base map through it, reusing the existing seam).
    private static let launchArgumentDemoBaseMap = "DemoBaseMap"

    /// The launch-argument key that clears the remembered choices at startup
    /// (the application's documented `-DemoResetRememberedChoices YES` flag).
    private static let launchArgumentResetRememberedChoices = "DemoResetRememberedChoices"

    /// The remembered search texts the persistence cases type.
    private static let rememberedOriginText = "Capitol Park"
    private static let rememberedDestinationText = "Tower Bridge"

    /// The settings sheet's height tolerance in points (the detent's own
    /// rounding).
    private static let settingsHeightTolerancePoints: CGFloat = 2

    /// The base-map section's label line while a styled vector base serves
    /// (the application's fixed consumer string; the suite asserts the exact
    /// line the screen renders).
    private static let vectorLabelsNoteText =
        "Vector styles draw land, water, roads with their names, and Latin place names."

    /// The suffix the base-map menu appends to the serving vector style's
    /// display name (the application's own serving marker).
    private static let vectorStyleServingSuffix = " — Serving"

    /// The separator between a vector style's provider name and its style
    /// name in the base-map menu (the application's `VectorBaseMapChoice`
    /// display composition).
    private static let vectorStyleNameSeparator = " · "

    /// The settings sheet's base-map menu identifier.
    private static let baseMapMenuIdentifier = "base-map-menu"

    /// The launch-argument value that reads as `true` in the argument
    /// domain's boolean parsing.
    private static let launchArgumentBooleanTrueValue = "YES"

    /// The application under test, relaunched per test.
    private var application: XCUIApplication?

    /// The automation credential from the test process's environment, if any
    /// (the same variable the application's runtime injection seam reads).
    private var runtimeInjectedApiKey: String? {
        let runtimeCredential = ProcessInfo.processInfo.environment["PROVIDER_API_KEY"]?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return (runtimeCredential?.isEmpty == false) ? runtimeCredential : nil
    }

    /// The optional provider key paired with the automation credential; nil
    /// lets the application target its registry's only iOS-available
    /// provider.
    private var runtimeInjectedProviderKey: String? {
        let runtimeProviderKey = ProcessInfo.processInfo.environment["PROVIDER_KEY"]?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return (runtimeProviderKey?.isEmpty == false) ? runtimeProviderKey : nil
    }

    /// Whether this run supplies the runtime-injected provider credential.
    private var hasRuntimeInjectedApiKey: Bool { runtimeInjectedApiKey != nil }

    // MARK: The suite's lifecycle

    override func setUpWithError() throws {
        try super.setUpWithError()
        continueAfterFailure = false
    }

    override func tearDown() {
        application?.terminate()
        application = nil
        super.tearDown()
    }

    // MARK: Test 1 — the readiness ladder at the peek home sheet

    /// The Espresso suite's launch test: the application launches to the
    /// ready ladder at the peek home sheet — the readiness chip names the
    /// ready state, no planned search and no trip run, the error strip is
    /// empty (an honest startup), and Auto is the theme default (§3).
    func testApplicationLaunchesToTheReadyLadderAtThePeekHomeSheet() throws {
        let application = launchApplication(launchArguments: [])

        if hasRuntimeInjectedApiKey {
            // §6.1: the ladder settles on the ready state (the chip's short
            // line; the full text lives in the diagnostics sheet).
            awaitReadinessChipReady(application: application)
            XCTAssertEqual(
                readinessChip(application: application).label, "Ready",
                "the readiness chip must name the ready state"
            )
        } else {
            // §6.5: a keyless launch shows either the neutral prompt or, when
            // the registry carries a credential-less base map (M24), the ready
            // line that serving map earns. Both are documented states; a
            // renderer failure or an endless loading line is neither.
            let settledChipPredicate = NSPredicate(
                format: "label == %@ OR label == %@", "Set provider key", "Ready"
            )
            expectation(
                for: settledChipPredicate,
                evaluatedWith: readinessChip(application: application)
            )
            waitForExpectations(timeout: Self.settleTimeoutSeconds)
        }
        XCTAssertFalse(
            elementWithIdentifier("error-report", in: application).exists,
            "an honest startup reports nothing in the error strip"
        )

        // §1: the home sheet starts at peek — the destination search field
        // and the one primary action row; no navigation drawer replaces
        // the sheet and no banner stack runs a trip.
        XCTAssertTrue(
            elementWithIdentifier("home-sheet-peek-search", in: application).exists,
            "the peek home sheet's destination search field must render"
        )
        let peekStartNavigation = elementWithIdentifier(
            "home-sheet-peek-start-navigation", in: application
        )
        XCTAssertTrue(
            peekStartNavigation.exists,
            "the peek home sheet's primary action row must render"
        )
        XCTAssertEqual(
            peekStartNavigation.label,
            "Start simulated navigation",
            "the peek's one primary action starts the simulated trip (§1)"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-drawer", in: application).exists,
            "no trip runs at launch, so no navigation drawer replaces the sheet"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-turn-banner", in: application).exists,
            "no trip runs at launch, so no turn banner renders"
        )

        // §3: Auto is the theme default on a device that never chose, so the
        // toggle's label names the choice it switches to next (light). The
        // half sheet's control is the accessibility tree's own default
        // witness.
        dragSheetGrabber(application: application, direction: .up)
        XCTAssertTrue(
            elementWithIdentifier("theme-toggle", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the half sheet's theme row must render"
        )
        XCTAssertEqual(
            elementWithIdentifier("theme-toggle", in: application).label,
            "Switch to light theme",
            "Auto is the default choice, so the toggle names the next choice (light)"
        )
        dragSheetGrabber(application: application, direction: .down)
        XCTAssertTrue(
            elementWithIdentifier("home-sheet-peek-search", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the grabber's down gesture restores the peek fold state"
        )
    }

    // MARK: Test 2 — the keyless demo search and recorded route

    /// The keyless plan flow (§4.1): with no provider credential applied,
    /// the search view filters the shared artifact's `demo_places` and plans
    /// the artifact's recorded route for the pair — the same demo data the
    /// web page serves, never a provider call. The two launch-argument demos
    /// drive the search view's own user-path methods (the suite's
    /// no-touch-injection rule); the assertions read the rendered rows and
    /// the route summary's recorded-route note.
    func testTheKeylessDemoSearchAndRecordedRouteNeedNoProviderKey() throws {
        try XCTSkipIf(
            hasRuntimeInjectedApiKey,
            "the keyless demo flow needs a credential-less session"
        )
        let catalog = try ReferenceScenesCatalog.loadedFromPackageResource()
        let firstDemoPlace = try XCTUnwrap(
            catalog.demoPlaces.first,
            "the shared artifact must carry demo places"
        )
        let recordedRoute = try XCTUnwrap(
            catalog.demoRoutes.first,
            "the shared artifact must carry recorded demo routes"
        )
        XCTAssertGreaterThan(
            recordedRoute.route.distanceMeters, 0,
            "the recorded route must carry its geometry"
        )

        // The keyless search offers the artifact's demo places and says the
        // rows are demo places, never live results.
        let searchApplication = launchApplication(launchArguments: [
            "-DemoKeylessSearch", "YES",
        ])
        XCTAssertTrue(
            elementWithIdentifier("search-results-demo-heading", in: searchApplication)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the keyless result list must name its rows as demo places"
        )
        XCTAssertTrue(
            searchApplication.staticTexts[firstDemoPlace.name]
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the keyless search must offer the artifact's demo place"
        )
        searchApplication.terminate()

        // The keyless plan applies the recorded pair's route and the summary
        // names it as the recorded demo route.
        let planApplication = launchApplication(launchArguments: [
            "-DemoKeylessPlan", "YES",
        ])
        XCTAssertTrue(
            elementWithIdentifier("route-summary-card", in: planApplication)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the keyless plan must present the recorded route's summary"
        )
        XCTAssertTrue(
            planApplication.staticTexts["Recorded demo route, pedestrian, fastest."].exists,
            "the route summary must name the recorded demo route"
        )
        XCTAssertFalse(
            elementWithIdentifier("error-report", in: planApplication).exists,
            "a successful keyless plan reports nothing in the error strip"
        )
    }

    // MARK: Test 3 — the demo-plan chip row and the §5.1 fit contract

    /// The Espresso suite's demo-plan test: the picker's chip row carries
    /// the three recorded walk plans with the artifact's trace active by
    /// default and each description behind its info affordance; selecting
    /// a plan applies the §5.1 route-preview framing (top-down, north up,
    /// the fit actually applied) and its route line rides the overlay
    /// push; the scene chips' toggles join and leave that overlay list —
    /// assertable on iOS through the live tile accounting's overlay
    /// triangles line, the drawn-frame witness of the pushed overlays.
    func testTheDemoPlanAndSceneChipsDriveThePlannedRouteDemo() throws {
        try XCTSkipUnless(
            hasRuntimeInjectedApiKey,
            "requires PROVIDER_API_KEY in the test environment (runtime injection)"
        )
        let application = launchApplication(
            launchArguments: [
                "-\(Self.launchArgumentSheetHalfState)",
                Self.launchArgumentBooleanTrueValue,
            ]
        )
        awaitReadinessChipReady(application: application)

        // The picker's three recorded walk plans (§4.1), with the
        // artifact's trace plan active by default.
        for planScenarioName in Self.planScenarioNames {
            XCTAssertTrue(
                elementWithIdentifier(
                    Self.planChipIdentifier(forScenarioName: planScenarioName),
                    in: application
                ).exists,
                "the picker must carry the recorded plan '\(planScenarioName)'"
            )
        }
        let artifactPlanChip = elementWithIdentifier(
            Self.planChipIdentifier(forScenarioName: Self.artifactPlanScenarioName),
            in: application
        )
        XCTAssertTrue(
            artifactPlanChip.isSelected,
            "the artifact's trace plan must start selected"
        )
        for divertedScenarioName in Self.divertedPlanScenarioNames {
            XCTAssertFalse(
                elementWithIdentifier(
                    Self.planChipIdentifier(forScenarioName: divertedScenarioName),
                    in: application
                ).isSelected,
                "'\(divertedScenarioName)' must not be the default-selected plan"
            )
        }

        // The info affordance reveals the plan's description (§4.1: not a
        // wall of prose under the controls).
        let rerouteInfoAffordance = elementWithIdentifier(
            Self.planInfoAffordanceIdentifier(
                forScenarioName: Self.divertedRerouteScenarioName
            ),
            in: application
        )
        XCTAssertTrue(
            rerouteInfoAffordance.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the reroute's info affordance must render beside its chip"
        )
        rerouteInfoAffordance.tap()
        let revealedPlanDescription = elementWithIdentifier(
            "demo-plan-info-text", in: application
        )
        XCTAssertTrue(
            revealedPlanDescription.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the info affordance must reveal the plan's description"
        )
        XCTAssertEqual(
            revealedPlanDescription.label,
            Self.divertedReroutePlanDescription,
            "the revealed description must be the reroute plan's own text"
        )

        // The pre-selection camera readback (the artifact preset's
        // framing), read from the diagnostics sheet's camera block (round
        // 9's attribute getters).
        let preSelectionCameraRows = openDiagnosticsAndReadCameraRows(application: application)
        XCTAssertTrue(
            preSelectionCameraRows.allSatisfy { !$0.isEmpty },
            "the pre-selection camera readback must render all four rows,\(preSelectionCameraRows)"
        )

        // The deviation-recovery chip's act: the plan gets selected (the
        // selection drops a planned route) and applies the route-preview
        // framing over its recorded route.
        let recoveryPlanChip = elementWithIdentifier(
            Self.planChipIdentifier(
                forScenarioName: Self.divertedRecoveryScenarioName
            ),
            in: application
        )
        recoveryPlanChip.tap()
        XCTAssertTrue(
            recoveryPlanChip.waitForExistence(timeout: Self.settleTimeoutSeconds)
                && pollElement(recoveryPlanChip) { $0.isSelected },
            "the tapped plan chip must take the selected trait"
        )
        XCTAssertFalse(
            elementWithIdentifier(
                Self.planChipIdentifier(forScenarioName: Self.artifactPlanScenarioName),
                in: application
            ).isSelected,
            "the artifact's plan chip must relinquish the selected trait"
        )
        XCTAssertFalse(
            elementWithIdentifier("route-summary-card", in: application).exists,
            "the picker's recorded demo plans are not search-planned routes"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-drawer", in: application).exists,
            "selecting a recorded plan must not start a trip"
        )

        // §5.1's fit contract: the preview's framing is top down (pitch
        // 0.0°) and north up (bearing 0.0°), and the fit actually applied —
        // the drawn frames' camera readback reports the pinned fit camera,
        // which moved the framing away from the pre-selection readback.
        let fittedCameraRows = openDiagnosticsAndReadCameraRows(
            application: application,
            settleCondition: { cameraRows in
                cameraRows != preSelectionCameraRows
                    && cameraRows[Self.bearingRowIndex] == Self.fittedBearingReadback
                    && cameraRows[Self.pitchRowIndex] == Self.fittedPitchReadback
            },
            closesSheetAfterReading: false
        )
        XCTAssertEqual(
            fittedCameraRows[Self.bearingRowIndex], Self.fittedBearingReadback,
            "the route-preview framing must be north up"
        )
        XCTAssertEqual(
            fittedCameraRows[Self.pitchRowIndex], Self.fittedPitchReadback,
            "the route-preview framing must be top down"
        )
        XCTAssertNotEqual(
            fittedCameraRows, preSelectionCameraRows,
            "the route-preview framing must actually move the framing (the §5.1 fit applied)"
        )

        // The plan's route line rides the pushed overlay list (the tiles
        // block's live overlay triangles row is its drawn-frame witness:
        // zero before the selection, non-zero after the route line
        // pushed). The sheet stays open from the fitted read for the
        // overlay read.
        let overlayTrianglesLine = awaitOverlayTrianglesLine(application: application)
        XCTAssertNotEqual(
            overlayTrianglesLine, Self.zeroOverlayTrianglesReadback,
            "the plan's route line must ride the pushed overlay list"
        )
        closeDiagnostics(application: application)

        // The scene chip's own act: the markers chip toggles on, its scene
        // joins the pushed overlay list; toggling it off leaves it again
        // (the tiles block's overlay triangles line is the drawn-frame
        // witness, read with the diagnostics sheet open — the chips toggle
        // while the sheet is dismissed, each read reopens it).
        let markersSceneChip = sceneChip(application: application, label: "Point markers")
        let halfSheetContent = elementWithIdentifier(
            Self.halfSheetContentIdentifier, in: application
        )
        scrollToMake(markersSceneChip, visibleIn: halfSheetContent)
        XCTAssertTrue(
            markersSceneChip.exists,
            "the scene carousel must render the markers chip"
        )
        markersSceneChip.tap()
        let markersOnOverlayTrianglesLine = openDiagnosticsAndReadChanged(
            application: application,
            fromLine: overlayTrianglesLine
        )
        markersSceneChip.tap()
        closeDiagnostics(application: application)
        reopenDiagnosticsAndAwaitRestored(
            application: application,
            fromLine: markersOnOverlayTrianglesLine,
            toLine: overlayTrianglesLine
        )
        XCTAssertFalse(
            elementWithIdentifier("error-report", in: application).exists,
            "a scene push reports nothing in the error strip"
        )
    }

    // MARK: Test 3 — the trace replay and the verbatim exit restore

    /// The Espresso suite's trace-replay test: the recorded journey's
    /// fixes replay through the navigation controller; the §7 banner
    /// renders a recorded step's display text (the recording's own text,
    /// distance-prefixed in the composed form); the drawer runs the
    /// Navigating phase; and the exit control's act stops the replay,
    /// restores the pre-trip camera verbatim (round 9's attribute-getter
    /// readback is the drawn-frame witness) and returns the peek home
    /// sheet.
    func testTheTraceReplayRendersTheRecordedBannerTextAndTheExitRestoresHome() throws {
        // The diagnostics camera readback is the drawn-frame witness; a
        // keyless session has no surface and therefore no camera to read
        // back. The replay itself is provider-free, but the assertions need
        // the drawn camera, so the test runs in keyed runs only.
        try XCTSkipUnless(
            hasRuntimeInjectedApiKey,
            "requires PROVIDER_API_KEY in the test environment (runtime injection)"
        )
        let application = launchApplication(launchArguments: [])
        awaitReadinessChipReady(application: application)

        // The pre-trip camera readback, from the diagnostics sheet's
        // camera block.
        let preTripCameraRows = openDiagnosticsAndReadCameraRows(application: application)
        XCTAssertTrue(
            preTripCameraRows.allSatisfy { !$0.isEmpty },
            "the pre-trip camera readback must render all four rows,\(preTripCameraRows)"
        )

        // The recorded demo must carry steps for the banner membership
        // assertion (the test bundle decodes the same committed fixture
        // the application replays).
        let recordedStepDisplayTexts = try Self.recordedStepDisplayTexts(
            fixtureScenarioNamed: Self.artifactPlanScenarioName
        )
        XCTAssertFalse(
            recordedStepDisplayTexts.isEmpty,
            "the recorded demo trace must carry steps to assert against"
        )

        // The half sheet's sample journey control starts the simulated
        // journey (the recorded trace replays through the navigation
        // controller).
        dragSheetGrabber(application: application, direction: .up)
        let sampleJourneyButton = elementWithIdentifier(
            "sample-journey-button", in: application
        )
        XCTAssertTrue(
            sampleJourneyButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the half sheet's sample journey control must render"
        )
        sampleJourneyButton.tap()

        // §1: the navigation drawer replaces the home sheet during the
        // trip; its phase chip runs the Navigating phase.
        let navigationDrawer = elementWithIdentifier("navigation-drawer", in: application)
        XCTAssertTrue(
            navigationDrawer.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "a started trip must replace the home sheet with the navigation drawer"
        )
        let navigationPhaseChip = elementWithIdentifier(
            "navigation-drawer-phase", in: application
        )
        XCTAssertTrue(
            navigationPhaseChip.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the drawer's phase chip must render"
        )
        XCTAssertEqual(
            elementWithIdentifier("navigation-drawer-phase", in: application).label,
            "Navigating",
            "the replay's drawer must run the Navigating phase"
        )

        // §7.1/§7.2: the turn banner renders a recorded step's composed
        // text — the banner's maneuver line ends with the recording's own
        // provider text (the live distance prefix composes onto it).
        let turnBanner = elementWithIdentifier("navigation-turn-banner", in: application)
        XCTAssertTrue(
            turnBanner.waitForExistence(timeout: Self.bannerDeliveryTimeoutSeconds),
            "the replay's first instruction must raise the turn banner"
        )
        let renderedBannerTexts = Self.bannerLabelTexts(banner: turnBanner)
        XCTAssertFalse(
            renderedBannerTexts.isEmpty,
            "the turn banner must render the composed instruction"
        )
        XCTAssertTrue(
            recordedStepDisplayTexts.contains { stepText in
                renderedBannerTexts.contains { $0.hasSuffix(stepText) }
            },
            "the banner's rendered lines \(renderedBannerTexts) must end with the recording's own step text"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-arrival-banner", in: application).exists,
            "the replay's first instruction is not the arrival"
        )

        // The drawer's exit control's act: the replay stops, the home
        // sheet returns at peek.
        let drawerExitButton = elementWithIdentifier(
            "navigation-drawer-exit", in: application
        )
        XCTAssertTrue(
            drawerExitButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the drawer's exit control must render"
        )
        drawerExitButton.tap()
        XCTAssertTrue(
            elementWithIdentifier("home-sheet-peek-search", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the exit must return the home sheet at peek"
        )
        pollForSettlement(
            timeoutDescription: "the stopped trip removing the navigation drawer and banner"
        ) {
            !navigationDrawer.exists && !turnBanner.exists
        }

        // §5.3's "applied at trip start, restored after": the drawn
        // frames' camera readback returns exactly to the pre-trip row set
        // (the verbatim restore).
        let restoredCameraRows = openDiagnosticsAndReadCameraRows(
            application: application,
            settleCondition: { cameraRows in
                cameraRows == preTripCameraRows
            }
        )
        XCTAssertEqual(
            restoredCameraRows, preTripCameraRows,
            "the exit must restore the pre-trip camera verbatim"
        )
    }

    // MARK: Test 3b — the playback's speed, pause/resume and held arrival

    /// The M27 playback test: a route-following trip walks the contract's
    /// shared walker over a committed route (network-free through the
    /// launch automation). The drawer offers the speed row; the fastest
    /// chip accelerates the walk; Pause freezes the reading while the
    /// drawer's phase stays Navigating; Resume carries the trip to the
    /// arrival state, which holds the destination with the playback
    /// controls hidden until Exit returns the peek home sheet.
    func testTheSimulatedTripFollowsItsCourseAndOffersNorthUp() throws {
        // The recorded walk heads south-west from the start, so a camera that
        // follows the smoothed course leaves north by more than the compass
        // threshold and shows the N control. A north-up camera (a broken
        // bearing path) would never show it.
        let demoBaseMapProviderKey = (try? loadProviderRegistry())?.providers.first { descriptor in
            descriptor.registrationAvailable.ios
                && !descriptor.rasterUrlTemplate.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ).isEmpty
        }?.providerKey
        var launchArguments = [
            "-DemoStartSimulatedJourney",
            Self.launchArgumentBooleanTrueValue,
        ]
        if let demoBaseMapProviderKey {
            launchArguments += [
                "-\(Self.launchArgumentDemoBaseMap)", demoBaseMapProviderKey,
            ]
        }
        let application = launchApplication(launchArguments: launchArguments)

        let navigationDrawer = elementWithIdentifier("navigation-drawer", in: application)
        XCTAssertTrue(
            navigationDrawer.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds),
            "the simulated trip must present the navigation drawer"
        )
        let compassControl = elementWithIdentifier("map-compass-control", in: application)
        XCTAssertTrue(
            compassControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "a course-following trip must show the N compass once its bearing leaves north"
        )
    }

    func testTheHomeSheetOffersTheDeviceLocationControl() throws {
        let application = launchApplication(launchArguments: [
            "-\(Self.launchArgumentSheetHalfState)",
            Self.launchArgumentBooleanTrueValue,
        ])
        let locationControl = elementWithIdentifier("device-location-control", in: application)
        XCTAssertTrue(
            locationControl.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds),
            "the half sheet must offer the device-location control"
        )
        XCTAssertEqual(
            locationControl.label,
            "Show my location",
            "the control starts inactive"
        )
    }

    func testThePlanFlowGatesItsRouteActionUntilBothFieldsHoldText() throws {
        let application = launchApplication(launchArguments: [
            "-DemoOpenSearch",
            Self.launchArgumentBooleanTrueValue,
        ])
        let planRouteButton = elementWithIdentifier("plan-route-button", in: application)
        XCTAssertTrue(
            planRouteButton.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds)
        )
        XCTAssertFalse(
            planRouteButton.isEnabled,
            "Plan route stays disabled with both fields empty"
        )
        let reason = elementWithIdentifier("plan-route-reason", in: application)
        XCTAssertTrue(reason.waitForExistence(timeout: Self.settleTimeoutSeconds))
        XCTAssertEqual(
            reason.label,
            "Enter an origin and a destination to plan the route."
        )

        let originField = application.textFields["Search an origin"]
        XCTAssertTrue(originField.waitForExistence(timeout: Self.settleTimeoutSeconds))
        originField.tap()
        originField.typeText("Capitol Park")
        XCTAssertFalse(
            planRouteButton.isEnabled,
            "Plan route stays disabled while the destination is empty"
        )
        XCTAssertEqual(
            reason.label,
            "Enter a destination to plan the route."
        )

        let destinationField = application.textFields["Search a destination"]
        destinationField.tap()
        destinationField.typeText("Tower Bridge")
        XCTAssertTrue(
            planRouteButton.isEnabled,
            "Plan route enables once both fields hold text"
        )
    }

    func testTheDeviceLocationSourceShowsALiveFix() throws {
        // The simulator must have a location set before this run
        // (`xcrun simctl location booted set 38.5766,-121.4944`) and the
        // authorization must be undetermined (reset it to see the prompt).
        let application = launchApplication(launchArguments: [
            "-DemoStartDeviceLocation",
            Self.launchArgumentBooleanTrueValue,
            "-\(Self.launchArgumentSheetHalfState)",
            Self.launchArgumentBooleanTrueValue,
        ])
        let authorizationAlert = application.alerts.firstMatch
        if authorizationAlert.waitForExistence(timeout: 5) {
            for allowLabel in ["Allow While Using App", "Allow Once", "Allow"] {
                let allowButton = authorizationAlert.buttons[allowLabel]
                if allowButton.exists {
                    allowButton.tap()
                    break
                }
            }
        } else {
            let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
            for allowLabel in ["Allow While Using App", "Allow Once", "Allow"] {
                let allowButton = springboard.buttons[allowLabel]
                if allowButton.waitForExistence(timeout: 2) {
                    allowButton.tap()
                    break
                }
            }
        }

        // The first start asked for authorization; start again now that it is
        // granted, exactly as the status line tells the visitor.
        let locationControl = elementWithIdentifier("device-location-control", in: application)
        XCTAssertTrue(locationControl.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds))
        if locationControl.label == "Show my location" {
            locationControl.tap()
        }

        let statusQuery = application.descendants(matching: .any)
            .matching(identifier: "device-location-status")
        let positionStatus = NSPredicate(format: "exists == true AND label CONTAINS %@", "Position")
        let positionExpectation = expectation(
            for: positionStatus,
            evaluatedWith: statusQuery.firstMatch
        )
        wait(for: [positionExpectation], timeout: Self.settleTimeoutSeconds)
    }

    /// The Location group's second control (M33): with no planned route it
    /// states what it needs and starts nothing; on the recorded
    /// Capitol Park -> Tower Bridge route the device source's own fixes
    /// drive the banner, phase and follow presentation, and stopping leaves
    /// the source the visitor started by hand running.
    func testDeviceNavigationFollowsThePlannedRouteFromLiveFixes() throws {
        // The simulator must have a location set before this run
        // (`xcrun simctl location start --interval=1 38.57693,-121.49492
        // 38.58,-121.49492`) and the authorization must be grantable (reset
        // it to see the prompt). The case stays keyless: the plan flow reads
        // the recorded demo route, never a provider.
        let application = launchApplication(
            launchArguments: [
                "-DemoStartDeviceLocation", Self.launchArgumentBooleanTrueValue,
                "-\(Self.launchArgumentSheetHalfState)", Self.launchArgumentBooleanTrueValue,
            ],
            injectsRuntimeCredential: false
        )
        grantWhenInUseLocationAuthorization(in: application)

        // The first start asked for authorization; start again now that it
        // is granted, exactly as the status line tells the visitor.
        let locationControl = elementWithIdentifier("device-location-control", in: application)
        XCTAssertTrue(
            locationControl.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds)
        )
        if locationControl.label == "Show my location" {
            locationControl.tap()
        }
        let locationStatus = elementWithIdentifier("device-location-status", in: application)
        XCTAssertTrue(
            waitForLabelContaining("Position", element: locationStatus),
            "the device source must report a live fix before the trip starts"
        )

        // Without a planned route the control states what it needs instead
        // of starting a trip nobody planned.
        let navigationControl = elementWithIdentifier("device-navigation-control", in: application)
        XCTAssertTrue(navigationControl.waitForExistence(timeout: Self.settleTimeoutSeconds))
        XCTAssertEqual(navigationControl.label, "Navigate from my location")
        navigationControl.tap()
        XCTAssertTrue(
            waitForLabel(
                "Plan a route first; device navigation follows the route you planned.",
                element: locationStatus
            ),
            "the keyless plan-first caption must state what device navigation needs"
        )
        XCTAssertEqual(
            navigationControl.label, "Navigate from my location",
            "the control stays idle while no route is planned"
        )

        // Plan the recorded route through the search view's own fields.
        dragSheetGrabber(application: application, direction: .up)
        planRecordedDemoRoute(application: application)
        let routeSummary = elementWithIdentifier("route-summary-card", in: application)
        XCTAssertTrue(
            routeSummary.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the recorded Capitol Park -> Tower Bridge route must present its summary"
        )

        // The source is already running, so the control starts guidance on
        // the planned route from its next accepted fix.
        let readyNavigationControl = elementWithIdentifier(
            "device-navigation-control", in: application
        )
        XCTAssertTrue(readyNavigationControl.waitForExistence(timeout: Self.settleTimeoutSeconds))
        readyNavigationControl.tap()

        let stopControl = elementWithIdentifier("device-navigation-control", in: application)
        XCTAssertTrue(
            waitForLabel("Stop device navigation", element: stopControl),
            "the control must name the active device-driven trip"
        )
        XCTAssertTrue(
            elementWithIdentifier("navigation-drawer", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the device-driven trip presents the navigation drawer"
        )
        XCTAssertTrue(
            elementWithIdentifier("navigation-turn-banner", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the turn banner reads the device fix stream"
        )
        let phaseChip = elementWithIdentifier("navigation-drawer-phase", in: application)
        XCTAssertTrue(phaseChip.waitForExistence(timeout: Self.settleTimeoutSeconds))
        XCTAssertTrue(
            waitForNonemptyLabel(element: phaseChip),
            "the trip phase is shown while the device fixes drive guidance"
        )
        let drawerStatus = elementWithIdentifier("device-location-status", in: application)
        XCTAssertTrue(
            waitForLabelContaining("Position", element: drawerStatus),
            "the accepted device fix keeps the position caption current, got '\(drawerStatus.exists ? drawerStatus.label : "absent")'"
        )

        // Stopping ends the trip; the source the visitor started by hand
        // keeps running, so the half sheet still offers Hide and the
        // position caption keeps updating.
        stopControl.tap()
        XCTAssertTrue(
            waitForNonexistence(elementWithIdentifier("navigation-drawer", in: application)),
            "stopping device navigation ends the trip presentation"
        )
        XCTAssertTrue(
            elementWithIdentifier("sheet-grabber", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds)
        )
        dragSheetGrabber(application: application, direction: .up)
        let restoredLocationControl = elementWithIdentifier(
            "device-location-control", in: application
        )
        XCTAssertTrue(restoredLocationControl.waitForExistence(timeout: Self.settleTimeoutSeconds))
        XCTAssertEqual(
            restoredLocationControl.label, "Hide my location",
            "the hand-started location source must keep running after the trip"
        )
        XCTAssertEqual(
            elementWithIdentifier("device-navigation-control", in: application).label,
            "Navigate from my location",
            "the control returns to its idle label after stopping"
        )
        XCTAssertTrue(
            waitForLabelContaining(
                "Position",
                element: elementWithIdentifier("device-location-status", in: application)
            ),
            "the position caption keeps updating after the trip"
        )
    }

    func testTheSimulatedTripPausesResumesAndHoldsItsArrival() throws {
        // The trip itself needs no provider, but the arrival's centred-
        // destination assertion reads the drawn camera. The registry's
        // credential-less demo base map (the same seam the styled-base case
        // launches with) gives the keyless run a surface to read.
        let demoBaseMapProviderKey = (try? loadProviderRegistry())?.providers.first { descriptor in
            descriptor.registrationAvailable.ios
                && !descriptor.rasterUrlTemplate.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ).isEmpty
        }?.providerKey
        var launchArguments = [
            "-\(Self.launchArgumentRouteFollowingJourney)",
            Self.launchArgumentBooleanTrueValue,
        ]
        if let demoBaseMapProviderKey {
            launchArguments += [
                "-\(Self.launchArgumentDemoBaseMap)", demoBaseMapProviderKey,
            ]
        }
        let application = launchApplication(launchArguments: launchArguments)

        // §1: the trip replaces the home sheet with the navigation drawer.
        let navigationDrawer = elementWithIdentifier("navigation-drawer", in: application)
        XCTAssertTrue(
            navigationDrawer.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds),
            "the route-following trip must present the navigation drawer"
        )
        let phaseChip = elementWithIdentifier("navigation-drawer-phase", in: application)
        XCTAssertTrue(
            phaseChip.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the running trip's phase chip must render"
        )
        XCTAssertEqual(
            phaseChip.label, "Navigating",
            "the route-following trip must run the Navigating phase"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-drawer-arrived", in: application).exists,
            "the trip starts short of its arrival"
        )

        // The speed row carries one chip per offered multiplier; the fastest
        // one is tapped so the committed walk arrives inside the suite's
        // bound.
        let speedRow = elementWithIdentifier("navigation-speed-row", in: application)
        XCTAssertTrue(
            speedRow.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the drawer's playback-speed row must render"
        )
        let fastestSpeedChip = elementWithIdentifier(
            "navigation-speed-chip-\(Self.fastestSpeedMultiplier)", in: application
        )
        XCTAssertTrue(
            fastestSpeedChip.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the fastest offered speed chip must render"
        )
        XCTAssertEqual(
            fastestSpeedChip.label, "\(Self.fastestSpeedMultiplier)×",
            "the chip carries the canonical multiplier label"
        )
        fastestSpeedChip.tap()

        // The pause act is asserted where the reading is fine-grained: the
        // ETA line switches from kilometers to meters under one kilometer,
        // where a running trip moves the number every tick.
        let etaLine = elementWithIdentifier("navigation-drawer-eta-line", in: application)
        pollForSettlement(
            timeoutDescription: "the trip's remaining distance entering the meters phrase",
            timeoutSeconds: Self.arrivalTimeoutSeconds
        ) {
            etaLine.exists && etaLine.label.contains(" m ·")
        }
        let pauseControl = elementWithIdentifier("navigation-playback-pause", in: application)
        XCTAssertTrue(
            pauseControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the drawer's pause control must render"
        )
        XCTAssertEqual(pauseControl.label, "Pause", "the running trip offers Pause")
        pauseControl.tap()
        pollForSettlement(
            timeoutDescription: "the paused playback control reading Resume"
        ) {
            pauseControl.exists && pauseControl.label == "Resume"
        }
        let pausedEtaLine = etaLine.label
        Thread.sleep(forTimeInterval: Self.pausedReadingStabilitySeconds)
        XCTAssertEqual(
            etaLine.label, pausedEtaLine,
            "a paused trip's reading must freeze at its current fix"
        )
        XCTAssertEqual(
            phaseChip.label, "Navigating",
            "pausing the playback does not end the trip"
        )

        // Resume: the reading moves again and the trip reaches its arrival.
        pauseControl.tap()
        pollForSettlement(
            timeoutDescription: "the resumed playback control reading Pause"
        ) {
            pauseControl.exists && pauseControl.label == "Pause"
        }
        let arrivedLine = elementWithIdentifier("navigation-drawer-arrived", in: application)
        XCTAssertTrue(
            arrivedLine.waitForExistence(timeout: Self.arrivalTimeoutSeconds),
            "the trip must reach its arrival state within the playback bound"
        )
        XCTAssertEqual(arrivedLine.label, "Arrived", "the arrival drawer says Arrived")
        XCTAssertFalse(
            elementWithIdentifier("navigation-playback-pause", in: application).exists,
            "the arrival state hides the playback control"
        )
        XCTAssertFalse(
            elementWithIdentifier("navigation-speed-row", in: application).exists,
            "the arrival state hides the speed row"
        )
        XCTAssertFalse(
            elementWithIdentifier("home-sheet-peek-search", in: application).exists,
            "the arrival presentation keeps the trip in place"
        )

        // §7.1/§7.2: the arrival outlives the playback (only Exit empties it).
        Thread.sleep(forTimeInterval: Self.pausedReadingStabilitySeconds)
        XCTAssertTrue(arrivedLine.exists, "the arrival state must hold")
        XCTAssertTrue(navigationDrawer.exists, "the arrival state must hold its drawer")

        // The destination stays the camera centre (the drawn-frame readback;
        // the launch needs a surface to read, keyed or the keyless demo base).
        if hasRuntimeInjectedApiKey || demoBaseMapProviderKey != nil {
            let destination = try XCTUnwrap(
                Self.recordedRouteEndCoordinate(
                    fixtureScenarioNamed: Self.artifactPlanScenarioName
                ),
                "the committed route fixture must carry a final shape coordinate"
            )
            let expectedCenterRow = "center "
                + String(format: "%.6f", destination.latitude) + ", "
                + String(format: "%.6f", destination.longitude)
            // The camera block can sit below the sheet's fold, so the poll
            // reads the rows through the scroll-aware read.
            openDiagnosticsSheet(application: application)
            let diagnosticsSheetElement = diagnosticsSheet(application: application)
            let diagnosticsScrollView = diagnosticsSheetElement.scrollViews.firstMatch
            pollForSettlement(
                timeoutDescription:
                    "the arrival's drawn camera centre reading the destination"
            ) {
                readCameraReadbackRowsWithScrolling(
                    sheet: diagnosticsSheetElement,
                    scrollView: diagnosticsScrollView
                ).first == expectedCenterRow
            }
            let cameraRows = readCameraReadbackRowsWithScrolling(
                sheet: diagnosticsSheetElement,
                scrollView: diagnosticsScrollView
            )
            closeDiagnostics(application: application)
            XCTAssertEqual(
                cameraRows.first, expectedCenterRow,
                "the arrival must hold the route's destination as the camera centre, was \(cameraRows)"
            )
        }

        // The exit's act: the trip tears down and the peek home sheet returns.
        elementWithIdentifier("navigation-drawer-exit", in: application).tap()
        XCTAssertTrue(
            elementWithIdentifier("home-sheet-peek-search", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the exit must return the home sheet at peek"
        )
        XCTAssertTrue(
            pollForNonExistence(navigationDrawer, within: Self.settleTimeoutSeconds),
            "the exit must remove the navigation drawer"
        )
    }

    // MARK: Test 3c — the playback's seek

    /// The M27 seek test: the drawer's scrubber moves the trip along the
    /// route's own geometry. Seeking to the end presents the walker's own
    /// arrival; seeking back leaves it and the paused trip stays paused.
    func testTheSimulatedTripSeeksToTheEndAndBackOutOfTheArrival() throws {
        var launchArguments = [
            "-\(Self.launchArgumentRouteFollowingJourney)",
            Self.launchArgumentBooleanTrueValue,
        ]
        let demoBaseMapProviderKey = (try? loadProviderRegistry())?.providers.first { descriptor in
            descriptor.registrationAvailable.ios
                && !descriptor.rasterUrlTemplate.trimmingCharacters(
                    in: .whitespacesAndNewlines
                ).isEmpty
        }?.providerKey
        if let demoBaseMapProviderKey {
            launchArguments += [
                "-\(Self.launchArgumentDemoBaseMap)", demoBaseMapProviderKey,
            ]
        }
        let application = launchApplication(launchArguments: launchArguments)

        let navigationDrawer = elementWithIdentifier("navigation-drawer", in: application)
        XCTAssertTrue(
            navigationDrawer.waitForExistence(timeout: Self.emulatorFirstReadyTimeoutSeconds),
            "the route-following trip must present the navigation drawer"
        )
        let seekSlider = elementWithIdentifier("navigation-seek-slider", in: application)
        XCTAssertTrue(
            seekSlider.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the route-following trip's seek control must render"
        )
        // Pause first, so each seek's own position is what the assertions
        // read (a running walker legitimately moves on).
        let pauseControl = elementWithIdentifier("navigation-playback-pause", in: application)
        XCTAssertTrue(
            pauseControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the drawer's pause control must render"
        )
        pauseControl.tap()
        pollForSettlement(
            timeoutDescription: "the paused playback control reading Resume"
        ) {
            pauseControl.exists && pauseControl.label == "Resume"
        }

        let arrivedLine = elementWithIdentifier("navigation-drawer-arrived", in: application)
        XCTAssertFalse(arrivedLine.exists, "the trip starts short of its arrival")
        seekSlider.adjust(toNormalizedSliderPosition: 1.0)
        XCTAssertTrue(
            arrivedLine.waitForExistence(timeout: Self.arrivalTimeoutSeconds),
            "seeking to the end must present the walker's arrival"
        )
        XCTAssertEqual(arrivedLine.label, "Arrived", "the arrival drawer says Arrived")

        // Backwards: the seek leaves the arrival and the paused trip holds
        // the new position.
        seekSlider.adjust(toNormalizedSliderPosition: 0.5)
        pollForSettlement(
            timeoutDescription: "a backwards seek leaving the arrival state"
        ) {
            !arrivedLine.exists
        }
        let phaseChip = elementWithIdentifier("navigation-drawer-phase", in: application)
        XCTAssertTrue(
            phaseChip.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the trip returns to its navigating contents"
        )
        XCTAssertEqual(
            phaseChip.label, "Navigating",
            "a backwards seek leaves the arrived state"
        )
        let pausedEtaLine = elementWithIdentifier("navigation-drawer-eta-line", in: application).label
        Thread.sleep(forTimeInterval: Self.pausedReadingStabilitySeconds)
        XCTAssertEqual(
            elementWithIdentifier("navigation-drawer-eta-line", in: application).label,
            pausedEtaLine,
            "seeking while paused keeps the trip paused at the new position"
        )
    }

    // MARK: Test 4 — the offline card's registered cache and live accounting

    /// The Espresso suite's offline-card test: the two honest lines
    /// reflect the application's own registration (the registered cache's
    /// path and the named byte budget) and the live tile statistics of
    /// the drawn frames.
    func testTheOfflineCardReflectsTheRegisteredTileCacheAndTheLiveTileAccounting() throws {
        try XCTSkipUnless(
            hasRuntimeInjectedApiKey,
            "requires PROVIDER_API_KEY in the test environment (runtime injection)"
        )
        let application = launchApplication(
            launchArguments: [
                "-\(Self.launchArgumentSheetHalfState)",
                Self.launchArgumentBooleanTrueValue,
            ]
        )
        awaitReadinessChipReady(application: application)

        let halfSheetContent = elementWithIdentifier(
            Self.halfSheetContentIdentifier, in: application
        )
        XCTAssertTrue(
            halfSheetContent.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the half sheet's working content must render"
        )

        // §4.1: the offline card's group row names the feature (rows name
        // the feature, never the seam).
        let offlineMapsGroupLabel = application.staticTexts[
            Self.offlineMapsGroupLabelText
        ]
        scrollToMake(offlineMapsGroupLabel, visibleIn: halfSheetContent)
        XCTAssertTrue(
            offlineMapsGroupLabel.exists,
            "the half sheet's offline maps card must render"
        )

        // The registered cache's line: the honest path and the byte
        // budget the application's own registration ran with.
        let offlineCacheStateLine = elementWithIdentifier(
            "offline-cache-state", in: application
        )
        scrollToMake(offlineCacheStateLine, visibleIn: halfSheetContent)
        XCTAssertTrue(
            offlineCacheStateLine.exists,
            "the offline card's cache line must present the registration"
        )
        XCTAssertTrue(
            offlineCacheStateLine.label.hasPrefix(Self.offlineCacheStatePrefix),
            "the offline card's cache line must name the registration, '\(offlineCacheStateLine.label)'"
        )
        XCTAssertTrue(
            offlineCacheStateLine.label.contains(Self.cacheBudgetPhrase),
            "the registered cache must carry the demo's named byte budget"
        )
        XCTAssertTrue(
            offlineCacheStateLine.label.contains(Self.tileCacheDatabaseFileName),
            "the registered cache must be the demo's named cache database, '\(offlineCacheStateLine.label)'"
        )

        // The live tile line: the latest drawn frame's statistics (the
        // honest accounting the renderer reports per frame).
        let liveTileLine = elementWithIdentifier("offline-tile-statistics", in: application)
        scrollToMake(liveTileLine, visibleIn: halfSheetContent)
        pollForSettlement(
            timeoutDescription: "the first drawn frame's tile statistics settling into the live tile line",
            timeoutSeconds: Self.firstFrameDrawnTimeoutSeconds
        ) {
            liveTileLine.exists
                && liveTileLine.label.hasPrefix(Self.offlineTileLinePrefix)
                && liveTileLine.label.contains(Self.offlineTileRequestedLabel)
                && !liveTileLine.label.contains(Self.offlineTileNoFrameYetText)
        }
    }

    // MARK: Test 4b — the offline card plans over the bundled test graph

    /// The Espresso suite's offline route test: the route control plans over
    /// the committed compiled archive bundled with the app, and the route
    /// summary presents the result with its recorded-test-graph honesty note.
    /// The plan needs no provider credential, so this case runs keyless.
    func testTheOfflineCardPlansARouteFromTheBundledTestGraph() throws {
        let application = launchApplication(
            launchArguments: [
                "-\(Self.launchArgumentSheetHalfState)",
                Self.launchArgumentBooleanTrueValue,
            ]
        )
        let halfSheetContent = elementWithIdentifier(
            Self.halfSheetContentIdentifier, in: application
        )
        XCTAssertTrue(
            halfSheetContent.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the half sheet's working content must render"
        )

        let offlineRouteButton = elementWithIdentifier(
            Self.offlineRouteButtonIdentifier, in: application
        )
        scrollToMake(offlineRouteButton, visibleIn: halfSheetContent)
        XCTAssertTrue(
            offlineRouteButton.exists,
            "the offline card's route control must render keyless"
        )
        offlineRouteButton.tap()

        let routeSummary = elementWithIdentifier("route-summary-card", in: application)
        XCTAssertTrue(
            routeSummary.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the offline control must produce a route summary"
        )
        // The summary's identifier propagates to its child texts, so the
        // content is asserted by its own value rather than a child identifier.
        XCTAssertTrue(
            application.staticTexts[Self.offlineRouteTitleText]
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the offline route summary must name the recorded test graph's route"
        )
        XCTAssertTrue(
            application.staticTexts[Self.offlineRouteDistanceText].exists,
            "the offline route summary must carry the archive route's distance"
        )
        XCTAssertTrue(
            application.staticTexts[Self.offlineRouteDurationText].exists,
            "the offline route summary must carry the archive route's duration"
        )
        XCTAssertTrue(
            application.staticTexts[Self.offlineRouteNoteText]
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the offline route summary must carry the §2.5 honesty note"
        )
    }

    // MARK: Test 5 — the §5.1 gesture directions (content follows the pointer)

    /// The drag-pan direction (§5.1): a rightward drag must move the map
    /// content **right** — the camera center wests. The launch-argument
    /// pan demo drives the drag gesture's own user-path method (no state
    /// forced, no touch injection); the assertion reads the diagnostics
    /// sheet's camera block after the pan settles into the drawn readback.
    func testTheGestureDragPanMovesTheContentWithThePointer() throws {
        try XCTSkipUnless(
            hasRuntimeInjectedApiKey,
            "requires PROVIDER_API_KEY in the test environment (runtime injection)"
        )
        let application = launchApplication(launchArguments: [
            "-\(Self.launchArgumentGesturePanDemo)",
            Self.launchArgumentBooleanTrueValue,
        ])
        awaitReadinessChipReady(application: application)

        let minimumPannedLongitude = Self.launchCameraCenterLongitudeDegrees
            - Self.panDemoMinimumLongitudeMoveDegrees
        let pannedCameraRows = openDiagnosticsAndReadCameraRows(
            application: application,
            settleCondition: { camera_rows in
                guard let center_coordinates = Self.centerRowCoordinates(of: camera_rows[0]) else {
                    return false
                }
                return center_coordinates.longitude <= minimumPannedLongitude
            }
        )
        guard let panned_center = Self.centerRowCoordinates(of: pannedCameraRows[0]) else {
            XCTFail(
                "the panned camera readback must render a center row, '\(pannedCameraRows.first ?? "")'"
            )
            return
        }
        XCTAssertLessThan(
            panned_center.longitude,
            minimumPannedLongitude,
            "a rightward drag must move the content right (the camera center wests)"
        )
        XCTAssertEqual(
            panned_center.latitude,
            Self.launchCameraCenterLatitudeDegrees,
            accuracy: Self.panDragLatitudeStandstillToleranceDegrees,
            "a pure-rightward drag must not move the camera center north or south"
        )
    }

    /// The two-finger rotation direction (§5.1): a clockwise rotation must
    /// rotate the map content clockwise — the bearing (the compass
    /// direction the screen top faces) lowers to the delta's reflection.
    /// The launch-argument rotate demo drives the rotation gesture's own
    /// user-path method; the assertion reads the diagnostics sheet's
    /// bearing row after the turn settles into the drawn readback.
    func testTheTwoFingerRotationMovesTheContentWithTheFingers() throws {
        try XCTSkipUnless(
            hasRuntimeInjectedApiKey,
            "requires PROVIDER_API_KEY in the test environment (runtime injection)"
        )
        let application = launchApplication(launchArguments: [
            "-\(Self.launchArgumentTwoFingerRotateDemo)",
            Self.launchArgumentBooleanTrueValue,
        ])
        awaitReadinessChipReady(application: application)

        let rotatedCameraRows = openDiagnosticsAndReadCameraRows(
            application: application,
            settleCondition: { camera_rows in
                camera_rows[Self.bearingRowIndex]
                    == Self.rotatedContentFollowBearingReadback
            }
        )
        XCTAssertEqual(
            rotatedCameraRows[Self.bearingRowIndex],
            Self.rotatedContentFollowBearingReadback,
            "a clockwise two-finger rotation must rotate the content clockwise (the bearing lowers to the delta's reflection)"
        )
    }

    // MARK: Test 6 — the tap contract (one tap once, a double tap one level)

    /// The Espresso suite's
    /// `aSingleTapReportsOnceAndADoubleTapZoomsExactlyOneLevel` mirrored on
    /// iOS with real taps: a single tap reports exactly one confirmed click
    /// and leaves the camera alone, while a double tap at the same point
    /// zooms exactly one level and reports no click of its own (the shipped
    /// view's single recognizer waits for the double tap to fail). The
    /// assertions read the diagnostics sheet's camera rows and its
    /// confirmed-tap count; the keyless base map draws the frame the tap
    /// unprojects through, so no provider credential is involved.
    func testASingleTapReportsOnceAndADoubleTapZoomsExactlyOneLevel() throws {
        let application = launchApplication(launchArguments: [])
        awaitReadinessChipReady(application: application)

        let initialZoomLevel = try XCTUnwrap(
            readCameraZoomLevel(application: application),
            "the diagnostics camera block must render the drawn zoom readback"
        )
        let initialTapCount = try XCTUnwrap(
            readMapTapCount(application: application),
            "the diagnostics sheet must render the confirmed-tap count"
        )
        XCTAssertEqual(
            initialTapCount, 0,
            "a fresh launch reports no confirmed map click"
        )

        let mapTapCoordinate = application.coordinate(
            withNormalizedOffset: CGVector(
                dx: Self.mapTapHorizontalFraction,
                dy: Self.mapTapVerticalFraction
            )
        )

        // One tap: exactly one click, no camera move.
        mapTapCoordinate.tap()
        openDiagnosticsSheet(application: application)
        pollForSettlement(
            timeoutDescription: "the confirmed single tap's one map click"
        ) {
            mapTapCountRow(application: application).label
                == Self.mapTapCountLabel(tapCount: initialTapCount + 1)
        }
        let singleTapZoomLevel = try XCTUnwrap(
            cameraZoomLevelFromOpenSheet(application: application),
            "the open sheet must render the camera zoom after the single tap"
        )
        XCTAssertEqual(
            singleTapZoomLevel, initialZoomLevel,
            accuracy: Self.cameraZoomReadoutTolerance,
            "a single tap must not move the camera"
        )
        closeDiagnostics(application: application)

        // One double tap: exactly one zoom level, and still exactly one
        // confirmed click overall (the double tap's first touch never
        // reaches the single-tap callback).
        mapTapCoordinate.doubleTap()
        openDiagnosticsSheet(application: application)
        let expectedZoomLevel = initialZoomLevel + Self.doubleTapZoomStep
        pollForSettlement(
            timeoutDescription: "the double tap's one-level zoom"
        ) {
            guard let zoomLevel = cameraZoomLevelFromOpenSheet(application: application) else {
                return false
            }
            return abs(zoomLevel - expectedZoomLevel) <= Self.cameraZoomReadoutTolerance
        }
        let doubleTapZoomLevel = try XCTUnwrap(
            cameraZoomLevelFromOpenSheet(application: application),
            "the open sheet must render the camera zoom after the double tap"
        )
        XCTAssertEqual(
            doubleTapZoomLevel, expectedZoomLevel,
            accuracy: Self.cameraZoomReadoutTolerance,
            "a double tap must zoom exactly one level"
        )
        // The confirmed-single-tap window has passed by the time the zoom
        // settles: a late click from the double tap's first touch would have
        // landed by now.
        XCTAssertEqual(
            mapTapCountRow(application: application).label,
            Self.mapTapCountLabel(tapCount: initialTapCount + 1),
            "one double tap must not also report a map click"
        )
        closeDiagnostics(application: application)
    }

    // MARK: Test 7 — the styled vector base (M22)

    /// The Espresso suite's
    /// `selectingACommittedVectorStyleServesTheStyledBaseAndStatesTheLabelLimit`
    /// mirrored on iOS: the application launches on the shared registry's
    /// credential-less demo base map, the settings surface's base-map menu
    /// offers the registry's committed vector styles, and selecting one
    /// serves the styled vector tileset — the base-map section states the
    /// labels the styles draw, the serving row names the selected style, and no
    /// failure state is reported. The demo base map and the vector style are
    /// both read from the shared registry artifact (bundled into the test
    /// bundle), never hardcoded, and the run is keyless.
    func testSelectingACommittedVectorStyleServesTheStyledBaseAndStatesTheLabelLimit() throws {
        let providerRegistry = try loadProviderRegistry()
        // The demo base map: the registry's credential-less raster source on
        // iOS (the same descriptor a keyless start selects).
        guard let demoBaseMapDescriptor = providerRegistry.providers.first(
            where: { descriptor in
                descriptor.registrationAvailable.ios
                    && !descriptor.rasterUrlTemplate.trimmingCharacters(
                        in: .whitespacesAndNewlines
                    ).isEmpty
            }
        ) else {
            throw XCTSkip(
                "the shared provider registry declares no credential-less base map for iOS"
            )
        }
        // The first committed vector style the base-map menu offers (the
        // registry's artifact order is the provider order and its style
        // order is the menu's order).
        let vectorBaseOffers = providerRegistry.providers
            .filter { $0.offersVectorBase }
            .compactMap { descriptor in
                descriptor.vectorStyles.first.map { style in
                    (descriptor: descriptor, style: style)
                }
            }
        guard let firstVectorBaseOffer = vectorBaseOffers.first else {
            throw XCTSkip(
                "the shared provider registry declares no committed vector style"
            )
        }
        // The menu row's label is the provider's display name and the
        // style's own name (`VectorBaseMapChoice.displayName`).
        let vectorStyleDisplayName =
            firstVectorBaseOffer.descriptor.displayName
            + Self.vectorStyleNameSeparator
            + firstVectorBaseOffer.style.displayName

        let application = launchApplication(launchArguments: [
            "-\(Self.launchArgumentDemoBaseMap)", demoBaseMapDescriptor.providerKey,
        ])
        // The demo base map's first presented frame settles the ladder on
        // the ready state; the styled base is asserted against a running map.
        awaitReadinessChipReady(application: application)

        // The gear's own tap opens the settings surface (the base-map row is
        // the shared registry's descriptor-driven control).
        openProviderSettings(application: application)
        let baseMapMenu = elementWithIdentifier(
            Self.baseMapMenuIdentifier, in: application
        )
        XCTAssertTrue(
            baseMapMenu.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the settings surface's base-map row must render"
        )
        baseMapMenu.tap()

        // The styled base's row's own act: the menu item named by the shared
        // registry's vector style descriptor.
        let vectorStyleButton = application.buttons[vectorStyleDisplayName]
        XCTAssertTrue(
            vectorStyleButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the base-map menu must offer the registry's committed vector style, '\(vectorStyleDisplayName)'"
        )
        vectorStyleButton.tap()

        // The stated limit travels with the base that has it, so a user never
        // reads the absence of labels as a failure.
        let vectorLabelsNote = application.staticTexts[Self.vectorLabelsNoteText]
        pollForSettlement(
            timeoutDescription: "the base-map section's vector labels note"
        ) {
            vectorLabelsNote.exists
        }
        XCTAssertTrue(
            vectorLabelsNote.exists,
            "the base-map section must state the labels the styles draw, '\(Self.vectorLabelsNoteText)'"
        )

        // The serving row names the selected style (the active vector base's
        // consumer-facing name), so the selection is the base in force.
        pollForSettlement(
            timeoutDescription: "the base-map row naming the selected vector style"
        ) {
            baseMapMenu.exists && baseMapMenu.label.contains(vectorStyleDisplayName)
        }
        XCTAssertTrue(
            baseMapMenu.label.contains(vectorStyleDisplayName),
            "the base-map row must name the serving vector style, '\(vectorStyleDisplayName)', was '\(baseMapMenu.label)'"
        )

        // The menu marks that same row as serving (the vector style's own
        // label act) — the iOS analogue of the Android active-base assertion.
        baseMapMenu.tap()
        let servingStyleButton = application.buttons[
            vectorStyleDisplayName + Self.vectorStyleServingSuffix
        ]
        XCTAssertTrue(
            servingStyleButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the selected vector style must be the serving base, '\(vectorStyleDisplayName + Self.vectorStyleServingSuffix)'"
        )
        servingStyleButton.tap()

        // Close the settings surface and read the ladder and the error strip
        // the app renders: the styled base is a base, so the application
        // reports it as serving, never as a failed or degraded renderer.
        let closeControl = elementWithIdentifier(
            "provider-settings-close", in: application
        )
        XCTAssertTrue(
            closeControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the settings surface's close control must render"
        )
        closeControl.tap()

        // No failure state: the chip is neither failed nor degraded and the
        // error strip stays empty. The styled base is an accepted base, not a
        // renderer failure.
        let styledReadinessLabel = readinessChip(application: application).label
        XCTAssertFalse(
            styledReadinessLabel.hasPrefix("Failed:"),
            "the styled vector base must not put the ladder in the failed state, '\(styledReadinessLabel)'"
        )
        XCTAssertFalse(
            styledReadinessLabel.hasPrefix("Degraded:"),
            "the styled vector base must not put the ladder in the degraded state, '\(styledReadinessLabel)'"
        )
        XCTAssertFalse(
            elementWithIdentifier("error-report", in: application).exists,
            "an accepted styled base reports nothing in the error strip"
        )

        // The ladder settles back to ready on the frames the styled base
        // draws: the chip reports the presented surface, not the state the
        // base-map change entered (round 41 fixed the shell, which used to
        // stop at the loading line once the view's single ready report had
        // passed).
        awaitReadinessChipReady(application: application)
        XCTAssertEqual(
            readinessChip(application: application).label, "Ready",
            "the readiness ladder must settle on the ready state once the styled base presents"
        )

        // Visual evidence for the provider audit: the styled base as it
        // presents, kept with the run so a raster fallback could not pass for
        // a vector base in review.
        let styledBaseScreenshot = XCTAttachment(screenshot: application.screenshot())
        styledBaseScreenshot.name = "vector base \(vectorStyleDisplayName)"
        styledBaseScreenshot.lifetime = .keepAlways
        add(styledBaseScreenshot)
    }

    // MARK: Test 7b — the keyless start's styled base (owner ruling 2026-10-31)

    /// The keyless start opens on the registry's declared styled vector base:
    /// the credential-less raster source still registers so the surface
    /// attaches, and the declared style is installed over it before the user
    /// touches anything. The declaration, provider and style names all come
    /// from the shared registry artifact, never a hardcoded provider.
    func testTheKeylessStartOpensOnTheRegistrysDeclaredStyledBase() throws {
        try XCTSkipIf(
            hasRuntimeInjectedApiKey,
            "the keyless start's styled base needs a credential-less session"
        )
        let providerRegistry = try loadProviderRegistry()
        guard let declared = providerRegistry.keylessBaseMap,
              let declaredDescriptor = providerRegistry.providers.first(
                  where: { $0.providerKey == declared.providerKey }
              ),
              let declaredStyle = declaredDescriptor.vectorStyles.first(
                  where: { $0.styleId == declared.styleId }
              )
        else {
            throw XCTSkip(
                "the shared provider registry declares no resolvable keyless styled base"
            )
        }
        let expectedBaseDisplayName =
            declaredDescriptor.displayName + Self.vectorStyleNameSeparator
            + declaredStyle.displayName
        let application = launchApplication(launchArguments: [])
        awaitReadinessChipReady(application: application)

        openProviderSettings(application: application)
        let baseMapMenu = elementWithIdentifier(
            Self.baseMapMenuIdentifier, in: application
        )
        XCTAssertTrue(
            baseMapMenu.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the settings surface's base-map row must render"
        )
        // The install follows the surface attach, so the row is polled until
        // it names the registry's declared style rather than the raster
        // source selected first to give the surface something to attach to.
        pollForSettlement(
            timeoutDescription: "the base-map row naming the keyless styled base"
        ) {
            baseMapMenu.label.contains(expectedBaseDisplayName)
        }
        XCTAssertTrue(
            baseMapMenu.label.contains(expectedBaseDisplayName),
            "a keyless start must open on the registry's declared styled base, '\(expectedBaseDisplayName)', was '\(baseMapMenu.label)'"
        )
        // The menu marks that same entry as serving, so the selection is the
        // base in force rather than a label the row borrowed.
        baseMapMenu.tap()
        let servingStyleButton = application.buttons[
            expectedBaseDisplayName + Self.vectorStyleServingSuffix
        ]
        XCTAssertTrue(
            servingStyleButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the keyless styled base must be the serving entry, '\(expectedBaseDisplayName + Self.vectorStyleServingSuffix)'"
        )
        servingStyleButton.tap()
        let closeControl = elementWithIdentifier(
            "provider-settings-close", in: application
        )
        XCTAssertTrue(
            closeControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the settings surface's close control must render"
        )
        closeControl.tap()
        XCTAssertFalse(
            elementWithIdentifier("error-report", in: application).exists,
            "the keyless styled base reports nothing in the error strip"
        )
        awaitReadinessChipReady(application: application)
    }

    // MARK: Test 8 — remembered choices, reset and settings sizing

    /// The explicit choices survive a relaunch: the theme, the base map and
    /// the plan fields are restored from the versioned `UserDefaults` record,
    /// and the remembered pair fills the fields without planning a route.
    func testRememberedChoicesSurviveRelaunch() throws {
        defer { resetRememberedChoicesAfterTest() }
        let providerRegistry = try loadProviderRegistry()
        let vectorOffers = providerRegistry.providers
            .filter { $0.offersVectorBase }
            .flatMap { descriptor in
                descriptor.vectorStyles.map { style in
                    (descriptor: descriptor, style: style)
                }
            }
        let keylessBaseMap = providerRegistry.keylessBaseMap
        guard let rememberedBaseMap = vectorOffers.first(where: { offer in
            offer.descriptor.providerKey != keylessBaseMap?.providerKey
                || offer.style.styleId != keylessBaseMap?.styleId
        }) else {
            throw XCTSkip(
                "the registry offers no vector style beyond the keyless default"
            )
        }
        let rememberedBaseMapLabel = rememberedBaseMap.descriptor.displayName
            + Self.vectorStyleNameSeparator + rememberedBaseMap.style.displayName

        let application = launchFreshApplication(
            launchArguments: ["-\(Self.launchArgumentSheetHalfState)", Self.launchArgumentBooleanTrueValue]
        )
        // The theme toggle cycles Auto -> Light; the label names the next choice.
        let themeToggle = elementWithIdentifier("theme-toggle", in: application)
        XCTAssertTrue(
            themeToggle.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the half sheet's theme row must render"
        )
        XCTAssertEqual(themeToggle.label, "Switch to light theme")
        themeToggle.tap()
        XCTAssertTrue(
            waitForLabel("Switch to dark theme", element: themeToggle),
            "the explicit Light choice must be in force"
        )

        // Choose a styled base map that the keyless start did not already
        // serve, through the settings menu's own item.
        openProviderSettings(application: application)
        let baseMapMenu = elementWithIdentifier(
            Self.baseMapMenuIdentifier, in: application
        )
        XCTAssertTrue(
            baseMapMenu.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the settings surface's base-map row must render"
        )
        baseMapMenu.tap()
        let rememberedBaseMapButton = application.buttons[rememberedBaseMapLabel]
        XCTAssertTrue(
            rememberedBaseMapButton.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the base-map menu must offer '\(rememberedBaseMapLabel)'"
        )
        rememberedBaseMapButton.tap()
        pollForSettlement(timeoutDescription: "the selected base map serving") {
            baseMapMenu.exists && baseMapMenu.label.contains(rememberedBaseMapLabel)
        }
        XCTAssertTrue(baseMapMenu.label.contains(rememberedBaseMapLabel))
        elementWithIdentifier("provider-settings-close", in: application).tap()

        // Type both plan fields through the search view; typing never plans.
        typeRememberedPlanFields(in: application)

        application.terminate()
        let relaunched = launchApplication(
            launchArguments: [
                "-\(Self.launchArgumentSheetHalfState)",
                Self.launchArgumentBooleanTrueValue,
            ],
            resetsRememberedChoices: false
        )
        let relaunchedThemeToggle = elementWithIdentifier(
            "theme-toggle", in: relaunched
        )
        XCTAssertTrue(
            relaunchedThemeToggle.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the relaunched half sheet's theme row must render"
        )
        XCTAssertTrue(
            waitForLabel("Switch to dark theme", element: relaunchedThemeToggle),
            "the explicit Light choice must be restored"
        )

        openProviderSettings(application: relaunched)
        let relaunchedBaseMapMenu = elementWithIdentifier(
            Self.baseMapMenuIdentifier, in: relaunched
        )
        XCTAssertTrue(
            relaunchedBaseMapMenu.waitForExistence(timeout: Self.settleTimeoutSeconds)
        )
        XCTAssertTrue(
            relaunchedBaseMapMenu.label.contains(rememberedBaseMapLabel),
            "the remembered base map must be serving, was '\(relaunchedBaseMapMenu.label)'"
        )
        elementWithIdentifier("provider-settings-close", in: relaunched).tap()

        openSearchViewArmedForOrigin(in: relaunched)
        XCTAssertEqual(
            textFieldValue(relaunched.textFields["Search an origin"]),
            Self.rememberedOriginText,
            "the remembered origin text must fill the field"
        )
        XCTAssertEqual(
            textFieldValue(relaunched.textFields["Search a destination"]),
            Self.rememberedDestinationText,
            "the remembered destination text must fill the field"
        )
        XCTAssertFalse(
            elementWithIdentifier("route-summary-card", in: relaunched).exists,
            "a remembered pair must never plan a route by itself"
        )
    }

    /// The reset row clears the record; the next launch returns to the
    /// never-chose defaults.
    func testResetRememberedChoicesClearsTheRecord() throws {
        defer { resetRememberedChoicesAfterTest() }
        let application = launchFreshApplication(
            launchArguments: ["-\(Self.launchArgumentSheetHalfState)", Self.launchArgumentBooleanTrueValue]
        )
        let themeToggle = elementWithIdentifier("theme-toggle", in: application)
        XCTAssertTrue(themeToggle.waitForExistence(timeout: Self.settleTimeoutSeconds))
        themeToggle.tap()
        XCTAssertTrue(waitForLabel("Switch to dark theme", element: themeToggle))
        typeRememberedPlanFields(in: application)

        openProviderSettings(application: application)
        let settingsSheet = elementWithIdentifier("provider-settings-sheet", in: application)
        let resetRow = elementWithIdentifier(
            "provider-settings-reset-remembered-choices", in: application
        )
        scrollToMake(resetRow, visibleIn: settingsSheet)
        XCTAssertTrue(resetRow.exists && resetRow.isHittable, "the reset row must be reachable")
        resetRow.tap()
        elementWithIdentifier("provider-settings-close", in: application).tap()

        application.terminate()
        let relaunched = launchApplication(
            launchArguments: [
                "-\(Self.launchArgumentSheetHalfState)",
                Self.launchArgumentBooleanTrueValue,
            ],
            resetsRememberedChoices: false
        )
        let relaunchedThemeToggle = elementWithIdentifier(
            "theme-toggle", in: relaunched
        )
        XCTAssertTrue(
            relaunchedThemeToggle.waitForExistence(timeout: Self.settleTimeoutSeconds)
        )
        XCTAssertTrue(
            waitForLabel("Switch to light theme", element: relaunchedThemeToggle),
            "the reset must restore the Auto default"
        )
        openSearchViewArmedForOrigin(in: relaunched)
        XCTAssertEqual(
            textFieldValue(application.textFields["Search an origin"]), "",
            "the reset must clear the remembered origin text"
        )
        XCTAssertEqual(
            textFieldValue(application.textFields["Search a destination"]), "",
            "the reset must clear the remembered destination text"
        )
    }

    /// The settings surface stays inside the documented height fraction, its
    /// Close action stays visible and its last section is reachable by
    /// scrolling inside the sheet.
    func testSettingsSurfaceFitsTheViewportAndScrollsInternally() throws {
        let application = launchFreshApplication(launchArguments: [])
        openProviderSettings(application: application)
        let settingsSheet = elementWithIdentifier("provider-settings-sheet", in: application)
        let window = application.windows.firstMatch
        XCTAssertTrue(settingsSheet.exists)
        let maximumHeight = window.frame.height
            * AppLayout.phonePanelMaximumHeightFraction
        XCTAssertLessThanOrEqual(
            settingsSheet.frame.height,
            maximumHeight + Self.settingsHeightTolerancePoints,
            "the settings sheet must respect the documented height fraction"
        )
        XCTAssertGreaterThanOrEqual(settingsSheet.frame.minY, 0)
        XCTAssertLessThanOrEqual(
            settingsSheet.frame.maxY,
            window.frame.maxY + Self.settingsHeightTolerancePoints,
            "the settings sheet must stay above the screen's bottom edge"
        )
        XCTAssertTrue(
            elementWithIdentifier("provider-settings-close", in: application).isHittable,
            "the pinned Close action must stay visible"
        )
        let resetRow = elementWithIdentifier(
            "provider-settings-reset-remembered-choices", in: application
        )
        scrollToMake(resetRow, visibleIn: settingsSheet)
        XCTAssertTrue(
            resetRow.exists && resetRow.isHittable,
            "the last settings section must be reachable inside the sheet"
        )
    }

    // MARK: The suite's shared driving helpers

    /// Launches with the remembered choices cleared first, so a persistence
    /// case starts from the never-chose defaults.
    private func launchFreshApplication(
        launchArguments: [String],
        injectsRuntimeCredential: Bool = true
    ) -> XCUIApplication {
        launchApplication(
            launchArguments: launchArguments,
            injectsRuntimeCredential: injectsRuntimeCredential,
            resetsRememberedChoices: true
        )
    }

    /// Restores the never-chose defaults for the following case (a relaunch
    /// with the record reset, then a clean exit).
    private func resetRememberedChoicesAfterTest() {
        application?.terminate()
        let cleanupApplication = XCUIApplication()
        cleanupApplication.launchArguments = [
            "-\(Self.launchArgumentResetRememberedChoices)",
            Self.launchArgumentBooleanTrueValue,
        ]
        cleanupApplication.launch()
        cleanupApplication.terminate()
        application = nil
    }

    /// Types both plan fields through the search view without submitting:
    /// typing never plans, and the fields' last text is what the record keeps.
    private func typeRememberedPlanFields(in application: XCUIApplication) {
        openSearchViewArmedForOrigin(in: application)
        let originField = application.textFields["Search an origin"]
        XCTAssertTrue(
            originField.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the search view's origin field must render"
        )
        originField.tap()
        originField.typeText(Self.rememberedOriginText)
        let destinationField = application.textFields["Search a destination"]
        XCTAssertTrue(
            destinationField.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the search view's destination field must render"
        )
        destinationField.tap()
        destinationField.typeText(Self.rememberedDestinationText)
    }

    /// Opens the search view armed for the origin through the peek entry.
    private func openSearchViewArmedForOrigin(in application: XCUIApplication) {
        dragSheetGrabber(application: application, direction: .down)
        let setOriginControl = elementWithIdentifier(
            "home-sheet-peek-set-origin", in: application
        )
        XCTAssertTrue(
            setOriginControl.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the peek's origin entry must render"
        )
        setOriginControl.tap()
        XCTAssertTrue(
            elementWithIdentifier("search-view-origin-field", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the origin entry must open the search view"
        )
    }

    /// A text field's typed value; an untouched field reports its placeholder
    /// as the value, which this helper maps back to the empty string.
    private func textFieldValue(_ textField: XCUIElement) -> String {
        let value = textField.value as? String ?? ""
        return value == textField.placeholderValue ? "" : value
    }

    /// Launches a fresh application instance with the given launch
    /// arguments (the documented demo-automation flags, `-key` form; no
    /// flags means the plain launch the ladder test covers). A case that
    /// must stay keyless opts out of the runtime credential seam, so its
    /// search and plan flow reads the shared artifact's recorded route
    /// rather than reaching a provider. Every ordinary launch clears the
    /// remembered choices first, so one case cannot inherit another's; the
    /// persistence cases pass `resetsRememberedChoices: false` on relaunch.
    private func launchApplication(
        launchArguments: [String],
        injectsRuntimeCredential: Bool = true,
        resetsRememberedChoices: Bool = true
    ) -> XCUIApplication {
        let application = XCUIApplication()
        application.launchArguments = (
            resetsRememberedChoices
                ? [
                    "-\(Self.launchArgumentResetRememberedChoices)",
                    Self.launchArgumentBooleanTrueValue,
                ]
                : []
        ) + launchArguments
        if injectsRuntimeCredential, let runtimeCredential = runtimeInjectedApiKey {
            // The automation credential seam (§6.5): the app applies it at
            // launch and never persists it.
            application.launchEnvironment["PROVIDER_API_KEY"] = runtimeCredential
        }
        if injectsRuntimeCredential, let runtimeProviderKey = runtimeInjectedProviderKey {
            application.launchEnvironment["PROVIDER_KEY"] = runtimeProviderKey
        }
        application.launch()
        self.application = application
        return application
    }

    /// Grants the when-in-use authorization prompt the device source raises
    /// (the system alert or Springboard's, depending on the runner).
    private func grantWhenInUseLocationAuthorization(in application: XCUIApplication) {
        let authorizationAlert = application.alerts.firstMatch
        if authorizationAlert.waitForExistence(timeout: 5) {
            for allowLabel in ["Allow While Using App", "Allow Once", "Allow"] {
                let allowButton = authorizationAlert.buttons[allowLabel]
                if allowButton.exists {
                    allowButton.tap()
                    return
                }
            }
        } else {
            let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
            for allowLabel in ["Allow While Using App", "Allow Once", "Allow"] {
                let allowButton = springboard.buttons[allowLabel]
                if allowButton.waitForExistence(timeout: 2) {
                    allowButton.tap()
                    return
                }
            }
        }
    }

    /// Plans the shared artifact's recorded Capitol Park -> Tower Bridge
    /// route through the search view's own fields, submit controls, result
    /// rows and explicit Plan route action (the keyless path; no provider
    /// call, no invented geometry).
    private func planRecordedDemoRoute(application: XCUIApplication) {
        let originField = application.textFields["Search an origin"]
        XCTAssertTrue(originField.waitForExistence(timeout: Self.settleTimeoutSeconds))
        originField.tap()
        originField.typeText("Capitol Park\n")
        let originResult = searchResultRow(containing: "Capitol Park", in: application)
        XCTAssertTrue(originResult.waitForExistence(timeout: Self.settleTimeoutSeconds))
        originResult.tap()

        let destinationField = application.textFields["Search a destination"]
        XCTAssertTrue(destinationField.waitForExistence(timeout: Self.settleTimeoutSeconds))
        destinationField.tap()
        destinationField.typeText("Tower Bridge\n")
        let destinationResult = searchResultRow(containing: "Tower Bridge", in: application)
        XCTAssertTrue(destinationResult.waitForExistence(timeout: Self.settleTimeoutSeconds))
        destinationResult.tap()

        let planRouteButton = elementWithIdentifier("plan-route-button", in: application)
        XCTAssertTrue(planRouteButton.waitForExistence(timeout: Self.settleTimeoutSeconds))
        XCTAssertTrue(planRouteButton.isEnabled, "both assigned fields enable Plan route")
        planRouteButton.tap()
    }

    /// The result row whose rendered label names `placeName`.
    private func searchResultRow(
        containing placeName: String,
        in application: XCUIApplication
    ) -> XCUIElement {
        application.descendants(matching: .any)
            .matching(identifier: "search-result-row")
            .matching(NSPredicate(format: "label CONTAINS %@", placeName))
            .firstMatch
    }

    /// Polls until the element's label equals `expectedLabel`.
    private func waitForLabel(
        _ expectedLabel: String,
        element: XCUIElement,
        timeout: TimeInterval = defaultAssertionTimeoutSeconds
    ) -> Bool {
        let labelPredicate = NSPredicate { _, _ in
            element.exists && element.label == expectedLabel
        }
        let labelExpectation = XCTNSPredicateExpectation(
            predicate: labelPredicate,
            object: nil
        )
        return XCTWaiter.wait(for: [labelExpectation], timeout: timeout) == .completed
    }

    /// Polls until the element's label contains `expectedText`.
    private func waitForLabelContaining(
        _ expectedText: String,
        element: XCUIElement,
        timeout: TimeInterval = defaultAssertionTimeoutSeconds
    ) -> Bool {
        let labelPredicate = NSPredicate { _, _ in
            element.exists && element.label.contains(expectedText)
        }
        let labelExpectation = XCTNSPredicateExpectation(
            predicate: labelPredicate,
            object: nil
        )
        return XCTWaiter.wait(for: [labelExpectation], timeout: timeout) == .completed
    }

    /// Polls until the element renders a non-empty label.
    private func waitForNonemptyLabel(
        element: XCUIElement,
        timeout: TimeInterval = defaultAssertionTimeoutSeconds
    ) -> Bool {
        let labelPredicate = NSPredicate { _, _ in
            element.exists && !element.label.isEmpty
        }
        let labelExpectation = XCTNSPredicateExpectation(
            predicate: labelPredicate,
            object: nil
        )
        return XCTWaiter.wait(for: [labelExpectation], timeout: timeout) == .completed
    }

    /// Polls until the element leaves the accessibility tree.
    private func waitForNonexistence(
        _ element: XCUIElement,
        timeout: TimeInterval = defaultAssertionTimeoutSeconds
    ) -> Bool {
        let nonexistencePredicate = NSPredicate { _, _ in !element.exists }
        let nonexistenceExpectation = XCTNSPredicateExpectation(
            predicate: nonexistencePredicate,
            object: nil
        )
        return XCTWaiter.wait(for: [nonexistenceExpectation], timeout: timeout) == .completed
    }

    /// The shared provider registry, decoded from the test bundle's copy of
    /// the single committed artifact (`platform/providers.json`) with the
    /// application's own schema type. The styled-base case names the demo base
    /// map and the vector style from it, so a registry edit is a data change,
    /// not a test rewrite.
    private func loadProviderRegistry() throws -> ProviderRegistryCatalog {
        let testBundle = Bundle(for: ReferenceApplicationUITests.self)
        guard let registryURL = testBundle.url(
            forResource: "providers", withExtension: "json"
        ) else {
            throw XCTSkip(
                "the shared provider registry resource is missing from the UI test bundle"
            )
        }
        return try ProviderRegistryCatalog.decoded(
            from: Data(contentsOf: registryURL)
        )
    }

    /// Opens the provider-settings sheet (the gear control's own tap act).
    private func openProviderSettings(application: XCUIApplication) {
        let settingsGear = elementWithIdentifier(
            "provider-settings-gear", in: application
        )
        XCTAssertTrue(
            settingsGear.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the gear control must open the provider-settings sheet"
        )
        settingsGear.tap()
        XCTAssertTrue(
            elementWithIdentifier("provider-settings-sheet", in: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the gear's tap must present the provider-settings sheet"
        )
    }

    /// Awaits the readiness ladder's ready state (the first honest settle;
    /// the chip's text is the ladder's rendered short line). The bound is
    /// the Android suite's minutes-scaled emulator settle bound.
    private func awaitReadinessChipReady(application: XCUIApplication) {
        let readinessChipElement = readinessChip(application: application)
        let readinessReadyPredicate = NSPredicate { _, _ in
            readinessChipElement.exists && readinessChipElement.label == "Ready"
        }
        let readinessReadyExpectation = XCTNSPredicateExpectation(
            predicate: readinessReadyPredicate,
            object: nil
        )
        XCTAssertEqual(
            XCTWaiter.wait(
                for: [readinessReadyExpectation],
                timeout: Self.emulatorFirstReadyTimeoutSeconds
            ),
            .completed,
            "the readiness ladder must settle on the ready state, '\(readinessChipElement.exists ? readinessChipElement.label : "absent")'"
        )
    }

    private func readinessChip(application: XCUIApplication) -> XCUIElement {
        elementWithIdentifier("readiness-chip", in: application)
    }

    /// The camera readback's `center <lat>, <lon>` row parsed into degrees
    /// (the application renders dot-decimal `String(format:)` numbers, and
    /// `Double`'s parser is locale-free), `nil` when the row is absent or
    /// unparseable.
    private static func centerRowCoordinates(
        of centerRow: String
    ) -> (latitude: Double, longitude: Double)? {
        let coordinateText = centerRow.dropFirst("center ".count)
        let coordinateParts = coordinateText
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
        guard coordinateParts.count == 2,
            let latitude_degrees = Double(coordinateParts[0]),
            let longitude_degrees = Double(coordinateParts[1])
        else {
            return nil
        }
        return (latitude_degrees, longitude_degrees)
    }

    /// The diagnostics sheet's element (its accessibility identifier
    /// scopes the readback row queries to the sheet's own subtree).
    private func diagnosticsSheet(application: XCUIApplication) -> XCUIElement {
        elementWithIdentifier("diagnostics-sheet", in: application)
    }

    /// Opens the diagnostics sheet (the readiness chip's own tap act).
    private func openDiagnosticsSheet(application: XCUIApplication) {
        let readinessChipElement = readinessChip(application: application)
        XCTAssertTrue(
            readinessChipElement.exists && readinessChipElement.isHittable,
            "the readiness chip must be the diagnostics sheet's opening control"
        )
        readinessChipElement.tap()
        XCTAssertTrue(
            diagnosticsSheet(application: application)
                .waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the readiness chip's tap must open the diagnostics sheet"
        )
    }

    /// Opens the diagnostics sheet (the readiness chip's own tap act) and
    /// reads the camera block's four readback rows, optionally waiting for
    /// the rows to satisfy the given settle condition first (each
    /// condition poll is a re-snapshot of the rendered tree — the readback
    /// is per drawn frame, so the wait is the drawn-frame settles).
    private func openDiagnosticsAndReadCameraRows(
        application: XCUIApplication,
        settleCondition: (([String]) -> Bool)? = nil,
        closesSheetAfterReading: Bool = true
    ) -> [String] {
        openDiagnosticsSheet(application: application)
        let diagnosticsSheetElement = diagnosticsSheet(application: application)
        XCTAssertTrue(
            diagnosticsSheetElement.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the readiness chip's tap must open the diagnostics sheet"
        )
        let sheetScrollView = diagnosticsSheetElement.scrollViews.firstMatch
        if let settleCondition {
            pollForSettlement(
                timeoutDescription: "the camera readback rows satisfying the awaited condition"
            ) {
                settleCondition(readCameraReadbackRows(sheet: diagnosticsSheetElement))
            }
        }
        let cameraRows = readCameraReadbackRowsWithScrolling(
            sheet: diagnosticsSheetElement,
            scrollView: sheetScrollView
        )
        if closesSheetAfterReading {
            closeDiagnostics(application: application)
        }
        return cameraRows
    }

    private func closeDiagnostics(application: XCUIApplication) {
        let closeControl = elementWithIdentifier("diagnostics-close", in: application)
        if closeControl.exists {
            closeControl.tap()
        }
        XCTAssertTrue(
            pollForNonExistence(
                elementWithIdentifier("diagnostics-sheet", in: application),
                within: Self.settleTimeoutSeconds
            ),
            "the diagnostics close control must dismiss the sheet"
        )
    }

    /// The diagnostics sheet's camera readback rows (the Camera block's
    /// lines — center, zoom, bearing and pitch, in the block's fixed
    /// order); an unrendered row reads as the empty string.
    private func readCameraReadbackRows(sheet: XCUIElement) -> [String] {
        Self.cameraReadbackRowPrefixes.map { rowPrefix in
            let rowQuery = sheet.staticTexts
                .matching(NSPredicate(format: "label BEGINSWITH %@", rowPrefix + " "))
                .firstMatch
            guard rowQuery.exists, !rowQuery.label.isEmpty else { return "" }
            return rowQuery.label
        }
    }

    /// The camera readback rows' scrolled read: the sheet's content
    /// scrolls until every row's label is readable (the Events backlog
    /// can push the Camera block below the fold; the content is not
    /// lazy, so off-screen labels usually read anyway — the scroll is the
    /// fallback, bounded).
    private func readCameraReadbackRowsWithScrolling(
        sheet: XCUIElement,
        scrollView: XCUIElement?
    ) -> [String] {
        for _ in 0 ..< Self.maximumScrollAttempts {
            let cameraRows = readCameraReadbackRows(sheet: sheet)
            if cameraRows.allSatisfy({ !$0.isEmpty }) {
                return cameraRows
            }
            guard let scrollView, scrollView.exists else { break }
            scrollDownElement(scrollView)
        }
        return readCameraReadbackRows(sheet: sheet)
    }

    /// The diagnostics sheet's confirmed-tap count row (the sheet's own
    /// accessibility identifier; the row's label is `map taps <count>`).
    private func mapTapCountRow(application: XCUIApplication) -> XCUIElement {
        elementWithIdentifier("diagnostics-map-tap-count", in: application)
    }

    /// The row's rendered label for one expected count.
    private static func mapTapCountLabel(tapCount: Int) -> String {
        mapTapCountRowPrefix + String(tapCount)
    }

    /// The camera zoom level parsed from a `zoom <levels>` readback row
    /// (the application renders two decimals; the parser is locale-free),
    /// `nil` when the row is absent or unparseable.
    private static func zoomLevel(fromCameraRow zoomRow: String) -> Double? {
        guard zoomRow.hasPrefix("zoom ") else { return nil }
        return Double(zoomRow.dropFirst("zoom ".count))
    }

    /// The diagnostics sheet's camera zoom readback, read through the
    /// sheet's own open/read/close cycle.
    private func readCameraZoomLevel(application: XCUIApplication) -> Double? {
        let cameraRows = openDiagnosticsAndReadCameraRows(application: application)
        return Self.zoomLevel(fromCameraRow: cameraRows[Self.zoomRowIndex])
    }

    /// The camera zoom readback from an already-open diagnostics sheet
    /// (scrolling the sheet when the Events backlog pushes the Camera
    /// block below the fold).
    private func cameraZoomLevelFromOpenSheet(
        application: XCUIApplication
    ) -> Double? {
        let sheet = diagnosticsSheet(application: application)
        let cameraRows = readCameraReadbackRowsWithScrolling(
            sheet: sheet,
            scrollView: sheet.scrollViews.firstMatch
        )
        return Self.zoomLevel(fromCameraRow: cameraRows[Self.zoomRowIndex])
    }

    /// The diagnostics sheet's confirmed-tap count (opens the sheet, reads
    /// the row, closes the sheet so the next act can reach the map).
    private func readMapTapCount(application: XCUIApplication) -> Int? {
        openDiagnosticsSheet(application: application)
        let tapCountRow = mapTapCountRow(application: application)
        XCTAssertTrue(
            tapCountRow.waitForExistence(timeout: Self.settleTimeoutSeconds),
            "the diagnostics sheet must render the confirmed-tap count row"
        )
        let tapCountLabel = tapCountRow.label
        closeDiagnostics(application: application)
        guard tapCountLabel.hasPrefix(Self.mapTapCountRowPrefix) else { return nil }
        return Int(tapCountLabel.dropFirst(Self.mapTapCountRowPrefix.count))
    }

    /// The toggled-on scene's read seam: opens the diagnostics sheet and
    /// awaits the overlay triangles line settling away from the given
    /// line (the scene joining the pushed overlay list), then closes the
    /// sheet again (the chips toggle under a dismissed sheet).
    private func openDiagnosticsAndReadChanged(
        application: XCUIApplication,
        fromLine: String
    ) -> String {
        openDiagnosticsSheet(application: application)
        let changedLine = awaitChangedOverlayTrianglesLine(
            application: application,
            fromLine: fromLine
        )
        closeDiagnostics(application: application)
        return changedLine
    }

    /// The toggled-off scene's read seam: opens the diagnostics sheet and
    /// awaits the overlay triangles line settling back to the given line
    /// (the scene leaving the pushed overlay list), then closes the sheet.
    private func reopenDiagnosticsAndAwaitRestored(
        application: XCUIApplication,
        fromLine: String,
        toLine: String
    ) {
        openDiagnosticsSheet(application: application)
        awaitRestoredOverlayTrianglesLine(
            application: application,
            fromLine: fromLine,
            toLine: toLine
        )
        closeDiagnostics(application: application)
    }

    /// The tiles block's overlay-triangles row query (the drawn-frame
    /// witness of the pushed overlay list; a prefix label match — the
    /// row's own live count trails the label).
    private func overlayTrianglesRow(
        application: XCUIApplication
    ) -> XCUIElement {
        diagnosticsSheet(application: application).staticTexts
            .matching(NSPredicate(
                format: "label BEGINSWITH %@",
                Self.overlayTrianglesRowPrefix + " "
            ))
            .firstMatch
    }

    /// The tiles block's overlay-triangles line (the drawn-frame witness
    /// of the pushed overlay list), awaited until it renders, scrolling
    /// the sheet when the line sits below the fold.
    private func awaitOverlayTrianglesLine(
        application: XCUIApplication
    ) -> String {
        let overlayTrianglesRow = overlayTrianglesRow(application: application)
        let sheetScrollView: XCUIElement? = diagnosticsSheet(application: application)
            .scrollViews.firstMatch
        for _ in 0 ..< Self.maximumScrollAttempts {
            if overlayTrianglesRow.exists, !overlayTrianglesRow.label.isEmpty {
                return overlayTrianglesRow.label
            }
            if let sheetScrollView, sheetScrollView.exists {
                scrollDownElement(sheetScrollView)
            }
        }
        return overlayTrianglesRow.exists ? overlayTrianglesRow.label : ""
    }

    /// Waits until the overlay triangles line differs from the given line
    /// (a pushed overlay joining the live accounting), then returns the
    /// settled line.
    private func awaitChangedOverlayTrianglesLine(
        application: XCUIApplication,
        fromLine: String
    ) -> String {
        let lineQuery = overlayTrianglesRow(application: application)
        pollForSettlement(
            timeoutDescription: "the toggled-on scene joining the pushed overlay list"
        ) {
            lineQuery.exists
                && !lineQuery.label.isEmpty
                && lineQuery.label != fromLine
        }
        return lineQuery.exists ? lineQuery.label : fromLine
    }

    /// Waits until the overlay triangles line returns to the given
    /// restored line (a toggled-off overlay leaving the live accounting).
    private func awaitRestoredOverlayTrianglesLine(
        application: XCUIApplication,
        fromLine: String,
        toLine: String
    ) {
        let lineQuery = overlayTrianglesRow(application: application)
        pollForSettlement(
            timeoutDescription: "the toggled-off scene leaving the pushed overlay list"
        ) {
            lineQuery.exists
                && !lineQuery.label.isEmpty
                && lineQuery.label != fromLine
                && lineQuery.label == toLine
        }
    }

    /// One downward scroll drag on an element (the scroll containers'
    /// shared drag shape).
    private func scrollDownElement(_ container: XCUIElement) {
        let containerCenter = container.coordinate(
            withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)
        )
        let dragStart = containerCenter.withOffset(CGVector(dx: 0, dy: 100))
        let dragFinish = containerCenter.withOffset(CGVector(dx: 0, dy: -140))
        dragStart.press(forDuration: 0.05, thenDragTo: dragFinish)
        Thread.sleep(forTimeInterval: Self.pollIntervalSeconds)
    }

    /// A scene chip by its rendered label (the shared artifact's scene
    /// labels).
    private func sceneChip(application: XCUIApplication, label: String) -> XCUIElement {
        application.buttons
            .matching(NSPredicate(format: "label == %@", label))
            .firstMatch
    }

    /// The banner's rendered text labels (the composed §7.1 form's slots —
    /// the distance phrase and the maneuver line — plus the banner's own
    /// flattened label, whichever shape the accessibility tree takes).
    private static func bannerLabelTexts(banner: XCUIElement) -> [String] {
        var bannerLabelTexts = banner.staticTexts
            .allElementsBoundByIndex
            .map(\.label)
        if !banner.label.isEmpty {
            bannerLabelTexts.append(banner.label)
        }
        return bannerLabelTexts.filter { !$0.isEmpty }
    }

    /// The recorded fixture's step display texts, decoded from the same
    /// committed fixture the test bundle carries (network-free; the
    /// fixture is the single source of the recorded content).
    private static func recordedStepDisplayTexts(
        fixtureScenarioNamed scenarioName: String
    ) throws -> [String] {
        guard let fixtureURL = Bundle(for: ReferenceApplicationUITests.self)
            .url(forResource: scenarioName, withExtension: "json") else {
            throw NSError(
                domain: "ReferenceApplicationUITests",
                code: 1,
                userInfo: [
                    NSLocalizedDescriptionKey:
                        "the recorded trace fixture '\(scenarioName).json' is not bundled with the test target"
                ]
            )
        }
        let fixtureDocument = try JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL))
        guard
            let fixtureDocumentDictionary = fixtureDocument as? [String: Any],
            let fixtureRoute = fixtureDocumentDictionary["route"] as? [String: Any],
            let fixtureLegs = fixtureRoute["legs"] as? [[String: Any]]
        else {
            return []
        }
        return fixtureLegs.flatMap { fixtureLeg in
            (fixtureLeg["steps"] as? [[String: Any]] ?? []).compactMap { fixtureStep in
                fixtureStep["instruction_display_text"] as? String
            }
        }
    }

    /// The recorded fixture's final route shape coordinate, decoded from
    /// the same committed fixture the application walks (the arrival's
    /// centred-destination assertion; network-free).
    private static func recordedRouteEndCoordinate(
        fixtureScenarioNamed scenarioName: String
    ) -> (latitude: Double, longitude: Double)? {
        guard let fixtureURL = Bundle(for: ReferenceApplicationUITests.self)
            .url(forResource: scenarioName, withExtension: "json"),
            let fixtureData = try? Data(contentsOf: fixtureURL),
            let fixtureDocument = try? JSONSerialization.jsonObject(with: fixtureData),
            let fixtureDocumentDictionary = fixtureDocument as? [String: Any],
            let fixtureRoute = fixtureDocumentDictionary["route"] as? [String: Any],
            let fixtureLegs = fixtureRoute["legs"] as? [[String: Any]]
        else {
            return nil
        }
        let finalShapeCoordinate = fixtureLegs
            .flatMap { fixtureLeg in
                (fixtureLeg["steps"] as? [[String: Any]] ?? []).flatMap { fixtureStep in
                    fixtureStep["shape"] as? [[String: Any]] ?? []
                }
            }
            .last
        guard
            let finalShapeCoordinate,
            let latitude = finalShapeCoordinate["latitude"] as? Double,
            let longitude = finalShapeCoordinate["longitude"] as? Double
        else {
            return nil
        }
        return (latitude, longitude)
    }

    /// The home sheet's grabber drag (the fold gesture's own target; the
    /// sheet's only gesture target, §4.2). The grabber is not a control —
    /// its identifier exists for the suite's fold act alone.
    private func dragSheetGrabber(
        application: XCUIApplication,
        direction: SheetFoldDirection
    ) {
        let grabber = elementWithIdentifier("sheet-grabber", in: application)
        guard grabber.exists else {
            XCTFail("the home sheet's grabber must render for the fold act")
            return
        }
        let dragDeltaPoints: CGFloat = direction == .up
            ? -Self.sheetFoldDragPoints
            : Self.sheetFoldDragPoints
        let dragStart = grabber.coordinate(
            withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)
        )
        let dragFinish = dragStart.withOffset(
            CGVector(dx: 0, dy: dragDeltaPoints)
        )
        dragStart.press(forDuration: 0.05, thenDragTo: dragFinish)
    }

    /// The sheet's fold directions (the grabber's drag gesture's own
    /// directions).
    private enum SheetFoldDirection {
        /// The sheet grows one fold state.
        case up
        /// The sheet collapses one fold state.
        case down
    }

    /// Scrolls a scrollable container toward its content's end until the
    /// element exists and is hittable; returns when it became visible or
    /// the drag count is exhausted.
    private func scrollToMake(_ element: XCUIElement, visibleIn container: XCUIElement) {
        guard container.exists else { return }
        for _ in 0 ..< Self.maximumScrollAttempts {
            if element.exists, element.isHittable {
                return
            }
            scrollDownElement(container)
        }
    }

    /// Polls a condition closure on the test thread until it holds or the
    /// given timeout elapses (the Espresso suite's `awaitOrTimeout` shape
    /// — the waits are never screenshot waits: every poll is a fresh
    /// accessibility-tree snapshot of the exact values the screen
    /// renders). No failing poll is a test failure itself; the caller's
    /// assertion is the verdict.
    private func pollForSettlement(
        timeoutDescription: String,
        timeoutSeconds: TimeInterval = defaultAssertionTimeoutSeconds,
        file: StaticString = #file,
        line: UInt = #line,
        condition: () -> Bool
    ) {
        let deadline = Date().addingTimeInterval(timeoutSeconds)
        while !condition() {
            if Date() > deadline {
                XCTFail(
                    "\(timeoutDescription) did not settle within \(Int(timeoutSeconds)) seconds",
                    file: file,
                    line: line
                )
                return
            }
            Thread.sleep(forTimeInterval: Self.pollIntervalSeconds)
        }
    }

    /// Whether the element leaves the rendered tree within the timeout
    /// (a `waitForNonExistence`-shaped poll).
    private func pollForNonExistence(
        _ element: XCUIElement,
        within timeoutSeconds: TimeInterval
    ) -> Bool {
        let deadline = Date().addingTimeInterval(timeoutSeconds)
        while element.exists {
            if Date() > deadline {
                return false
            }
            Thread.sleep(forTimeInterval: Self.pollIntervalSeconds)
        }
        return true
    }

    /// Whether the element satisfies the given trait condition within the
    /// settle bound.
    private func pollElement(
        _ element: XCUIElement,
        condition: (XCUIElement) -> Bool
    ) -> Bool {
        let deadline = Date().addingTimeInterval(Self.settleTimeoutSeconds)
        while !condition(element) {
            if Date() > deadline {
                return false
            }
            Thread.sleep(forTimeInterval: Self.pollIntervalSeconds)
        }
        return true
    }

    /// The application subtree's element search: any element type with the
    /// accessibility identifier (the SwiftUI elements' traits vary — the
    /// button, other and static-text queries all descend from this one).
    private func elementWithIdentifier(
        _ identifier: String,
        in application: XCUIApplication
    ) -> XCUIElement {
        application.descendants(matching: .any)
            .matching(identifier: identifier)
            .firstMatch
    }
}