// Host-JVM smoke test: exercises the generated Kotlin bindings through JNA
// against the Apple (`aarch64-apple-darwin`) cdylib built by
// scripts/build-android.sh. It proves the bindings load the library, pass
// records and check checksums; the Android `.so` libraries themselves are
// only loadable on Android, so an Android-runtime smoke stays an on-device
// concern for a later slice.
package com.rusticmaps.sdk.smoke

import uniffi.rustic_maps.BoundingBox
import uniffi.rustic_maps.GeographicCoordinate
import uniffi.rustic_maps.MapCamera
import uniffi.rustic_maps.SdkException
import uniffi.rustic_maps.ViewportSize
import uniffi.rustic_maps.coordinateToNormalizedWorld
import uniffi.rustic_maps.getSdkCompiledVersion
import uniffi.rustic_maps.tilesCovering

/// The viewport of the smoke projections, in physical pixels.
val SMOKE_VIEWPORT_PIXELS = ViewportSize(
    widthPixels = 640.0,
    heightPixels = 480.0,
)

/// Half the default camera field of view, in degrees.
const val SMOKE_FIELD_OF_VIEW_DEGREES = 60.0

fun main() {
    val compiledVersion = getSdkCompiledVersion()
    check(compiledVersion.isNotBlank()) {
        "the compiled SDK version must be readable through the FFI, got `$compiledVersion`"
    }

    val sanFrancisco = GeographicCoordinate(latitude = 37.77, longitude = -122.42)
    val normalized = coordinateToNormalizedWorld(sanFrancisco)
    check(normalized.x in 0.0..1.0 && normalized.y in 0.0..1.0) {
        "normalized world coordinate outside [0, 1]^2: ${normalized.x}, ${normalized.y}"
    }

    val tiles = tilesCovering(
        boundingBox = BoundingBox(
            southWest = GeographicCoordinate(latitude = 37.0, longitude = -123.0),
            northEast = GeographicCoordinate(latitude = 38.0, longitude = -122.0),
        ),
        zoomLevel = 4u,
    )
    check(tiles.isNotEmpty()) { "tile covering must return at least one tile" }

    MapCamera(
        center = sanFrancisco,
        zoomLevel = 12.0,
        bearingDegrees = 270.0,
        pitchDegrees = 0.0,
    ).use { camera ->
        val screenPoint = camera.projectToScreen(
            coordinate = sanFrancisco,
            viewport = SMOKE_VIEWPORT_PIXELS,
            fieldOfViewDegrees = SMOKE_FIELD_OF_VIEW_DEGREES,
        )
        checkNotNull(screenPoint) { "the camera center must project onto the viewport" }

        val ground = camera.screenToGroundCoordinate(
            screenPoint = screenPoint,
            viewport = SMOKE_VIEWPORT_PIXELS,
            fieldOfViewDegrees = SMOKE_FIELD_OF_VIEW_DEGREES,
        )
        checkNotNull(ground) { "the projected camera center must unproject back onto the ground" }
    }

    try {
        coordinateToNormalizedWorld(
            coordinate = GeographicCoordinate(latitude = 91.0, longitude = 0.0),
        )
        error("an out-of-range latitude must throw an SdkException")
    } catch (error: SdkException) {
        check(error is SdkException.InvalidCoordinateInput) { "expected the invalid-input variant, got $error" }
    }

    println(
        "JVM smoke passed: version=$compiledVersion, " +
            "normalized=(${normalized.x}, ${normalized.y}), " +
            "tiles[0]=${tiles.firstOrNull()}, projections OK",
    )
}