package com.rusticmaps.sdk

import uniffi.rustic_maps.MapSdk
import uniffi.rustic_maps.UrlTemplateRasterTileSource

/**
 * Thin facade over the uniffi-generated [MapSdk]: constructs the SDK keyless
 * and installs provider registrations only when a runtime credential is
 * applied (docs/ReferenceAppUX.md §6.5; docs/ProviderCredentialsAndBrowserProviders.md).
 *
 * No provider credential is a build input. [applyProviderCredential] is the
 * one dispatch point: it maps a provider key onto that provider's SDK
 * registration call, so a new provider is a dispatch arm here plus a
 * descriptor row in the shared provider registry — never a settings-view
 * rewrite.
 * A refused credential surfaces verbatim from the generated call as
 * [uniffi.rustic_maps.SdkException] to the caller.
 *
 * The offline-maps demo registers the same MapQuest provider set a second
 * time, with the raster-tile contract wrapped in the disk response cache
 * (`setProviderCredentialWithTileCache`, round 9): re-registration
 * replaces every slot, including the cached raster-tile slot, so the demo
 * runs one call with the cache file and budget once it holds them.
 */
class MapsSdkFacade {
    /** The generated SDK object every surface, provider call and camera builds from. */
    val nativeSdk: MapSdk = MapSdk()

    /**
     * The MapQuest credential the last successful application installed, kept
     * only for the tile-cache re-registration (which repeats the key). It is
     * session memory, never written to disk by this facade.
     */
    private var appliedMapQuestCredential: String? = null

    /**
     * Registers the provider named by `providerKey` with `credential`.
     *
     * `"mapquest"` registers the whole MapQuest provider set. An unknown
     * provider key is refused with a clear [IllegalArgumentException] naming
     * the key (a provider without a registration arm must never pretend to
     * work). A blank credential and the SDK's own validation failures both
     * surface verbatim to the caller. The credential is retained in memory for
     * [registerTileCacheWithProviders] and is never logged.
     */
    fun applyProviderCredential(providerKey: String, credential: String) {
        require(credential.isNotBlank()) {
            "a provider credential must not be blank"
        }
        when (providerKey) {
            MAPQUEST_PROVIDER_KEY -> {
                nativeSdk.setProviderCredential(credential)
                appliedMapQuestCredential = credential
            }
            else -> throw IllegalArgumentException(
                "provider '$providerKey' has no registration on this platform yet",
            )
        }
    }

    /**
     * Registers a provider-neutral base map (M9's native base-map switch): a
     * raster tileset the shared provider registry declares as a `{z}/{x}/{y}`
     * URL template, served by the SDK itself with no vendor code involved.
     * The registration replaces the raster-tile slot only, so the
     * credential-registered contracts (geocoding, routing, search, traffic)
     * keep serving whichever base map is active.
     *
     * A malformed template, a blank source name or an inverted zoom range
     * throws the SDK's verbatim [uniffi.rustic_maps.SdkException]; the
     * previously serving source stays installed.
     */
    fun applyUrlTemplateRasterTileSource(source: UrlTemplateRasterTileSource) {
        nativeSdk.registerUrlTemplateRasterTileSource(source)
    }

    /**
     * Re-registers the applied MapQuest credential so its raster-tile slot
     * serves the base map again — the switch back from a credential-less
     * source. Re-registration replaces every MapQuest slot, which is the
     * documented behavior of [MapSdk.setProviderCredential]; it also drops a
     * tile-cache installation, so the caller re-registers the cache
     * afterwards when the offline demo owns one.
     *
     * Refuses honestly with an [IllegalStateException] when no MapQuest
     * credential has been applied in this session.
     */
    fun restoreCredentialedBaseMap(providerKey: String) {
        require(providerKey == MAPQUEST_PROVIDER_KEY) {
            "provider '$providerKey' has no credential-based base map on this platform"
        }
        val mapQuestCredential = appliedMapQuestCredential ?: throw IllegalStateException(
            "no MapQuest credential is applied; set one in Settings before selecting its base map",
        )
        nativeSdk.setProviderCredential(mapQuestCredential)
    }

    /**
     * Re-registers the MapQuest provider set with the raster-tile contract
     * wrapped in the disk response cache opened at `tileCacheDatabasePath`
     * under the absolute byte budget `tileCacheAbsoluteMaximumBytes` (§4.1's
     * offline maps card).
     *
     * Refuses honestly with an [IllegalStateException] when no MapQuest
     * credential has been applied: the cache variant repeats the credential,
     * so registering it keyless is never attempted. Any SDK refusal surfaces
     * verbatim to the caller.
     */
    fun registerTileCacheWithProviders(
        tileCacheDatabasePath: String,
        tileCacheAbsoluteMaximumBytes: ULong,
    ) {
        val mapQuestCredential = appliedMapQuestCredential ?: throw IllegalStateException(
            "no MapQuest credential is applied; set one in Settings before registering the tile cache",
        )
        nativeSdk.setProviderCredentialWithTileCache(
            mapQuestCredential,
            tileCacheDatabasePath,
            tileCacheAbsoluteMaximumBytes,
        )
    }

    private companion object {
        /** The provider key the shared artifact's MapQuest descriptor carries. */
        const val MAPQUEST_PROVIDER_KEY: String = "mapquest"
    }
}
