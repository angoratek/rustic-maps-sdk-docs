package com.rusticmaps.sdk.demo

import android.content.res.AssetManager
import org.json.JSONObject

/**
 * One vector style a registry descriptor offers (M22): the committed style id
 * the SDK paints the base with, the consumer-facing style name the base-map
 * dropdown shows, the theme the style belongs to (`light`/`dark`), and the
 * attribution line the style's design requires.
 */
data class VectorStyleDescriptor(
    /** The committed style id the SDK paints with (`bright-light`, …). */
    val styleId: String,
    /** Consumer-facing style name (`Bright`, `Fiord`, `Positron`). */
    val displayName: String,
    /** The theme the style was designed on. */
    val theme: String,
    /** The attribution line the style's design requires. */
    val attributionText: String,
)

/**
 * One provider descriptor of the shared registry `platform/providers.json`
 * (docs/ProviderGenericity.md): the settings surface renders one row per
 * descriptor and offers the provider in each capability picker its
 * `served_contracts` declares, so a new provider is a registry entry plus a
 * registration dispatch arm, never a view rewrite. The descriptor carries
 * labels and availability only — never a credential value.
 */
data class ProviderCredentialDescriptor(
    /** Stable dispatch key the credential applier switches on. */
    val providerKey: String,
    /** Consumer-facing provider name. */
    val displayName: String,
    /** Consumer-facing label of the credential field. */
    val credentialLabel: String,
    /** Whether this platform has a registration arm for the provider. */
    val isRegistrationAvailableOnAndroid: Boolean,
    /** The provider's attribution/terms line. */
    val attributionText: String,
    /** The provider's terms note (the attribution panel's second block). */
    val termsNote: String,
    /** Where to create a credential, shown under the field. */
    val settingsHint: String,
    /**
     * The public demo deployment address of a keyless provider (the registry's
     * `demo_base_url`), or blank when the descriptor declares none. The
     * reference applications pass it as the contract's deployment-address
     * argument; a keyless provider without one is offered only honestly, never
     * with an empty address that would silently reach a local default.
     */
    val demoBaseUrl: String = "",
    /** The descriptor's note about the demo address, or blank when it declares none. */
    val demoBaseUrlNote: String = "",
    /**
     * The provider's raster-tile URL template (`{z}/{x}/{y}`), or blank when
     * the provider publishes no raster source of that shape. A keyless
     * descriptor with a template serves its own base map without any
     * credential; the settings surface offers it in the base-map section.
     */
    val rasterUrlTemplate: String,
    /** The provider's highest served tile zoom level (the descriptor default of zero). */
    val maximumZoomLevel: Int,
    /**
     * The provider's vector-tile URL template (`{z}/{x}/{y}`), or blank when
     * the provider publishes no vector tileset (M22).
     */
    val vectorUrlTemplate: String,
    /**
     * The tile schema the provider's vector tileset carries (`carto`,
     * `openmaptiles`); informational, because the styles the base offers are
     * named by the descriptor's own list.
     */
    val vectorStyleSchema: String,
    /** The vector styles the registry offers for this provider, in artifact order. */
    val vectorStyles: List<VectorStyleDescriptor>,
    /**
     * The capabilities the provider serves, named with the contract's
     * snake_case storage names (`geocoding`, `routing`, …). A settings
     * surface offers the provider only for the capabilities it declares,
     * never for one this build cannot serve.
     */
    val servedContracts: List<String>,
) {
    /**
     * Whether this platform can register the provider as a base map without a
     * credential: the provider-neutral URL-template raster arm exists on all
     * three native platforms.
     */
    val isCredentiallessBaseMapAvailableOnAndroid: Boolean
        get() = rasterUrlTemplate.isNotBlank() && isRegistrationAvailableOnAndroid

    /**
     * Whether the provider offers a styled vector base (M22): a vector
     * tileset URL template plus at least one committed style. The vector base
     * is served by the shipped `MapView` on every platform through the
     * additive contract member, so no registration arm gates it.
     */
    val offersVectorBase: Boolean
        get() = vectorUrlTemplate.isNotBlank() && vectorStyles.isNotEmpty()
}

/**
 * The styled vector base a keyless start opens on (owner ruling 2026-10-31,
 * PRD §6 item 18): the provider key and committed style id the registry names
 * at its top level. Resolved against the descriptors by the reference
 * application, so a registry whose declaration is incomplete falls back to
 * the credential-less raster source rather than installing nothing.
 */
data class KeylessBaseMapDescriptor(
    /** The provider whose vector tileset the base uses. */
    val providerKey: String,
    /** The committed style id the base paints with. */
    val styleId: String,
)

/** The decoded shared provider registry. */
data class ProviderRegistry(
    /** The registry schema version the artifact declares. */
    val schemaVersion: Int,
    /** The provider descriptors in artifact order. */
    val providers: List<ProviderCredentialDescriptor>,
    /**
     * The reference apps' own `User-Agent` template (one `%s` slot for the
     * app's SDK version), or blank when the artifact declares none. It sits
     * in the shared artifact because all four surfaces identify themselves
     * the same way to the public tile services their base maps come from.
     */
    val referenceAppUserAgentTemplate: String,
    /**
     * The styled vector base a keyless start opens on, or null when the
     * artifact declares none (the keyless start then keeps the
     * credential-less raster source).
     */
    val keylessBaseMap: KeylessBaseMapDescriptor?,
)

/**
 * Decodes the shared provider registry. The repository file
 * `platform/providers.json` is copied into the application assets at build
 * time (a Gradle task, never a checked-in duplicate), so the descriptors
 * cannot drift from the registry the dev server, the playground and the
 * other refapps consume.
 *
 * The section is read tolerantly (a registry without descriptors yields no
 * rows) so an older artifact never breaks a keyless start; a missing
 * `android` availability flag reads as unavailable, the honest default.
 */
object ProviderRegistryLoader {
    /** Asset name the copy task writes the registry to inside the application. */
    const val REGISTRY_ASSET_NAME: String = "providers.json"

    /** Loads and decodes the registry from the application's assets. */
    fun load(assets: AssetManager): ProviderRegistry {
        assets.open(REGISTRY_ASSET_NAME).use { stream ->
            val registryText = stream.readBytes().decodeToString()
            return decode(registryText)
        }
    }

    /** Decodes the registry's JSON text (separate from loading for tests). */
    fun decode(registryText: String): ProviderRegistry {
        val root = JSONObject(registryText)
        val descriptorArray = root.optJSONArray("providers")
        val providers = (0 until (descriptorArray?.length() ?: 0)).map { index ->
            val descriptorObject = descriptorArray!!.getJSONObject(index)
            ProviderCredentialDescriptor(
                providerKey = descriptorObject.getString("provider_key"),
                displayName = descriptorObject.getString("display_name"),
                credentialLabel = descriptorObject.optString("credential_label", ""),
                isRegistrationAvailableOnAndroid = descriptorObject
                    .optJSONObject("registration_available")
                    ?.optBoolean("android", false)
                    ?: false,
                attributionText = descriptorObject.optString("attribution_text", ""),
                termsNote = descriptorObject.optString("terms_note", ""),
                settingsHint = descriptorObject.optString("settings_hint", ""),
                demoBaseUrl = descriptorObject.optString("demo_base_url", ""),
                demoBaseUrlNote = descriptorObject.optString("demo_base_url_note", ""),
                rasterUrlTemplate = descriptorObject.optString("raster_url_template", ""),
                maximumZoomLevel = descriptorObject.optInt("maximum_zoom_level", 0),
                vectorUrlTemplate = descriptorObject.optString("url_template", ""),
                vectorStyleSchema = descriptorObject.optString("vector_style", ""),
                vectorStyles = decodeVectorStyles(descriptorObject.optJSONArray("vector_styles")),
                servedContracts = decodeServedContracts(
                    descriptorObject.optJSONArray("served_contracts"),
                ),
            )
        }
        return ProviderRegistry(
            schemaVersion = root.optInt("schema_version", 0),
            providers = providers,
            referenceAppUserAgentTemplate = root.optString(
                "reference_app_user_agent_template",
                "",
            ),
            keylessBaseMap = decodeKeylessBaseMap(root.optJSONObject("keyless_base_map")),
        )
    }

    /**
     * Decodes the registry's top-level `keyless_base_map` (null when the
     * artifact declares none, or when either half is blank — the caller then
     * keeps the credential-less raster start).
     */
    private fun decodeKeylessBaseMap(keylessBaseMapObject: JSONObject?): KeylessBaseMapDescriptor? {
        val providerKey = keylessBaseMapObject?.optString("provider_key", "").orEmpty()
        val styleId = keylessBaseMapObject?.optString("style_id", "").orEmpty()
        if (providerKey.isBlank() || styleId.isBlank()) {
            return null
        }
        return KeylessBaseMapDescriptor(providerKey = providerKey, styleId = styleId)
    }

    /**
     * Decodes a descriptor's `served_contracts` list (empty when it declares
     * none, so an older artifact offers the provider for no capability rather
     * than guessing one).
     */
    private fun decodeServedContracts(servedContractsArray: org.json.JSONArray?): List<String> =
        (0 until (servedContractsArray?.length() ?: 0)).mapNotNull { contractIndex ->
            servedContractsArray!!
                .optString(contractIndex)
                .takeIf { contractName -> contractName.isNotBlank() }
        }

    /** Decodes a descriptor's `vector_styles` list (empty when it declares none). */
    private fun decodeVectorStyles(vectorStylesArray: org.json.JSONArray?): List<VectorStyleDescriptor> =
        (0 until (vectorStylesArray?.length() ?: 0)).map { styleIndex ->
            val styleObject = vectorStylesArray!!.getJSONObject(styleIndex)
            VectorStyleDescriptor(
                styleId = styleObject.getString("style_id"),
                displayName = styleObject.getString("display_name"),
                theme = styleObject.optString("theme", ""),
                attributionText = styleObject.optString("attribution_text", ""),
            )
        }
}
