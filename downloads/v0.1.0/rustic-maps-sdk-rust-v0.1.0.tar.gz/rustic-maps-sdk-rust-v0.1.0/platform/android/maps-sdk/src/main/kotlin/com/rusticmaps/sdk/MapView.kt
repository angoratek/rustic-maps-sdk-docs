package com.rusticmaps.sdk

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Choreographer
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import uniffi.rustic_maps.BoundingBox
import uniffi.rustic_maps.EdgeInsets
import uniffi.rustic_maps.FrameStatistics
import uniffi.rustic_maps.GeographicCoordinate
import uniffi.rustic_maps.LocationIndicatorState
import uniffi.rustic_maps.LocationIndicatorStyle
import uniffi.rustic_maps.MapCamera
import uniffi.rustic_maps.MapOverlay
import uniffi.rustic_maps.MapSdk
import uniffi.rustic_maps.MapView as NativeMapView
import uniffi.rustic_maps.ScreenPoint
import uniffi.rustic_maps.SdkException
import uniffi.rustic_maps.SurfaceHandle
import uniffi.rustic_maps.UrlTemplateVectorTileSource
import uniffi.rustic_maps.VectorTileSourceStatus
import uniffi.rustic_maps.ViewportSize
import java.lang.ref.WeakReference
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min

/**
 * The camera values a [MapView] reads back from the SDK's anchored camera.
 *
 * The SDK owns the math; this plain value is what the wrapper exposes so an
 * integrator never holds a `MapCamera` handle and never has to close one.
 * Zoom and pitch are the SDK's clamped values, and bearing is wrapped into
 * `[0, 360)` exactly as the contract constructor defines.
 */
data class MapCameraPose(
    /** Camera center latitude in decimal degrees. */
    val latitudeDegrees: Double,
    /** Camera center longitude in decimal degrees. */
    val longitudeDegrees: Double,
    /** Zoom level. */
    val zoomLevel: Double,
    /** Bearing in degrees clockwise from true north. */
    val bearingDegrees: Double,
    /** Pitch in degrees; zero is top-down. */
    val pitchDegrees: Double,
)

/** Which wrapper operation produced a [MapViewFailure]. */
enum class MapViewFailurePhase {
    /** Acquiring the native window or attaching the surface. */
    SURFACE,
    /** Reconfiguring an attached surface. */
    RESIZE,
    /** Drawing a frame or querying idle settlement. */
    DRAW,
    /** Reading, building or transforming the camera. */
    CAMERA,
    /** Pushing the overlay list. */
    OVERLAY,
    /** Pushing or clearing the location layer. */
    LOCATION_INDICATOR,
    /** Installing, clearing or reading the vector base source. */
    BASE_MAP,
    /** Unprojecting a tap. */
    TAP,
}

/**
 * One refused [MapView] operation carrying its verbatim SDK failure.
 *
 * The wrapper never swallows an SDK exception: every failure reaches
 * [MapViewListener.onError] with the phase it occurred in and the original
 * throwable, so an app can present the SDK's own message.
 */
class MapViewFailure(
    /** The wrapper operation that failed. */
    val phase: MapViewFailurePhase,
    /** The verbatim SDK or platform failure (also reachable as `cause`). */
    override val cause: Throwable,
) : Exception(cause.message, cause)

/**
 * The callbacks a [MapView] delivers on the main thread.
 *
 * Every member has an empty default: an integrator overrides only what it
 * needs.
 */
interface MapViewListener {
    /** The first frame drew and presented successfully. */
    fun onMapReady() {}

    /**
     * The camera changed: a set, an animation step, a gesture or a fit.
     *
     * @param camera the adopted pose.
     * @param isGestureDriven true when a pan, pinch or rotate produced the
     *   change, which is the hook a follow camera uses to break on gesture.
     */
    fun onCameraChanged(camera: MapCameraPose, isGestureDriven: Boolean) {}

    /** A tap unprojected onto the ground plane; null misses report nothing. */
    fun onMapClick(coordinate: GeographicCoordinate) {}

    /** An SDK or platform operation failed; the failure is never swallowed. */
    fun onError(failure: MapViewFailure) {}

    /** One presented frame's tile and overlay accounting. */
    fun onFrameStatistics(statistics: FrameStatistics) {}

    /**
     * A frame was skipped because a draw or resize held the render state
     * (`RenderingSurfaceUnavailable` backpressure); the next tick retries.
     */
    fun onFrameDeferred() {}

    /** The pump paused because `isFrameSettled` answered true. */
    fun onFrameSettled() {}
}

/**
 * The lifecycle-aware Android map view shipped in the AAR (M17): it owns the
 * platform surface, the surface-pointer shim, the Choreographer frame pump,
 * resize, the camera value store and animation, gestures and the overlay and
 * location-layer bookkeeping. The app owns only its widgets and its own
 * camera intent.
 *
 * ## Drawing
 *
 * There is no SDK-internal render loop: this view pumps explicit frames from
 * the Choreographer and follows the documented idle-settled discipline
 * (`docs/PublicApiV2.md` §10):
 *
 * 1. resize when the capped pixel extent changed, never every frame;
 * 2. ask `isFrameSettled`; when it answers true the pump stops entirely
 *    instead of burning frames on an unchanged, fully presented view;
 * 3. otherwise draw with at most one draw in flight
 *    (`RenderingSurfaceUnavailable` retries on the next tick);
 * 4. report statistics, readiness and failures.
 *
 * The pump resumes on a camera set or animation, a gesture, an overlay or
 * location mutation, a surface create/change, window attach or visibility,
 * [setRenderingPaused]`(false)`, [retryAttach] and a one-second watchdog.
 * When only unavailable tiles remain with an unchanged pose, the pump drops
 * to that one-second retry cadence rather than spinning against the
 * provider.
 *
 * ## Lifecycle
 *
 * Hosts call [onStart], [onStop] and [onDestroy] from the matching lifecycle
 * callbacks (the Compose wrapper does this automatically). The view also
 * pauses on window detach or invisibility. [onDestroy] releases the surface
 * and the native objects; the view is not reusable afterwards.
 *
 * All members are expected on the main thread.
 */
class MapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback2 {

    // ------------------------------------------------------------------
    // Public state
    // ------------------------------------------------------------------

    /**
     * The SDK whose registered raster-tile provider the view draws from.
     *
     * Setting it creates the native view; setting it while attached rebuilds
     * the native view and re-attaches on the next pump tick. Null until the
     * host supplies one: the view shows its background surface and draws
     * nothing.
     */
    var sdk: MapSdk? = null
        set(value) {
            if (field === value) {
                return
            }
            field = value
            rebuildNativeMapView()
        }

    /** The listener; held weakly so the view never keeps an activity alive. */
    var listener: MapViewListener?
        get() = listenerReference?.get()
        set(value) {
            listenerReference = if (value == null) null else WeakReference(value)
        }
    private var listenerReference: WeakReference<MapViewListener>? = null

    /** Whether touch gestures pan, pinch and rotate the camera. */
    var isGestureEnabled: Boolean = true

    /** The camera the pump draws with; reads the last adopted pose. */
    val camera: MapCameraPose
        get() = cameraPose

    /**
     * The render viewport in pixels, or null before the surface attached.
     * This is the capped extent the frames render at, not the raw surface
     * extent; gestures and taps scale between the two.
     */
    val viewportSize: ViewportSize?
        get() = if (attachedWidthPixels > 0 && attachedHeightPixels > 0) {
            ViewportSize(
                widthPixels = attachedWidthPixels.toDouble(),
                heightPixels = attachedHeightPixels.toDouble(),
            )
        } else {
            null
        }

    /** The render viewport width in pixels (zero before attach). */
    val viewportWidthPixels: Int
        get() = attachedWidthPixels

    /** The render viewport height in pixels (zero before attach). */
    val viewportHeightPixels: Int
        get() = attachedHeightPixels

    // ------------------------------------------------------------------
    // Surface and native view state
    // ------------------------------------------------------------------

    private var nativeMapView: NativeMapView? = null
    /**
     * The vector base source installed before the native view existed; the
     * native view is rebuilt on every SDK swap, and the contract keeps the
     * source across detach/attach, so the wrapper re-applies it like the
     * overlay list.
     */
    private var pendingVectorTileSource: UrlTemplateVectorTileSource? = null
    private var availableSurface: Surface? = null
    private var surfaceWidthPixels: Int = 0
    private var surfaceHeightPixels: Int = 0
    private var attachedWidthPixels: Int = 0
    private var attachedHeightPixels: Int = 0
    private var acquiredNativeWindowPointer: Long = 0L
    private var requiresAttach: Boolean = false
    private var retryAttachRequested: Boolean = false
    private var isAttached: Boolean = false

    // ------------------------------------------------------------------
    // Camera state
    // ------------------------------------------------------------------

    private var cameraPose: MapCameraPose = DEFAULT_CAMERA_POSE
    private var cameraRevision: Long = 0L
    private var builtCamera: MapCamera? = null
    private var builtCameraRevision: Long = -1L
    private var cameraAnimation: CameraAnimation? = null

    // ------------------------------------------------------------------
    // Overlay and location state
    // ------------------------------------------------------------------

    private var overlayDescriptors: List<MapOverlay> = emptyList()
    private val overlayDescriptorsById: LinkedHashMap<String, MapOverlay> = LinkedHashMap()
    private var locationIndicatorState: LocationIndicatorState? = null
    private var locationIndicatorStyle: LocationIndicatorStyle? = null

    // ------------------------------------------------------------------
    // Pump state
    // ------------------------------------------------------------------

    private val pumpScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val frameChannel: Channel<Long> = Channel(Channel.CONFLATED)
    private val frameCallback: Choreographer.FrameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFrameCallbackPosted) {
                return
            }
            // Re-post before feeding the consumer: a consumer that pauses the
            // pump inside `trySend` removes this just-posted callback, so no
            // stale frame is left queued.
            choreographerInstance.postFrameCallback(this)
            frameChannel.trySend(frameTimeNanos)
        }
    }
    private val watchdogRunnable: Runnable = Runnable { resumePump(resetBackoff = false) }
    private val mainHandler: Handler = Handler(Looper.getMainLooper())
    private var isFrameCallbackPosted: Boolean = false
    private var isPumpConsumerRunning: Boolean = false
    private var isDrawInFlight: Boolean = false

    /**
     * Whether [pendingVectorTileSource] still has to be handed to the native
     * view. A base-map selection can land while a frame draw is in flight —
     * the SDK refuses a source change then, by design, because the scheduler
     * must not be swapped under a running frame — so the request waits for the
     * next pump tick instead of failing the user's tap.
     */
    private var isVectorTileSourceInstallPending: Boolean = false
    private var isBackoffActive: Boolean = false
    private var consecutiveUnavailableOnlyFrames: Int = 0
    private var hasReportedMapReady: Boolean = false
    private var isRenderingPaused: Boolean = false
    private var isLifecycleStarted: Boolean = true
    private var isWindowAttached: Boolean = false
    private var isWindowVisible: Boolean = true
    private var isDestroyed: Boolean = false

    // ------------------------------------------------------------------
    // Gesture state
    // ------------------------------------------------------------------

    private var lastPanX: Float = 0f
    private var lastPanY: Float = 0f
    private var hasTwoPointerBaseline: Boolean = false
    private var lastSpanPixels: Double = 0.0
    private var lastAngleRadians: Double = 0.0

    private val tapDetector: GestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(event: MotionEvent): Boolean = true

            // Confirmed, not `onSingleTapUp`: a double tap must zoom without
            // also reporting a map click for its first tap.
            override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
                reportTapAt(event.x.toDouble(), event.y.toDouble())
                return true
            }

            override fun onDoubleTap(event: MotionEvent): Boolean {
                if (viewportSize == null) {
                    return false
                }
                transformCamera(
                    zoomLevels = DOUBLE_TAP_ZOOM_STEP,
                    focalPoint = ScreenPoint(
                        x = surfacePositionToViewport(
                            event.x.toDouble(),
                            surfaceWidthPixels,
                            attachedWidthPixels,
                        ),
                        y = surfacePositionToViewport(
                            event.y.toDouble(),
                            surfaceHeightPixels,
                            attachedHeightPixels,
                        ),
                    ),
                )
                return true
            }
        },
    )

    init {
        holder.addCallback(this)
        isFocusable = true
        isClickable = true
    }

    // ------------------------------------------------------------------
    // Camera API
    // ------------------------------------------------------------------

    /** Sets the camera immediately; a refused pose reports and keeps the old one. */
    fun setCamera(camera: MapCameraPose) {
        cameraAnimation = null
        applyCameraPose(camera, isGestureDriven = false)
    }

    /**
     * Animates the camera to [camera] over [durationMillis], interpolating
     * latitude, longitude, zoom and pitch linearly and bearing along the
     * shortest angular path. A non-positive duration is an immediate set.
     */
    fun animateCamera(
        camera: MapCameraPose,
        durationMillis: Long = DEFAULT_CAMERA_ANIMATION_DURATION_MILLIS,
    ) {
        val normalizedTarget = normalizeCameraPose(camera) ?: return
        if (durationMillis <= 0L) {
            setCamera(normalizedTarget)
            return
        }
        cameraAnimation = CameraAnimation(
            startNanos = System.nanoTime(),
            durationNanos = durationMillis * NANOS_PER_MILLISECOND,
            fromPose = cameraPose,
            toPose = normalizedTarget,
        )
        resumePump(resetBackoff = true)
    }

    /**
     * Frames [boundingBox] inside the viewport's inset region (top-down and
     * north-up by construction) and adopts the fitted camera. Without an
     * attached viewport the call reports and changes nothing.
     */
    fun fitBounds(
        boundingBox: BoundingBox,
        edgeInsets: EdgeInsets = ZERO_EDGE_INSETS,
        maximumZoomLevel: Double = DEFAULT_FIT_BOUNDS_MAXIMUM_ZOOM_LEVEL,
    ) {
        val viewport = viewportSize ?: return
        val fitted = try {
            MapCamera.fitBounds(
                boundingBox = boundingBox,
                viewport = viewport,
                edgeInsets = edgeInsets,
                maximumZoomLevel = maximumZoomLevel,
            )
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.CAMERA, failure)
            return
        }
        try {
            adoptCamera(fitted, isGestureDriven = false)
        } finally {
            fitted.close()
        }
    }

    /**
     * Ground meters represented by one screen pixel at the camera center
     * (the scale bar's helper), or null before the surface attached.
     */
    fun groundMetersPerScreenPixel(): Double? {
        val viewport = viewportSize ?: return null
        val currentCamera = currentCameraOrNull() ?: return null
        return try {
            currentCamera.groundMetersPerScreenPixel(
                viewport = viewport,
                fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
            )
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.CAMERA, failure)
            null
        }
    }

    /**
     * The geographic bounds of the drawn camera's viewport, or null before
     * the surface attached or when the projection cannot answer.
     *
     * The four viewport corners are unprojected through the contract camera;
     * a steep pitch can put the far corner below the horizon, in which case
     * the camera's own ground scale bounds a box around its center. The
     * traffic layer asks for these bounds once the camera settles.
     */
    fun cameraGeographicBounds(): BoundingBox? {
        val viewport = viewportSize ?: return null
        val currentCamera = currentCameraOrNull() ?: return null
        val cornerScreenPoints = listOf(
            ScreenPoint(x = 0.0, y = 0.0),
            ScreenPoint(x = viewport.widthPixels, y = 0.0),
            ScreenPoint(x = viewport.widthPixels, y = viewport.heightPixels),
            ScreenPoint(x = 0.0, y = viewport.heightPixels),
        )
        val cornerCoordinates = cornerScreenPoints.mapNotNull { screenPoint ->
            try {
                currentCamera.screenToGroundCoordinate(
                    screenPoint = screenPoint,
                    viewport = viewport,
                    fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
                )
            } catch (failure: Exception) {
                if (failure is CancellationException) {
                    throw failure
                }
                // A corner the projection cannot answer is skipped, exactly
                // as a steep pitch below the horizon skips it; the fallback
                // box below covers a camera no corner answers.
                null
            }
        }
        if (cornerCoordinates.size >= MINIMUM_UNPROJECTED_CORNER_COUNT) {
            return BoundingBox(
                southWest = GeographicCoordinate(
                    latitude = cornerCoordinates.minOf { coordinate -> coordinate.latitude },
                    longitude = cornerCoordinates.minOf { coordinate -> coordinate.longitude },
                ),
                northEast = GeographicCoordinate(
                    latitude = cornerCoordinates.maxOf { coordinate -> coordinate.latitude },
                    longitude = cornerCoordinates.maxOf { coordinate -> coordinate.longitude },
                ),
            )
        }
        val metersPerPixel = groundMetersPerScreenPixel() ?: return null
        val halfHeightMeters = metersPerPixel * viewport.heightPixels / 2
        val halfWidthMeters = metersPerPixel * viewport.widthPixels / 2
        val latitudeDeltaDegrees = halfHeightMeters / METERS_PER_DEGREE_LATITUDE
        val longitudeScale = METERS_PER_DEGREE_LATITUDE * cos(
            cameraPose.latitudeDegrees * PI / HALF_CIRCLE_DEGREES,
        )
        val longitudeDeltaDegrees = if (longitudeScale == 0.0) {
            latitudeDeltaDegrees
        } else {
            halfWidthMeters / longitudeScale
        }
        return BoundingBox(
            southWest = GeographicCoordinate(
                latitude = cameraPose.latitudeDegrees - latitudeDeltaDegrees,
                longitude = cameraPose.longitudeDegrees - longitudeDeltaDegrees,
            ),
            northEast = GeographicCoordinate(
                latitude = cameraPose.latitudeDegrees + latitudeDeltaDegrees,
                longitude = cameraPose.longitudeDegrees + longitudeDeltaDegrees,
            ),
        )
    }

    /**
     * Pans by a screen-pixel delta through the contract camera's
     * `panByScreenPixels` (the programmatic twin of a drag).
     */
    fun panByScreenPixels(
        deltaXPixels: Double,
        deltaYPixels: Double,
        isGestureDriven: Boolean = true,
    ) {
        transformCamera(
            panXPixels = deltaXPixels,
            panYPixels = deltaYPixels,
            isGestureDriven = isGestureDriven,
        )
    }

    /**
     * Zooms by [deltaZoomLevels] around the viewport's center — the control
     * cluster's zoom buttons go through the same contract member as a pinch.
     */
    fun zoomByLevels(deltaZoomLevels: Double) {
        val viewport = viewportSize ?: return
        transformCamera(
            zoomLevels = deltaZoomLevels,
            focalPoint = ScreenPoint(
                x = viewport.widthPixels / 2.0,
                y = viewport.heightPixels / 2.0,
            ),
            isGestureDriven = false,
        )
    }

    // ------------------------------------------------------------------
    // Overlay API (addressed by caller id)
    // ------------------------------------------------------------------

    /** Adds or replaces the overlay held under [id]; answers whether it was accepted. */
    fun addOverlay(id: String, overlay: MapOverlay): Boolean {
        overlayDescriptorsById[id] = overlay
        return replaceOverlays(overlayDescriptorsById.values.toList())
    }

    /**
     * Replaces an existing overlay under [id] and answers whether it was
     * accepted; an unknown id is a caller error.
     */
    fun updateOverlay(id: String, overlay: MapOverlay): Boolean {
        require(overlayDescriptorsById.containsKey(id)) {
            "no overlay is registered under the id '$id'; use addOverlay for a new id"
        }
        overlayDescriptorsById[id] = overlay
        return replaceOverlays(overlayDescriptorsById.values.toList())
    }

    /** Removes the overlay under [id] (an unknown id is a no-op); answers acceptance. */
    fun removeOverlay(id: String): Boolean {
        if (overlayDescriptorsById.remove(id) == null) {
            return true
        }
        return replaceOverlays(overlayDescriptorsById.values.toList())
    }

    /**
     * Replaces the whole overlay list and resets the id bookkeeping: later
     * [addOverlay]/[updateOverlay]/[removeOverlay] calls start from an empty
     * id map. Answers whether the SDK accepted the list.
     */
    fun setOverlays(overlays: List<MapOverlay>): Boolean {
        overlayDescriptorsById.clear()
        return replaceOverlays(overlays)
    }

    /** Clears every overlay and the id bookkeeping; answers acceptance. */
    fun clearOverlays(): Boolean {
        overlayDescriptorsById.clear()
        return replaceOverlays(emptyList())
    }

    // ------------------------------------------------------------------
    // Location layer API
    // ------------------------------------------------------------------

    /** Sets the renderer-owned location layer; a refused push reports. */
    fun setLocationIndicator(state: LocationIndicatorState, style: LocationIndicatorStyle) {
        locationIndicatorState = state
        locationIndicatorStyle = style
        val nativeView = nativeMapView ?: return
        try {
            nativeView.setLocationIndicator(state, style)
            resumePump(resetBackoff = true)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.LOCATION_INDICATOR, failure)
        }
    }

    /** Clears the location layer; a refused clear reports. */
    fun clearLocationIndicator() {
        locationIndicatorState = null
        locationIndicatorStyle = null
        val nativeView = nativeMapView ?: return
        try {
            nativeView.clearLocationIndicator()
            resumePump(resetBackoff = true)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.LOCATION_INDICATOR, failure)
        }
    }

    // ------------------------------------------------------------------
    // Vector base map API (M22)
    // ------------------------------------------------------------------

    /**
     * Installs a vector base map: a provider-neutral vector tileset painted
     * with one of the SDK's committed styles, drawn in place of the raster
     * tiles (the raster layer is hidden while a vector base serves) and
     * beneath every overlay. The source outlives attach/detach cycles, so an
     * install before the surface exists is carried into the first frame.
     * Answers whether the SDK accepted it; a refusal reports through
     * [MapViewListener.onError] and leaves the previously installed base in
     * force.
     */
    fun setVectorTileSource(source: UrlTemplateVectorTileSource): Boolean {
        // The stored source survives a native-view rebuild (an SDK swap), so
        // it is recorded before the push and rolled back by a refusal.
        val previousVectorTileSource = pendingVectorTileSource
        pendingVectorTileSource = source
        val nativeView = nativeMapView ?: return true
        if (isDrawInFlight) {
            // A selection is a user act, not a race: queue it for the next
            // pump tick rather than refusing the tap.
            isVectorTileSourceInstallPending = true
            resumePump(resetBackoff = true)
            return true
        }
        return try {
            nativeView.setVectorTileSource(source)
            resumePump(resetBackoff = true)
            true
        } catch (failure: Exception) {
            pendingVectorTileSource = previousVectorTileSource
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.BASE_MAP, failure)
            false
        }
    }

    /** Removes the vector base map; answers whether the SDK accepted the clear. */
    fun clearVectorTileSource(): Boolean {
        val previousVectorTileSource = pendingVectorTileSource
        pendingVectorTileSource = null
        val nativeView = nativeMapView ?: return true
        if (isDrawInFlight) {
            isVectorTileSourceInstallPending = true
            resumePump(resetBackoff = true)
            return true
        }
        return try {
            nativeView.clearVectorTileSource()
            resumePump(resetBackoff = true)
            true
        } catch (failure: Exception) {
            pendingVectorTileSource = previousVectorTileSource
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.BASE_MAP, failure)
            false
        }
    }

    /**
     * The vector base source's status — the configured style, name and
     * attribution plus the last frame's drawn and failed tile counts — or
     * null before the native view exists.
     */
    fun vectorTileSourceStatus(): VectorTileSourceStatus? =
        try {
            nativeMapView?.vectorTileSourceStatus()
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.BASE_MAP, failure)
            null
        }

    // ------------------------------------------------------------------
    // Lifecycle API
    // ------------------------------------------------------------------

    /** Host lifecycle start: resumes the pump. */
    fun onStart() {
        if (isDestroyed) {
            return
        }
        isLifecycleStarted = true
        resumePump(resetBackoff = true)
    }

    /** Host lifecycle stop: pauses the pump but keeps the surface attached. */
    fun onStop() {
        isLifecycleStarted = false
        stopFrameCallback()
        cancelWatchdog()
    }

    /**
     * Host lifecycle destroy: detaches, releases the native window and closes
     * the native view. Call it from the host's `onDestroy`; the view is not
     * reusable afterwards.
     */
    fun onDestroy() {
        if (isDestroyed) {
            return
        }
        isDestroyed = true
        isLifecycleStarted = false
        stopFrameCallback()
        cancelWatchdog()
        detachSurface()
        nativeMapView?.close()
        nativeMapView = null
        pumpScope.cancel()
        holder.removeCallback(this)
    }

    /**
     * Pauses or resumes drawing explicitly (a host may release the GPU
     * surface in the background). Visibility and lifecycle pauses are
     * automatic and independent.
     */
    fun setRenderingPaused(paused: Boolean) {
        if (isRenderingPaused == paused) {
            return
        }
        isRenderingPaused = paused
        if (paused) {
            stopFrameCallback()
            cancelWatchdog()
        } else {
            resumePump(resetBackoff = true)
        }
    }

    /**
     * Re-resolves the SDK's raster-tile provider and drops every pooled tile,
     * so a provider registered after this view attached serves the next
     * frame. The view holds its provider from the moment it attaches, and the
     * pooled tiles are keyed by tile coordinate alone, so without this call a
     * base-map switch leaves the previous imagery on screen until the camera
     * moves onto unfetched tiles.
     *
     * The surface is detached and re-attached internally — the one place the
     * provider is resolved — and [applyStoredStateToNativeView] restores the
     * camera, overlays, location indicator and listeners, exactly as after any
     * re-attach. A failure surfaces through [MapViewListener.onError].
     */
    fun reloadRasterTileSource() {
        if (isDestroyed) {
            return
        }
        detachSurface()
        requiresAttach = true
        retryAttachRequested = true
        resumePump(resetBackoff = true)
    }

    /** Retries a failed attach; the error surfaced through [MapViewListener.onError]. */
    fun retryAttach() {
        if (isDestroyed || availableSurface == null) {
            return
        }
        requiresAttach = true
        retryAttachRequested = true
        resumePump(resetBackoff = true)
    }

    // ------------------------------------------------------------------
    // View lifecycle overrides
    // ------------------------------------------------------------------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isWindowAttached = true
        isWindowVisible = windowVisibility == View.VISIBLE
        if (isWindowVisible) {
            resumePump(resetBackoff = true)
        }
    }

    override fun onDetachedFromWindow() {
        isWindowAttached = false
        stopFrameCallback()
        cancelWatchdog()
        detachSurface()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        isWindowVisible = visibility == View.VISIBLE
        if (isWindowVisible) {
            resumePump(resetBackoff = true)
        } else {
            stopFrameCallback()
            cancelWatchdog()
        }
    }

    // ------------------------------------------------------------------
    // SurfaceHolder.Callback2
    // ------------------------------------------------------------------

    override fun surfaceCreated(holder: SurfaceHolder) {
        availableSurface = holder.surface
        surfaceWidthPixels = holder.surfaceFrame.width()
        surfaceHeightPixels = holder.surfaceFrame.height()
        requiresAttach = true
        retryAttachRequested = true
        isAttached = false
        resumePump(resetBackoff = true)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        availableSurface = holder.surface
        surfaceWidthPixels = width
        surfaceHeightPixels = height
        if (!isAttached) {
            requiresAttach = true
            retryAttachRequested = true
        }
        resumePump(resetBackoff = true)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        // After this callback returns the surface is invalid: stop the pump,
        // detach synchronously and only then release the acquired window.
        stopFrameCallback()
        cancelWatchdog()
        detachSurface()
        availableSurface = null
        requiresAttach = false
    }

    override fun surfaceRedrawNeeded(holder: SurfaceHolder) {
        resumePump(resetBackoff = true)
    }

    override fun surfaceRedrawNeededAsync(holder: SurfaceHolder, drawingFinished: Runnable) {
        resumePump(resetBackoff = true)
        drawingFinished.run()
    }

    // ------------------------------------------------------------------
    // Touch handling
    // ------------------------------------------------------------------

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isGestureEnabled) {
            return super.onTouchEvent(event)
        }
        tapDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastPanX = event.x
                lastPanY = event.y
                hasTwoPointerBaseline = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= TWO_POINTER_COUNT) {
                    captureTwoPointerBaseline(event)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= TWO_POINTER_COUNT) {
                    handleTwoPointerMove(event)
                } else {
                    val deltaXPixels = event.x - lastPanX
                    val deltaYPixels = event.y - lastPanY
                    lastPanX = event.x
                    lastPanY = event.y
                    if (deltaXPixels != 0f || deltaYPixels != 0f) {
                        transformCamera(
                            panXPixels = surfaceDeltaToViewport(deltaXPixels.toDouble(), surfaceWidthPixels, attachedWidthPixels),
                            panYPixels = surfaceDeltaToViewport(deltaYPixels.toDouble(), surfaceHeightPixels, attachedHeightPixels),
                        )
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount - 1 >= TWO_POINTER_COUNT) {
                    captureTwoPointerBaseline(event, removedPointerIndex = event.actionIndex)
                } else {
                    hasTwoPointerBaseline = false
                    val remainingIndex = if (event.actionIndex == 0) 1 else 0
                    lastPanX = event.getX(remainingIndex)
                    lastPanY = event.getY(remainingIndex)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                hasTwoPointerBaseline = false
            }
        }
        return true
    }

    private fun captureTwoPointerBaseline(event: MotionEvent, removedPointerIndex: Int = -1) {
        val remainingIndices = (0 until event.pointerCount).filter { index ->
            index != removedPointerIndex
        }
        if (remainingIndices.size < TWO_POINTER_COUNT) {
            hasTwoPointerBaseline = false
            return
        }
        val firstIndex = remainingIndices[0]
        val secondIndex = remainingIndices[1]
        val deltaXPixels = event.getX(secondIndex) - event.getX(firstIndex)
        val deltaYPixels = event.getY(secondIndex) - event.getY(firstIndex)
        lastSpanPixels = hypot(deltaXPixels.toDouble(), deltaYPixels.toDouble())
        lastAngleRadians = atan2(deltaYPixels.toDouble(), deltaXPixels.toDouble())
        hasTwoPointerBaseline = true
    }

    private fun handleTwoPointerMove(event: MotionEvent) {
        if (!hasTwoPointerBaseline) {
            captureTwoPointerBaseline(event)
            return
        }
        val firstIndex = 0
        val secondIndex = 1
        val deltaXPixels = event.getX(secondIndex) - event.getX(firstIndex)
        val deltaYPixels = event.getY(secondIndex) - event.getY(firstIndex)
        val spanPixels = hypot(deltaXPixels.toDouble(), deltaYPixels.toDouble())
        val angleRadians = atan2(deltaYPixels.toDouble(), deltaXPixels.toDouble())
        if (lastSpanPixels < MINIMUM_PINCH_SPAN_PIXELS || spanPixels < MINIMUM_PINCH_SPAN_PIXELS) {
            lastSpanPixels = spanPixels
            lastAngleRadians = angleRadians
            return
        }
        val zoomLevels = log2(spanPixels / lastSpanPixels)
        val rotateDegrees = normalizeDegrees((angleRadians - lastAngleRadians) * DEGREES_PER_RADIAN)
        lastSpanPixels = spanPixels
        lastAngleRadians = angleRadians
        val focalPoint = ScreenPoint(
            x = surfacePositionToViewport(
                ((event.getX(firstIndex) + event.getX(secondIndex)) / 2f).toDouble(),
                surfaceWidthPixels,
                attachedWidthPixels,
            ),
            y = surfacePositionToViewport(
                ((event.getY(firstIndex) + event.getY(secondIndex)) / 2f).toDouble(),
                surfaceHeightPixels,
                attachedHeightPixels,
            ),
        )
        transformCamera(
            zoomLevels = zoomLevels,
            rotateDegrees = rotateDegrees,
            focalPoint = focalPoint,
        )
    }

    private fun reportTapAt(surfaceXPixels: Double, surfaceYPixels: Double) {
        val viewport = viewportSize ?: return
        val camera = currentCameraOrNull() ?: return
        val screenPoint = ScreenPoint(
            x = surfacePositionToViewport(surfaceXPixels, surfaceWidthPixels, attachedWidthPixels),
            y = surfacePositionToViewport(surfaceYPixels, surfaceHeightPixels, attachedHeightPixels),
        )
        try {
            val coordinate = camera.screenToGroundCoordinate(
                screenPoint = screenPoint,
                viewport = viewport,
                fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
            )
            if (coordinate != null) {
                listener?.onMapClick(coordinate)
            }
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.TAP, failure)
        }
    }

    // ------------------------------------------------------------------
    // Camera internals
    // ------------------------------------------------------------------

    private fun normalizeCameraPose(pose: MapCameraPose): MapCameraPose? {
        val camera = try {
            MapCamera(
                center = GeographicCoordinate(
                    latitude = pose.latitudeDegrees,
                    longitude = pose.longitudeDegrees,
                ),
                zoomLevel = pose.zoomLevel,
                bearingDegrees = pose.bearingDegrees,
                pitchDegrees = pose.pitchDegrees,
            )
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.CAMERA, failure)
            return null
        }
        return try {
            readCameraPose(camera)
        } finally {
            camera.close()
        }
    }

    private fun applyCameraPose(pose: MapCameraPose, isGestureDriven: Boolean) {
        val normalized = normalizeCameraPose(pose) ?: return
        adoptPose(normalized, isGestureDriven)
    }

    private fun adoptCamera(camera: MapCamera, isGestureDriven: Boolean) {
        adoptPose(readCameraPose(camera), isGestureDriven)
    }

    private fun adoptPose(pose: MapCameraPose, isGestureDriven: Boolean) {
        cameraPose = pose
        cameraRevision += 1
        listener?.onCameraChanged(pose, isGestureDriven)
        resumePump(resetBackoff = true)
    }

    private fun readCameraPose(camera: MapCamera): MapCameraPose {
        val center = camera.center()
        return MapCameraPose(
            latitudeDegrees = center.latitude,
            longitudeDegrees = center.longitude,
            zoomLevel = camera.zoomLevel(),
            bearingDegrees = camera.bearingDegrees(),
            pitchDegrees = camera.pitchDegrees(),
        )
    }

    private fun currentCameraOrNull(): MapCamera? {
        if (builtCameraRevision == cameraRevision && builtCamera != null) {
            return builtCamera
        }
        val replacedCamera = builtCamera
        val rebuiltCamera = try {
            MapCamera(
                center = GeographicCoordinate(
                    latitude = cameraPose.latitudeDegrees,
                    longitude = cameraPose.longitudeDegrees,
                ),
                zoomLevel = cameraPose.zoomLevel,
                bearingDegrees = cameraPose.bearingDegrees,
                pitchDegrees = cameraPose.pitchDegrees,
            )
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.CAMERA, failure)
            builtCameraRevision = cameraRevision
            return replacedCamera
        }
        builtCamera = rebuiltCamera
        builtCameraRevision = cameraRevision
        replacedCamera?.close()
        return rebuiltCamera
    }

    private fun transformCamera(
        panXPixels: Double = 0.0,
        panYPixels: Double = 0.0,
        zoomLevels: Double = 0.0,
        rotateDegrees: Double = 0.0,
        focalPoint: ScreenPoint? = null,
        isGestureDriven: Boolean = true,
    ) {
        val viewport = viewportSize ?: return
        var workingCamera: MapCamera? = null
        try {
            workingCamera = MapCamera(
                center = GeographicCoordinate(
                    latitude = cameraPose.latitudeDegrees,
                    longitude = cameraPose.longitudeDegrees,
                ),
                zoomLevel = cameraPose.zoomLevel,
                bearingDegrees = cameraPose.bearingDegrees,
                pitchDegrees = cameraPose.pitchDegrees,
            )
            if (panXPixels != 0.0 || panYPixels != 0.0) {
                val panned = workingCamera.panByScreenPixels(
                    deltaXPixels = panXPixels,
                    deltaYPixels = panYPixels,
                    viewport = viewport,
                    fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
                )
                workingCamera.close()
                workingCamera = panned
            }
            if (zoomLevels != 0.0 && focalPoint != null) {
                val zoomed = workingCamera.zoomByLevelsAroundScreenPoint(
                    deltaZoomLevels = zoomLevels,
                    focalPoint = focalPoint,
                    viewport = viewport,
                    fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
                )
                workingCamera.close()
                workingCamera = zoomed
            }
            if (rotateDegrees != 0.0 && focalPoint != null) {
                val rotated = workingCamera.rotateByDegreesAroundScreenPoint(
                    deltaBearingDegrees = rotateDegrees,
                    focalPoint = focalPoint,
                    viewport = viewport,
                    fieldOfViewDegrees = DEFAULT_FIELD_OF_VIEW_DEGREES,
                )
                workingCamera.close()
                workingCamera = rotated
            }
            adoptCamera(workingCamera, isGestureDriven = isGestureDriven)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.CAMERA, failure)
        } finally {
            workingCamera?.close()
        }
    }

    private fun advanceCameraAnimation(frameTimeNanos: Long) {
        val animation = cameraAnimation ?: return
        val elapsedNanos = frameTimeNanos - animation.startNanos
        if (elapsedNanos < 0L) {
            return
        }
        val fraction = (elapsedNanos.toDouble() / animation.durationNanos).coerceIn(0.0, 1.0)
        val easedFraction = smoothstepFraction(fraction)
        val nextPose = MapCameraPose(
            latitudeDegrees = interpolate(
                animation.fromPose.latitudeDegrees,
                animation.toPose.latitudeDegrees,
                easedFraction,
            ),
            longitudeDegrees = interpolate(
                animation.fromPose.longitudeDegrees,
                animation.toPose.longitudeDegrees,
                easedFraction,
            ),
            zoomLevel = interpolate(
                animation.fromPose.zoomLevel,
                animation.toPose.zoomLevel,
                easedFraction,
            ),
            bearingDegrees = interpolateBearingDegrees(
                animation.fromPose.bearingDegrees,
                animation.toPose.bearingDegrees,
                easedFraction,
            ),
            pitchDegrees = interpolate(
                animation.fromPose.pitchDegrees,
                animation.toPose.pitchDegrees,
                easedFraction,
            ),
        )
        if (fraction >= 1.0) {
            cameraAnimation = null
        }
        adoptPose(nextPose, isGestureDriven = false)
    }

    // ------------------------------------------------------------------
    // Overlay internals
    // ------------------------------------------------------------------

    private fun replaceOverlays(descriptors: List<MapOverlay>): Boolean {
        val nativeView = nativeMapView
        if (nativeView == null) {
            overlayDescriptors = descriptors
            return true
        }
        return try {
            nativeView.setOverlays(descriptors)
            overlayDescriptors = descriptors
            resumePump(resetBackoff = true)
            true
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.OVERLAY, failure)
            false
        }
    }

    // ------------------------------------------------------------------
    // Native view construction
    // ------------------------------------------------------------------

    private fun rebuildNativeMapView() {
        stopFrameCallback()
        cancelWatchdog()
        detachSurface()
        nativeMapView?.close()
        nativeMapView = null
        hasReportedMapReady = false
        val suppliedSdk = sdk
        if (suppliedSdk != null && !isDestroyed) {
            nativeMapView = NativeMapView(suppliedSdk)
            applyStoredStateToNativeView()
            if (availableSurface != null) {
                requiresAttach = true
                retryAttachRequested = true
                resumePump(resetBackoff = true)
            }
        }
    }

    private fun applyStoredStateToNativeView() {
        val nativeView = nativeMapView ?: return
        applyDevicePixelRatio(nativeView, MapViewFailurePhase.SURFACE)
        try {
            nativeView.setOverlays(overlayDescriptors)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.OVERLAY, failure)
        }
        val state = locationIndicatorState
        val style = locationIndicatorStyle
        if (state != null && style != null) {
            try {
                nativeView.setLocationIndicator(state, style)
            } catch (failure: Exception) {
                if (failure is CancellationException) {
                    throw failure
                }
                reportFailure(MapViewFailurePhase.LOCATION_INDICATOR, failure)
            }
        }
        val vectorTileSource = pendingVectorTileSource
        if (vectorTileSource != null) {
            try {
                nativeView.setVectorTileSource(vectorTileSource)
            } catch (failure: Exception) {
                if (failure is CancellationException) {
                    throw failure
                }
                reportFailure(MapViewFailurePhase.BASE_MAP, failure)
            }
        }
    }

    /**
     * Reports the display's device pixels per dp to the SDK: the labels and
     * overlay screen sizes are declared in dp/points, so the surface scales
     * them by this ratio. Called whenever the effective scale is applied — at
     * attach, after a resize and on a rebuilt native view.
     */
    private fun applyDevicePixelRatio(
        nativeView: NativeMapView,
        failurePhase: MapViewFailurePhase,
    ) {
        try {
            nativeView.setDevicePixelRatio(displayDensity())
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(failurePhase, failure)
        }
    }

    /** The display's device pixels per dp, or the identity ratio before it resolves. */
    private fun displayDensity(): Double {
        val density = resources.displayMetrics.density
        return if (density.isFinite() && density > 0f) {
            density.toDouble()
        } else {
            DEFAULT_DEVICE_PIXEL_RATIO
        }
    }

    // ------------------------------------------------------------------
    // Frame pump
    // ------------------------------------------------------------------

    private fun canPump(): Boolean =
        !isDestroyed && isLifecycleStarted && isWindowAttached && isWindowVisible &&
            !isRenderingPaused && nativeMapView != null && availableSurface != null

    private fun resumePump(resetBackoff: Boolean) {
        if (!canPump()) {
            return
        }
        cancelWatchdog()
        if (resetBackoff) {
            isBackoffActive = false
            consecutiveUnavailableOnlyFrames = 0
        }
        ensurePumpConsumer()
        if (!isFrameCallbackPosted) {
            isFrameCallbackPosted = true
            choreographerInstance.postFrameCallback(frameCallback)
        }
    }

    private fun ensurePumpConsumer() {
        if (isPumpConsumerRunning) {
            return
        }
        isPumpConsumerRunning = true
        pumpScope.launch {
            for (frameTimeNanos in frameChannel) {
                if (!canPump()) {
                    continue
                }
                pumpOneFrame(frameTimeNanos)
            }
        }
    }

    private suspend fun pumpOneFrame(frameTimeNanos: Long) {
        val surface = availableSurface ?: return
        val nativeView = nativeMapView ?: return
        if (requiresAttach) {
            if (retryAttachRequested) {
                retryAttachRequested = false
                tryAttach(nativeView, surface)
            }
            return
        }
        if (!isAttached) {
            return
        }
        val renderWidthPixels = cappedRenderExtent(surfaceWidthPixels)
        val renderHeightPixels = cappedRenderExtent(surfaceHeightPixels)
        if (renderWidthPixels <= 0 || renderHeightPixels <= 0) {
            return
        }
        if (attachedWidthPixels != renderWidthPixels || attachedHeightPixels != renderHeightPixels) {
            tryResize(nativeView, renderWidthPixels, renderHeightPixels)
            return
        }
        applyPendingVectorTileSourceInstall(nativeView)
        advanceCameraAnimation(frameTimeNanos)
        val camera = currentCameraOrNull() ?: return
        val isSettledNow = try {
            nativeView.isFrameSettled(camera)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.DRAW, failure)
            false
        }
        if (isSettledNow) {
            listener?.onFrameSettled()
            pauseForSettled()
            return
        }
        if (isDrawInFlight) {
            return
        }
        isDrawInFlight = true
        val drawnCameraRevision = cameraRevision
        try {
            val statistics = nativeView.draw(camera)
            handleDrawnFrame(statistics, drawnCameraRevision)
        } catch (busyFailure: SdkException.RenderingSurfaceUnavailable) {
            // Documented backpressure of the serialized-draw rule: retry next tick.
            consecutiveUnavailableOnlyFrames = 0
            listener?.onFrameDeferred()
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.DRAW, failure)
            pauseForRetry()
        } finally {
            isDrawInFlight = false
        }
    }

    /**
     * Hands the queued vector base source to the native view once no frame is
     * in flight, then keeps the pump awake so the change is drawn.
     *
     * A source the SDK still refuses is reported through the listener and the
     * queue is dropped: retrying a refusal forever would spin the pump.
     */
    private fun applyPendingVectorTileSourceInstall(nativeView: NativeMapView?) {
        if (!isVectorTileSourceInstallPending || isDrawInFlight || nativeView == null) {
            return
        }
        isVectorTileSourceInstallPending = false
        val source = pendingVectorTileSource
        try {
            if (source == null) {
                nativeView.clearVectorTileSource()
            } else {
                nativeView.setVectorTileSource(source)
            }
            resumePump(resetBackoff = true)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            // The view owns the refusal's wording; the state drops its record
            // so a later selection is not silently overwritten by this one.
            reportFailure(MapViewFailurePhase.BASE_MAP, failure)
        }
    }

    private fun handleDrawnFrame(statistics: FrameStatistics, drawnCameraRevision: Long) {
        listener?.onFrameStatistics(statistics)
        if (!hasReportedMapReady) {
            hasReportedMapReady = true
            listener?.onMapReady()
        }
        val nothingDeferred = statistics.deferredTileCount == 0u
        val somethingUnavailable = statistics.unavailableTileCount > 0u
        // "Unchanged pose" is judged against the camera this frame actually
        // drew, not against a gesture that landed while the draw was awaiting
        // its tiles.
        val poseUnchanged = drawnCameraRevision == cameraRevision
        if (nothingDeferred && somethingUnavailable && poseUnchanged) {
            if (isBackoffActive) {
                pauseForBackoff()
                return
            }
            consecutiveUnavailableOnlyFrames += 1
            if (consecutiveUnavailableOnlyFrames >= UNAVAILABLE_BACKOFF_FRAME_COUNT) {
                isBackoffActive = true
                pauseForBackoff()
            }
        } else {
            consecutiveUnavailableOnlyFrames = 0
            isBackoffActive = false
        }
    }

    private fun pauseForSettled() {
        // The settled state is represented by the stopped frame callback:
        // any resume trigger restarts it, and the watchdog re-checks cheaply.
        stopFrameCallback()
        scheduleWatchdog()
    }

    private fun pauseForBackoff() {
        stopFrameCallback()
        scheduleWatchdog()
    }

    private fun pauseForRetry() {
        stopFrameCallback()
        scheduleWatchdog()
    }

    private fun stopFrameCallback() {
        if (isFrameCallbackPosted) {
            choreographerInstance.removeFrameCallback(frameCallback)
            isFrameCallbackPosted = false
        }
    }

    private fun scheduleWatchdog() {
        cancelWatchdog()
        mainHandler.postDelayed(watchdogRunnable, WATCHDOG_INTERVAL_MILLIS)
    }

    private fun cancelWatchdog() {
        mainHandler.removeCallbacks(watchdogRunnable)
    }

    // ------------------------------------------------------------------
    // Attach / resize / detach
    // ------------------------------------------------------------------

    private fun tryAttach(nativeView: NativeMapView, surface: Surface) {
        val renderWidthPixels = cappedRenderExtent(surfaceWidthPixels)
        val renderHeightPixels = cappedRenderExtent(surfaceHeightPixels)
        if (renderWidthPixels <= 0 || renderHeightPixels <= 0) {
            return
        }
        val nativeWindowPointer = NativeWindowBridge.nativeWindowPointerFromSurface(surface)
        acquiredNativeWindowPointer = nativeWindowPointer
        val surfaceHandle = SurfaceHandle(
            appkitViewPointer = null,
            iosViewPointer = null,
            androidNativeWindowPointer = if (nativeWindowPointer != 0L) {
                nativeWindowPointer.toULong()
            } else {
                null
            },
        )
        try {
            nativeView.attach(
                surfaceHandle = surfaceHandle,
                widthPixels = renderWidthPixels.toUInt(),
                heightPixels = renderHeightPixels.toUInt(),
            )
            attachedWidthPixels = renderWidthPixels
            attachedHeightPixels = renderHeightPixels
            requiresAttach = false
            isAttached = true
            applyStoredStateToNativeView()
            resumePump(resetBackoff = true)
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            // The failed attach must not leak the acquired window reference:
            // release it here, then surface the verbatim failure and wait for
            // an explicit retry (a registration may have arrived meanwhile).
            releaseAcquiredNativeWindow()
            requiresAttach = true
            retryAttachRequested = false
            reportFailure(MapViewFailurePhase.SURFACE, failure)
            stopFrameCallback()
            cancelWatchdog()
        }
    }

    private fun tryResize(nativeView: NativeMapView, widthPixels: Int, heightPixels: Int) {
        try {
            nativeView.resize(widthPixels.toUInt(), heightPixels.toUInt())
            attachedWidthPixels = widthPixels
            attachedHeightPixels = heightPixels
            applyDevicePixelRatio(nativeView, MapViewFailurePhase.RESIZE)
            resumePump(resetBackoff = true)
        } catch (busyFailure: SdkException.RenderingSurfaceUnavailable) {
            // A mid-draw resize is documented backpressure: the next tick retries.
        } catch (failure: Exception) {
            if (failure is CancellationException) {
                throw failure
            }
            reportFailure(MapViewFailurePhase.RESIZE, failure)
            pauseForRetry()
        }
    }

    private fun detachSurface() {
        if (isAttached) {
            nativeMapView?.detach()
            isAttached = false
        }
        releaseAcquiredNativeWindow()
        requiresAttach = false
        retryAttachRequested = false
        attachedWidthPixels = 0
        attachedHeightPixels = 0
    }

    private fun releaseAcquiredNativeWindow() {
        val pointer = acquiredNativeWindowPointer
        if (pointer != 0L) {
            NativeWindowBridge.releaseNativeWindow(pointer)
            acquiredNativeWindowPointer = 0L
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private fun reportFailure(phase: MapViewFailurePhase, cause: Throwable) {
        listener?.onError(MapViewFailure(phase, cause))
    }

    /** The surface extent, capped to the downlevel texture limit per axis. */
    private fun cappedRenderExtent(surfaceExtentPixels: Int): Int =
        min(surfaceExtentPixels, MAXIMUM_RENDER_EXTENT_PIXELS)

    private fun surfaceDeltaToViewport(
        surfaceDeltaPixels: Double,
        surfaceExtentPixels: Int,
        viewportExtentPixels: Int,
    ): Double = if (surfaceExtentPixels > 0) {
        surfaceDeltaPixels * viewportExtentPixels / surfaceExtentPixels
    } else {
        surfaceDeltaPixels
    }

    private fun surfacePositionToViewport(
        surfacePositionPixels: Double,
        surfaceExtentPixels: Int,
        viewportExtentPixels: Int,
    ): Double = surfaceDeltaToViewport(surfacePositionPixels, surfaceExtentPixels, viewportExtentPixels)

    private class CameraAnimation(
        val startNanos: Long,
        val durationNanos: Double,
        val fromPose: MapCameraPose,
        val toPose: MapCameraPose,
    )

    private companion object {
        /** The SDK's default perspective field of view (`rustic-maps-rendering`). */
        const val DEFAULT_FIELD_OF_VIEW_DEGREES: Double = 60.0

        /**
         * `wgpu::Limits::downlevel_defaults()`'s `max_texture_dimension_2d`:
         * a surface buffer larger than this is rejected by the downlevel
         * adapter, so the render extent is capped per axis (the drawable
         * cap `docs/PublicApiV2.md` §10 requires).
         */
        const val MAXIMUM_RENDER_EXTENT_PIXELS: Int = 2048

        /**
         * The identity drawing-buffer ratio: one device pixel per dp. Used
         * until the display reports its density.
         */
        const val DEFAULT_DEVICE_PIXEL_RATIO: Double = 1.0

        /** Cheap idle insurance when the pump is settled or backing off. */
        const val WATCHDOG_INTERVAL_MILLIS: Long = 1_000L

        /**
         * Consecutive unavailable-only, pose-unchanged frames before the
         * pump drops to the watchdog's one-second retry cadence: a provider
         * that keeps rejecting tiles must not become a 60 fps retry spin.
         */
        const val UNAVAILABLE_BACKOFF_FRAME_COUNT: Int = 3

        /** Default camera animation duration (docs/ReferenceAppUX.md §5.3). */
        const val DEFAULT_CAMERA_ANIMATION_DURATION_MILLIS: Long = 300L

        /**
         * One double tap's zoom step (docs/ReferenceAppUX.md §5.2): the
         * gesture zooms exactly one level around the tapped point, the same
         * contract focal-zoom member the pinch recognizer feeds.
         */
        const val DOUBLE_TAP_ZOOM_STEP: Double = 1.0

        /** The SDK's maximum zoom level, the default fit-bounds ceiling. */
        const val DEFAULT_FIT_BOUNDS_MAXIMUM_ZOOM_LEVEL: Double = 24.0

        /** The initial pose before any host camera intent. */
        val DEFAULT_CAMERA_POSE: MapCameraPose = MapCameraPose(
            latitudeDegrees = 0.0,
            longitudeDegrees = 0.0,
            zoomLevel = 2.0,
            bearingDegrees = 0.0,
            pitchDegrees = 0.0,
        )

        /** No insets, the natural default of [fitBounds]. */
        val ZERO_EDGE_INSETS: EdgeInsets = EdgeInsets(
            left = 0.0,
            top = 0.0,
            right = 0.0,
            bottom = 0.0,
        )

        /** Number of pointers a pinch or rotate needs. */
        const val TWO_POINTER_COUNT: Int = 2

        /** Below this span the pinch/rotate ratio is dominated by noise. */
        const val MINIMUM_PINCH_SPAN_PIXELS: Double = 16.0

        /** Radians-to-degrees conversion of the two-finger angle. */
        const val DEGREES_PER_RADIAN: Double = 180.0 / Math.PI

        /** One full turn in degrees. */
        const val FULL_CIRCLE_DEGREES: Double = 360.0

        /** Half a turn in degrees. */
        const val HALF_CIRCLE_DEGREES: Double = 180.0

        /**
         * The number of viewport corners the bounds computation needs to
         * unproject before it trusts the corner box; a steep pitch can put
         * one corner below the horizon.
         */
        const val MINIMUM_UNPROJECTED_CORNER_COUNT: Int = 3

        /** Ground meters per degree of latitude (the equatorial scale). */
        const val METERS_PER_DEGREE_LATITUDE: Double = 111_320.0

        /** Nanoseconds in one millisecond. */
        const val NANOS_PER_MILLISECOND: Double = 1_000_000.0

        /** The Choreographer must be created on a looper thread (the UI thread). */
        val choreographerInstance: Choreographer = Choreographer.getInstance()
    }
}

/** Linear interpolation between [from] and [to] at [fraction]. */
private fun interpolate(from: Double, to: Double, fraction: Double): Double =
    from + (to - from) * fraction

/** The smoothstep ease used by camera animations (docs/ReferenceAppUX.md §5.3). */
private fun smoothstepFraction(fraction: Double): Double = fraction * fraction * (3.0 - 2.0 * fraction)

/** Wraps an angle in degrees into `[0, 360)`. */
private fun normalizeDegrees(angleDegrees: Double): Double {
    val wrapped = angleDegrees % 360.0
    return if (wrapped < 0.0) wrapped + 360.0 else wrapped
}

/**
 * Interpolates a bearing along the shortest angular path, so a move from
 * 350° to 10° turns 20° clockwise instead of 340° counter-clockwise.
 */
private fun interpolateBearingDegrees(fromDegrees: Double, toDegrees: Double, fraction: Double): Double {
    var deltaDegrees = (toDegrees - fromDegrees) % 360.0
    if (deltaDegrees > 180.0) {
        deltaDegrees -= 360.0
    } else if (deltaDegrees < -180.0) {
        deltaDegrees += 360.0
    }
    return normalizeDegrees(fromDegrees + deltaDegrees * fraction)
}
