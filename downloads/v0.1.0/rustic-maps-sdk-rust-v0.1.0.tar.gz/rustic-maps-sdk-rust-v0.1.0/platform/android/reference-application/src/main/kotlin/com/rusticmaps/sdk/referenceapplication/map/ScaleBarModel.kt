package com.rusticmaps.sdk.referenceapplication.map

import com.rusticmaps.sdk.ux.ReferenceAppUXDimensions
import kotlin.math.pow

/**
 * The scale bar's distance selection (docs/ReferenceAppUX.md §2.4's
 * `scale-bar-width-range` + the 1-2-3-5-10 distance ladder): from the map
 * camera's `ground_meters_per_screen_pixel` answer the bar picks the
 * ladder-distance whose bar width in physical pixels lands inside the token
 * width range — the largest fitting distance, so the bar is as informative
 * as the allowed width, and the bar width follows exactly from the distance
 * chosen.
 */
object ScaleBarModel {
    /** The clean distance ladder's multipliers, per decade (§2.4). */
    val LADDER_MULTIPLIERS: List<Double> = listOf(1.0, 2.0, 3.0, 5.0, 10.0)

    /** The ladder's decade scan range around one meter: `10⁻² … 10⁹` m spans
     *  every usable zoom the SDK camera clamps to (§5.1's zoom range), from
     *  deep-zoom centimeters to zoom-0 hemisphere bars, with slack on both
     *  ends — candidates outside the range can never fit. (The ladder multiplies
     *  to 5·10⁹⁶ m at the ceiling; scanning stops once a candidate's width
     *  passes the maximum, so the slack decades never evaluate their full lists.) */
    const val LADDER_DECADE_SCAN_RANGE: Int = 9
    const val LADDER_LOWER_DECADE_SCAN_RANGE: Int = 2

    /** One chosen scale-bar scale: the labeled distance and the bar's physical width. */
    data class SelectedScaleBarScale(
        /** The bar's labeled distance, in meters. */
        val distanceMeters: Double,
        /** The bar's physical width for that distance, in viewport pixels. */
        val widthPixels: Double,
    )

    /**
     * Selects the ladder distance fitting the token width range for one
     * ground meters-per-screen-pixel answer: the largest ladder distance
     * whose bar width does not exceed the maximum width, when its width also
     * reaches the minimum (the ladder's consecutive ratios — at most 2× at
     * a decade step — are tighter than the width range's 120/50 ratio, so a
     * fitting candidate exists for every positive ground answer); a
     * non-finite or non-positive ground answer selects nothing (the scale
     * bar then renders no bar rather than an invented distance).
     */
    fun selectScaleBarScale(groundMetersPerScreenPixel: Double): SelectedScaleBarScale? {
        if (groundMetersPerScreenPixel.isNaN() || groundMetersPerScreenPixel.isInfinite() ||
            groundMetersPerScreenPixel <= 0.0
        ) {
            return null
        }
        val minimumWidthPixels = ReferenceAppUXDimensions.SCALE_BAR_WIDTH_MINIMUM_PIXELS
        val maximumWidthPixels = ReferenceAppUXDimensions.SCALE_BAR_WIDTH_MAXIMUM_PIXELS
        val ascendingCandidates = (-LADDER_LOWER_DECADE_SCAN_RANGE..LADDER_DECADE_SCAN_RANGE)
            .flatMap { decadeExponent ->
                LADDER_MULTIPLIERS.map { multiplier ->
                    multiplier * pow10(decadeExponent)
                }
            }
            .sorted()
        var selected: SelectedScaleBarScale? = null
        // Ascending scan; the last candidate under the maximum is the
        // largest fitting one, so it is kept as the selection when it also
        // reaches the minimum width.
        for (candidateDistanceMeters in ascendingCandidates) {
            val candidateWidthPixels = candidateDistanceMeters / groundMetersPerScreenPixel
            if (candidateWidthPixels > maximumWidthPixels) {
                break
            }
            selected = SelectedScaleBarScale(
                distanceMeters = candidateDistanceMeters,
                widthPixels = candidateWidthPixels,
            )
        }
        return selected?.takeIf { it.widthPixels >= minimumWidthPixels }
    }

    /** The ladder distance's metric label (the scale bar's text). */
    fun distanceLabelText(distanceMeters: Double): String =
        if (distanceMeters < METERS_PER_KILOMETER) {
            "${distanceMeters.toInt()} m"
        } else {
            "${roundHalves(distanceMeters / METERS_PER_KILOMETER)} km"
        }

    private const val METERS_PER_KILOMETER: Double = 1000.0

    private fun roundHalves(value: Double): Long =
        kotlin.math.round(value).toLong()

    private fun pow10(exponent: Int): Double = 10.0.pow(exponent.toDouble())
}