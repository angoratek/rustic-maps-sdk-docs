package com.rusticmaps.sdk.referenceapplication.map

import com.rusticmaps.sdk.ux.ReferenceAppUXDimensions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The round-10 map-logics unit tests (JVM): the follow camera's state
 * machine (engage, gesture-break, fix re-engage, trip-end restore, zoom
 * clamp), the median course smoother, the camera easings, the scale bar's
 * ladder fit, and the compass's visibility threshold
 * (docs/ReferenceAppUX.md §4.2/§5.3/§2.4). Pure Kotlin, no SDK object inside.
 */
class FollowCameraTest {
    @Test
    fun `trip start captures the pre-trip camera and applies the fixed follow zoom`() {
        val followCameraController = FollowCameraController()
        followCameraController.engageTrip(
            currentCenterLatitudeDegrees = 47.3,
            currentCenterLongitudeDegrees = 8.5,
            currentZoomLevel = 15.0,
            currentBearingDegrees = 10.0,
            currentPitchDegrees = 0.0,
        )
        assertEquals(FollowCameraController.FollowPhase.ENGAGED, followCameraController.phase)
        assertEquals(ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM, followCameraController.targetZoomLevel, 0.0)
        assertNull(followCameraController.targetBearingDegrees)
        val preTripCamera = followCameraController.preTripCamera!!
        assertEquals(15.0, preTripCamera.zoomLevel, 0.0)
        assertEquals(0.0, preTripCamera.pitchDegrees, 0.0)
    }

    @Test
    fun `a location fix retargets center, smoothed bearing and ramped zoom`() {
        val followCameraController = FollowCameraController()
        followCameraController.engageTrip(47.3, 8.5, 15.0, 10.0, 0.0)
        followCameraController.onFix(
            latitudeDegrees = 47.4,
            longitudeDegrees = 8.6,
            courseHeadingDegrees = 90.0,
            remainingDistanceFraction = 1.0,
        )
        assertEquals(47.4, followCameraController.targetCenterLatitudeDegrees, 0.0)
        assertEquals(8.6, followCameraController.targetCenterLongitudeDegrees, 0.0)
        assertEquals(90.0, followCameraController.targetBearingDegrees!!, 0.0)
        assertEquals(
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM,
            followCameraController.targetZoomLevel,
            ZOOM_ASSERTION_TOLERANCE,
        )
    }

    @Test
    fun `a user gesture breaks follow immediately and a later fix keeps it broken`() {
        val followCameraController = FollowCameraController()
        followCameraController.engageTrip(47.3, 8.5, 15.0, 10.0, 0.0)
        followCameraController.onFix(47.4, 8.6, 90.0, 1.0)
        followCameraController.breakOnGesture()
        assertEquals(FollowCameraController.FollowPhase.BROKEN_BY_GESTURE, followCameraController.phase)
        // The fix keeps the targets current but never re-engages follow: the
        // user's panned view stands until the my-location control re-engages
        // it (§5.3's re-center rule).
        followCameraController.onFix(47.5, 8.7, 95.0, 0.8)
        assertEquals(FollowCameraController.FollowPhase.BROKEN_BY_GESTURE, followCameraController.phase)
        assertEquals(47.5, followCameraController.targetCenterLatitudeDegrees, 0.0)
        // The window {90, 95} ties its circular median; the earlier sample wins.
        assertEquals(90.0, followCameraController.targetBearingDegrees!!, 0.0)
    }

    @Test
    fun `the my-location control re-engages a broken follow`() {
        val followCameraController = FollowCameraController()
        followCameraController.engageTrip(47.3, 8.5, 15.0, 10.0, 0.0)
        followCameraController.breakOnGesture()
        // A later fix keeps follow broken; the explicit re-engage resumes it.
        followCameraController.onFix(47.5, 8.7, 95.0, 0.8)
        followCameraController.reengage()
        assertEquals(FollowCameraController.FollowPhase.ENGAGED, followCameraController.phase)
    }

    @Test
    fun `the trip end restores the captured pre-trip camera and disengages`() {
        val followCameraController = FollowCameraController()
        followCameraController.engageTrip(47.3, 8.5, 15.0, 10.0, 0.0)
        followCameraController.onFix(47.4, 8.6, 90.0, 0.2)
        val restoredCamera = followCameraController.restorePreTripCamera()!!
        assertEquals(15.0, restoredCamera.zoomLevel, 0.0)
        assertEquals(10.0, restoredCamera.bearingDegrees, 0.0)
        assertEquals(47.3, restoredCamera.centerLatitudeDegrees, 0.0)
        assertEquals(0.0, restoredCamera.pitchDegrees, 0.0)
        assertEquals(FollowCameraController.FollowPhase.DISENGAGED, followCameraController.phase)
        assertNull(followCameraController.preTripCamera)
    }

    @Test
    fun `the follow zoom ramps from the base toward the maximum toward trip end`() {
        assertEquals(
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM,
            FollowCameraController.followZoomTowardTripEnd(1.0),
            ZOOM_ASSERTION_TOLERANCE,
        )
        assertEquals(
            (ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM +
                ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM_MAXIMUM) / 2.0,
            FollowCameraController.followZoomTowardTripEnd(0.5),
            ZOOM_ASSERTION_TOLERANCE,
        )
        assertEquals(
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM_MAXIMUM,
            FollowCameraController.followZoomTowardTripEnd(0.0),
            ZOOM_ASSERTION_TOLERANCE,
        )
        // Fractions beyond the trip's ends clamp.
        assertEquals(
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM,
            FollowCameraController.followZoomTowardTripEnd(2.0),
            ZOOM_ASSERTION_TOLERANCE,
        )
        assertEquals(
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM_MAXIMUM,
            FollowCameraController.followZoomTowardTripEnd(-1.0),
            ZOOM_ASSERTION_TOLERANCE,
        )
    }

    @Test
    fun `the course median smooths over the named window with circular courses`() {
        val courseMedianSmoother = CourseMedianSmoother(FollowCameraController.COURSE_SMOOTHING_WINDOW_FIXES)
        assertNull(courseMedianSmoother.median())
        listOf(100.0, 96.0, 104.0, 98.0, 102.0).forEach { course ->
            courseMedianSmoother.add(course)
        }
        assertEquals(100.0, courseMedianSmoother.median()!!, 0.0)
        // The window drops its oldest: the median rides forward.
        courseMedianSmoother.add(200.0)
        assertEquals(102.0, courseMedianSmoother.median()!!, 0.0)
        // Circular wrap: a north-crossing window medians across the wrap.
        courseMedianSmoother.reset()
        listOf(356.0, 2.0, 358.0, 4.0, 0.0).forEach { course ->
            courseMedianSmoother.add(course)
        }
        // The circular median is the windowed sample minimizing the total
        // angular distance — here the wrap-window's true center, 0 degrees.
        assertEquals(0.0, courseMedianSmoother.median()!!, 0.0)
    }

    @Test
    fun `the smoothstep ease completes over its duration and rests`() {
        val pitchSwingEase = SmoothstepTimedEase()
        pitchSwingEase.begin(
            startNanos = 1_000,
            from = 0.0,
            to = 45.0,
            durationNanos = 300_000_000,
        )
        val (midValue, midFinished) = pitchSwingEase.advance(1_000 + 150_000_000)
        // The smoothstep midpoint is exactly halfway.
        assertEquals(22.5, midValue, 0.5)
        assertFalse(midFinished)
        val (endValue, endFinished) = pitchSwingEase.advance(1_000 + 400_000_000)
        assertEquals(45.0, endValue, 0.0)
        assertTrue(endFinished)
    }

    @Test
    fun `the chase advances toward the target and snaps under the snap distance`() {
        val followBearingChase = ExponentialValueChase(timeConstantNanos = 150_000_000.0)
        val firstChasedValue = followBearingChase.advance(
            current = 0.0,
            target = 10.0,
            nowNanos = 0,
        )
        assertTrue(firstChasedValue in 0.0..10.0 && firstChasedValue != 10.0)
        // A target inside the snap distance resolves exactly to the target.
        assertEquals(
            0.04,
            followBearingChase.advance(
                current = 0.0,
                target = 0.04,
                nowNanos = 50,
            ),
            0.0,
        )
        // The shortest way around: 350 degrees reached from 0 through the
        // (+) wrap, never the long way through 180.
        val wrappedChasedValue = followBearingChase.advance(
            current = 0.0,
            target = 350.0,
            nowNanos = 100,
        )
        assertTrue(wrappedChasedValue > 180.0 || wrappedChasedValue <= 0.05)
    }

    @Test
    fun `the scale bar picks the largest ladder distance fitting the width range`() {
        // One ground meter per pixel: the 100 m bar sits at 100 px, inside
        // the token range; 200 m overflows, so 100 m wins.
        val selectedScaleBarScale = ScaleBarModel.selectScaleBarScale(1.0)!!
        assertEquals(100.0, selectedScaleBarScale.distanceMeters, 0.0)
        assertEquals(100.0, selectedScaleBarScale.widthPixels, 0.0)
        // A finer camera (0.4 ground meters per pixel): the 30 m bar spans
        // 75 px (the largest fitting ladder distance under the 120 px
        // ceiling; 50 m would span 125 px and overflow).
        val deepZoomScale = ScaleBarModel.selectScaleBarScale(0.4)!!
        assertEquals(30.0, deepZoomScale.distanceMeters, 1e-9)
        assertEquals(75.0, deepZoomScale.widthPixels, 1e-9)
        // A degenerate answer selects nothing.
        assertNull(ScaleBarModel.selectScaleBarScale(Double.NaN))
        assertNull(ScaleBarModel.selectScaleBarScale(0.0))
        assertNull(ScaleBarModel.selectScaleBarScale(-1.0))
    }

    @Test
    fun `the scale bar labels its ladder distances metric`() {
        assertEquals("100 m", ScaleBarModel.distanceLabelText(100.0))
        assertEquals("3 m", ScaleBarModel.distanceLabelText(3.0))
        assertEquals("1 km", ScaleBarModel.distanceLabelText(1000.0))
        assertEquals("2 km", ScaleBarModel.distanceLabelText(2000.0))
        assertEquals("50 km", ScaleBarModel.distanceLabelText(50_000.0))
    }

    @Test
    fun `the compass appears only when the bearing is off north by the threshold`() {
        val compassVisibilityBearingThreshold =
            ReferenceAppUXDimensions.COMPASS_VISIBILITY_BEARING_THRESHOLD_DEGREES
        // North up: no compass.
        assertTrue(bearingOffNorthDegrees(0.0) < compassVisibilityBearingThreshold)
        assertTrue(bearingOffNorthDegrees(360.0) < compassVisibilityBearingThreshold)
        // Half a degree is under the token threshold; one degree and beyond is over.
        assertTrue(bearingOffNorthDegrees(0.5) < compassVisibilityBearingThreshold)
        assertTrue(bearingOffNorthDegrees(2.0) >= compassVisibilityBearingThreshold)
        // A westward bearing wraps to its clockwise deviation.
        assertTrue(bearingOffNorthDegrees(350.0) >= compassVisibilityBearingThreshold)
        assertTrue(bearingOffNorthDegrees(-90.0) >= compassVisibilityBearingThreshold)
        assertEquals(180.0, bearingOffNorthDegrees(180.0), 0.0)
    }
}

private const val ZOOM_ASSERTION_TOLERANCE: Double = 1e-9