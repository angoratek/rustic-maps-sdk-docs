package com.rusticmaps.sdk.referenceapplication

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.view.MotionEvent
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rusticmaps.sdk.referenceapplication.ReferenceApplicationState.HomeSheetState
import com.rusticmaps.sdk.referenceapplication.ReferenceApplicationState.ReadinessState
import java.io.File
import java.io.FileOutputStream
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Assume
import org.junit.Test
import org.junit.runner.RunWith
import uniffi.rustic_maps.ProviderContract

/**
 * Captures the three published Android reference-application screenshots from
 * one run: the plan sheet with both endpoints chosen, the provider section
 * with every row's display name and credential state, and the navigation
 * frame with the turn banner, planned polyline, ETA line and speed controls.
 *
 * The capture is opt-in so the connected suite stays read-only and fast:
 *
 * ```
 * ./gradlew :reference-application:connectedDebugAndroidTest \
 *   -Pandroid.testInstrumentationRunnerArguments.class=\
 *   com.rusticmaps.sdk.referenceapplication.ReferenceApplicationScreenshotCaptureTest \
 *   -Pandroid.testInstrumentationRunnerArguments.captureReferenceScreenshots=true
 * adb pull /sdcard/Android/data/com.rusticmaps.sdk.referenceapplication/files/reference-screenshots
 * ```
 *
 * Every state is reached through the same public user-path methods the
 * sheet's controls call, exactly like the behavior suite; nothing is forced.
 */
@RunWith(AndroidJUnit4::class)
class ReferenceApplicationScreenshotCaptureTest {

    /** The application scenario the capture launched, closed afterwards. */
    private var applicationScenario: ActivityScenario<MainActivity>? = null

    @After
    fun closesTheApplication() {
        applicationScenario?.close()
        applicationScenario = null
    }

    @Test
    fun capturesThePlanSheetProviderSectionAndNavigationFrame() {
        Assume.assumeTrue(
            "screenshot capture is opt-in",
            InstrumentationRegistry.getArguments()
                .getString(CAPTURE_ARGUMENT) == "true",
        )
        clearRememberedChoices()
        val activity = launchReferenceApplication()
        val applicationState = awaitApplicationState(activity)
        awaitOrTimeout(
            timeoutMilliseconds = READY_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the map's first ready frame",
        ) {
            applicationState.readinessState != ReadinessState.LOADING &&
                applicationState.mapView != null
        }
        val recordedRoute = applicationState.artifact.demoRoutes.firstOrNull()
            ?: throw AssertionError("the shared artifact carries no recorded demo route")
        // Selecting the keyless routing choice registers the descriptor's
        // public demo deployment, so the Directions capability read succeeds
        // without a credential. Nothing in this capture plans through it: the
        // trip replays the committed demo trace, so the capture never reaches
        // a provider.
        awaitOrTimeout(
            timeoutMilliseconds = ROUTE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the routing capability's keyless choice",
        ) {
            applicationState.capabilityProviderState.rows.any { row ->
                row.contract == ProviderContract.ROUTING &&
                    row.choices.any { choice -> !choice.requiresCredential }
            }
        }
        val keylessRoutingKey = applicationState.capabilityProviderState.rows
            .first { row -> row.contract == ProviderContract.ROUTING }
            .choices
            .first { choice -> !choice.requiresCredential }
            .providerKey
        driveOnMainThread { state ->
            state.selectCapabilityProvider(ProviderContract.ROUTING, keylessRoutingKey)
        }

        driveOnMainThread { state ->
            state.openPlanSearch()
            state.originSearchText = recordedRoute.originName
            state.destinationSearchText = recordedRoute.destinationName
        }
        driveOnMainThread { state -> state.requestHomeSheetState(HomeSheetState.FULL) }
        // The first frame of a fresh session fetches the vector base's tiles;
        // on the emulator's software renderer they arrive tens of seconds in.
        settleFrames(BASE_MAP_SETTLE_MILLISECONDS)
        captureScreenshot(PLAN_SHEET_FILE_NAME)

        // The provider section is captured over the plan surface, before a
        // trip starts, and scrolled past the base-map and credential rows to
        // the capability rows the screenshot documents.
        driveOnMainThread { state -> state.openSettings() }
        settleFrames()
        swipeUpWithinSheet()
        settleFrames()
        captureScreenshot(PROVIDER_SECTION_FILE_NAME)
        driveOnMainThread { state -> state.closeSettings() }
        settleFrames()

        driveOnMainThread { state -> state.startSimulatedTrip() }
        awaitOrTimeout(
            timeoutMilliseconds = READY_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the trip's first instruction",
        ) {
            applicationState.isNavigationInTrip &&
                applicationState.navigationListener.instructionState.value != null
        }
        settleFrames()
        captureScreenshot(NAVIGATION_FILE_NAME)

        val outputDirectory = screenshotDirectory()
        val capturedFiles = listOf(
            PLAN_SHEET_FILE_NAME,
            PROVIDER_SECTION_FILE_NAME,
            NAVIGATION_FILE_NAME,
        ).map { fileName -> File(outputDirectory, fileName) }
        capturedFiles.forEach { capturedFile ->
            assertTrue(
                "the capture ${capturedFile.name} was never written",
                capturedFile.isFile && capturedFile.length() > 0,
            )
        }
    }

    /** Launches the application keyless, exactly like a fresh install. */
    private fun launchReferenceApplication(): MainActivity {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val scenario = ActivityScenario.launch<MainActivity>(
            android.content.Intent(context, MainActivity::class.java),
        )
        applicationScenario = scenario
        var launchedActivity: MainActivity? = null
        scenario.onActivity { launchedActivity = it }
        return launchedActivity
            ?: throw AssertionError("the scenario never produced the application activity")
    }

    /** Awaits the application state the activity constructs. */
    private fun awaitApplicationState(activity: MainActivity): ReferenceApplicationState {
        awaitOrTimeout(
            timeoutMilliseconds = STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the application state construction",
        ) {
            activity.automationApplicationState != null
        }
        return activity.automationApplicationState
            ?: throw AssertionError("no application state constructed")
    }

    /** Drives one user-path act on the main thread, as the screen does. */
    private fun driveOnMainThread(action: (ReferenceApplicationState) -> Unit) {
        val scenario = applicationScenario ?: error("no application scenario started")
        scenario.onActivity { activity ->
            activity.automationApplicationState?.let(action)
        }
    }

    /** Clears both preference stores the app reads at launch. */
    private fun clearRememberedChoices() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences(
            RememberedChoicesStore.PREFERENCES_NAME,
            Context.MODE_PRIVATE,
        ).edit().clear().commit()
        context.getSharedPreferences(
            ThemeChoiceStore.PREFERENCES_NAME,
            Context.MODE_PRIVATE,
        ).edit().clear().commit()
    }

    /** Lets Compose and the map's frame pump present the driven state. */
    private fun settleFrames(settleMilliseconds: Long = CAPTURE_SETTLE_MILLISECONDS) {
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        SystemClock.sleep(settleMilliseconds)
    }

    /**
     * Scrolls the open settings sheet toward its capability rows with one
     * real pointer swipe, the gesture a visitor makes. The capture harness
     * cannot compose-scroll a sheet it does not host, so it injects the
     * gesture the same way the behavior suite injects map taps.
     */
    private fun swipeUpWithinSheet() {
        val metrics = ApplicationProvider.getApplicationContext<Context>()
            .resources.displayMetrics
        val horizontalCenterPixels = metrics.widthPixels / 2
        val startYPixels = (metrics.heightPixels * SWIPE_START_HEIGHT_FRACTION).toInt()
        val endYPixels = (metrics.heightPixels * SWIPE_END_HEIGHT_FRACTION).toInt()
        val uiAutomation = InstrumentationRegistry.getInstrumentation().uiAutomation
        val downTime = SystemClock.uptimeMillis()
        fun inject(action: Int, yPixels: Int, eventTime: Long) {
            uiAutomation.injectInputEvent(
                MotionEvent.obtain(
                    downTime,
                    eventTime,
                    action,
                    horizontalCenterPixels.toFloat(),
                    yPixels.toFloat(),
                    0,
                ),
                true,
            )
        }
        inject(MotionEvent.ACTION_DOWN, startYPixels, downTime)
        for (step in 1..SWIPE_STEP_COUNT) {
            val stepY = startYPixels +
                (endYPixels - startYPixels) * step / SWIPE_STEP_COUNT
            val stepTime = downTime + SWIPE_DURATION_MILLISECONDS * step / SWIPE_STEP_COUNT
            inject(MotionEvent.ACTION_MOVE, stepY, stepTime)
        }
        inject(
            MotionEvent.ACTION_UP,
            endYPixels,
            downTime + SWIPE_DURATION_MILLISECONDS,
        )
    }

    /** Writes one full-screen PNG into the app's external files directory. */
    private fun captureScreenshot(fileName: String) {
        val bitmap = InstrumentationRegistry.getInstrumentation()
            .uiAutomation
            .takeScreenshot()
            ?: throw AssertionError("the device produced no screenshot")
        val outputFile = File(screenshotDirectory(), fileName)
        FileOutputStream(outputFile).use { outputStream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, PNG_QUALITY_PERCENT, outputStream)
        }
        bitmap.recycle()
    }

    /** The on-device directory the host pulls after the run. */
    private fun screenshotDirectory(): File {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val directory = File(context.getExternalFilesDir(null), SCREENSHOT_DIRECTORY_NAME)
        directory.mkdirs()
        return directory
    }

    /** Polls a state condition until it holds or the named timeout elapses. */
    private fun awaitOrTimeout(
        timeoutMilliseconds: Long,
        timeoutDescription: String,
        condition: () -> Boolean,
    ) {
        val deadlineMilliseconds = SystemClock.elapsedRealtime() + timeoutMilliseconds
        while (!condition()) {
            if (SystemClock.elapsedRealtime() > deadlineMilliseconds) {
                throw AssertionError(
                    "$timeoutDescription did not settle within $timeoutMilliseconds ms",
                )
            }
            SystemClock.sleep(POLL_INTERVAL_MILLISECONDS)
        }
    }

    private companion object {
        /** The instrumentation argument that opts into the capture. */
        const val CAPTURE_ARGUMENT: String = "captureReferenceScreenshots"

        /** The on-device directory the host pulls. */
        const val SCREENSHOT_DIRECTORY_NAME: String = "reference-screenshots"

        /** The three published captures, named in page order. */
        const val PLAN_SHEET_FILE_NAME: String = "android-plan-sheet.png"
        const val PROVIDER_SECTION_FILE_NAME: String = "android-provider-section.png"
        const val NAVIGATION_FILE_NAME: String = "android-navigation.png"

        /** Lossless PNG encoding. */
        const val PNG_QUALITY_PERCENT: Int = 100

        /** Compose and the frame pump usually present within a few frames. */
        const val CAPTURE_SETTLE_MILLISECONDS: Long = 1_500

        /** The vector base's first tiles take this long on the emulator's renderer. */
        const val BASE_MAP_SETTLE_MILLISECONDS: Long = 12_000

        /** The swipe starts low on the screen. */
        const val SWIPE_START_HEIGHT_FRACTION: Float = 0.82f

        /** A third of the screen's travel lands the Routing row and its terms in frame. */
        const val SWIPE_END_HEIGHT_FRACTION: Float = 0.52f

        /** Move events sent for one swipe. */
        const val SWIPE_STEP_COUNT: Int = 10

        /** Wall time the swipe takes. */
        const val SWIPE_DURATION_MILLISECONDS: Long = 300

        /** State polling interval, matching the behavior suite. */
        const val POLL_INTERVAL_MILLISECONDS: Long = 250

        /** The application state construction is a startup step. */
        const val STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS: Long = 30_000

        /** The first ready frame and the first trip instruction on SwiftShader. */
        const val READY_TIMEOUT_MILLISECONDS: Long = 120_000

        /** A recorded demo route plans without a provider call. */
        const val ROUTE_TIMEOUT_MILLISECONDS: Long = 30_000
    }
}
