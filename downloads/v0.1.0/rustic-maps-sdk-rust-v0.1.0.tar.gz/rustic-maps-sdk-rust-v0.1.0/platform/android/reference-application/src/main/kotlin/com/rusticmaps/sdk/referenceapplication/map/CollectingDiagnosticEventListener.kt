package com.rusticmaps.sdk.referenceapplication.map

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import uniffi.rustic_maps.LogEvent
import uniffi.rustic_maps.SdkDiagnosticEventListener

/**
 * One consumer-facing diagnostics line of the recent-events readout
 * (docs/ReferenceAppUX.md §4.1, round 10): the event's subsystem target,
 * severity and the verbatim detail line (diagnostics detail is the one place
 * SDK jargon is *required* verbatim — §1).
 */
data class DiagnosticEventLine(
    val subsystemTarget: String,
    val severity: String,
    val messageLine: String,
    val timestampMillisecondsSinceEpoch: ULong,
)

/**
 * The recent-events ring of the diagnostics sheet (round 10): the foreign
 * [SdkDiagnosticEventListener] the app subscribes at Info severity when the
 * sheet first opens. The callbacks run on the SDK's producing threads
 * fire-and-forget — the collector only appends into Compose snapshot state
 * (thread-safe from any thread) and never blocks (the contract's listener
 * rule). The ring keeps the newest [DIAGNOSTICS_RECENT_EVENT_LIMIT] events
 * (oldest dropped), so the sheet's readout always shows the most recent
 * events, the flushed backlog (oldest first) included.
 */
class CollectingDiagnosticEventListener : SdkDiagnosticEventListener {
    /** The events, oldest first; every append evicts the dropped oldest. */
    val eventLines: SnapshotStateList<DiagnosticEventLine> = mutableStateListOf()

    /**
     * The count the backlog flush reported (the contract returns the number
     * of events it drained into the listener), as the sheet's backlog line.
     */
    var flushedEventCount: UInt? by mutableStateOf(null)
        private set

    override fun onDiagnosticEvent(diagnosticLogEvent: LogEvent) {
        val eventLine = DiagnosticEventLine(
            subsystemTarget = diagnosticLogEvent.subsystemTarget,
            severity = diagnosticLogEvent.severity.name,
            messageLine = diagnosticLogEvent.messageLine,
            timestampMillisecondsSinceEpoch = diagnosticLogEvent.timestampMillisecondsSinceEpoch,
        )
        synchronized(eventLines) {
            eventLines.add(eventLine)
            while (eventLines.size > DIAGNOSTICS_RECENT_EVENT_LIMIT) {
                eventLines.removeAt(0)
            }
        }
    }

    /** Records the backlog flush's returned count for the sheet's line. */
    fun noteBacklogFlushed(flushedCount: UInt) {
        flushedEventCount = flushedCount
    }

    private companion object {
        /**
         * The readout's capacity: the most recent diagnostics events the
         * sheet keeps on device (the ring's own bound lives in the SDK; this
         * is the consumer readout's smaller display window).
         */
        const val DIAGNOSTICS_RECENT_EVENT_LIMIT: Int = 50
    }
}