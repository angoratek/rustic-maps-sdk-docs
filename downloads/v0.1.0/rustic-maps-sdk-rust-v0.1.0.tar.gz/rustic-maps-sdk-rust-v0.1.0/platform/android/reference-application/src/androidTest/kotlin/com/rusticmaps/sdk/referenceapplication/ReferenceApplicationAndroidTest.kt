package com.rusticmaps.sdk.referenceapplication

import android.content.Intent
import android.graphics.PointF
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.rusticmaps.sdk.referenceapplication.ReferenceApplicationState.HomeSheetState
import com.rusticmaps.sdk.referenceapplication.ReferenceApplicationState.ReadinessState
import com.rusticmaps.sdk.referenceapplication.navigation.SimulatedTrace
import com.rusticmaps.sdk.ux.ReferenceAppUXDimensions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assume
import org.junit.Test
import org.junit.runner.RunWith
import uniffi.rustic_maps.NavigationPhase

/**
 * The connected UI-automation suite of the Compose reference application
 * (round 12): instrumentation drives the same user-path methods the sheet's
 * controls call — the Android analogue of the iOS reference app's launch-
 * argument demo automation (`ReferenceApplicationLaunchAutomation.swift`,
 * written there because `simctl` cannot inject touch) — and asserts the exact
 * values the screen renders (docs/ReferenceAppUX.md §1/§4/§6/§7). No state
 * is ever forced; every drive goes through the public user-path methods of
 * [ReferenceApplicationState], read back through MainActivity's documented
 * automation seam.
 *
 * Determinism rules of the suite: no screenshot waits (every await is a poll
 * on Compose snapshot state with a named timeout), no live provider call
 * from the tests (the demos replay the committed recorded traces and the
 * bundled shared demo artifact; the search flow under test would geocode
 * live, so it is deliberately not exercised here), and no test enters or logs
 * a provider credential by default: the application starts keyless, and a
 * credential reaches it only through the launch-intent automation seam when
 * the instrumentation run supplies one (§6.5).
 */
@RunWith(AndroidJUnit4::class)
class ReferenceApplicationAndroidTest {

    /** The one application scenario the running test launched, closed after each test. */
    private var applicationScenario: ActivityScenario<MainActivity>? = null

    @After
    fun restoresTheApplicationToItsIdleHomeState() {
        val scenario = applicationScenario ?: return
        applicationScenario = null
        try {
            scenario.onActivity { activity ->
                val applicationState = activity.automationApplicationState ?: return@onActivity
                // A trip left running would keep replaying into a torn-down
                // composition: the suite stops it the way the user's exit
                // control does, then collapses the sheet toward peek — the
                // demo's idle home state (no navigation, no automation state
                // carrying over into the next test).
                if (applicationState.isNavigationInTrip || applicationState.tripDriver.isTripActive) {
                    applicationState.exitSimulatedTrip()
                }
                // A location source a case started by hand must not keep
                // listening into the next test.
                if (applicationState.isDeviceLocationActive) {
                    applicationState.stopDeviceLocation()
                }
                applicationState.dismissDiagnostics()
                applicationState.requestHomeSheetState(HomeSheetState.PEEK)
            }
        } finally {
            scenario.close()
        }
    }

    @Test
    fun applicationLaunchesToTheReadyLadderOrTheNeutralKeylessPrompt() {
        // A previous session on this device may have remembered explicit
        // choices; clear them so this case pins the never-chose defaults.
        clearRememberedChoices()
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        Espresso.onView(ViewMatchers.isRoot()).check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        if (hasRuntimeInjectedApiKey()) {
            assertEquals(ReadinessState.READY, applicationState.readinessState)
            assertTrue(
                "the readiness chip must name the gpu renderer with the compiled version",
                applicationState.readinessChipText.startsWith(READY_STATUS_TEXT_PREFIX),
            )
        } else {
            assertTrue("a keyless start registers no provider", applicationState.isProviderKeyless)
            // The registry's credential-less base map serves the map (M24), so
            // the chip carries the ready line; a registry without one shows the
            // neutral keyless prompt instead.
            val registryCarriesKeylessBaseMap = applicationState.baseMapChoices.any { choice ->
                choice.descriptor.rasterUrlTemplate.isNotBlank()
            }
            if (registryCarriesKeylessBaseMap) {
                assertEquals(ReadinessState.READY, applicationState.readinessState)
            } else {
                assertEquals(
                    ReferenceApplicationConstants.KEYLESS_CREDENTIAL_STATUS_TEXT,
                    applicationState.readinessChipText,
                )
            }
        }
        // §3: three-way theme choice with Auto the default on a device that
        // never chose; Auto resolves against the live system scheme.
        assertEquals(ThemeChoice.AUTO, applicationState.themeChoice)
        assertTrue(applicationState.resolvesToDarkTheme(true))
        assertFalse(applicationState.resolvesToDarkTheme(false))
        // §1: the home sheet starts at peek; no planned search and no trip.
        assertEquals(HomeSheetState.PEEK, applicationState.homeSheetState)
        assertFalse(applicationState.isNavigationInTrip)
        assertEquals("", applicationState.navigationPhaseChip)
        // §9: the shared artifact's overlay scenes all start off.
        applicationState.sceneToggleStates.values.forEach { isSceneSelected ->
            assertFalse(isSceneSelected)
        }
        if (hasRuntimeInjectedApiKey()) {
            // A frame really drew on this emulator's software graphics stack —
            // the readiness ladder's honest accounting, not a screenshot.
            awaitOrTimeout(
                timeoutMilliseconds = FIRST_FRAME_DRAWN_TIMEOUT_MILLISECONDS,
                timeoutDescription = "the first drawn frame on the emulator graphics stack",
            ) {
                applicationState.framesDrawnCount > 0
            }
        }
        assertNull("an honest startup reports nothing in the error strip", applicationState.errorReport)
    }

    @Test
    fun theDemoPlanAndSceneChipsDriveThePlannedRouteDemo() {
        Assume.assumeTrue(
            "the recorded-route preview needs the runtime-injected provider key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val initialCameraValues = readApplicationCameraValues(applicationState)

        // The demo-plan chip's own act (§4.1's picker): selecting the clean
        // walk applies the route-preview framing over the recorded trace's
        // route — a live demo of the planned route without any live route
        // provider call (the recorded fixture is the route).
        // The picker's rows and copy come from the shared artifact; the test
        // selects the artifact's own navigation demo row by name.
        val cleanWalkDefinition = applicationState.artifact.demoPlans.first { planDefinition ->
            planDefinition.scenarioName == applicationState.artifact.navigationDemo.traceName
        }
        val cleanWalkPlan = applicationState.demoPlans.firstOrNull { demoPlan ->
            demoPlan.label == cleanWalkDefinition.label
        } ?: error("${cleanWalkDefinition.label} plan missing from the picker")
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.selectDemoPlan(cleanWalkPlan)
        }
        assertEquals(cleanWalkDefinition.label, applicationState.selectedDemoPlan.label)
        assertEquals(
            cleanWalkDefinition.scenarioName,
            applicationState.selectedDemoPlan.scenarioName,
        )
        assertNull("the picker's recorded demo plans are not search-planned routes", applicationState.plannedRoute)
        assertFalse(applicationState.isNavigationInTrip)
        // §5.1's fit contract: the preview's framing is top-down and north up.
        assertEquals(0.0, applicationState.bearingDegrees, CAMERA_READBACK_TOLERANCE_DEGREES)
        assertEquals(0.0, applicationState.pitchDegrees, CAMERA_READBACK_TOLERANCE_DEGREES)
        // The fit actually applied: the preview framing moved the camera
        // values away from the initial demo preset the app starts on.
        assertTrue(
            "the route-preview framing must change the camera values",
            readApplicationCameraValues(applicationState).differsFrom(initialCameraValues),
        )

        // The active plan's route line rides the overlay push (the chip act
        // toggles one shared-artifact scene and the push follows).
        awaitOrTimeout(
            timeoutMilliseconds = OVERLAY_PUSH_SETTLE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the route-line overlay push of the selected plan",
        ) {
            applicationState.pushedOverlayCount == PLANNED_ROUTE_LINE_OVERLAY_COUNT
        }
        driveUserPathOnMainThread { applicationUserState ->
            // The scene chip's own act: the markers chip toggles on, the
            // artifact's markers scene joins the pushed overlay list.
            applicationUserState.sceneToggleStates[MARKERS_SCENE_KEY] = true
        }
        awaitOrTimeout(
            timeoutMilliseconds = OVERLAY_PUSH_SETTLE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the markers scene joining the pushed overlay list",
        ) {
            applicationState.pushedOverlayCount == PLANNED_ROUTE_LINE_OVERLAY_COUNT + SCENE_OVERLAY_COUNT
        }
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.sceneToggleStates[MARKERS_SCENE_KEY] = false
        }
        awaitOrTimeout(
            timeoutMilliseconds = OVERLAY_PUSH_SETTLE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the toggled-off scene leaving the pushed overlay list",
        ) {
            applicationState.pushedOverlayCount == PLANNED_ROUTE_LINE_OVERLAY_COUNT
        }
        assertNull("a scene push reports nothing in the error strip", applicationState.errorReport)
    }

    @Test
    fun theTraceReplayRendersTheRecordingsStepInstructionsAndTheExitRestoresHome() {
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val preTripCameraValues = readApplicationCameraValues(applicationState)
        val selectedPlan = applicationState.selectedDemoPlan
        val recordedStepDisplayTexts = selectedPlan.trace.route.legs
            .flatMap { leg -> leg.steps }
            .map { step -> step.instructionDisplayText }
        assertTrue(
            "the recorded demo trace must carry steps to assert against",
            recordedStepDisplayTexts.isNotEmpty(),
        )

        // The peek primary button's own act (§4.2): the trip replays the
        // artifact trace's recorded fixes through the navigation controller.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.startSimulatedTrip()
        }
        assertFalse(
            "the trip start must not half-start",
            applicationState.tripDriver.startFailure != null,
        )
        awaitOrTimeout(
            timeoutMilliseconds = TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the replay's first instruction delivery",
        ) {
            applicationState.navigationListener.instructionState.value != null
        }

        // §7.1/§7.2: the turn banner renders a recorded step's display text
        // (the exact composed form the banner card renders), the drawer runs
        // the Navigating phase, and the replay's fixes already drive the trip
        // state before the test exits the trip.
        val deliveredInstruction = applicationState.navigationListener.instructionState.value ?: error("no instruction delivered")
        val providerStepText = deliveredInstruction.activeManeuver.instruction.providerDisplayText
            ?: throw AssertionError("the delivered maneuver carried no provider display text")
        // The reducer's replay is provider-text-based: the composed banner
        // prefixes the live distance phrase onto the recording's own text.
        assertTrue(
            "the banner's provider step text must be the recording's text, was '$providerStepText'",
            providerStepText in recordedStepDisplayTexts,
        )
        val renderedBannerText = displayInstructionText(
            instructionText = deliveredInstruction.activeManeuver.instruction,
            roundaboutExitIndex = deliveredInstruction.activeManeuver.roundaboutExitIndex,
        )
        assertTrue(
            "the banner must render the distance-composed step text, was '$renderedBannerText'",
            renderedBannerText.endsWith(providerStepText),
        )
        assertTrue(applicationState.isNavigationInTrip)
        assertEquals(NAVIGATING_PHASE_CHIP_TEXT, applicationState.navigationPhaseChip)
        awaitOrTimeout(
            timeoutMilliseconds = TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the replay's first processed trip state",
        ) {
            applicationState.tripDriver.latestTripState != null
        }

        // The drawer's exit control's own act: the replay stops, the pre-trip
        // camera restores verbatim, the location layer clears, home returns.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.exitSimulatedTrip()
        }
        assertFalse(applicationState.isNavigationInTrip)
        assertFalse(applicationState.tripDriver.isTripActive)
        assertEquals("", applicationState.navigationPhaseChip)
        assertNull(applicationState.latestLocationFix)
        assertEquals(HomeSheetState.PEEK, applicationState.homeSheetState)
        val restoredCameraValues = readApplicationCameraValues(applicationState)
        assertTrue(
            "the exit must restore the pre-trip camera verbatim",
            restoredCameraValues == preTripCameraValues,
        )
        // Arrived must not present after the exit: the phase topic stays reset.
        assertNull(applicationState.navigationListener.phaseChangeState.value)
        assertTrue(
            "the exit must stop the replay short of the arrival phase",
            applicationState.tripDriver.latestTripState?.phase != NavigationPhase.ARRIVED,
        )
    }

    /**
     * The seek path (M27): a route-following trip over a committed demo
     * route's geometry is walked by the contract's shared walker. Seeking to
     * the route's end presents the walker's own arrival, and seeking back
     * leaves it while the paused trip stays paused at the new position.
     */
    @Test
    fun seekingToTheEndArrivesAndSeekingBackLeavesTheArrival() {
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val demoRoute = applicationState.selectedDemoPlan.trace.route
        // The route-following source: the same walker a search-planned trip
        // uses, over committed geometry, so the run needs no provider.
        driveUserPathOnMainThread { userPathState ->
            userPathState.tripDriver.startTrip(
                CoroutineScope(Dispatchers.Main),
                SimulatedTrace.fromRouteData(demoRoute, "seek-assertion"),
            )
        }
        awaitOrTimeout(
            timeoutMilliseconds = TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the route-following walker's seekable range",
        ) {
            applicationState.tripDriver.seekableDistanceMeters > 0.0
        }
        val totalDistanceMeters = applicationState.tripDriver.seekableDistanceMeters

        driveUserPathOnMainThread { userPathState -> userPathState.pauseSimulatedTrip() }
        driveUserPathOnMainThread { userPathState ->
            userPathState.seekSimulatedTrip(totalDistanceMeters)
        }
        awaitOrTimeout(
            timeoutMilliseconds = TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the seek to the route's end presenting the arrival",
        ) {
            applicationState.tripDriver.hasArrived
        }
        assertTrue(
            "a seek to the end must land exactly on the route's total distance",
            kotlin.math.abs(
                applicationState.tripDriver.travelledDistanceMeters - totalDistanceMeters,
            ) <= SEEK_POSITION_TOLERANCE_METERS,
        )

        driveUserPathOnMainThread { userPathState ->
            userPathState.seekSimulatedTrip(totalDistanceMeters / 2)
        }
        awaitOrTimeout(
            timeoutMilliseconds = TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the backwards seek leaving the arrival",
        ) {
            !applicationState.tripDriver.hasArrived
        }
        assertEquals(
            "the backwards seek lands at the requested distance",
            totalDistanceMeters / 2,
            applicationState.tripDriver.travelledDistanceMeters,
            SEEK_POSITION_TOLERANCE_METERS,
        )
        assertTrue(
            "seeking while paused keeps the trip paused",
            applicationState.tripDriver.isTripPaused,
        )
        val heldDistanceMeters = applicationState.tripDriver.travelledDistanceMeters
        Thread.sleep(READINESS_POLL_INTERVAL_MILLISECONDS)
        assertEquals(
            "a paused trip holds the seek's position",
            heldDistanceMeters,
            applicationState.tripDriver.travelledDistanceMeters,
            SEEK_POSITION_TOLERANCE_METERS,
        )
        driveUserPathOnMainThread { userPathState -> userPathState.exitSimulatedTrip() }
    }

    @Test
    fun theLiveSearchAndRouteFlowRunsWhenAKeyIsInjected() {
        Assume.assumeTrue(
            "requires the runtime-injected provider key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        // The plan flow's own user path: type both fields, run the provider
        // search, assign one result per field, then the explicit Plan route
        // action (§4.1: assignment never plans by itself).
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.openPlanSearch()
            applicationUserState.originSearchText = LIVE_ORIGIN_SEARCH_QUERY_TEXT
            applicationUserState.destinationSearchText = LIVE_SEARCH_QUERY_TEXT
            applicationUserState.runPlanSearch(
                ReferenceApplicationState.PlanSearchField.DESTINATION,
            )
        }
        awaitOrTimeout(
            timeoutMilliseconds = LIVE_PROVIDER_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the live provider's geocode results",
        ) {
            applicationState.searchResults.isNotEmpty()
        }
        val firstSearchResult = applicationState.searchResults.first()
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.assignSearchResult(firstSearchResult)
            assertFalse(
                "assignment alone never plans (the explicit Plan route action does)",
                applicationState.plannedRoute != null,
            )
        }
        // The explicit action resolves the unassigned origin text through the
        // provider, then plans the route.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.planRouteFromPlanFields()
        }
        awaitOrTimeout(
            timeoutMilliseconds = LIVE_PROVIDER_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the live provider's planned route",
        ) {
            applicationState.plannedRoute != null
        }
        assertNull("a successful live flow reports nothing in the error strip", applicationState.errorReport)
    }

    @Test
    fun theKeylessPlanFlowSearchesTheArtifactPlacesAndPlansTheRecordedRoute() {
        Assume.assumeFalse(
            "the keyless demo flow needs a credential-less session",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val recordedRoute = applicationState.artifact.demoRoutes.firstOrNull()
            ?: throw AssertionError("the shared artifact carries no recorded demo route")
        // The keyless search filters the artifact's demo places by the typed
        // text and never calls the provider; the rows say they are demo
        // places (§4.1's keyless search).
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.openPlanSearch()
            applicationUserState.originSearchText = recordedRoute.originName
            applicationUserState.runPlanSearch(
                ReferenceApplicationState.PlanSearchField.ORIGIN,
            )
        }
        assertEquals(1, applicationState.searchResults.size)
        assertEquals(recordedRoute.originName, applicationState.searchResults.first().structuredAddressText)
        assertTrue(
            "the keyless result list is the artifact's demo places",
            applicationState.searchResultsAreDemoPlaces,
        )
        assertNull(applicationState.demoSearchNoMatchText)
        val originSearchResult = applicationState.searchResults.first()
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.assignSearchResult(originSearchResult)
            applicationUserState.destinationSearchText = recordedRoute.destinationName
            applicationUserState.runPlanSearch(
                ReferenceApplicationState.PlanSearchField.DESTINATION,
            )
        }
        assertEquals(1, applicationState.searchResults.size)
        assertEquals(
            recordedRoute.destinationName,
            applicationState.searchResults.first().structuredAddressText,
        )
        val destinationSearchResult = applicationState.searchResults.first()
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.assignSearchResult(destinationSearchResult)
        }
        assertNull(
            "assignment alone never plans (the explicit Plan route action does)",
            applicationState.plannedRoute,
        )
        // The explicit Plan route action applies the recorded route without a
        // provider call, and the summary names it as the recorded demo route.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.planRouteFromPlanFields()
        }
        awaitOrTimeout(
            timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the keyless recorded-route plan",
        ) {
            applicationState.plannedRoute != null
        }
        val plannedRoute = applicationState.plannedRoute
            ?: throw AssertionError("the keyless plan produced no route")
        assertTrue("the keyless plan is the artifact's recorded route", plannedRoute.isRecordedDemoRoute)
        assertEquals(recordedRoute.route, plannedRoute.route)
        assertNull("a successful keyless flow reports nothing in the error strip", applicationState.errorReport)

        // A pair the artifact does not record refuses with the named reason
        // instead of failing silently (the same place twice has no route).
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.destinationSearchText = recordedRoute.originName
            applicationUserState.planRouteFromPlanFields()
        }
        awaitOrTimeout(
            timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the missing recorded-route refusal",
        ) {
            applicationState.errorReport?.detailText != null
        }
        assertEquals(
            ReferenceApplicationConstants.NO_RECORDED_ROUTE_HINT_TEMPLATE
                .format(recordedRoute.originName, recordedRoute.originName),
            applicationState.errorReport?.detailText,
        )
    }

    @Test
    fun theApplicationStartsKeylessAndTheOfflineCardStaysHonest() {
        Assume.assumeFalse(
            "the keyless state is asserted only without an injected key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        // §6.5: the app ships and starts keyless — no provider is registered
        // from a build-time credential, and the dock says what to do next in
        // neutral product language rather than reporting a renderer failure.
        assertTrue(
            "a keyless start must register no provider",
            applicationState.appliedProviderKeys.isEmpty(),
        )
        assertEquals(
            ReferenceApplicationConstants.KEYLESS_CREDENTIAL_STATUS_TEXT,
            applicationState.credentialStatusLineText,
        )
        // The offline card stays honest: the tile cache registers only after a
        // credential application, so it is simply not registered yet.
        assertNull(applicationState.tileCacheRegisteredPath)
        // A credential-less base map serves uncached, and the card says so
        // (M24); with no base map at all there is nothing to explain.
        val registryCarriesKeylessBaseMap = applicationState.baseMapChoices.any { choice ->
            choice.descriptor.rasterUrlTemplate.isNotBlank()
        }
        if (registryCarriesKeylessBaseMap) {
            assertEquals(
                ReferenceApplicationConstants.BASE_MAP_UNCACHED_NOTE_TEXT,
                applicationState.tileCacheFailureReason,
            )
        } else {
            assertNull(applicationState.tileCacheFailureReason)
        }
        if (registryCarriesKeylessBaseMap) {
            // A credential-less base map serves uncached; the card says that
            // rather than claiming no cache exists for no reason.
            assertEquals(
                ReferenceApplicationConstants.BASE_MAP_UNCACHED_NOTE_TEXT,
                applicationState.offlineCacheStateText,
            )
        } else {
            assertEquals(
                ReferenceApplicationConstants.OFFLINE_MAPS_NOT_REGISTERED_TEXT,
                applicationState.offlineCacheStateText,
            )
            // Without a provider no surface attaches and no frame draws: the
            // tile line states that honestly instead of inventing counts.
            assertEquals(
                ReferenceApplicationConstants.OFFLINE_TILES_PENDING_TEXT,
                applicationState.offlineLiveTileLineText,
            )
        }
        // The gear's own user path opens the settings surface, whose rows are
        // the shared provider registry's descriptors.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.openSettings()
        }
        assertTrue("the gear must open the settings surface", applicationState.isSettingsOpen)
        assertTrue(
            "the settings rows must come from the shared provider registry's descriptors",
            applicationState.providerCredentialDescriptors.any { descriptor ->
                descriptor.isRegistrationAvailableOnAndroid
            },
        )
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.closeSettings()
        }
        assertFalse(applicationState.isSettingsOpen)
        assertNull("a keyless start reports nothing in the error strip", applicationState.errorReport)
    }

    /**
     * The keyed counterpart of the keyless startup: a runtime-injected
     * credential registers the provider over the demo's disk tile cache, and
     * the keyless-base startup must not replace that registration (which
     * silently dropped the cache before the round-43 guard).
     */
    @Test
    fun theKeyedStartKeepsItsProviderRegistrationAndTileCache() {
        Assume.assumeTrue(
            "the keyed registration is asserted only with an injected key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        assertTrue(
            "a keyed start must register the injected provider",
            applicationState.appliedProviderKeys.isNotEmpty(),
        )
        assertNotNull(
            "the credential's registration must install the disk tile cache",
            applicationState.tileCacheRegisteredPath,
        )
        assertNull(
            "a keyed start must not report the keyless uncached note",
            applicationState.tileCacheFailureReason,
        )
        assertNull("a keyed start reports nothing in the error strip", applicationState.errorReport)
    }

    /**
     * The keyless start opens on the registry's declared styled vector base
     * (owner ruling 2026-10-31, PRD §6 item 18): the credential-less raster
     * source still registers so the surface attaches, and the declared style
     * is installed over it before the first draw. The declaration is read from
     * the shared registry, never hardcoded.
     */
    @Test
    fun theKeylessStartOpensOnTheRegistrysDeclaredStyledBase() {
        Assume.assumeFalse(
            "the keyless start is asserted only without an injected key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val keylessChoice = applicationState.keylessVectorBaseChoice
        Assume.assumeTrue(
            "the shared registry must declare a keyless styled base",
            keylessChoice != null,
        )
        if (keylessChoice == null) {
            return
        }
        awaitOrTimeout(
            timeoutMilliseconds = VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the keyless styled base's SDK status to report it serving",
        ) {
            applicationState.activeVectorBase?.choiceKey == keylessChoice.choiceKey
        }
        assertEquals(
            "a keyless start must install the registry's declared styled base",
            keylessChoice.choiceKey,
            applicationState.activeVectorBase?.choiceKey,
        )
        assertEquals(
            "the attribution must be the styled base's own design line",
            keylessChoice.attributionText,
            applicationState.attributionText,
        )
        assertNull(
            "the keyless default styled base reports nothing in the error strip",
            applicationState.errorReport,
        )
    }

    /**
     * The offline card's route control (§2.5 `offline.plan_route_action`): the
     * bundled recorded test graph answers the demo request over the contract's
     * `offlineRouteFromArchiveBytes` free function, and the result is a real
     * planned route with its own distance and duration. No provider credential
     * is involved, so the test runs keyless.
     */
    @Test
    fun theOfflineCardPlansARouteFromTheBundledTestGraph() {
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.planOfflineRouteFromArchive()
        }
        awaitOrTimeout(
            timeoutMilliseconds = OFFLINE_ROUTE_PLAN_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the offline archive route plan",
        ) {
            applicationState.plannedRoute != null || applicationState.errorReport != null
        }
        assertNull(
            "the bundled archive must plan without an error report, was " +
                "${applicationState.errorReport?.variantLabel}/${applicationState.errorReport?.detailText}",
            applicationState.errorReport,
        )
        val plannedRoute = applicationState.plannedRoute
            ?: throw AssertionError("the offline control produced no planned route")
        assertTrue(
            "the planned route must be the offline archive's answer",
            plannedRoute.isOfflineArchiveRoute,
        )
        assertFalse(
            "the offline archive route is not the artifact's recorded demo route",
            plannedRoute.isRecordedDemoRoute,
        )
        assertTrue(
            "the offline route must carry its distance, was ${plannedRoute.route.distanceMeters}",
            plannedRoute.route.distanceMeters > 0.0,
        )
        assertTrue(
            "the offline route must carry its duration, was ${plannedRoute.route.durationSeconds}",
            plannedRoute.route.durationSeconds > 0.0,
        )
        assertEquals(
            ReferenceApplicationConstants.OFFLINE_ROUTE_TITLE_TEXT,
            plannedRoute.nameText,
        )
    }

    @Test
    fun theDragPanMovesTheMapContentWithThePointer() {
        Assume.assumeTrue(
            "the pan needs a drawn surface, so it needs the runtime-injected key",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        // The pan's user-path method unprojects through the drawn camera,
        // so the first drawn frame must have settled first.
        awaitOrTimeout(
            timeoutMilliseconds = FIRST_FRAME_DRAWN_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the first drawn frame before the pan",
        ) {
            applicationState.framesDrawnCount > 0
        }
        val prePanCameraValues = readApplicationCameraValues(applicationState)

        // The pan gestures' own user-path method (§5.2's drag-pan): a
        // rightward drag must move the content right — the camera center
        // wests, so the longitude drops — and the ground point under the
        // pointer sticks to it, so the latitude barely moves. The launch
        // camera is top-down and north up (the artifact's fixture-center
        // preset), so screen east is longitude east throughout.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.panByPixels(PAN_DRAG_RIGHTWARD_PIXELS, 0.0)
        }
        val cameraAfterRightwardPan = readApplicationCameraValues(applicationState)
        assertTrue(
            "a rightward drag must move the content right (the camera center wests), " +
                "was ${cameraAfterRightwardPan.centerLongitudeDegrees}",
            cameraAfterRightwardPan.centerLongitudeDegrees <
                prePanCameraValues.centerLongitudeDegrees - PAN_MOVE_DEGREES_MINIMUM,
        )
        assertEquals(
            "a pure-rightward drag must not move the camera center north or south",
            prePanCameraValues.centerLatitudeDegrees,
            cameraAfterRightwardPan.centerLatitudeDegrees,
            PAN_STANDSTILL_TOLERANCE_DEGREES,
        )

        // The vertical axis: a downward drag moves the content down — the
        // camera center norths, so the latitude rises — with the longitude
        // barely moving.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.panByPixels(0.0, PAN_DRAG_DOWNWARD_PIXELS)
        }
        val cameraAfterDownwardPan = readApplicationCameraValues(applicationState)
        assertTrue(
            "a downward drag must move the content down (the camera center norths), " +
                "was ${cameraAfterDownwardPan.centerLatitudeDegrees}",
            cameraAfterDownwardPan.centerLatitudeDegrees >
                cameraAfterRightwardPan.centerLatitudeDegrees + PAN_MOVE_DEGREES_MINIMUM,
        )
        assertEquals(
            "a pure-downward drag must not move the camera center east or west",
            cameraAfterRightwardPan.centerLongitudeDegrees,
            cameraAfterDownwardPan.centerLongitudeDegrees,
            PAN_STANDSTILL_TOLERANCE_DEGREES,
        )
    }

    /**
     * The tap contract on the Compose-hosted shipped MapView (§5.2): one
     * confirmed single tap reports exactly one map click and leaves the camera
     * alone, while one double tap zooms exactly the app's one-level step
     * around the tapped point and reports no click of its own (the view's
     * confirmed-single-tap rule). The taps are real pointer events injected at
     * the map's screen point; the suite reads the values the diagnostics
     * sheet renders.
     */
    @Test
    fun aSingleTapReportsOnceAndADoubleTapZoomsExactlyOneLevel() {
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        // The gesture contract is base-agnostic, so the keyless run reads it on
        // the credential-less raster base: the emulator's software renderer
        // draws that layer at a stable rate, whereas the styled vector base's
        // feature count makes the injected pointer events queue behind frames.
        if (!hasRuntimeInjectedApiKey()) {
            val framesDrawnBeforeBaseSelection = applicationState.framesDrawnCount
            val rasterChoice = applicationState.baseMapChoices.firstOrNull { choice ->
                choice.isServable && choice.descriptor.rasterUrlTemplate.isNotBlank()
            }
            Assume.assumeTrue(
                "the shared registry must declare a credential-less raster base",
                rasterChoice != null,
            )
            if (rasterChoice != null) {
                driveUserPathOnMainThread { applicationUserState ->
                    applicationUserState.selectBaseMap(rasterChoice.providerKey)
                }
                awaitOrTimeout(
                    timeoutMilliseconds = FIRST_FRAME_DRAWN_TIMEOUT_MILLISECONDS,
                    timeoutDescription = "a drawn frame on the raster base before the tap gestures",
                ) {
                    applicationState.activeVectorBase == null &&
                        applicationState.framesDrawnCount > framesDrawnBeforeBaseSelection
                }
            }
        }
        // The tap unprojects through the drawn camera and the double tap needs
        // a viewport, so the first frame must have settled. The keyless base
        // map serves it, so this runs without a provider credential.
        awaitOrTimeout(
            timeoutMilliseconds = FIRST_FRAME_DRAWN_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the first drawn frame before the tap gestures",
        ) {
            applicationState.framesDrawnCount > 0
        }
        val initialZoomLevel = applicationState.zoomLevel
        val initialClickCount = applicationState.mapClickCount

        // One tap: exactly one click, no camera move.
        injectMapTaps(tapCount = SINGLE_TAP_COUNT)
        awaitOrTimeout(
            timeoutMilliseconds = TAP_CONFIRMATION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the confirmed single tap's one map click",
        ) {
            applicationState.mapClickCount == initialClickCount + 1
        }
        assertEquals(
            "a single tap must not move the camera",
            initialZoomLevel,
            applicationState.zoomLevel,
            CAMERA_ZOOM_TOLERANCE,
        )

        // A double tap at the same point zooms exactly one level, and its
        // first tap is not also reported as a click.
        injectMapTaps(tapCount = DOUBLE_TAP_COUNT)
        awaitOrTimeout(
            timeoutMilliseconds = TAP_CONFIRMATION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the double tap's one-level zoom",
        ) {
            kotlin.math.abs(
                applicationState.zoomLevel -
                    (initialZoomLevel + ReferenceAppUXDimensions.MAP_CONTROL_ZOOM_STEP),
            ) <= CAMERA_ZOOM_TOLERANCE
        }
        assertEquals(
            "a double tap must zoom exactly the app's one-level step",
            initialZoomLevel + ReferenceAppUXDimensions.MAP_CONTROL_ZOOM_STEP,
            applicationState.zoomLevel,
            CAMERA_ZOOM_TOLERANCE,
        )
        // The confirmed-single-tap window has passed: a late click from the
        // double tap's first touch would have landed by now.
        Thread.sleep(TAP_CONFIRMATION_TIMEOUT_MILLISECONDS)
        assertEquals(
            "one double tap must not also report a map click",
            initialClickCount + SINGLE_TAP_COUNT,
            applicationState.mapClickCount,
        )
        assertNull("the tap gestures report nothing in the error strip", applicationState.errorReport)
    }

    @Test
    fun selectingACommittedVectorStyleServesTheStyledBaseAndStatesTheLabelLimit() {
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val vectorChoice = applicationState.vectorBaseMapChoices.firstOrNull()
        Assume.assumeTrue(
            "the shared registry must offer a vector tileset with committed styles",
            vectorChoice != null,
        )
        if (vectorChoice == null) {
            return
        }
        Assume.assumeTrue(
            "installing a vector base needs the shipped MapView",
            applicationState.mapView != null,
        )
        // The row's user-path act: the SDK validates the source, so a refusal
        // would leave no selection recorded and this test would fail honestly.
        driveUserPathOnMainThread { applicationUserState ->
            applicationUserState.selectVectorBase(vectorChoice.choiceKey)
        }
        // The install can be queued behind an in-flight draw; the SDK's own
        // status readback is the authority on what serves, not the request.
        awaitOrTimeout(
            timeoutMilliseconds = VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the styled vector base's SDK status to report it serving",
        ) {
            applicationState.activeVectorBase?.choiceKey == vectorChoice.choiceKey
        }
        assertEquals(
            "the settings row must name the base the SDK reports serving (error: " +
                "${applicationState.errorReport?.variantLabel}/${applicationState.errorReport?.detailText})",
            vectorChoice.choiceKey,
            applicationState.activeVectorBase?.choiceKey,
        )
        val vectorStatus = applicationState.vectorBaseStatus
        assertEquals(
            "the SDK must report the selected style's source and style id",
            vectorChoice.descriptor.providerKey,
            vectorStatus?.sourceName,
        )
        assertEquals(
            "the SDK must report the selected committed style",
            vectorChoice.style.styleId,
            vectorStatus?.styleId,
        )
        // The drawn base agrees with the row: a frame with the styled vector
        // base requests no raster tiles, because the raster layer is hidden
        // while the vector base serves. Before the fix this stayed at the last
        // raster frame's counts under a row naming the vector style, which is
        // the perception bug this test pins.
        awaitOrTimeout(
            timeoutMilliseconds = VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "a frame drawn with the raster layer hidden under the vector base",
        ) {
            applicationState.latestTileStatistics?.requestedTileCount?.toInt() == 0
        }
        assertEquals(
            "a vector-base frame must request no raster tiles",
            0,
            applicationState.latestTileStatistics?.requestedTileCount?.toInt(),
        )
        assertEquals(
            "a vector-base frame must draw no raster tiles",
            0,
            applicationState.latestTileStatistics?.presentTileCount?.toInt(),
        )
        assertEquals(
            "the attribution must be the active style's own design line",
            vectorChoice.attributionText,
            applicationState.attributionText,
        )
        assertEquals(
            "the base-map section must state the labels limit",
            ReferenceApplicationConstants.BASE_MAP_VECTOR_LABELS_NOTE_TEXT,
            applicationState.vectorBaseLabelsNote,
        )
        // Leave the raster base serving again so the following tests start
        // from the suite's documented idle base map.
        val rasterChoice = applicationState.baseMapChoices.firstOrNull { it.isServable }
        if (rasterChoice != null) {
            driveUserPathOnMainThread { applicationUserState ->
                applicationUserState.selectBaseMap(rasterChoice.providerKey)
            }
            assertNull(
                "a raster selection must remove the vector base",
                applicationState.activeVectorBase,
            )
        }
    }

    /**
     * The explicit choices survive a relaunch: the theme, the base map and
     * the plan fields are restored from the versioned preferences record,
     * and the remembered pair fills the fields without planning a route.
     */
    @Test
    fun rememberedChoicesSurviveActivityRecreation() {
        clearRememberedChoices()
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        val vectorChoice = applicationState.vectorBaseMapChoices.firstOrNull { choice ->
            choice.choiceKey != applicationState.activeVectorBase?.choiceKey
        }
        Assume.assumeTrue(
            "the registry must offer a vector base different from the startup default",
            vectorChoice != null,
        )
        if (vectorChoice == null) {
            return
        }

        driveUserPathOnMainThread { userPathState -> userPathState.cycleThemeChoice() }
        assertEquals(ThemeChoice.LIGHT, applicationState.themeChoice)
        driveUserPathOnMainThread { userPathState ->
            userPathState.selectVectorBase(vectorChoice.choiceKey)
        }
        awaitOrTimeout(
            timeoutMilliseconds = VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the selected vector base to be recorded",
        ) {
            applicationState.selectedVectorBaseChoiceKey == vectorChoice.choiceKey
        }
        driveUserPathOnMainThread { userPathState ->
            userPathState.originSearchText = REMEMBERED_ORIGIN_TEXT
            userPathState.destinationSearchText = REMEMBERED_DESTINATION_TEXT
            userPathState.runPlanSearch(ReferenceApplicationState.PlanSearchField.DESTINATION)
        }
        assertEquals(REMEMBERED_DESTINATION_TEXT, applicationState.lastSearchQueryText)

        val recreatedActivity = recreateApplicationAndAwaitStateConstruction()
        val restoredState = awaitSettledState(recreatedActivity)
        assertEquals(ThemeChoice.LIGHT, restoredState.themeChoice)
        awaitOrTimeout(
            timeoutMilliseconds = VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the remembered vector base to be installed again",
        ) {
            restoredState.selectedVectorBaseChoiceKey == vectorChoice.choiceKey
        }
        assertEquals(REMEMBERED_ORIGIN_TEXT, restoredState.originSearchText)
        assertEquals(REMEMBERED_DESTINATION_TEXT, restoredState.destinationSearchText)
        assertEquals(REMEMBERED_DESTINATION_TEXT, restoredState.lastSearchQueryText)
        assertNull(
            "a remembered plan pair fills the fields but never plans a route",
            restoredState.plannedRoute,
        )
        assertNull("the restore reports nothing in the error strip", restoredState.errorReport)
    }

    /** The reset row clears the record and the next launch returns to defaults. */
    @Test
    fun resetRememberedChoicesClearsTheRecordAndReturnsToDefaults() {
        clearRememberedChoices()
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        driveUserPathOnMainThread { userPathState -> userPathState.cycleThemeChoice() }
        driveUserPathOnMainThread { userPathState ->
            userPathState.originSearchText = REMEMBERED_ORIGIN_TEXT
            userPathState.destinationSearchText = REMEMBERED_DESTINATION_TEXT
        }
        assertNotNull(readRememberedChoices())

        driveUserPathOnMainThread { userPathState -> userPathState.resetRememberedChoices() }
        assertNull("the reset row clears the whole record", readRememberedChoices())
        assertEquals(ThemeChoice.AUTO, applicationState.themeChoice)
        assertEquals("", applicationState.originSearchText)
        assertEquals("", applicationState.destinationSearchText)

        val recreatedActivity = recreateApplicationAndAwaitStateConstruction()
        val restoredState = awaitSettledState(recreatedActivity)
        assertEquals(ThemeChoice.AUTO, restoredState.themeChoice)
        assertEquals("", restoredState.originSearchText)
        assertEquals("", restoredState.destinationSearchText)
        assertNull(restoredState.plannedRoute)
    }

    /**
     * The settings surface fits the viewport at the documented maximum height
     * fraction and scrolls its content column internally.
     */
    @Test
    fun settingsSurfaceFitsTheViewportAndScrollsInternally() {
        clearRememberedChoices()
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        driveUserPathOnMainThread { userPathState -> userPathState.openSettings() }
        awaitOrTimeout(
            timeoutMilliseconds = SETTINGS_MEASUREMENT_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the settings panel's measured layout",
        ) {
            applicationState.settingsViewportHeightPixels > 0 &&
                applicationState.settingsSheetHeightPixels > 0
        }
        val viewportHeightPixels = applicationState.settingsViewportHeightPixels
        val sheetHeightPixels = applicationState.settingsSheetHeightPixels
        val maximumHeightPixels =
            (viewportHeightPixels * ReferenceAppUXDimensions.PANEL_MAXIMUM_HEIGHT_FRACTION).toInt()
        assertTrue(
            "the settings panel must stay inside the viewport, was $sheetHeightPixels of $viewportHeightPixels",
            sheetHeightPixels <= viewportHeightPixels,
        )
        assertTrue(
            "the settings panel must respect the documented height fraction, was " +
                "$sheetHeightPixels of the $maximumHeightPixels cap",
            sheetHeightPixels <= maximumHeightPixels + SETTINGS_HEIGHT_TOLERANCE_PIXELS,
        )
        // When the content overflows, the same column the user scrolls must
        // move under a swipe; when it fits, every section is already reachable.
        if (applicationState.settingsContentMaximumScrollPixels > 0) {
            Espresso.onView(ViewMatchers.isRoot())
                .perform(androidx.test.espresso.action.ViewActions.swipeUp())
            awaitOrTimeout(
                timeoutMilliseconds = SETTINGS_MEASUREMENT_TIMEOUT_MILLISECONDS,
                timeoutDescription = "the settings content's internal scroll",
            ) {
                applicationState.settingsContentScrollOffsetPixels > 0
            }
        }
    }

    // ---------------------------------------------------------------
    // The suite's shared driving helpers
    // ---------------------------------------------------------------

    /** Launches the application and awaits either the state or its failure. */
    @Test
    fun theLocationControlStartsInactiveAndReportsDeniedPermissionHonestly() {
        launchReferenceApplicationAndAwaitStateConstruction()
        applicationScenario?.onActivity { activity ->
            val applicationState = activity.automationApplicationState
            assertNotNull(applicationState)
            applicationState!!.requestHomeSheetState(HomeSheetState.HALF)
            assertFalse(applicationState.isDeviceLocationActive)
            assertNull(applicationState.deviceLocationStatusText)

            // The permission denial the sheet's launcher reports reaches the
            // controller and the status line.
            applicationState.onDeviceLocationPermissionResult(false)
            assertFalse(applicationState.isDeviceLocationActive)
            assertEquals(
                ReferenceApplicationConstants.DEVICE_LOCATION_PERMISSION_DENIED_TEXT,
                applicationState.deviceLocationStatusText,
            )
        }
    }

    @Test
    fun theDeviceNavigationControlRequiresAPlanAndNavigatesThePlannedRoute() {
        // The plan flow below uses the artifact's recorded places; a keyed
        // run would need a live provider to plan the pair.
        Assume.assumeFalse(
            "the device-navigation case plans through the artifact's places",
            hasRuntimeInjectedApiKey(),
        )
        val activity = launchReferenceApplicationAndAwaitStateConstruction()
        val applicationState = awaitSettledState(activity)
        driveUserPathOnMainThread { userPathState ->
            userPathState.requestHomeSheetState(HomeSheetState.HALF)
        }
        assertFalse(applicationState.isDeviceLocationActive)
        assertFalse(applicationState.isDeviceNavigationActive)

        // Without a planned route the control states what it needs and starts
        // nothing.
        driveUserPathOnMainThread { userPathState -> userPathState.startDeviceNavigation() }
        assertFalse(applicationState.isDeviceNavigationActive)
        assertFalse(applicationState.isNavigationInTrip)
        assertEquals(
            ReferenceApplicationConstants.DEVICE_NAVIGATION_PLAN_FIRST_TEXT,
            applicationState.deviceLocationStatusText,
        )

        // Plan the artifact's recorded route through the same keyless flow
        // the plan tests drive.
        val recordedRoute = applicationState.artifact.demoRoutes.firstOrNull()
            ?: throw AssertionError("the shared artifact carries no recorded demo route")
        driveUserPathOnMainThread { userPathState ->
            userPathState.openPlanSearch()
            userPathState.originSearchText = recordedRoute.originName
            userPathState.runPlanSearch(ReferenceApplicationState.PlanSearchField.ORIGIN)
        }
        val originSearchResult = applicationState.searchResults.firstOrNull()
            ?: throw AssertionError("the artifact origin search produced no result")
        driveUserPathOnMainThread { userPathState ->
            userPathState.assignSearchResult(originSearchResult)
            userPathState.destinationSearchText = recordedRoute.destinationName
            userPathState.runPlanSearch(ReferenceApplicationState.PlanSearchField.DESTINATION)
        }
        val destinationSearchResult = applicationState.searchResults.firstOrNull()
            ?: throw AssertionError("the artifact destination search produced no result")
        driveUserPathOnMainThread { userPathState ->
            userPathState.assignSearchResult(destinationSearchResult)
            userPathState.planRouteFromPlanFields()
        }
        awaitOrTimeout(
            timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the keyless recorded-route plan",
        ) {
            applicationState.plannedRoute != null
        }
        assertNull(applicationState.errorReport)

        // The sheet's launcher asks for the runtime permission; grant it here
        // and skip honestly when the emulator has no enabled provider.
        InstrumentationRegistry.getInstrumentation().uiAutomation.grantRuntimePermission(
            ApplicationProvider.getApplicationContext<android.content.Context>().packageName,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
        )
        driveUserPathOnMainThread { userPathState -> userPathState.startDeviceNavigation() }
        Assume.assumeTrue(
            "the SDK location source is available on this emulator",
            applicationState.isDeviceLocationActive,
        )
        assertTrue("the device-driven trip must start", applicationState.isDeviceNavigationActive)
        assertTrue(applicationState.isNavigationInTrip)
        assertTrue(applicationState.tripDriver.isTripActive)
        assertNull(applicationState.tripDriver.startFailure)
        assertEquals(
            "the follow camera takes the fixed deep zoom at trip start",
            ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM,
            applicationState.zoomLevel,
            0.0,
        )

        // Stopping ends the trip and the source this mode started.
        driveUserPathOnMainThread { userPathState -> userPathState.stopDeviceNavigation() }
        assertFalse(applicationState.isDeviceNavigationActive)
        assertFalse(applicationState.isNavigationInTrip)
        assertFalse(applicationState.tripDriver.isTripActive)
        assertFalse(applicationState.isDeviceLocationActive)
        assertEquals(
            ReferenceApplicationConstants.DEVICE_LOCATION_OFF_TEXT,
            applicationState.deviceLocationStatusText,
        )

        // A location source the visitor started by hand stays running when
        // the trip ends.
        driveUserPathOnMainThread { userPathState -> userPathState.startDeviceLocation() }
        Assume.assumeTrue(
            "the SDK location source is available on this emulator",
            applicationState.isDeviceLocationActive,
        )
        driveUserPathOnMainThread { userPathState -> userPathState.startDeviceNavigation() }
        assertTrue(applicationState.isDeviceNavigationActive)
        driveUserPathOnMainThread { userPathState -> userPathState.stopDeviceNavigation() }
        assertFalse(applicationState.isDeviceNavigationActive)
        assertTrue(
            "a hand-started location source keeps running after the trip stops",
            applicationState.isDeviceLocationActive,
        )
        driveUserPathOnMainThread { userPathState -> userPathState.stopDeviceLocation() }
    }

    private fun launchReferenceApplicationAndAwaitStateConstruction(
        clearsRememberedChoices: Boolean = true,
    ): MainActivity {
        if (clearsRememberedChoices) {
            clearRememberedChoices()
        }
        val launchIntent = Intent(
            ApplicationProvider.getApplicationContext<android.content.Context>(),
            MainActivity::class.java,
        )
        runtimeInjectedApiKey()?.let { runtimeCredential ->
            launchIntent.putExtra(
                ReferenceApplicationConstants.RUNTIME_CREDENTIAL_INTENT_EXTRA,
                runtimeCredential,
            )
        }
        runtimeInjectedProviderKey()?.let { runtimeProviderKey ->
            launchIntent.putExtra(
                ReferenceApplicationConstants.RUNTIME_PROVIDER_KEY_INTENT_EXTRA,
                runtimeProviderKey,
            )
        }
        val scenario = ActivityScenario.launch<MainActivity>(launchIntent)
        applicationScenario = scenario
        var launchedActivity: MainActivity? = null
        scenario.onActivity { activity -> launchedActivity = activity }
        val activity = launchedActivity ?: error("the scenario never produced the application activity")
        awaitOrTimeout(
            timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the application state construction",
        ) {
            activity.automationApplicationState != null || activity.automationStartupFailureText != null
        }
        val applicationState = activity.automationApplicationState
        return if (applicationState != null) {
            activity
        } else {
            throw AssertionError(
                "the application never constructed: " +
                    (activity.automationStartupFailureText ?: "unknown startup failure"),
            )
        }
    }

    /** The automation credential from the instrumentation arguments, if any. */
    private fun runtimeInjectedApiKey(): String? =
        InstrumentationRegistry.getArguments()
            .getString(ReferenceApplicationConstants.RUNTIME_CREDENTIAL_INTENT_EXTRA)
            ?.takeIf { it.isNotBlank() }

    /**
     * The optional provider key the automation credential belongs to; absent,
     * the application targets the registry's only Android-available provider.
     */
    private fun runtimeInjectedProviderKey(): String? =
        InstrumentationRegistry.getArguments()
            .getString(ReferenceApplicationConstants.RUNTIME_PROVIDER_KEY_INTENT_EXTRA)
            ?.takeIf { it.isNotBlank() }

    /** Whether this run supplies the runtime-injected provider credential. */
    private fun hasRuntimeInjectedApiKey(): Boolean = runtimeInjectedApiKey() != null

    /**
     * Awaits the first honest settle: the ready ladder when the automation
     * supplied a credential, otherwise the neutral keyless prompt (§6.5).
     */
    private fun awaitSettledState(activity: MainActivity): ReferenceApplicationState {
        val applicationState = activity.automationApplicationState ?: error("no application state constructed")
        if (hasRuntimeInjectedApiKey()) {
            awaitOrTimeout(
                timeoutMilliseconds = EMULATOR_FIRST_READY_TIMEOUT_MILLISECONDS,
                timeoutDescription = "the readiness ladder's ready state on the emulator graphics stack",
            ) {
                applicationState.readinessState != ReadinessState.LOADING
            }
            assertEquals(
                "the readiness ladder settled on the ready state",
                ReadinessState.READY,
                applicationState.readinessState,
            )
        } else {
            // Without a credential the application still opens: the registry's
            // credential-less base map serves the map (M24), so the ladder
            // reaches READY and the chip carries the ready line. The neutral
            // keyless prompt is what a registry with no keyless source shows,
            // and this assertion pins whichever of the two this build's
            // registry implies.
            val registryCarriesKeylessBaseMap = applicationState.baseMapChoices.any { choice ->
                choice.descriptor.rasterUrlTemplate.isNotBlank()
            }
            awaitOrTimeout(
                timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
                timeoutDescription = "the keyless readiness settle",
            ) {
                applicationState.readinessState != ReadinessState.LOADING
            }
            if (registryCarriesKeylessBaseMap) {
                assertEquals(
                    "a keyless base map serves, so the ladder reaches the ready state",
                    ReadinessState.READY,
                    applicationState.readinessState,
                )
            } else {
                assertEquals(
                    ReferenceApplicationConstants.KEYLESS_CREDENTIAL_STATUS_TEXT,
                    applicationState.readinessChipText,
                )
            }
        }
        return applicationState
    }

    /** Drives one user-path act on the main thread (the same thread the screen drives them on). */
    private fun driveUserPathOnMainThread(action: (ReferenceApplicationState) -> Unit) {
        val scenario = applicationScenario ?: error("no application scenario started")
        scenario.onActivity { activity ->
            val applicationState = activity.automationApplicationState ?: return@onActivity
            action(applicationState)
        }
    }

    /** Clears both preference stores the app reads at launch. */
    private fun clearRememberedChoices() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.getSharedPreferences(
            RememberedChoicesStore.PREFERENCES_NAME,
            android.content.Context.MODE_PRIVATE,
        ).edit().clear().commit()
        context.getSharedPreferences(
            ThemeChoiceStore.PREFERENCES_NAME,
            android.content.Context.MODE_PRIVATE,
        ).edit().clear().commit()
    }

    /** Reads the record the running application wrote. */
    private fun readRememberedChoices(): RememberedChoices? =
        RememberedChoicesStore(
            ApplicationProvider.getApplicationContext<android.content.Context>(),
        ).load()

    /**
     * Recreates the activity and awaits its freshly constructed state — the
     * relaunch path the record must survive. The process stays alive, so the
     * only state the new activity can read is what the stores hold.
     */
    private fun recreateApplicationAndAwaitStateConstruction(): MainActivity {
        val scenario = applicationScenario ?: error("no application scenario started")
        scenario.recreate()
        var recreatedActivity: MainActivity? = null
        scenario.onActivity { activity -> recreatedActivity = activity }
        val activity = recreatedActivity
            ?: error("the recreated scenario never produced the application activity")
        awaitOrTimeout(
            timeoutMilliseconds = APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS,
            timeoutDescription = "the recreated application state construction",
        ) {
            activity.automationApplicationState != null ||
                activity.automationStartupFailureText != null
        }
        if (activity.automationApplicationState == null) {
            throw AssertionError(
                "the recreated application never constructed: " +
                    (activity.automationStartupFailureText ?: "unknown startup failure"),
            )
        }
        return activity
    }

    /** Reads the camera values the screen renders (the snapshot-state view). */
    private fun readApplicationCameraValues(applicationState: ReferenceApplicationState): ApplicationCameraValues =
        ApplicationCameraValues(
            centerLatitudeDegrees = applicationState.centerLatitudeDegrees,
            centerLongitudeDegrees = applicationState.centerLongitudeDegrees,
            zoomLevel = applicationState.zoomLevel,
            bearingDegrees = applicationState.bearingDegrees,
            pitchDegrees = applicationState.pitchDegrees,
        )

    /**
     * Polls a state condition on the test thread until it holds or the named
     * timeout elapses. The waits are never screenshot waits: the polled values
     * are the exact ones the screen renders.
     */
    private fun awaitOrTimeout(
        timeoutMilliseconds: Long,
        timeoutDescription: String,
        condition: () -> Boolean,
    ) {
        val deadlineMilliseconds = android.os.SystemClock.elapsedRealtime() + timeoutMilliseconds
        while (!condition()) {
            if (android.os.SystemClock.elapsedRealtime() > deadlineMilliseconds) {
                throw AssertionError("$timeoutDescription did not settle within $timeoutMilliseconds ms")
            }
            Thread.sleep(READINESS_POLL_INTERVAL_MILLISECONDS)
        }
    }

    /**
     * Injects [tapCount] real pointer taps at one point inside the shipped
     * MapView (the Compose host forwards them to the view's own gesture
     * detector). A double tap's two presses sit inside the platform's
     * double-tap window but above its minimum gap, so the view recognizes the
     * gesture rather than two separate clicks.
     */
    private fun injectMapTaps(tapCount: Int) {
        val tapPoint = mapViewScreenPoint()
        val uiAutomation = InstrumentationRegistry.getInstrumentation().uiAutomation
        repeat(tapCount) { tapIndex ->
            val downTime = SystemClock.uptimeMillis()
            injectPointerEvent(
                uiAutomation,
                MotionEvent.obtain(
                    downTime,
                    downTime,
                    MotionEvent.ACTION_DOWN,
                    tapPoint.x,
                    tapPoint.y,
                    0,
                ),
            )
            Thread.sleep(TAP_PRESS_DURATION_MILLISECONDS)
            injectPointerEvent(
                uiAutomation,
                MotionEvent.obtain(
                    downTime,
                    SystemClock.uptimeMillis(),
                    MotionEvent.ACTION_UP,
                    tapPoint.x,
                    tapPoint.y,
                    0,
                ),
            )
            if (tapIndex < tapCount - 1) {
                Thread.sleep(TAP_GAP_MILLISECONDS)
            }
        }
    }

    /** Injects one touchscreen event into the window; a refusal fails the test. */
    private fun injectPointerEvent(
        uiAutomation: android.app.UiAutomation,
        event: MotionEvent,
    ) {
        try {
            event.source = InputDevice.SOURCE_TOUCHSCREEN
            assertTrue("the input system must accept the map tap event", uiAutomation.injectInputEvent(event, true))
        } finally {
            event.recycle()
        }
    }

    /**
     * The screen point the tap gestures use: the middle of the map at 35% of
     * its height, clear of the readiness chip, the compass and the bottom
     * sheet dock.
     */
    private fun mapViewScreenPoint(): PointF {
        var tapPoint: PointF? = null
        Espresso.onView(
            ViewMatchers.isAssignableFrom(com.rusticmaps.sdk.MapView::class.java),
        ).check { view, noViewFoundException ->
            if (noViewFoundException != null) {
                throw noViewFoundException
            }
            val matchedView = view ?: throw AssertionError("the MapView check produced no view")
            val locationOnScreen = IntArray(2)
            matchedView.getLocationOnScreen(locationOnScreen)
            tapPoint = PointF(
                locationOnScreen[0] + matchedView.width * MAP_TAP_HORIZONTAL_FRACTION,
                locationOnScreen[1] + matchedView.height * MAP_TAP_VERTICAL_FRACTION,
            )
        }
        return tapPoint ?: throw AssertionError("the shipped MapView is not in the view hierarchy")
    }

    /** The camera values one comparison covers (the screen renders all five). */
    private data class ApplicationCameraValues(
        val centerLatitudeDegrees: Double,
        val centerLongitudeDegrees: Double,
        val zoomLevel: Double,
        val bearingDegrees: Double,
        val pitchDegrees: Double,
    ) {
        /** Whether any one camera value differs (an applied fit always moves at least one). */
        fun differsFrom(other: ApplicationCameraValues): Boolean =
            centerLatitudeDegrees != other.centerLatitudeDegrees ||
                centerLongitudeDegrees != other.centerLongitudeDegrees ||
                zoomLevel != other.zoomLevel ||
                bearingDegrees != other.bearingDegrees ||
                pitchDegrees != other.pitchDegrees
    }

    private companion object {
        /** The readiness poll's cadence. */
        const val READINESS_POLL_INTERVAL_MILLISECONDS: Long = 250

        /** The keyed live-provider flow's bound (one network round trip each). */
        const val LIVE_PROVIDER_TIMEOUT_MILLISECONDS: Long = 60_000

        /** The live search's query (a place the recorded fixtures also cover). */
        const val LIVE_SEARCH_QUERY_TEXT: String = "Sacramento,California"
        // The origin field's live query of the same provider (§4.1's two
        // fields; the fixture router serves both).
        const val LIVE_ORIGIN_SEARCH_QUERY_TEXT: String = "Sacramento,California"

        /** The application state construction's bound (the facade construction is synchronous). */
        const val APPLICATION_STATE_CONSTRUCTION_TIMEOUT_MILLISECONDS: Long = 30_000

        /**
         * The readiness ladder's settle bound on the emulator's software
         * graphics stack (the SwiftShader-over-ANGLE first accepted surface
         * frame is slower than hardware, minutes-scaled).
         */
        const val EMULATOR_FIRST_READY_TIMEOUT_MILLISECONDS: Long = 120_000

        /** The first drawn frame's bound (the ladder's ready can precede it). */
        const val FIRST_FRAME_DRAWN_TIMEOUT_MILLISECONDS: Long = 120_000

        /**
         * The styled vector base's serve bound: the SDK installs the source on
         * the next pump tick and the first vector frame fetches its visible
         * tiles, so this is bounded like a first frame (the emulator's software
         * graphics stack plus live vector tiles).
         */
        const val VECTOR_BASE_SERVE_TIMEOUT_MILLISECONDS: Long = 120_000

        /** The replay's first instruction/fix delivery bound. */
        const val TRIP_FIRST_INSTRUCTION_TIMEOUT_MILLISECONDS: Long = 10_000

        /** One overlay push's settle bound after a chip act. */
        const val OVERLAY_PUSH_SETTLE_TIMEOUT_MILLISECONDS: Long = 5_000

        /** The offline archive route plan's bound (the archive is 552 bytes). */
        const val OFFLINE_ROUTE_PLAN_TIMEOUT_MILLISECONDS: Long = 30_000

        /** The route line's own overlay slot in the pushed overlay list. */
        const val PLANNED_ROUTE_LINE_OVERLAY_COUNT: Int = 1

        /** One toggled scene contributes one overlay descriptor. */
        const val SCENE_OVERLAY_COUNT: Int = 1

        /** The remembered plan pair the persistence cases type. */
        const val REMEMBERED_ORIGIN_TEXT: String = "Capitol Park"
        const val REMEMBERED_DESTINATION_TEXT: String = "Tower Bridge"

        /** The settings measurement's settle bound. */
        const val SETTINGS_MEASUREMENT_TIMEOUT_MILLISECONDS: Long = 30_000

        /** One pixel of rounding slack on the settings height cap. */
        const val SETTINGS_HEIGHT_TOLERANCE_PIXELS: Int = 1

        /** The seek assertion's tolerance on the requested distance, in meters. */
        const val SEEK_POSITION_TOLERANCE_METERS: Double = 1.0

        /** The camera read-back tolerance of the fit contract's zeroed values. */
        const val CAMERA_READBACK_TOLERANCE_DEGREES: Double = 0.0

        /** The markers scene's key in the shared artifact's overlay scenes. */
        const val MARKERS_SCENE_KEY: String = "markers"

        /** The rendered Navigating phase chip (ReferenceApplicationState's label). */
        const val NAVIGATING_PHASE_CHIP_TEXT: String = "Navigating"

        /** The offline card's live tile line prefix (§4.1's honest line). */
        const val OFFLINE_TILE_LINE_PREFIX: String = "Tiles: requested "

        /**
         * The readiness status line's ready prefix (the chip itself renders
         * the canonical "Ready"; the status line names the gpu renderer and
         * the compiled version).
         */
        const val READY_STATUS_TEXT_PREFIX: String = "Maps SDK gpu renderer active (version "

        /** The pan direction test's rightward drag (screen pixels). */
        const val PAN_DRAG_RIGHTWARD_PIXELS: Double = 100.0

        /** The pan direction test's downward drag (screen pixels). */
        const val PAN_DRAG_DOWNWARD_PIXELS: Double = 100.0

        /**
         * The pan direction's minimum camera-center move in degrees: a
         * 100-pixel drag at the launch camera's zoom 14 is hundreds of
         * ground meters, far above the readback's float noise.
         */
        const val PAN_MOVE_DEGREES_MINIMUM: Double = 1e-3

        /**
         * The pan direction's standstill tolerance on the untouched axis
         * (the mirrored pixel keeps the Mercator latitude; only projection
         * round-trip noise remains).
         */
        const val PAN_STANDSTILL_TOLERANCE_DEGREES: Double = 1e-6

        /** One tap's press duration (short enough for the tap recognizer). */
        const val TAP_PRESS_DURATION_MILLISECONDS: Long = 50

        /**
         * The gap between a double tap's first release and second press: above
         * the platform's double-tap minimum (40 ms) and well inside its 300 ms
         * window.
         */
        const val TAP_GAP_MILLISECONDS: Long = 80

        /** The confirmed-single-tap window's bound (the platform's 300 ms plus slack). */
        const val TAP_CONFIRMATION_TIMEOUT_MILLISECONDS: Long = 3_000

        /** One tap's count in the single-tap case. */
        const val SINGLE_TAP_COUNT: Int = 1

        /** A double tap is two presses. */
        const val DOUBLE_TAP_COUNT: Int = 2

        /** The camera zoom comparison's tolerance (a double tap is exactly one level). */
        const val CAMERA_ZOOM_TOLERANCE: Double = 1e-6

        /** The map tap point's horizontal fraction of the view (centered). */
        const val MAP_TAP_HORIZONTAL_FRACTION: Float = 0.5f

        /** The map tap point's vertical fraction of the view (clear of the docks). */
        const val MAP_TAP_VERTICAL_FRACTION: Float = 0.35f
    }
}