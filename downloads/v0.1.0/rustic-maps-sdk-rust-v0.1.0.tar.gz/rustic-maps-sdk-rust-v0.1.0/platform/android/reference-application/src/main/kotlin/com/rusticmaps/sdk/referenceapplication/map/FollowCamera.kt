package com.rusticmaps.sdk.referenceapplication.map

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.rusticmaps.sdk.ux.ReferenceAppUXDimensions

/**
 * The navigation follow camera's state machine
 * (docs/ReferenceAppUX.md §5.3, round 10): while a simulated trip is guided
 * the camera holds a fixed deep zoom (`navigation-follow-zoom`, clamped by
 * `navigation-follow-zoom-maximum` toward trip end), centers on the guided
 * fix, and eases its bearing toward a median-smoothed course-over-ground.
 * A user gesture breaks follow immediately; follow stays broken until the
 * my-location control re-engages it (a later fix never snaps the user's
 * panned view back — §5.3's re-center rule); the pre-trip camera is captured
 * at trip start and restored after (the follow camera is the in-trip state,
 * the framing camera the pre-trip preset).
 *
 * Pure values, no SDK object inside it: the reference-application state
 * applies the controller's targets to the camera values (center applies
 * exactly; bearing and the 2D/3D pitch ease in the platform frame pump).
 */
class FollowCameraController(
    /** The median course smoother the target bearing follows (§5.3). */
    private val courseSmoother: CourseMedianSmoother =
        CourseMedianSmoother(COURSE_SMOOTHING_WINDOW_FIXES),
) {
    /** The follow camera's states (§5.3's engage / gesture-break / re-engage). */
    enum class FollowPhase { DISENGAGED, ENGAGED, BROKEN_BY_GESTURE }

    /** The camera values captured at trip start and restored at trip end. */
    data class PreTripCamera(
        val centerLatitudeDegrees: Double,
        val centerLongitudeDegrees: Double,
        val zoomLevel: Double,
        val bearingDegrees: Double,
        val pitchDegrees: Double,
    )

    var phase: FollowPhase by mutableStateOf(FollowPhase.DISENGAGED)
        private set

    /** The captured pre-trip camera, or null outside a trip. */
    var preTripCamera: PreTripCamera? by mutableStateOf(null)
        private set

    /** The follow camera's center target: the guided fix's position. */
    var targetCenterLatitudeDegrees: Double by mutableStateOf(0.0)
        private set
    var targetCenterLongitudeDegrees: Double by mutableStateOf(0.0)
        private set

    /**
     * The follow camera's zoom target: the fixed deep zoom ramped toward the
     * maximum as the remaining trip distance runs out (§5.3's clamp).
     */
    var targetZoomLevel: Double by mutableStateOf(0.0)
        private set

    /**
     * The follow camera's bearing target: the median-smoothed course; null
     * until the first fix with a course report sets it.
     */
    var targetBearingDegrees: Double? by mutableStateOf(null)
        private set

    /**
     * Applies the trip follow camera (§5.3: applied at trip start): captures
     * the pre-trip camera for the later restore, applies the fixed deep zoom
     * immediately, and leaves the center/bearing at their current values
     * until the first location fix retargets them.
     */
    fun engageTrip(
        currentCenterLatitudeDegrees: Double,
        currentCenterLongitudeDegrees: Double,
        currentZoomLevel: Double,
        currentBearingDegrees: Double,
        currentPitchDegrees: Double,
    ) {
        preTripCamera = PreTripCamera(
            centerLatitudeDegrees = currentCenterLatitudeDegrees,
            centerLongitudeDegrees = currentCenterLongitudeDegrees,
            zoomLevel = currentZoomLevel,
            bearingDegrees = currentBearingDegrees,
            pitchDegrees = currentPitchDegrees,
        )
        phase = FollowPhase.ENGAGED
        targetCenterLatitudeDegrees = currentCenterLatitudeDegrees
        targetCenterLongitudeDegrees = currentCenterLongitudeDegrees
        targetZoomLevel = ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM
        // The bearing holds until the first course fix retargets it (§5.3:
        // bearing eases toward the smoothed course, never jumps).
        targetBearingDegrees = null
        courseSmoother.reset()
    }

    /**
     * A user gesture (§5.3: drag/pinch/rotate) breaks follow immediately;
     * the camera keeps the values the user panned to.
     */
    fun breakOnGesture() {
        if (phase == FollowPhase.ENGAGED) {
            phase = FollowPhase.BROKEN_BY_GESTURE
        }
    }

    /**
     * One location fix of the active trip (§5.3): the fix always re-targets
     * center, smoothed bearing and ramped zoom so a re-engagement is current,
     * but a follow broken by a gesture stays broken — only the my-location
     * control re-engages it, so a later fix never snaps the user's panned view
     * back. The trip-end clamp follows the remaining-distance fraction: the
     * zoom ramps from the base value to the maximum as the remaining distance
     * runs out.
     */
    fun onFix(
        latitudeDegrees: Double,
        longitudeDegrees: Double,
        courseHeadingDegrees: Double?,
        remainingDistanceFraction: Double,
    ) {
        if (phase != FollowPhase.BROKEN_BY_GESTURE) {
            phase = FollowPhase.ENGAGED
        }
        targetCenterLatitudeDegrees = latitudeDegrees
        targetCenterLongitudeDegrees = longitudeDegrees
        targetZoomLevel = followZoomTowardTripEnd(remainingDistanceFraction)
        if (courseHeadingDegrees != null) {
            courseSmoother.add(courseHeadingDegrees)
            targetBearingDegrees = courseSmoother.median()
        }
    }

    /**
     * The my-location control's explicit re-engage (§4.2: during a trip it
     * re-engages the follow camera): a broken follow returns to ENGAGED at
     * the current targets (the state re-applies them to the camera values).
     */
    fun reengage() {
        if (phase == FollowPhase.BROKEN_BY_GESTURE) {
            phase = FollowPhase.ENGAGED
        }
    }

    /**
     * Trip end: disengages follow and returns the captured pre-trip camera
     * for the state to restore (null when engageTrip never ran).
     */
    fun restorePreTripCamera(): PreTripCamera? {
        val capturedCamera = preTripCamera
        phase = FollowPhase.DISENGAGED
        preTripCamera = null
        targetBearingDegrees = null
        courseSmoother.reset()
        return capturedCamera
    }

    companion object {
        /**
         * Median smoothing's fix window (§5.3: "median-smoothed
         * course-over-ground over a named constant window of fixes"): five
         * fixes smooth the walk demo's stepwise courses without lagging turns
         * meaningfully at the demo's accelerated cadence.
         */
        const val COURSE_SMOOTHING_WINDOW_FIXES: Int = 5

        /**
         * The follow camera's zoom toward trip end (§5.3): the fixed deep
         * zoom at the trip's start, ramping linearly with the *travelled*
         * fraction to the maximum at arrival — "clamped by
         * `navigation-follow-zoom-maximum` toward trip end".
         */
        fun followZoomTowardTripEnd(remainingDistanceFraction: Double): Double {
            val clampedRemainingFraction = remainingDistanceFraction.coerceIn(0.0, 1.0)
            val travelledFraction = 1.0 - clampedRemainingFraction
            return ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM +
                (ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM_MAXIMUM -
                    ReferenceAppUXDimensions.NAVIGATION_FOLLOW_ZOOM) *
                travelledFraction
        }
    }
}

/**
 * The median-smoothed course-over-ground (§5.3): the circular median of the
 * named constant window of recent fixes. The circular median is the windowed
 * sample that minimizes the sum of great-circle (degree) distances to the
 * rest of the window — an angular median over the full circle; the walk demo
 * keeps directionality mild (§5.3), and real GPS courses carry the same
 * property the smoothing assumes.
 */
class CourseMedianSmoother(private val windowFixCount: Int) {
    private val recentCourseDegrees = ArrayDeque<Double>()

    /** Adds one fix's course-over-ground, dropping the window's oldest. */
    fun add(courseDegreeValue: Double) {
        recentCourseDegrees.addLast(courseDegreeValue)
        while (recentCourseDegrees.size > windowFixCount) {
            recentCourseDegrees.removeFirst()
        }
    }

    /** The circular median, or null with no windowed sample. */
    fun median(): Double? {
        if (recentCourseDegrees.isEmpty()) {
            return null
        }
        val windowedList = recentCourseDegrees.toList()
        return windowedList.minByOrNull { candidateDegrees ->
            windowedList.sumOf { otherDegrees -> angularDistanceDegrees(candidateDegrees, otherDegrees) }
        }
    }

    fun reset() {
        recentCourseDegrees.clear()
    }

    private fun angularDistanceDegrees(firstDegrees: Double, secondDegrees: Double): Double {
        val absoluteDifference = kotlin.math.abs(firstDegrees - secondDegrees) % FULL_CIRCLE_DEGREES
        return if (absoluteDifference > FULL_CIRCLE_DEGREES / 2.0) {
            FULL_CIRCLE_DEGREES - absoluteDifference
        } else {
            absoluteDifference
        }
    }

    private companion object {
        const val FULL_CIRCLE_DEGREES: Double = 360.0
    }
}