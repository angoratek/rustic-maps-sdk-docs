package com.rusticmaps.sdk.referenceapplication.map

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import uniffi.rustic_maps.LogEvent
import uniffi.rustic_maps.SdkLogSeverity

/**
 * Unit tests of the diagnostics pane's bounded window: events coalesce until
 * a publish, the window keeps the newest rows, and Clear empties both the
 * displayed rows and the backlog count. Nothing is collected before the pane
 * subscribes because the listener is only connected on open.
 */
class CollectingDiagnosticEventListenerTest {
    @Test
    fun `events stay pending until the pane publishes them`() {
        val listener = CollectingDiagnosticEventListener()
        listener.onDiagnosticEvent(event("first"))
        assertTrue(listener.eventLines.isEmpty())

        listener.publishPendingEvents()
        assertEquals(listOf("first"), listener.eventLines.map { line -> line.messageLine })
    }

    @Test
    fun `a burst coalesces into one publish`() {
        val listener = CollectingDiagnosticEventListener()
        repeat(12) { index -> listener.onDiagnosticEvent(event("event $index")) }
        listener.publishPendingEvents()
        assertEquals(12, listener.eventLines.size)
        listener.publishPendingEvents()
        assertEquals("a second publish has nothing pending", 12, listener.eventLines.size)
    }

    @Test
    fun `the window keeps the newest events`() {
        val listener = CollectingDiagnosticEventListener(windowEventLimit = 5)
        repeat(9) { index -> listener.onDiagnosticEvent(event("event $index")) }
        listener.publishPendingEvents()
        assertEquals(
            listOf("event 4", "event 5", "event 6", "event 7", "event 8"),
            listener.eventLines.map { line -> line.messageLine },
        )
    }

    @Test
    fun `clear empties the rows and the backlog count`() {
        val listener = CollectingDiagnosticEventListener()
        listener.onDiagnosticEvent(event("first"))
        listener.publishPendingEvents()
        listener.noteBacklogFlushed(3u)

        listener.clear()
        assertTrue(listener.eventLines.isEmpty())
        assertNull(listener.flushedEventCount)
    }

    private fun event(messageLine: String): LogEvent = LogEvent(
        timestampMillisecondsSinceEpoch = 1UL,
        severity = SdkLogSeverity.INFO,
        subsystemTarget = "tile_fetch",
        messageLine = messageLine,
    )
}
