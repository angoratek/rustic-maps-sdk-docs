package com.rusticmaps.sdk.referenceapplication.map

/**
 * Easing primitives of the platform frame pump (docs/ReferenceAppUX.md §5.3:
 * eased camera moves interpolate in the platform's frame pump — no new
 * contract surface). Both helpers are pure: the pump calls the helpers with
 * the Compose frame clock's nanosecond timestamps, and every duration is a
 * named constant of the token table.
 */

/** Smoothstep easing (`3t²−2t³`): eased in, eased out, structural math. */
internal fun smoothstepEasedProgress(linearProgress: Double): Double {
    val clampedProgress = linearProgress.coerceIn(0.0, 1.0)
    return clampedProgress * clampedProgress * (3.0 - 2.0 * clampedProgress)
}

/**
 * The camera bearing's smallest off-north angular distance in degrees (the
 * compass control's visibility-threshold input, §2.4): a bearing's deviation
 * from north wrapped into the shortest direction, always in [0, 180].
 */
internal fun bearingOffNorthDegrees(bearingDegrees: Double): Double {
    val normalizedDegrees = ((bearingDegrees % FULL_CIRCLE_DEGREES) + FULL_CIRCLE_DEGREES) % FULL_CIRCLE_DEGREES
    return if (normalizedDegrees <= HALF_CIRCLE_DEGREES) {
        normalizedDegrees
    } else {
        FULL_CIRCLE_DEGREES - normalizedDegrees
    }
}

private const val FULL_CIRCLE_DEGREES: Double = 360.0
private const val HALF_CIRCLE_DEGREES: Double = 180.0

/**
 * A linear-in-time, smoothstep-eased value move begun with a frame-clock
 * timestamp: the compass's eased "north up" return and the 2D/3D pitch
 * toggle's swing both run as this timed ease over the language's one
 * eased-camera-move duration (§2.4's `compass-renorth-animation` mill value).
 */
class SmoothstepTimedEase {
    private var startFrameNanos: Long = 0
    private var fromValue: Double = 0.0
    private var toValue: Double = 0.0
    private var running: Boolean = false

    /** Begins (or restarts) the ease from `from` to `to` at `startNanos`. */
    fun begin(startNanos: Long, from: Double, to: Double, durationNanos: Long) {
        startFrameNanos = startNanos
        fromValue = from
        toValue = to
        running = true
        this.durationNanos = durationNanos
    }

    private var durationNanos: Long = 0

    /** Whether an ease is in flight. */
    val isRunning: Boolean
        get() = running

    /** The ease's target. */
    val targetValue: Double
        get() = toValue

    /** Stops an in-flight ease without applying anything. */
    fun reset() {
        running = false
    }

    /**
     * Advances the ease at `nowNanos`: the current eased value, then true
     * when the move just finished this call (the caller then stops).
     */
    fun advance(nowNanos: Long): Pair<Double, Boolean> {
        if (!running) {
            return toValue to true
        }
        val elapsedNanos = nowNanos - startFrameNanos
        if (elapsedNanos >= durationNanos) {
            val finalValue = toValue
            running = false
            return finalValue to true
        }
        val easedValue = fromValue + (toValue - fromValue) *
            smoothstepEasedProgress(elapsedNanos.toDouble() / durationNanos.toDouble())
        return easedValue to false
    }
}

/**
 * An exponential chase toward a moving target (the follow camera's bearing
 * toward the median-smoothed course, §5.3): a time-constant chase settles on
 * its own when the target stops moving. The chase value snaps when the
 * remaining distance falls under [SNAP_DISTANCE_DEGREES].
 */
class ExponentialValueChase(private val timeConstantNanos: Double) {
    private var lastFrameNanos: Long? = null

    /**
     * Advances the chase at `nowNanos` toward `target`: the next current
     * value. The first call after a start adopts the target's delta with the
     * real elapsed frame time; frames that report a clock going backwards
     * (a recycled clock) are treated as a first frame.
     */
    fun advance(current: Double, target: Double, nowNanos: Long): Double {
        val lastNanos = lastFrameNanos
        val deltaTimeSeconds = when {
            lastNanos == null -> FIRST_FRAME_TIME_CONSTANT_FALLBACK_NANOS / timeConstantNanos
            nowNanos < lastNanos -> FIRST_FRAME_TIME_CONSTANT_FALLBACK_NANOS / timeConstantNanos
            else -> (nowNanos - lastNanos).toDouble() / timeConstantNanos
        }
        lastFrameNanos = nowNanos
        val deltaDegrees = signedAngularDifferenceDegrees(target, current)
        if (kotlin.math.abs(deltaDegrees) <= SNAP_DISTANCE_DEGREES) {
            return target
        }
        val followFactor = 1.0 - kotlin.math.exp(-deltaTimeSeconds)
        return current + deltaDegrees * followFactor
    }

    fun reset() {
        lastFrameNanos = null
    }

    /**
     * The shortest signed angular difference `to − from` from `from` in
     * degrees, wrapped to (−180, 180].
     */
    fun signedAngularDifferenceDegrees(to: Double, from: Double): Double {
        var difference = (to - from) % FULL_CIRCLE_DEGREES
        if (difference > HALF_CIRCLE_DEGREES) difference -= FULL_CIRCLE_DEGREES
        if (difference < -HALF_CIRCLE_DEGREES) difference += FULL_CIRCLE_DEGREES
        return difference
    }

    private companion object {
        const val FULL_CIRCLE_DEGREES: Double = 360.0
        const val HALF_CIRCLE_DEGREES: Double = 180.0

        /**
         * The first frame of a chase has one frame's worth of catching up:
         * the constant folds one 60 Hz frame's delta into the chase factor.
         * (Structural: one frame at the display cadence the pump runs at.)
         */
        const val FIRST_FRAME_TIME_CONSTANT_FALLBACK_NANOS: Double = 16_666_666.7

        /**
         * The chase snaps to its target under this remaining angular
         * distance (the eased value is visually identical to the target).
         */
        const val SNAP_DISTANCE_DEGREES: Double = 0.05
    }
}