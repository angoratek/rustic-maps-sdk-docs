# The JNI surface-pointer shim compiled into librustic_maps.so exports
# fixed symbols named after this Kotlin object (see
# crates/rustic-maps-native-core/src/android_jni.rs). R8 must keep the class and its
# native declarations exactly as named, or the JVM cannot resolve them.
-keep class com.rusticmaps.sdk.NativeWindowBridge {
    native <methods>;
}
