// Playwright global setup: runs the three pure file-parsing gates once before
// the browser suite starts — the contract-sync test (the frozen UniFFI
// contract's TypeScript/wasm mirror, `tests/contract_sync.mjs`), the
// provider-name guard (`tests/provider_name_guard.mjs`, the M15 allowlist) and
// the platform-parity floor (`tests/platform_parity_gate.mjs`, M31: binding
// paths, the UDL interfaces the apps consume, the wasm capability floor, the
// three-way theme, web accessibility and the registry mirror). None touches a
// server or a browser session, so the suite gains only microseconds.
import { run_contract_sync_checks } from './tests/contract_sync.mjs';
import { run_platform_parity_checks } from './tests/platform_parity_gate.mjs';
import { run_provider_name_guard_checks } from './tests/provider_name_guard.mjs';

export default function run_file_parsing_gates() {
  run_contract_sync_checks();
  run_provider_name_guard_checks();
  run_platform_parity_checks();
}
