/**
 * TypeScript declarations for the SDK's frozen UniFFI contract: the single
 * source of truth for its binding surface. This module re-expresses the
 * camera, routing, navigation, positioning and provider-record shapes for
 * WebAssembly consumers. Every declaration here is maintained by hand, and
 * the contract-sync test asserts that this mirror stays in lockstep with the
 * contract's dictionaries, error variants and WebAssembly export sources.
 *
 * The callable WebAssembly surface itself (the `MapCamera` class and the free
 * functions) is declared by the generated package declarations; the generated
 * declarations type the record-shaped results below only generically
 * (`object`, `Array<any>`), so a consumer imports the named interfaces from
 * here to type-check the runtime values.
 *
 * The module covers the camera and projection surface — the `MapCamera`
 * members including the gesture algebra (`panByScreenPixels`,
 * `zoomByLevelsAroundScreenPoint`, `rotateByDegreesAroundScreenPoint`, whose
 * pose results use the same
 * `latitude`/`longitude`/`zoomLevel`/`bearingDegrees`/`pitchDegrees` field
 * names) — plus the simulated-trip records of the contract's `RouteSimulator`
 * and the route records (`Route`, `RouteLeg`, `RouteStep`) the offline
 * routing surface answers, plus the live place rows the geocoding and search
 * calls answer, plus the distance-matrix and traffic rows. The rest of the
 * contract's async provider surface (`MapSdk`, cache terms) is outside this
 * mirror.
 *
 * The live-navigation records are mirrored too: the snapshot the wasm
 * `Navigator`'s `currentTripState`/`updateLocation` methods answer
 * (`NavigatorTripState` and its parts) and the location update it consumes
 * (`NavigatorLocationUpdate`). The class itself is declared by the generated
 * package declarations; these interfaces type the plain objects it exchanges.
 *
 * Field names match the JavaScript objects the surface passes and returns:
 * snake-case contract fields become lower camel case (`tile_x` becomes
 * `tileX`), so these interfaces type-check the runtime values directly.
 * Record-shaped parameters are flattened into scalar parameters at the seam
 * (for example `BoundingBox` as its two corner coordinates) and are declared
 * anyway as the contract's value shapes, because the contract's record-based
 * constructors (the `fit_bounds` constructor) consume them verbatim.
 */

/**
 * A position on the WGS 84 ellipsoid in decimal degrees.
 */
export interface GeographicCoordinate {
    /** Latitude in decimal degrees, valid within `[-90, 90]`. */
    readonly latitude: number;
    /** Longitude in decimal degrees, valid within `[-180, 180]`. */
    readonly longitude: number;
}

/**
 * Rectangular area between a south-west and a north-east corner; boxes never
 * span the antimeridian.
 */
export interface BoundingBox {
    /** South-west corner (minimum latitude and longitude). */
    readonly southWest: GeographicCoordinate;
    /** North-east corner (maximum latitude and longitude). */
    readonly northEast: GeographicCoordinate;
}

/**
 * Pace chosen by the application for a simulated trip. The SDK carries no
 * default pace; both values must be finite and strictly positive, and their
 * product must stay finite. Mirrors the contract's `SimulatedTripPace`
 * dictionary.
 */
export interface SimulatedTripPace {
    /** Baseline travel speed in meters per second. */
    readonly speedMetersPerSecond: number;
    /** Multiplier applied to the baseline speed (for example 1, 2, 4, 8). */
    readonly speedMultiplier: number;
}

/**
 * One position of a simulated trip along the planned route's own polyline.
 * Mirrors the contract's `SimulatedTripFix` dictionary; the wasm
 * `RouteSimulator`'s `fixAtTravelledMeters`/`fixAtElapsedSeconds` answer
 * exactly this shape.
 */
export interface SimulatedTripFix {
    /** Position on the planned route's geometry. */
    readonly coordinate: GeographicCoordinate;
    /** Direction of travel along the active segment, in degrees clockwise
     * from true north, or `null` when the route has no segment. */
    readonly courseHeadingDegrees: number | null;
    /** Distance travelled from the route start, in meters. */
    readonly travelledMeters: number;
    /** Distance left to the route end, in meters. */
    readonly remainingMeters: number;
    /** Simulated elapsed time from the trip start, in seconds. */
    readonly elapsedSeconds: number;
    /** True exactly when the fix sits at the route's final coordinate. */
    readonly isArrived: boolean;
}

/**
 * One maneuver within a route leg. Mirrors the UDL `RouteStep` dictionary:
 * the offline archive route (`offlineRouteFromArchiveBytes`) and the live
 * route call answer this shape, and the maneuver classification rides as
 * the contract's stable snake-case `maneuverType` label.
 */
export interface RouteStep {
    /** Distance of this step in meters. */
    readonly distanceMeters: number;
    /** Travel time of this step in seconds. */
    readonly durationSeconds: number;
    /** Maneuver classification as a stable snake-case text label. */
    readonly maneuverType: string;
    /** Human-readable instruction in the display language. */
    readonly instructionDisplayText: string;
    /** Instruction tuned for text-to-speech engines. */
    readonly instructionSpeechText: string;
    /** Step geometry from the previous step end to this maneuver point. */
    readonly shape: GeographicCoordinate[];
}

/**
 * Leg between two consecutive waypoints. Mirrors the UDL `RouteLeg`
 * dictionary.
 */
export interface RouteLeg {
    /** Leg distance in meters. */
    readonly distanceMeters: number;
    /** Leg travel time in seconds. */
    readonly durationSeconds: number;
    /** Maneuver steps in traversal order. */
    readonly steps: RouteStep[];
}

/**
 * A complete calculated route. Mirrors the UDL `Route` dictionary; the
 * offline archive seam answers exactly this shape.
 */
export interface Route {
    /** Total distance across all legs, in meters. */
    readonly distanceMeters: number;
    /** Total travel time across all legs, in seconds. */
    readonly durationSeconds: number;
    /** Geographic bounds of the full route geometry. */
    readonly boundingBox: BoundingBox;
    /** Legs, one per consecutive waypoint pair. */
    readonly legs: RouteLeg[];
}

/**
 * One position fix handed to the wasm `Navigator`'s `updateLocation`. Mirrors
 * the UDL `NavigationLocationUpdate` dictionary field for field: the raw
 * position before route snapping, the horizontal-accuracy radius, the course
 * heading and the fix instant, each nullable when the source does not report
 * it. Fixes without an accuracy report never trigger a step advance and are
 * never judged by the deviation detector.
 */
export interface NavigatorLocationUpdate {
    /** Raw position on the WGS 84 ellipsoid, before route snapping. */
    readonly coordinate: GeographicCoordinate;
    /** Radius, in meters, of the 68% horizontal-accuracy envelope, or `null`
     * when the source does not report accuracy. */
    readonly horizontalAccuracyMeters: number | null;
    /** Direction of travel in degrees clockwise from true north, or `null`
     * when the source does not report a course. */
    readonly courseHeadingDegrees: number | null;
    /** Fix instant in seconds since the Unix epoch, or `null` for untimed
     * sources. */
    readonly timestampSeconds: number | null;
}

/**
 * The active deviation of a trip snapshot. Mirrors the UDL
 * `DeviationStatusChange` shape where the snapshot flattens it: the snapshot
 * is `null` on route, so a present deviation always reports the `OffRoute`
 * status kind, and the measured distance replaces the nested deviation-info
 * record. The contract's wrong-step grade (which leaves the phase
 * `Navigating`) is guidance feedback and is not surfaced here.
 */
export interface NavigatorDeviation {
    /** Which form the status update takes (the contract's enum spelling). */
    readonly statusChangeKind: "OffRoute" | "OnRoute";
    /** Distance, in meters, from the raw fix to the remaining route line. */
    readonly distanceFromRouteMeters: number;
}

/**
 * The composed turn-by-turn instruction payload of a trip snapshot, mirroring
 * the UDL `NavigationInstruction` record: the active maneuver's two banner
 * lines, the following maneuver when the route has one, progress along the
 * remaining trip, and the arrival/rerouting markers.
 */
export interface NavigatorInstruction {
    /** The banner maneuver currently being traversed. */
    readonly activeManeuver: {
        /** Canonical distance phrase text (for example `"130 meters"`, or
         * `"now"` when the maneuver is immediate). */
        readonly distancePhraseText: string;
        /** Composed instruction text: the live distance prefix plus the
         * provider-authored display text. */
        readonly displayText: string;
        /** Provider-authored banner text, verbatim, or `null` when the
         * provider authored none. The native cards show this beside the
         * separately phrased distance; `displayText` repeats the distance
         * inside the sentence. */
        readonly providerDisplayText: string | null;
        /** The text-to-speech variant (the speech text with the same distance
         * prefix); empty when the provider authored no text. */
        readonly speechText: string;
    };
    /** The maneuver after the active one, or `null` on the final step and
     * after arrival. */
    readonly upcomingManeuver: {
        /** Composed instruction text of the following step. */
        readonly displayText: string;
        /** The text-to-speech variant of the following step. */
        readonly speechText: string;
    } | null;
    /** Progress along the remaining trip. */
    readonly progress: {
        /** Distance, in meters, to the end of the current step (the next
         * maneuver point). */
        readonly distanceToNextManeuverMeters: number;
        /** Total remaining distance, in meters. */
        readonly distanceRemainingMeters: number;
        /** Total remaining travel time, in seconds. */
        readonly durationRemainingSeconds: number;
    };
    /** True exactly while the trip has arrived with zero remaining progress. */
    readonly isArrival: boolean;
    /** True exactly while the trip is off route: the instruction must not be
     * presented as current guidance. */
    readonly isReroutingRequired: boolean;
}

/**
 * The trip snapshot the wasm `Navigator`'s `currentTripState()` and
 * `updateLocation()` methods answer, projecting the UDL
 * `TripNavigationState`/`NavigationInstruction` pair into the fields the
 * browser turn-by-turn card consumes.
 */
export interface NavigatorTripState {
    /** High-level trip phase: `"navigating"`, `"offRoute"` or `"arrived"`
     * (the contract's `Navigating`/`OffRoute`/`Arrived`). */
    readonly phase: "navigating" | "offRoute" | "arrived";
    /** The composed instruction payload of the current state. */
    readonly instruction: NavigatorInstruction;
    /** The active deviation, or `null` while the trip is on route. */
    readonly deviation: NavigatorDeviation | null;
    /** Position snapped onto the current step, or `null` until the first
     * location update has been processed. */
    readonly snappedCoordinate: GeographicCoordinate | null;
    /** True exactly while the trip has arrived. */
    readonly isArrived: boolean;
    /** Traversal-ordered index of the step currently traversed. */
    readonly currentStepIndex: number;
}

/**
 * Position on the viewport in physical pixels (origin top-left, `y` down).
 */
export interface ScreenPoint {
    /** Horizontal position in pixels. */
    readonly x: number;
    /** Vertical position in pixels. */
    readonly y: number;
}

/**
 * A world position in normalized world coordinates, both axes within
 * `[0, 1]`.
 */
export interface NormalizedWorldCoordinate {
    /** Eastward position from the antimeridian. */
    readonly x: number;
    /** Southward position from the north pole. */
    readonly y: number;
}

/**
 * One web-mercator XYZ tile address.
 */
export interface TileKey {
    /** Tile column, in `0..2^zoom_level`. */
    readonly tileX: number;
    /** Tile row, counted from the north, in `0..2^zoom_level`. */
    readonly tileY: number;
    /** Zoom level this tile belongs to. */
    readonly zoomLevel: number;
}

/**
 * Viewport dimensions in physical pixels.
 */
export interface ViewportSize {
    /** Horizontal extent in pixels. */
    readonly widthPixels: number;
    /** Vertical extent in pixels. */
    readonly heightPixels: number;
}

/**
 * Screen-space insets kept clear of map content: distances from each viewport
 * edge in pixels, so UI overlays — route cards, attribution, sheet panels —
 * never cover the content the camera guarantees visible.
 */
export interface EdgeInsets {
    /** Pixels kept clear from the left viewport edge. */
    readonly left: number;
    /** Pixels kept clear from the top viewport edge. */
    readonly top: number;
    /** Pixels kept clear from the right viewport edge. */
    readonly right: number;
    /** Pixels kept clear from the bottom viewport edge. */
    readonly bottom: number;
}

/**
 * Failures the contract throws across the binding surface, mirroring the
 * contract's `SdkError` variants one to one with their payload fields.
 *
 * On the WebAssembly surface a failure is thrown as a JavaScript `Error`
 * whose `message` is the verbatim detail and whose `code` is a stable
 * lower-camel identifier. The code is the matching contract variant name, or
 * one of the documented seam-level codes below when the contract has no
 * matching variant. The error's `name` is empty, so `String(error)` yields the
 * message alone and message comparisons keep working. Branch on
 * `error.code`, not on message text.
 *
 * Contract codes: `invalidCoordinateInput`, `networkRequestFailed`,
 * `responseParsingFailure`, `providerRequestRejected`, `rateLimitExhausted`,
 * `providerNotConfigured`, `invalidNavigationInput`, `invalidRenderInput`,
 * `renderingSurfaceUnavailable`, `cacheOperationFailure`,
 * `offlineRoutingFailure`.
 *
 * Seam-level codes: `invalidArgument` (a malformed argument, an unknown
 * address or a lifecycle misuse), `unsupportedCapability`,
 * `geometryUnavailable` (no screen-to-ground or ground-to-screen transform
 * exists), `runtimeUnavailable`, and `internal`.
 *
 * The discriminated union below is the structured contract shape the native
 * surfaces receive.
 */
export type SdkError =
    | { readonly variant: "InvalidCoordinateInput"; readonly detail: string }
    | { readonly variant: "NetworkRequestFailed"; readonly detail: string }
    | { readonly variant: "ResponseParsingFailure"; readonly detail: string }
    | { readonly variant: "ProviderRequestRejected"; readonly detail: string }
    | { readonly variant: "RateLimitExhausted" }
    | { readonly variant: "ProviderNotConfigured"; readonly contractName: string }
    | { readonly variant: "InvalidNavigationInput"; readonly detail: string }
    | { readonly variant: "InvalidRenderInput"; readonly detail: string }
    | { readonly variant: "RenderingSurfaceUnavailable"; readonly detail: string }
    | { readonly variant: "CacheOperationFailure"; readonly detail: string }
    | { readonly variant: "OfflineRoutingFailure"; readonly detail: string };

/**
 * Stable codes carried by a failure thrown from the WebAssembly surface
 * (`error.code`). The first eleven are the contract's `SdkError` variants in
 * lower camel case; the remaining five are seam-level categories the contract
 * does not model.
 */
export type SdkErrorCode =
    | "invalidCoordinateInput"
    | "networkRequestFailed"
    | "responseParsingFailure"
    | "providerRequestRejected"
    | "rateLimitExhausted"
    | "providerNotConfigured"
    | "invalidNavigationInput"
    | "invalidRenderInput"
    | "renderingSurfaceUnavailable"
    | "cacheOperationFailure"
    | "offlineRoutingFailure"
    | "invalidArgument"
    | "unsupportedCapability"
    | "geometryUnavailable"
    | "runtimeUnavailable"
    | "internal";

/**
 * Which overlay shape one descriptor configures. The values are the wasm
 * canvas' plain-object `kind` strings (`MapView::setOverlays` accepts
 * exactly these); the UDL `enum MapOverlayKind` variants carry the CamelCase
 * spellings (`RoutePolyline`, `FilledPolygon`, `PointMarkers`,
 * `TrafficFlow`, `PointPins`), which Kotlin's generated bindings keep and
 * Swift's camel lowering reproduces as these strings.
 */
export type MapOverlayKind =
    | "routePolyline"
    | "filledPolygon"
    | "pointMarkers"
    | "trafficFlow"
    | "pointPins";

/**
 * Solid RGBA overlay style, every channel in `[0, 1]`. Mirrors the contract's
 * `OverlayColor` dictionary and the wasm canvas' `color` plain object. A
 * descriptor without a color keeps the documented rustic-maps-rendering default style
 * of its kind; every present channel must lie in the range or the whole call
 * refuses.
 */
export interface OverlayColor {
    /** Red channel in `[0, 1]`. */
    readonly red: number;
    /** Green channel in `[0, 1]`. */
    readonly green: number;
    /** Blue channel in `[0, 1]`. */
    readonly blue: number;
    /** Alpha channel in `[0, 1]` (the overlay pipeline alpha-blends). */
    readonly alpha: number;
}

/**
 * One overlay shape drawn over the map surface's tiles in every frame,
 * selected by `kind`. Each kind reads exactly its own payload fields and
 * ignores the others; a kind-required payload must be present, and style
 * fields carry the same names the wasm canvas passes (`coordinates`,
 * `ringCoordinates`, `pointMarkerPositions`, `pointMarkerRadiusPixels`,
 * `trafficFlowSegments`, `rgbaColor`, `widthPixels`). Mirrors the contract's
 * `MapOverlay` record; the wasm surface does not consume this type directly —
 * the canvas' `setOverlays` plain objects stay byte-compatible with this
 * shape.
 */
/**
 * The styled vector base source the wasm canvas installs: the contract's
 * `UrlTemplateVectorTileSource` record in the surface's lower-camel spelling.
 * Passed to `MapView.setVectorTileSource`; the canvas fetches, decodes, styles
 * and labels the tileset itself, so no page-side vector geometry is needed
 * (`setLabels` remains only for the isolated text-quality probe).
 */
export interface UrlTemplateVectorTileSource {
    /** The `{z}/{x}/{y}` URL template the tileset publishes. */
    readonly urlTemplate: string;
    /** The tileset's name, used verbatim in every diagnostic it raises. */
    readonly sourceName: string;
    /** The attribution line the tileset's terms require. */
    readonly attributionText: string;
    /** The committed style id the base paints with. */
    readonly styleId: string;
    /** Lowest zoom level the tileset serves. */
    readonly minimumZoomLevel: number;
    /** Highest zoom level the tileset serves. */
    readonly maximumZoomLevel: number;
}

/**
 * The contract's position fix record: the coordinate plus the source's
 * optional accuracy, course and timestamp. The native bindings receive this
 * shape; the WebAssembly surface's `PositionController.latestFix` reports the
 * same fields as {@link DevicePositionFix}.
 */
export interface PositionFix {
    /** The reported coordinate on the WGS 84 ellipsoid. */
    readonly coordinate: GeographicCoordinate;
    /** Radius in meters of the 68% horizontal-accuracy envelope, or absent. */
    readonly horizontalAccuracyMeters?: number | null;
    /** Direction of travel in degrees clockwise from true north, or absent. */
    readonly courseHeadingDegrees?: number | null;
    /** The fix instant in seconds since the Unix epoch, or absent. */
    readonly timestampSeconds?: number | null;
}

/**
 * Why a positioning source could not produce fixes, mirroring the contract's
 * `PositionSourceError` enum.
 */
export type PositionSourceError =
    | "PermissionDenied"
    | "ServiceDisabled"
    | "Unavailable"
    | "Timeout";

/**
 * One device position fix the wasm `PositionController` accepted: the Rust
 * `rustic-maps-positioning` record in the surface's lower-camel spelling. Reported
 * back by `latestFix`; the controller validates and smooths the same fixes
 * the native targets carry through the contract.
 */
export interface DevicePositionFix {
    /** Latitude in decimal degrees. */
    readonly latitude: number;
    /** Longitude in decimal degrees. */
    readonly longitude: number;
    /** The 68% horizontal-accuracy radius in meters, or null. */
    readonly horizontalAccuracyMeters: number | null;
    /** Direction of travel in degrees clockwise from true north, or null. */
    readonly courseHeadingDegrees: number | null;
    /** The fix instant in seconds since the Unix epoch, or null. */
    readonly timestampSeconds: number | null;
}

/**
 * A positioning source's failure name, as `PositionController.sourceFailed`
 * accepts and `sourceStatus` reports it.
 */
export type PositionSourceStatusName =
    | "permissionDenied"
    | "serviceDisabled"
    | "unavailable"
    | "timeout";

/**
 * The vector base source's status readback: the contract's
 * `VectorTileSourceStatus` record, answered by
 * `MapView.vectorTileSourceStatus` without drawing or fetching.
 */
export interface VectorTileSourceStatus {
    /** Whether the view carries a vector base source at all. */
    readonly isConfigured: boolean;
    /** The active style id; empty when no source is configured. */
    readonly styleId: string;
    /** The tileset's name; empty when no source is configured. */
    readonly sourceName: string;
    /** The attribution line the tileset's terms require. */
    readonly attributionText: string;
    /** Highest zoom level the tileset serves; zero with no source. */
    readonly maximumZoomLevel: number;
    /** Tile addresses the last resolved frame drew. */
    readonly drawnTileCount: number;
    /** Tile addresses the last frame skipped after a fetch or decode failure. */
    readonly failedTileCount: number;
    /** The last resolved frame's last failure detail, or null. */
    readonly lastFailureDetail: string | null;
    /** Payload-cache lookups that hit, cumulative while the source is
     * configured. Absent from the not-configured status. */
    readonly payloadCacheHitCount?: number;
    /** Payload-cache lookups that missed, cumulative while the source is
     * configured. Absent from the not-configured status. */
    readonly payloadCacheMissCount?: number;
    /** Tile fetches in flight when the last frame resolved. */
    readonly inFlightTileFetchCount?: number;
    /** Missing tiles the last frame covered with a cached ancestor. */
    readonly fallbackTileCount?: number;
    /** Milliseconds from installing the source to the first painted tile, or
     * null until a tile has painted. */
    readonly timeToFirstDrawnTileMilliseconds?: number | null;
}

export interface MapOverlay {
    /** Which overlay shape this descriptor configures. */
    readonly kind: MapOverlayKind;
    /** `RoutePolyline`: the traversal-order polyline (required for the kind). */
    readonly coordinates?: readonly GeographicCoordinate[];
    /** Route polyline, filled polygon and point markers: color override, or
     * absent for the kind's documented default. */
    readonly rgbaColor?: OverlayColor;
    /** Route polyline and traffic flow: line width in screen pixels
     * (positive and finite), or absent for the documented default. */
    readonly widthPixels?: number;
    /** `FilledPolygon`: the outer ring without a repeated closing vertex. */
    readonly ringCoordinates?: readonly GeographicCoordinate[];
    /** `PointMarkers` and `PointPins`: the geographic anchor of every marker
     * (a pin's anchor is its tip). */
    readonly pointMarkerPositions?: readonly GeographicCoordinate[];
    /** Point markers and point pins: radius in screen pixels (positive and
     * finite); a pin's radius is its head radius. */
    readonly pointMarkerRadiusPixels?: number;
    /** `TrafficFlow`: the flow observations to paint (see `TrafficFlowData`). */
    readonly trafficFlowSegments?: readonly TrafficFlowData[];
}

/**
 * Flow condition for one road segment inside the traffic-flow overlay
 * payload. Mirrors the contract's `TrafficFlowData` record field for field
 * (the `fetch_traffic_flow` return on the async provider surface; the overlay
 * payload uses the same record). The WebAssembly surface does not expose the
 * provider calls directly, so this mirror enters through the overlay payload.
 */
export interface TrafficFlowData {
    /** Segment geometry, ordered along the road. */
    readonly shapeCoordinates: readonly GeographicCoordinate[];
    /** Currently observed speed in kilometers per hour, when reported. */
    readonly currentSpeedKilometersPerHour?: number;
    /** Unconstrained (free-flow) speed, when reported. */
    readonly freeFlowSpeedKilometersPerHour?: number;
    /** Congestion classification from the speed ratio or provider buckets. */
    readonly congestionLevel: TrafficFlowCongestionLevel;
}

/**
 * Congestion classification of a traffic-flow overlay segment, mirroring the
 * UDL `TrafficFlowCongestionLevel` enum. The values are the camel-lower tags
 * the wasm canvas' plain objects use (the canvas itself passes the numeric
 * wasm-bindgen enum discriminants); the UDL variants carry the CamelCase
 * spellings.
 */
export type TrafficFlowCongestionLevel =
    | "freeFlow"
    | "slow"
    | "congested"
    | "blocked";

/**
 * The platform window surface handle foreign code hands to the native
 * `MapView::attach`: exactly one platform pointer is set, the rest stay null
 * (the `u64?` members). Mirrors the contract's `SurfaceHandle` record; the
 * browsers' WebAssembly surface never attaches a native window, so this
 * mirror documents the native contract for shared consumers — the canvas
 * owns its `<canvas>` element directly.
 */
export interface SurfaceHandle {
    /** macOS: pointer to the `NSView` the surface renders into. */
    readonly appkitViewPointer?: number | null;
    /** iOS: pointer to the `UIView` the surface renders into. */
    readonly iosViewPointer?: number | null;
    /** Android: pointer to the `ANativeWindow` from the platform `Surface`. */
    readonly androidNativeWindowPointer?: number | null;
}
/**
 * One place row the WebAssembly geocoding and search calls answer: the
 * contract's `Place` record flattened to the surface's scalar field names.
 * Returned by `forwardGeocode`, `suggestPlaces`, `suggestPlacesInBoundary`,
 * `searchPlaces` and `searchPlacesInBoundary`.
 */
export interface PlaceRow {
    /** Display string the provider produced for this place. */
    readonly structuredAddressText: string;
    /** Resolved latitude in decimal degrees. */
    readonly latitudeDegrees: number;
    /** Resolved longitude in decimal degrees. */
    readonly longitudeDegrees: number;
    /** Structural precision reached for this resolution (the contract enum's name). */
    readonly qualityText: string;
}

/**
 * One origin-destination cell of the WebAssembly distance-matrix answer: the
 * contract's `DistanceMatrixEntry` record with the surface's camel-case field
 * names. Returned by `calculateDistanceMatrix`.
 */
export interface DistanceMatrixEntry {
    /** Index into the request's origins. */
    readonly originIndex: number;
    /** Index into the request's destinations. */
    readonly destinationIndex: number;
    /** Distance for this cell in meters. */
    readonly distanceMeters: number;
    /** Travel time for this cell in seconds. */
    readonly durationSeconds: number;
}

/**
 * One traffic incident row the WebAssembly `fetchTrafficIncidents` call
 * answers: the contract's `TrafficIncident` record with lower-camel field
 * names and its `incidentType`/`severity` enums as text (the surface's
 * enum-name convention, like a place row's `qualityText`).
 */
export interface TrafficIncidentRow {
    /** Provider-stable incident identifier. */
    readonly identifier: string;
    /** Class of disruption (the contract enum's variant name). */
    readonly incidentType: string;
    /** Severity ranking (the contract enum's variant name). */
    readonly severity: string;
    /** Provider display text for this incident. */
    readonly shortDescriptionText: string;
    /** Position where the incident starts. */
    readonly startCoordinate: GeographicCoordinate;
    /** Position where the incident ends, when reported. */
    readonly endCoordinate: GeographicCoordinate | null;
}

/**
 * One traffic-flow row the WebAssembly `fetchTrafficFlow` call answers: the
 * contract's `TrafficFlowData` record with lower-camel field names, nullable
 * speeds and the congestion level's enum name as text.
 */
export interface TrafficFlowRow {
    /** Segment geometry, ordered along the road. */
    readonly shapeCoordinates: readonly GeographicCoordinate[];
    /** Currently observed speed in kilometers per hour, when reported. */
    readonly currentSpeedKilometersPerHour: number | null;
    /** Unconstrained speed in kilometers per hour, when reported. */
    readonly freeFlowSpeedKilometersPerHour: number | null;
    /** Congestion classification (the contract enum's variant name). */
    readonly congestionLevel: string;
}

/**
 * The plain options object the WebAssembly `calculateRouteWithOptions` call
 * accepts: the contract's `RouteOptions` and `AvoidOptions` records with
 * lower-camel field names. Every field is optional; an omitted field takes
 * the contract default (automobile, fastest, metric, no avoids, depart now).
 * Enum fields take the contract variant name or its lowercase spelling.
 */
export interface RouteOptionsObject {
    /** Mode of transport: automobile, bicycle or pedestrian. */
    readonly transportationMode?: string;
    /** Optimization target: fastest or shortest. */
    readonly routeStrategy?: string;
    /** Display units: metric or imperial. */
    readonly unitSystem?: string;
    /** Features to avoid; every flag defaults to false. */
    readonly avoidOptions?: {
        readonly tollRoads?: boolean;
        readonly limitedAccessHighways?: boolean;
        readonly ferries?: boolean;
        readonly unpavedRoads?: boolean;
    };
    /** Departure instant in seconds since the Unix epoch; omit to depart now. */
    readonly departureTimestampSeconds?: number;
}

/**
 * One navigation event delivered to a listener registered through the wasm
 * `Navigator.addNavigationListener`: the contract's foreign
 * `NavigationListener` topics modelled over wasm-bindgen. `instruction`
 * arrives for every dispatched fix, `phase` once per transition (with its
 * `phaseChange` name), `deviation` when the deviation judgment changes,
 * `speech` when a new non-empty instruction carries speech text, and the
 * wasm-only `stop` when the trip ends (with a null snapshot).
 */
export type NavigatorEventTopic =
    | "instruction"
    | "phase"
    | "deviation"
    | "speech"
    | "stop";

/**
 * One navigation event's shape. `snapshot` is the plain trip snapshot the
 * `currentTripState` read returns, or `null` for the stop topic.
 */
export interface NavigatorEvent {
    readonly topic: NavigatorEventTopic;
    readonly snapshot: NavigatorTripState | null;
    /** Present on a `speech` event: the contract's speech text. */
    readonly speechText?: string;
    /** Present on a `phase` event when the transition has a name. */
    readonly phaseChange?:
        | "offRouteEntered"
        | "offRouteCleared"
        | "arrived"
        | "rerouteApplied";
}
