// Playwright configuration for the browser harness: a dependency-free static
// server from `serve.mjs` and the system Chromium channel at device scale one.
// The launch flags enable WebGPU in the headless Chromium build (the smoke
// test degrades cleanly to the documented overlay path when they cannot).
import { defineConfig } from '@playwright/test';
import { HOST, PORT } from './serve.mjs';

const TEST_DIRECTORY = './tests';
// WebGPU is behind Chromium's own switch in headless mode: the GPU sandbox
// switch keeps the headless GPU process from crashing the adapter request.
// Dawn on Linux runners wants its Vulkan backend: without the feature flag
// the adapter initializes (`renderer_mode` reports `gpu`) but the frame
// loop then stalls — golden probes and pixel checks never settle, and the
// CI wasm-e2e job times out the WebGPU tests (2026-10-28 diagnosis). The
// Vulkan-on-SwiftShader pairing unblocks the shader path on a no-GPU Linux
// runner; on macOS hosts the flag is inert (the MoltenVK path is default).
const BROWSER_LAUNCH_OPTIONS = {
  args: [
    '--enable-unsafe-webgpu',
    '--enable-gpu',
    '--enable-features=Vulkan',
    '--use-vulkan=swiftshader',
    '--use-angle=swiftshader',
    '--no-sandbox',
  ],
};

export default defineConfig({
  testDir: TEST_DIRECTORY,
  // One retry on the CI runner: several cases drive an asynchronous
  // tile/label settle, and a software-rendered share-of-a-core runner can
  // miss a poll window that never reproduces standalone. Local runs stay
  // strict so a real regression fails on the first attempt.
  retries: process.env.CI ? 1 : 0,
  // Asserts the frozen UniFFI contract's wasm/TypeScript mirror
  // (`tests/contract_sync.mjs`) before any browser test runs; pure file
  // parsing, no server involved.
  globalSetup: './global_setup.mjs',
  use: {
    channel: 'chromium',
    baseURL: `http://${HOST}:${PORT}`,
    viewport: { width: 640, height: 480 },
    contextOptions: { deviceScaleFactor: 1 },
    launchOptions: BROWSER_LAUNCH_OPTIONS,
  },
  webServer: {
    command: 'node serve.mjs',
    url: `http://${HOST}:${PORT}/`,
    reuseExistingServer: false,
  },
});