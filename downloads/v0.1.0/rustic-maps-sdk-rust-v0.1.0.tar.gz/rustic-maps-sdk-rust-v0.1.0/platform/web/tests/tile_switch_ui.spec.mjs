// The demo's raster ⇄ vector base-map switch (M9 live-tile integration): the
// page hides the raster layer, decodes the provider-declared vector tiles and
// paints them through the overlay layer, then switches back. Every provider
// fact comes from the shared registry and every tile payload is the committed
// fixture, intercepted by the test, so no external network is touched.
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { expect, test } from '@playwright/test';

/** Closes the settings sheet (Escape, the dialog's own dismiss). */
async function close_base_map_settings(page) {
  const settings_dialog = page.locator('#settings-dialog');
  if (await settings_dialog.evaluate((element) => element.open)) {
    await page.keyboard.press('Escape');
  }
  await expect(settings_dialog).toBeHidden();
}

/** Opens the settings sheet, the base-map flow's home on every platform. */
async function open_base_map_settings(page) {
  const settings_dialog = page.locator('#settings-dialog');
  if (!(await settings_dialog.evaluate((element) => element.open))) {
    await page.locator('#settings-control').click();
  }
  await expect(settings_dialog).toBeVisible();
}

const TEST_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));
const REPOSITORY_ROOT = path.resolve(TEST_DIRECTORY, '..', '..', '..');

/** The shared provider registry the page and the assertions read. */
const providers_registry = JSON.parse(
  readFileSync(path.join(REPOSITORY_ROOT, 'platform', 'providers.json'), 'utf8'),
);

/** The first descriptor that declares a vector-tile fixture route. */
const vector_provider_descriptor = providers_registry.providers.find(
  (provider_descriptor) => provider_descriptor.fixture_routes.some(
    (fixture_route) => fixture_route.purpose === 'vector_tiles'),
);

/** The recorded vector tile every intercepted request answers with. */
const recorded_vector_tile_bytes = readFileSync(path.join(
  REPOSITORY_ROOT,
  vector_provider_descriptor.fixture_routes.find(
    (fixture_route) => fixture_route.purpose === 'vector_tiles',
  ).fixture,
));

/** Every provider that can back a vector base layer. */
const vector_provider_descriptors = providers_registry.providers.filter(
  (provider_descriptor) => typeof provider_descriptor.url_template === 'string',
);

/** The second vector provider and its recorded tile (the style proof). */
const second_vector_provider_descriptor = vector_provider_descriptors.find(
  (provider_descriptor) => provider_descriptor !== vector_provider_descriptor,
);
const second_vector_fixture_route = second_vector_provider_descriptor.fixture_routes.find(
  (fixture_route) => fixture_route.purpose === 'vector_tiles',
);
const recorded_second_vector_tile_bytes = readFileSync(path.join(
  REPOSITORY_ROOT, second_vector_fixture_route.fixture,
));

test('the base-map switch hides the raster layer and paints the decoded vector base', async ({
  page,
}) => {
  // Intercept every vector-tile request and answer with the committed
  // fixture: the page's own URL template is exercised, the network is not.
  await page.route('**/*.mvt', (route) => route.fulfill({
    status: 200,
    contentType: 'application/vnd.mapbox-vector-tile',
    body: recorded_vector_tile_bytes,
  }));
  await page.goto('/?advanced&useProviderFixtures');
  await page.evaluate(() => window.mapTestReady);

  const toggle_buttons = page.locator('#base-map-toggle button');
  // One raster row plus one vector row per provider that declares a tile URL
  // template — the registry decides how many bases exist.
  const vector_provider_count = providers_registry.providers.filter(
    (provider_descriptor) => typeof provider_descriptor.url_template === 'string',
  ).length;
  await expect(toggle_buttons).toHaveCount(1 + vector_provider_count);
  await expect(toggle_buttons.nth(0)).toContainText('Raster');
  await expect(toggle_buttons.nth(1)).toContainText('Vector');
  await expect(toggle_buttons.nth(1)).toContainText(
    vector_provider_descriptor.display_name);
  await expect(toggle_buttons.nth(0)).toHaveAttribute('aria-pressed', 'true');

  // Let the raster layer settle at least one drawn tile, then switch.
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.drawnTiles ?? 0), { timeout: 15000 })
    .toBeGreaterThan(0);

  await open_base_map_settings(page);
  await toggle_buttons.nth(1).click();
  await expect(toggle_buttons.nth(1)).toHaveAttribute('aria-pressed', 'true');
  expect(await page.evaluate(() => window.mapTileMode())).toBe('vector');

  // The vector base paints decoded overlays while the raster layer reports
  // no drawn tiles; the overlay triangles prove the decoded geometry reached
  // the GPU frame.
  await expect
    .poll(async () => page.evaluate(() => window.mapVectorBaseStatus()),
      { timeout: 20000 })
    .toContain('tiles drawn');
  await expect
    .poll(async () => page.evaluate(
      () => (window.mapLastFrameStats()?.overlayTriangles ?? 0) > 0),
    { timeout: 20000 })
    .toBe(true);
  expect(await page.evaluate(
    () => window.mapLastFrameStats()?.drawnTiles ?? -1)).toBe(0);

  // Switching back restores the raster layer and the scene overlays.
  await toggle_buttons.nth(0).click();
  await expect(toggle_buttons.nth(0)).toHaveAttribute('aria-pressed', 'true');
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.drawnTiles ?? 0), { timeout: 15000 })
    .toBeGreaterThan(0);
  expect(await page.evaluate(() => window.mapTileMode())).toBe('raster');
  await close_base_map_settings(page);
});

test('a second vector provider paints with its own committed style', async ({
  page,
}) => {
  // The second provider's tiles are served by interception with its committed
  // fixture, so the browser never touches the external tile service.
  await page.route('**/*.pbf', (route) => route.fulfill({
    status: 200,
    contentType: 'application/vnd.mapbox-vector-tile',
    body: recorded_second_vector_tile_bytes,
  }));
  await page.goto('/?advanced');
  await page.evaluate(() => window.mapTestReady);

  await open_base_map_settings(page);
  const second_provider_button = page
    .locator('#base-map-toggle button')
    .filter({ hasText: second_vector_provider_descriptor.display_name });
  await expect(second_provider_button).toHaveCount(1);
  await second_provider_button.click();
  await expect(second_provider_button).toHaveAttribute('aria-pressed', 'true');
  expect(await page.evaluate(() => window.mapTileMode())).toBe('vector');
  expect(await page.evaluate(() => window.mapVectorProviderKey())).toBe(
    second_vector_provider_descriptor.provider_key,
  );

  // Its own schema's style paints filled, lined and pointed features.
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 20000 })
    .toContain('tiles drawn');
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 20000 })
    .toContain(second_vector_provider_descriptor.display_name);
  await expect
    .poll(() => page.evaluate(
      () => (window.mapLastFrameStats()?.overlayTriangles ?? 0) > 0),
    { timeout: 20000 })
    .toBe(true);

  // Switching back to the first provider repaints that provider's schema.
  const first_provider_button = page
    .locator('#base-map-toggle button')
    .filter({ hasText: vector_provider_descriptor.display_name });
  await first_provider_button.click();
  await expect(first_provider_button).toHaveAttribute('aria-pressed', 'true');
  expect(await page.evaluate(() => window.mapVectorProviderKey())).toBe(
    vector_provider_descriptor.provider_key,
  );
});

test('the vector style picker offers the registry styles and Auto follows the OS', async ({
  page,
}) => {
  // The owner ruling of 2026-10-30: the vector base offers the descriptor's
  // named styles (Bright, Fiord, Positron), and the theme's Auto default picks
  // the offered style matching the operating system's preference.
  // The descriptor offering the named Bright/Fiord/Positron family (a second
  // vector descriptor now offers its own Carto styles).
  const styled_descriptor = vector_provider_descriptors.find(
    (provider_descriptor) => Array.isArray(provider_descriptor.vector_styles)
      && provider_descriptor.vector_styles.some(
        (style_choice) => style_choice.style_id === 'fiord-dark',
      ),
  );
  const styled_fixture_route = styled_descriptor.fixture_routes.find(
    (fixture_route) => fixture_route.purpose === 'vector_tiles',
  );
  await page.route('**/*.pbf', (route) => route.fulfill({
    status: 200,
    contentType: 'application/vnd.mapbox-vector-tile',
    body: readFileSync(path.join(REPOSITORY_ROOT, styled_fixture_route.fixture)),
  }));
  await page.emulateMedia({ colorScheme: 'dark' });
  await page.goto('/?advanced');
  await page.evaluate(() => window.mapTestReady);
  await open_base_map_settings(page);
  await page.locator('#base-map-toggle button')
    .filter({ hasText: styled_descriptor.display_name })
    .click();

  // The picker lists exactly the descriptor's offered styles, and Auto's
  // dark preference resolves to the dark one.
  const style_select = page.locator('#vector-style-select');
  await expect(style_select).toBeVisible();
  const offered_style_ids = styled_descriptor.vector_styles.map(
    (style_choice) => style_choice.style_id);
  expect(await page.evaluate(
    () => [...document.getElementById('vector-style-select').options]
      .map((option) => option.value),
  )).toEqual(offered_style_ids);
  expect(await style_select.inputValue()).toBe('fiord-dark');
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 20000 })
    .toContain('fiord-dark');

  // An explicit pick repaints the base in that style.
  await style_select.selectOption('bright-light');
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 20000 })
    .toContain('bright-light');
  await expect
    .poll(() => page.evaluate(
      () => (window.mapLastFrameStats()?.overlayTriangles ?? 0) > 0),
    { timeout: 20000 })
    .toBe(true);

  // Auto follows the OS: the light preference resolves to Bright again.
  await page.emulateMedia({ colorScheme: 'light' });
  await style_select.selectOption({ index: 0 });
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 20000 })
    .toContain('bright-light');
});

test('scene overlays stay available and draw over the vector base', async ({
  page,
}) => {
  // The round-36 field report: choosing a vector base used to disable the
  // scene toggles and clear the overlay list. The base is composed with the
  // page's own overlays now, so both draw in one frame.
  await page.route('**/*.mvt', (route) => route.fulfill({
    status: 200,
    contentType: 'application/vnd.mapbox-vector-tile',
    body: recorded_vector_tile_bytes,
  }));
  await page.goto('/?advanced&useProviderFixtures');
  await page.evaluate(() => window.mapTestReady);

  await open_base_map_settings(page);
  const vector_button = page
    .locator('#base-map-toggle button')
    .filter({ hasText: vector_provider_descriptor.display_name });
  await vector_button.click();
  expect(await page.evaluate(() => window.mapTileMode())).toBe('vector');

  // The vector base paints while the scene toggles stay usable (not the
  // disabled-with-reason state the old clear-and-pause behavior produced).
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.overlayTriangles ?? 0), { timeout: 20_000 })
    .toBeGreaterThan(0);
  // Back to the sheet's own content: the scene toggles live outside Settings.
  await close_base_map_settings(page);
  expect(await page.evaluate(
    () => document.getElementById('scene-overlay-controls').disabled)).toBe(false);
  expect(await page.evaluate(
    () => document.getElementById('scene-overlay-reason').hidden)).toBe(true);

  // Enabling a scene composes its geometry over the base: the frame's overlay
  // triangle count grows by the scene's own triangles.
  const base_triangle_count = await page.evaluate(
    () => window.mapLastFrameStats()?.overlayTriangles ?? 0);
  await page.locator('#route-overlay-control').check();
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.overlayTriangles ?? 0), { timeout: 15_000 })
    .toBeGreaterThan(base_triangle_count);

  // ...and unchecking it returns to the base alone (the base is remembered,
  // not re-fetched into an empty list).
  await page.locator('#route-overlay-control').uncheck();
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.overlayTriangles ?? 0), { timeout: 15_000 })
    .toBe(base_triangle_count);
});

test('switching back to raster while a vector load is in flight paints no vector geometry', async ({
  page,
}) => {
  // The field-reported superposition: a vector-base load starts, the visitor
  // switches back to raster before the first tile answers, and the completed
  // load paints its geometry over the restored imagery. The tile answer is
  // held here until after the switch, so the race is deterministic.
  let release_tile_response;
  const tile_response_gate = new Promise((resolve) => {
    release_tile_response = resolve;
  });
  await page.route('**/*.mvt', async (route) => {
    await tile_response_gate;
    await route.fulfill({
      status: 200,
      contentType: 'application/vnd.mapbox-vector-tile',
      body: recorded_vector_tile_bytes,
    });
  });

  await page.goto('/?advanced&useProviderFixtures');
  await page.evaluate(() => window.mapTestReady);
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.drawnTiles ?? 0), { timeout: 15_000 })
    .toBeGreaterThan(0);

  await open_base_map_settings(page);
  const toggle_buttons = page.locator('#base-map-toggle button');
  await toggle_buttons.nth(1).click();
  await expect
    .poll(() => page.evaluate(() => window.mapVectorBaseStatus()), { timeout: 15_000 })
    .toContain('Loading');

  // Back to raster while the first tile is still in flight.
  await toggle_buttons.nth(0).click();
  release_tile_response();

  // Let the released load finish and a few frames settle: no vector overlays
  // and no labels may appear over the raster base.
  await expect
    .poll(async () => page.evaluate(
      () => window.mapLastFrameStats()?.drawnTiles ?? 0), { timeout: 15_000 })
    .toBeGreaterThan(0);
  await page.waitForTimeout(1_000);
  const settled_frame = await page.evaluate(() => window.mapLastFrameStats());
  expect(settled_frame.overlayTriangles).toBe(0);
  expect(settled_frame.labelCount).toBe(0);
  expect(await page.evaluate(() => window.mapTileMode())).toBe('raster');
});
