// Contract-sync test (PRD §4.7): the hand-reviewed wasm surface — the
// `wasm-bindgen` exports in `crates/rustic-maps-web-bindings/src/exports.rs` and
// `crates/rustic-maps-web-bindings/src/navigation.rs`, and the curated TypeScript
// record mirror in `platform/web/types/` — must keep mirroring the frozen
// UniFFI contract `crates/rustic-maps-native-core/src/rustic_maps.udl`. On wasm
// there is no
// UniFFI code generation, so the only thing keeping the surfaces aligned is
// this test: it reads the sources with a small line reader (the web harness
// carries no npm dependencies) and compares the shared dictionaries and
// callable surfaces by member name, record field, optionality and field type.
//
// The comparison is addition-tolerant by design. The UDL grows with every
// slice (the async provider surface followed the frozen camera/projection
// core), while the wasm seam serves only part of it, so the test:
//   - asserts every dictionary the TypeScript mirror declares agrees with its
//     UDL dictionary field by field: no missing or extra fields, an exact
//     field type, and the UDL's nullable `?` written as `T | null` rather
//     than an optional TypeScript property (a dictionary the mirror does not
//     declare stays outside the check, so a contract-only record is never a
//     failure),
//   - asserts the `SdkError` variant names agree one to one,
//   - asserts the frozen `MapCamera` methods, the frozen `Navigator` methods
//     and the frozen free helpers exist in the UDL and in every wasm export
//     source (the hand-reviewed Rust exports, and the generated `pkg`
//     declarations when they are present), and
//   - asserts the wasm surface never invents a member the UDL contract lacks
//     (apart from the documented wasm-only lifecycle helpers).
// It deliberately does not assert set equality of the whole UDL namespace:
// contract-only members (`MapSdk`, the provider records and enums, the
// `fit_bounds` constructor) stay surface the wasm seam may adopt later, so
// their absence in the wasm sources is not a failure.
//
// Run directly (no server or browser involved):
//   node --test platform/web/tests/contract_sync.mjs
// Playwright also runs it through its `globalSetup`.

import { strict as assert } from 'node:assert';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath, pathToFileURL } from 'node:url';

// --- Contract surface under comparison --------------------------------------

/**
 * Every curated TypeScript interface that mirrors one UDL dictionary, mapped
 * to the contract dictionary it mirrors. The mirror spells a few records
 * under a surface name (`NavigatorLocationUpdate`, `TrafficIncidentRow`,
 * `TrafficFlowRow`); the UDL name stays the comparison source.
 *
 * The two tables below must classify every interface the mirror declares, so
 * a new interface can never slip in unchecked.
 */
const MIRROR_INTERFACE_CONTRACT_DICTIONARIES = new Map([
  ['GeographicCoordinate', 'GeographicCoordinate'],
  ['BoundingBox', 'BoundingBox'],
  ['SimulatedTripPace', 'SimulatedTripPace'],
  ['SimulatedTripFix', 'SimulatedTripFix'],
  ['RouteStep', 'RouteStep'],
  ['RouteLeg', 'RouteLeg'],
  ['Route', 'Route'],
  ['NavigatorLocationUpdate', 'NavigationLocationUpdate'],
  ['ScreenPoint', 'ScreenPoint'],
  ['NormalizedWorldCoordinate', 'NormalizedWorldCoordinate'],
  ['TileKey', 'TileKey'],
  ['ViewportSize', 'ViewportSize'],
  ['EdgeInsets', 'EdgeInsets'],
  ['OverlayColor', 'OverlayColor'],
  ['UrlTemplateVectorTileSource', 'UrlTemplateVectorTileSource'],
  ['PositionFix', 'PositionFix'],
  ['VectorTileSourceStatus', 'VectorTileSourceStatus'],
  ['MapOverlay', 'MapOverlay'],
  ['TrafficFlowData', 'TrafficFlowData'],
  ['SurfaceHandle', 'SurfaceHandle'],
  ['DistanceMatrixEntry', 'DistanceMatrixEntry'],
  ['TrafficIncidentRow', 'TrafficIncident'],
  ['TrafficFlowRow', 'TrafficFlowData'],
]);

/**
 * Curated interfaces the mirror derives instead of mirroring a dictionary
 * verbatim: the wasm seam renames, flattens or composes the contract record,
 * so field-for-field equality would be wrong. Each entry records the reason;
 * the mapping above owns the verbatim mirrors.
 */
const MIRROR_PROJECTION_INTERFACES = new Map([
  ['NavigatorDeviation', 'projects the off-route measurement out of DeviationStatusChange'],
  ['NavigatorInstruction', 'composes NavigationInstruction into the turn-card payload'],
  ['NavigatorTripState', 'projects TripNavigationState into the browser trip snapshot'],
  ['DevicePositionFix', 'mirrors the positioning record, which the UDL does not carry'],
  ['PlaceRow', 'flattens Place into scalar latitude, longitude and quality fields'],
  ['RouteOptionsObject', 'flattens RouteOptions and AvoidOptions into one optional surface object'],
  ['NavigatorEvent', 'models the wasm-only navigation event bridge, which the UDL does not carry'],
]);

/**
 * Interfaces whose UDL enum fields the surface reports as the variant's text
 * name (`qualityText`, `incidentType`, `severity`, `congestionLevel`) instead
 * of an enum-typed value; their enum fields therefore compare against
 * TypeScript `string`.
 */
const MIRROR_ENUM_TEXT_INTERFACE_NAMES = new Set([
  'TrafficIncidentRow',
  'TrafficFlowRow',
]);

/**
 * Additive diagnostic fields the wasm surface adds to a dictionary answer
 * while a live source is configured. They have no UDL counterpart (the
 * contract record keeps its exact shape in the not-configured answer), so
 * they are compared for presence only and listed here explicitly.
 */
const MIRROR_SURFACE_ADDITIVE_FIELDS = new Map([
  ['VectorTileSourceStatus', new Set([
    'payloadCacheHitCount',
    'payloadCacheMissCount',
    'inFlightTileFetchCount',
    'fallbackTileCount',
    'timeToFirstDrawnTileMilliseconds',
  ])],
]);

/** The UDL error interface whose variants must be mirrored verbatim. */
const CONTRACT_ERROR_INTERFACE_NAME = 'SdkError';

/** The UDL camera object the wasm seam mirrors member by member. */
const CONTRACT_CAMERA_INTERFACE_NAME = 'MapCamera';

/** The `MapCamera` methods the wasm seam serves today. */
const FROZEN_CAMERA_METHOD_NAMES = [
  'projectToScreen',
  'screenToGroundCoordinate',
  'visibleTileKeys',
  'tileZoomLevel',
  'groundMetersPerScreenPixel',
  // The gesture members (M17's fourth slice): the contract's camera algebra
  // every shell applies, served on the wasm camera class too.
  'panByScreenPixels',
  'zoomByLevelsAroundScreenPoint',
  'rotateByDegreesAroundScreenPoint',
  // The attribute getters (M19's bounds-fitting slice): a fitted camera's
  // chosen center, zoom, bearing and pitch read back through the contract's
  // own getters.
  'center',
  'zoomLevel',
  'bearingDegrees',
  'pitchDegrees',
];

/** The UDL simulated-trip object the wasm seam mirrors member by member. */
const CONTRACT_ROUTE_SIMULATOR_INTERFACE_NAME = 'RouteSimulator';

/** The `RouteSimulator` methods the wasm seam serves (M27). */
const FROZEN_ROUTE_SIMULATOR_METHOD_NAMES = [
  'totalDistanceMeters',
  'totalDurationSeconds',
  'fixAtTravelledMeters',
  'fixAtElapsedSeconds',
];

/** The UDL constructor attribute naming the contract's bounds-fitting camera. */
const CONTRACT_BOUNDS_FITTING_CONSTRUCTOR_NAME = 'fit_bounds';

/** The wasm `MapCamera` static mirroring that constructor. */
const WASM_BOUNDS_FITTING_EXPORT_NAME = 'fittingBounds';

/** The UDL navigation object the wasm seam mirrors member by member. */
const CONTRACT_NAVIGATOR_INTERFACE_NAME = 'Navigator';
/** The contract's rendering-surface interface the wasm canvas serves part of. */
const CONTRACT_MAP_VIEW_INTERFACE_NAME = 'MapView';

/**
 * The `Navigator` members the wasm seam serves: the trip-driving and readback
 * core. The contract's listener, speech and reroute-recalculation members stay
 * native until the wasm surface carries a foreign-listener contract, so their
 * absence on the wasm class is deliberate and not a drift.
 */
const FROZEN_NAVIGATOR_METHOD_NAMES = [
  'startNavigation',
  'updateLocation',
  'applyReroute',
  'stopNavigation',
  'currentTripState',
];

/**
 * Wasm-only `Navigator` helpers the contract has no member for: the trip
 * activity probe the page's controls read, and the event bridge (M31) that
 * models the contract's foreign `NavigationListener` trait over
 * wasm-bindgen (the trait itself cannot cross that boundary).
 */
const WASM_ONLY_NAVIGATOR_METHOD_NAMES = [
  'hasActiveTrip',
  'addNavigationListener',
  'removeNavigationListener',
];

/**
 * Canvas `MapView` members the UDL contract has no counterpart for (or spells
 * differently): the browser surface owns its canvas lifetime and its glyph
 * pipeline, which the native contract's `MapView` leaves to the platform
 * wrapper. The contract members the canvas does serve are compared below; the
 * absent ones (`attach`, `resize`, `detach`, `isFrameSettled`, the vector
 * source trio, `setDevicePixelRatio`) are the audit's known vector-source gap,
 * not an invention.
 */
const WASM_ONLY_MAP_VIEW_METHOD_NAMES = [
  'initialize',
  'sdkCompiledVersion',
  'renderFrame',
  'stageParentTile',
  'setLabels',
  'clearLabels',
  'setGlyphRange',
  'setBaseMapVisible',
  'setBackgroundColor',
];

/** The free projection helpers the wasm seam serves today. */
const FROZEN_FREE_HELPER_NAMES = [
  'coordinateToNormalizedWorld',
  'tileKeyForCoordinate',
  'tilesCovering',
  'getSdkCompiledVersion',
  // The offline routing seam (M7) is now a contract free helper too: the
  // contract's `offline_route_from_archive_bytes` function and the wasm
  // export share one `rustic-maps-core` implementation, so the name is asserted in
  // both surfaces.
  'offlineRouteFromArchiveBytes',
];

/**
 * Wasm-only lifecycle helpers the seam exports but the UDL contract
 * deliberately does not carry as its own free functions: the panic-hook and
 * readiness starter, the retina threshold the browser playground consumes,
 * and the diagnostics readout ring's seam — the wasm mirror of the
 * contract's `MapSdk::subscribeToDiagnosticEvents` /
 * `flushRecentDiagnosticEvents` methods minus their live-listener
 * parameter (the wasm surface has no foreign-listener seam; the page reads
 * the bounded rings directly). Plus the gesture-input camera seam that M3
 * landed ahead of the contract (crates/rustic-maps-rendering/src/camera_interaction.rs,
 * exercised by the playground's pointer/wheel loop): the free
 * `camera_*` pose helpers now stay as addition-only aliases of the
 * `MapCamera` gesture members the contract carries (M17's fourth slice), so
 * the playground's existing call sites keep working unchanged.
 * This surface stays unchecked by the `MapSdk`-carrying assertions.
 */
const WASM_ONLY_FREE_HELPER_NAMES = [
  'devicePixelRatioThreshold',
  'initializeSdk',
  'subscribeToDiagnosticEvents',
  'flushRecentDiagnosticEvents',
  'panCameraByScreenPixels',
  'zoomCameraByLevelsAroundScreenPoint',
  'rotateCameraByDegreesAroundScreenPoint',
  // The live provider registration (M13/M15/M45): the browser demo takes a
  // runtime credential and fetches real provider data through the same
  // per-capability registry the native targets use. `configureProvider` and
  // `providerRegistrations` are the contract's own members; the two helpers
  // beside them exist only on the browser — `setProviderBaseUrl` points a
  // provider at a same-origin route for the test harness, and
  // `clearProviderRegistrations` is the settings Clear act the contract has
  // no member for.
  'setProviderBaseUrl',
  'clearProviderRegistrations',
  'forwardGeocode',
  'reverseGeocode',
  'routeCapabilities',
  'fetchElevationPoints',
  'registerUrlTemplateRasterTileSource',
  'clearUrlTemplateRasterTileSource',
  // The traffic layer's cache counters: no contract member reports them yet;
  // the developer console reads them on the browser target.
  'trafficFlowCacheStatistics',
  // The live search-place surface (M31): the contract's `MapSdk::suggest` and
  // `MapSdk::search`, each with its optional ranking boundary, answered by
  // the active provider's `SearchPlaceProvider`. The native provider surface
  // is contract-only today; these wasm aliases stay ahead of it, like
  // `forwardGeocode` above.
  'suggestPlaces',
  'suggestPlacesInBoundary',
  'searchPlaces',
  'searchPlacesInBoundary',
  // The live distance-matrix call (M31): the contract's
  // `MapSdk::calculate_distance_matrix`, answered by the active provider's
  // `DistanceMatrixProvider`. Native-only in the contract today; this wasm
  // alias stays ahead of it.
  'calculateDistanceMatrix',
  // The live traffic calls (M31): the contract's
  // `MapSdk::fetch_traffic_incidents`/`fetch_traffic_flow`, answered by the
  // active provider's traffic traits. Native-only in the contract today;
  // these wasm aliases stay ahead of it.
  'fetchTrafficIncidents',
  'fetchTrafficFlow',
  // The live route and raster-tile calls (M13): the same registered provider
  // set answering a two-waypoint Directions route and one Tiles API raster
  // tile. The native provider surface is contract-only today; these stay
  // ahead of it.
  'calculateRoute',
  // The options-taking route form (M31): the contract's `MapSdk::calculate_route`
  // options argument, read as one plain object with the contract defaults.
  'calculateRouteWithOptions',
  'fetchRasterTile',
  // The vector-tile seam (M9): one fetched MVT payload becomes the canvas'
  // overlay descriptors, and the tile's geographic bounds come from the same
  // conversion. The native contract has no vector-tile surface yet; these
  // stand ahead of it, like the other wasm-only helpers above.
  'vectorTileOverlayDescriptors',
  // The same conversion painted with one committed style variant (light or
  // dark palette, one per tile schema), so a provider registry descriptor
  // can name its schema and the page its theme instead of a page-side style
  // table. Wasm-only for the same reason as the pair above.
  'vectorTileOverlayDescriptorsForStyle',
  'vectorTileGeographicBounds',
  // The tile's symbol-layer text (M9 slice S3): the frame-level label pass's
  // point-label descriptors, read through the same style's ordered text
  // fallbacks and painted by the canvas' glyph pipeline. The native contract
  // carries no label surface yet; these stand ahead of it like the vector
  // helpers above.
  'vectorTileLabelDescriptors',
  'vectorTileLabelDescriptorsForStyle',
  // The reference applications' shared behavior math (M64): the wasm seam
  // exports `crates/map-refapp-core` directly so the page reads the same
  // follow-camera, median, easing, scale-bar and trace-cursor implementation
  // the native reference applications consume. The frozen SDK contract has no
  // reference-application surface, so these free helpers and their classes are
  // deliberately wasm-only.
  'smoothstepEasedProgress',
  'bearingOffNorthDegrees',
  'signedAngularDifferenceDegrees',
  'followZoomTowardTripEnd',
  'selectScaleBarScale',
  'selectScaleBarScaleWithWidthRange',
  'scaleBarDistanceLabelText',
  'traceDispatchIntervalMilliseconds',
];

/**
 * The constructor of a `wasm-bindgen` class is generated as its own
 * `#wasm_bindgen(constructor)` member (the generated JavaScript sees `new`),
 * so it has no UDL method-name counterpart and is excluded from the member
 * comparisons.
 */
const WASM_CONSTRUCTOR_METHOD_NAME = 'new';

/**
 * The generated pkg TypeScript spells the class constructor as its own
 * `constructor` member; like the Rust-side `new`, it has no UDL method-name
 * counterpart and is excluded from the reverse member comparisons.
 */
const GENERATED_CONSTRUCTOR_METHOD_NAME = 'constructor';

// --- File locations ---------------------------------------------------------

const TEST_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));
const REPOSITORY_ROOT = path.resolve(TEST_DIRECTORY, '..', '..', '..');
const UNIFFI_CONTRACT_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-native-core', 'src', 'rustic_maps.udl',
);
const TYPESCRIPT_MIRROR_PATH = path.join(
  REPOSITORY_ROOT, 'platform', 'web', 'types', 'rustic_maps.d.ts',
);
const WASM_EXPORTS_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-web-bindings', 'src', 'exports.rs',
);
const WASM_NAVIGATION_EXPORTS_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-web-bindings', 'src', 'navigation.rs',
);
/** The hand-reviewed wasm canvas `MapView` source. */
const WASM_CANVAS_EXPORTS_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-web-bindings', 'src', 'canvas.rs',
);
/** The hand-reviewed wasm provider surface (registration and live calls). */
const WASM_LIVE_PROVIDERS_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-web-bindings', 'src', 'live_providers.rs',
);
/** The hand-reviewed wasm diagnostics seam (the contract's event stream). */
const WASM_DIAGNOSTICS_PATH = path.join(
  REPOSITORY_ROOT, 'crates', 'rustic-maps-web-bindings', 'src', 'diagnostics.rs',
);
const GENERATED_TYPESCRIPT_PATH = path.join(
  REPOSITORY_ROOT, 'platform', 'web', 'pkg', 'rustic_maps_web_bindings.d.ts',
);

// --- Name and type conventions ---------------------------------------------

/**
 * Contract field names are snake_case; the JavaScript objects the seam
 * passes and returns write multi-word fields in lower camel case (see the
 * field-name constants in `exports.rs`).
 */
function convert_contract_field_name_to_typescript(contract_field_name) {
  return contract_field_name.replace(
    /_+([a-z0-9])/g,
    (_match, character) => character.toUpperCase(),
  );
}

/** UniFFI numeric primitives all narrow to JavaScript `number`. */
const NUMERIC_UNIFFI_TYPE_NAMES = new Set([
  'double', 'f32', 'f64', 'float',
  'i8', 'i16', 'i32', 'i64', 'u8', 'u16', 'u32', 'u64',
]);

/** The scalar UniFFI types with a direct TypeScript spelling. */
const SCALAR_UNIFFI_TYPE_TO_TYPESCRIPT = new Map([
  ['boolean', 'boolean'],
  ['char', 'string'],
  ['string', 'string'],
]);

/**
 * Maps one UDL type name onto the TypeScript spelling the mirror uses. A
 * dictionary keeps its interface name, an enum keeps its union type name
 * (or narrows to `string` where the surface reports the variant's text), and
 * a type outside the contract yields null.
 * @param {string} type_name The UniFFI type annotation.
 * @param {boolean} is_nullable Whether the field carries the `?` marker.
 * @param {ParsedContract} contract The parsed contract (dictionary and enum
 *   names).
 * @param {boolean} enum_fields_are_text Whether enum fields narrow to text.
 * @returns {string | null}
 */
function typescript_type_for_contract_type(
  type_name,
  is_nullable,
  contract,
  enum_fields_are_text,
) {
  /** @type {string | null} */
  let base_type = null;
  const scalar_type = SCALAR_UNIFFI_TYPE_TO_TYPESCRIPT.get(type_name);
  if (scalar_type !== undefined) {
    base_type = scalar_type;
  } else if (NUMERIC_UNIFFI_TYPE_NAMES.has(type_name)) {
    base_type = 'number';
  } else if (contract.dictionaries.has(type_name)) {
    base_type = type_name;
  } else if (contract.enums.has(type_name)) {
    base_type = enum_fields_are_text ? 'string' : type_name;
  }
  if (base_type === null) {
    return null;
  }
  return is_nullable ? `${base_type} | null` : base_type;
}

/**
 * Maps a UniFFI dictionary field onto the TypeScript spelling the mirror
 * uses; an unmappable type (one of a later slice the mirror does not carry
 * yet) yields null and stays outside the dictionary comparisons.
 * @param {ContractField} field
 * @param {ParsedContract} contract
 * @param {boolean} enum_fields_are_text
 * @returns {string | null}
 */
function typescript_type_for_contract_field(field, contract, enum_fields_are_text) {
  if (field.sequenceElementType !== null) {
    const element_type = typescript_type_for_contract_type(
      field.sequenceElementType,
      false,
      contract,
      enum_fields_are_text,
    );
    if (element_type === null) {
      return null;
    }
    const sequence_type = `${element_type}[]`;
    return field.isOptional ? `${sequence_type} | null` : sequence_type;
  }
  return typescript_type_for_contract_type(
    field.typeName,
    field.isOptional,
    contract,
    enum_fields_are_text,
  );
}

/**
 * Canonical form of a TypeScript type annotation for comparison: the
 * `readonly` array modifier is semantically transparent to a value the
 * surface returns, whitespace is normalized and union members are sorted so
 * `null | number` and `number | null` compare equal.
 * @param {string} type_text The raw declared type.
 * @returns {string}
 */
function normalized_typescript_type(type_text) {
  const without_readonly = type_text
    .replace(/\breadonly\s+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const union_members = [...new Set(
    without_readonly.split('|').map((member) => member.trim()),
  )].sort();
  return union_members.join(' | ');
}

// --- UniFFI contract parser -------------------------------------------------

/** Opens a UniFFI `dictionary` block. */
const UNIFFI_DICTIONARY_OPEN_PATTERN = /^\s*dictionary\s+([A-Za-z0-9_]+)\s*\{/;
/** Opens a UniFFI `interface` block, plain or `[Error]`. */
const UNIFFI_INTERFACE_OPEN_PATTERN =
  /^\s*(?:\[Error\]\s+)?interface\s+([A-Za-z0-9_]+)\s*\{/;
/** Opens the single UniFFI `namespace` block of the contract. */
const UNIFFI_NAMESPACE_OPEN_PATTERN = /^\s*namespace\s+rustic_maps\s*\{/;
/** Opens a UniFFI `enum` block. */
const UNIFFI_ENUM_OPEN_PATTERN = /^\s*enum\s+([A-Za-z0-9_]+)\s*\{/;
/** One quoted `enum` variant. */
const UNIFFI_ENUM_VARIANT_PATTERN = /^\s*"([A-Za-z0-9_]+)"\s*,?\s*$/;
/** Closes any UniFFI block. */
const UNIFFI_BLOCK_CLOSE_PATTERN = /^\s*\}\s*;/;
/** A `sequence<...>` dictionary field, with the optional `?` marker. */
const UNIFFI_SEQUENCE_FIELD_PATTERN =
  /^\s*sequence<([A-Za-z0-9_]+)>(\?)?\s+([a-z][0-9a-z_]*);/;
/** A scalar or record-typed dictionary field, with the optional `?` marker. */
const UNIFFI_PLAIN_FIELD_PATTERN = /^\s*([A-Za-z0-9_]+)(\?)?\s+([a-z][0-9a-z_]*);/;
/**
 * A namespace member, an `interface` method or an `[Error]` variant: an
 * optional leading type annotation, then the member name before the first
 * `(`. Matches `constructor(...)` under its own name, which the callers
 * then discard.
 */
const UNIFFI_MEMBER_PATTERN = /^\s*(?:[A-Za-z0-9_]+(?:<[^>]+>)*\??\s+)?([A-Za-z0-9_]+)\s*\(/;

/** Comment lines (`///`) and attribute lines (`[Throws=...]`) carry no code. */
const UNIFFI_IGNORABLE_LINE_PATTERN = /^\s*(?:\/|\[)/;
/** The UniFFI constructor member line; not a named method of the surface. */
const UNIFFI_CONSTRUCTOR_MEMBER_NAME = 'constructor';

/**
 * One dictionary field of the contract, verbatim name and annotation.
 * @typedef {object} ContractField
 * @property {string} name Snake-case field name from the contract.
 * @property {string} typeName UniFFI type annotation of the field.
 * @property {boolean} isOptional Whether the field carries the `?` marker.
 * @property {string | null} sequenceElementType Element type of a `sequence<>`.
 */

/**
 * @typedef {object} ParsedContract
 * @property {Map<string, ContractField[]>} dictionaries Dictionary name to its fields.
 * @property {Map<string, string[]>} enums Enum name to its quoted variant names.
 * @property {Map<string, string[]>} interface_members Interface name to its member
 *   method and variant names (constructors filtered out).
 * @property {string[]} namespace_members Free function names of the namespace.
 */

/**
 * Parses the frozen UniFFI contract into the shapes the comparisons need.
 * @param {string} contract_text The raw UDL source.
 * @returns {ParsedContract}
 */
function parse_uniffi_contract(contract_text) {
  /** @type {Map<string, ContractField[]>} */
  const dictionaries = new Map();
  /** @type {Map<string, string[]>} */
  const enums = new Map();
  /** @type {Map<string, string[]>} */
  const interface_members = new Map();
  /** @type {string[]} */
  let namespace_members = [];
  /** @type {null | 'dictionary' | 'enum' | 'interface' | 'namespace'} */
  let block_kind = null;
  let block_name = '';
  /** @type {ContractField[] | string[]} */
  let block_members = [];
  /** @type {string[]} */
  let member_names = [];

  for (const line of contract_text.split('\n')) {
    if (block_kind !== null && UNIFFI_BLOCK_CLOSE_PATTERN.test(line)) {
      if (block_kind === 'dictionary') {
        dictionaries.set(block_name, block_members);
      } else if (block_kind === 'enum') {
        enums.set(block_name, member_names);
      } else if (block_kind === 'interface') {
        interface_members.set(block_name, member_names);
      } else {
        namespace_members = member_names;
      }
      block_kind = null;
      continue;
    }
    const dictionary_open = UNIFFI_DICTIONARY_OPEN_PATTERN.exec(line);
    if (block_kind === null && dictionary_open !== null) {
      block_kind = 'dictionary';
      block_name = dictionary_open[1];
      block_members = [];
      continue;
    }
    const interface_open = UNIFFI_INTERFACE_OPEN_PATTERN.exec(line);
    if (block_kind === null && interface_open !== null) {
      block_kind = 'interface';
      block_name = interface_open[1];
      member_names = [];
      continue;
    }
    const enum_open = UNIFFI_ENUM_OPEN_PATTERN.exec(line);
    if (block_kind === null && enum_open !== null) {
      block_kind = 'enum';
      block_name = enum_open[1];
      member_names = [];
      continue;
    }
    const namespace_open = UNIFFI_NAMESPACE_OPEN_PATTERN.exec(line);
    if (block_kind === null && namespace_open !== null) {
      block_kind = 'namespace';
      block_name = 'rustic_maps';
      member_names = [];
      continue;
    }
    if (block_kind === null || UNIFFI_IGNORABLE_LINE_PATTERN.test(line)) {
      continue;
    }
    if (block_kind === 'dictionary') {
      const sequence_field = UNIFFI_SEQUENCE_FIELD_PATTERN.exec(line);
      if (sequence_field !== null) {
        block_members.push({
          name: sequence_field[3],
          typeName: `sequence<${sequence_field[1]}>`,
          isOptional: sequence_field[2] === '?',
          sequenceElementType: sequence_field[1],
        });
        continue;
      }
      const plain_field = UNIFFI_PLAIN_FIELD_PATTERN.exec(line);
      if (plain_field !== null) {
        block_members.push({
          name: plain_field[3],
          typeName: plain_field[1],
          isOptional: plain_field[2] === '?',
          sequenceElementType: null,
        });
      }
      continue;
    }
    if (block_kind === 'enum') {
      const enum_variant = UNIFFI_ENUM_VARIANT_PATTERN.exec(line);
      if (enum_variant !== null) {
        member_names.push(enum_variant[1]);
      }
      continue;
    }
    const member = UNIFFI_MEMBER_PATTERN.exec(line);
    if (member !== null && member[1] !== UNIFFI_CONSTRUCTOR_MEMBER_NAME) {
      member_names.push(member[1]);
    }
  }
  return { dictionaries, enums, interface_members, namespace_members };
}

// --- TypeScript mirror parser -----------------------------------------------

/** Opens an `export interface` block in the curated mirror. */
const TYPESCRIPT_INTERFACE_OPEN_PATTERN =
  /^\s*export interface\s+([A-Za-z0-9_]+)\s*\{/;
/** A `readonly` interface field with its optional marker and type annotation. */
const TYPESCRIPT_FIELD_PATTERN =
  /^\s*readonly\s+([A-Za-z0-9_]+)(\?)?:\s*(.+);\s*$/;
/** The error variant union the mirror declares for the contract error. */
const TYPESCRIPT_ERROR_UNION_PATTERN = /export type SdkError =/;
/** One `{ readonly variant: "..." ... }` union member of the error union. */
const TYPESCRIPT_VARIANT_PATTERN = /variant:\s*"([A-Za-z0-9_]+)"/g;
/** Closes a TypeScript block (an interface body or the error union). */
const TYPESCRIPT_BLOCK_END_PATTERN = /^\s*};?\s*$/;

/**
 * @typedef {object} TypescriptField
 * @property {string} type The declared type annotation.
 * @property {boolean} isOptional Whether the property carries the `?` marker.
 */

/**
 * @typedef {object} TypescriptMirror
 * @property {Map<string, Map<string, TypescriptField>>} interfaces Interface
 *   name to its declared `readonly` field names, types and optional markers.
 * @property {string[] | null} error_variant_names Declared `SdkError` variant
 *   names, or null when the union is missing.
 */

/**
 * Reads the curated TypeScript mirror: the interface field declarations and
 * the `SdkError` variant union. The callable wasm surface stays in the
 * generated pkg declarations and is compared from the wasm export sources.
 * @param {string} mirror_text The raw `.d.ts` source.
 * @returns {TypescriptMirror}
 */
function parse_typescript_mirror(mirror_text) {
  /** @type {Map<string, Map<string, TypescriptField>>} */
  const interfaces = new Map();
  /** @type {null | string} */
  let current_interface_name = null;
  /** @type {null | Map<string, TypescriptField>} */
  let current_field_declarations = null;
  let error_variant_names = null;
  let error_union_text = null;

  const error_union_start = mirror_text.search(TYPESCRIPT_ERROR_UNION_PATTERN);
  if (error_union_start >= 0) {
    const union_lines = [];
    for (const line of mirror_text.slice(error_union_start).split('\n').slice(1)) {
      union_lines.push(line);
      if (line.trimEnd().endsWith(';')) {
        break;
      }
    }
    error_union_text = union_lines.join('\n');
    error_variant_names = [...error_union_text.matchAll(TYPESCRIPT_VARIANT_PATTERN)]
      .map((match) => match[1]);
  }

  for (const line of mirror_text.split('\n')) {
    const interface_open = TYPESCRIPT_INTERFACE_OPEN_PATTERN.exec(line);
    if (interface_open !== null) {
      current_interface_name = interface_open[1];
      current_field_declarations = new Map();
      interfaces.set(current_interface_name, current_field_declarations);
      continue;
    }
    if (current_interface_name === null) {
      continue;
    }
    if (TYPESCRIPT_BLOCK_END_PATTERN.test(line)) {
      current_interface_name = null;
      current_field_declarations = null;
      continue;
    }
    const field = TYPESCRIPT_FIELD_PATTERN.exec(line);
    if (field !== null && current_field_declarations !== null) {
      current_field_declarations.set(field[1], {
        type: field[3],
        isOptional: field[2] === '?',
      });
    }
  }
  return { interfaces, error_variant_names };
}

// --- Wasm export surface parsers --------------------------------------------

/** The `#wasm_bindgen` camera class implementation block in `exports.rs`. */
const WASM_CAMERA_IMPL_OPEN_PATTERN = /impl MapCamera \{/;
/** The `#wasm_bindgen` route-simulator implementation block in `exports.rs`. */
const WASM_ROUTE_SIMULATOR_IMPL_OPEN_PATTERN = /impl RouteSimulator \{/;
/** The `#wasm_bindgen` navigator implementation block in `navigation.rs`. */
const WASM_NAVIGATOR_IMPL_OPEN_PATTERN = /impl Navigator \{/;
/** The `#wasm_bindgen` canvas surface implementation block in `canvas.rs`. */
const WASM_MAP_VIEW_IMPL_OPEN_PATTERN = /impl MapView \{/;
/** A public method of the camera class in `exports.rs`. */
const WASM_CAMERA_METHOD_PATTERN = /pub fn ([a-z][0-9a-z_]*)\(/g;
/** A free `#[wasm_bindgen]` helper function in `exports.rs` (column zero). */
const WASM_FREE_FUNCTION_PATTERN = /^pub fn ([a-z][0-9a-z_]*)\(/gm;
/** The generated camera class declaration in the pkg TypeScript. */
const GENERATED_CAMERA_CLASS_OPEN_PATTERN = /export class MapCamera \{/;
/** The generated route-simulator class declaration in the pkg TypeScript. */
const GENERATED_ROUTE_SIMULATOR_CLASS_OPEN_PATTERN = /export class RouteSimulator \{/;
/** The generated navigator class declaration in the pkg TypeScript. */
const GENERATED_NAVIGATOR_CLASS_OPEN_PATTERN = /export class Navigator \{/;
/** A method of the generated camera class (indented member call line). */
const GENERATED_CAMERA_METHOD_PATTERN = /^    ([A-Za-z][0-9A-Za-z_]*)\(/gm;
/** A generated free helper function in the pkg TypeScript. */
const GENERATED_FREE_FUNCTION_PATTERN = /^export function ([A-Za-z][0-9A-Za-z_]*)\(/gm;
/** The lifecycle `free` member wasm-bindgen adds to every class. */
const GENERATED_LIFECYCLE_METHOD_NAME = 'free';
/** wasm-bindgen's own module initializers, never SDK exports. */
const GENERATED_INITIALIZER_EXPORT_NAMES = new Set(['init', 'initSync', 'default']);

/** A `#[wasm_bindgen(js_name = …)]` attribute (plain or with getter/setter modifiers). */
const WASM_JS_NAME_ATTRIBUTE_PATTERN = /#\[wasm_bindgen\((?:[a-z]+, )*js_name = ([A-Za-z0-9_]+)\)\]/;
/** A free `#[wasm_bindgen]` function: declared at column zero. */
const WASM_FREE_DECLARATION_PATTERN = /^pub (?:async )?fn ([a-z][0-9a-z_]*)\(/;
/** A method inside a `#[wasm_bindgen] impl` block: indented. */
const WASM_METHOD_DECLARATION_PATTERN = /^\s+pub (?:async )?fn ([a-z][0-9a-z_]*)\(/;

/**
 * @typedef {object} WasmExports
 * @property {string[]} camera_method_names Class methods of `MapCamera`.
 * @property {string[]} route_simulator_method_names Class methods of
 *   `RouteSimulator`.
 * @property {string[]} navigator_method_names Class methods of `Navigator`.
 * @property {string[]} map_view_method_names Class methods of the canvas
 *   `MapView`.
 * @property {string[]} free_function_names Free helper functions.
 */

/**
 * Extracts the text of one class implementation/declaration block: the lines
 * after its opening pattern up to the block's closing brace.
 * @param {string} source_text The source to read.
 * @param {RegExp} open_pattern The block's opening line pattern.
 * @param {string} description Assertion message when the block is absent.
 * @returns {string}
 */
function block_text_after(source_text, open_pattern, description) {
  const block_start = source_text.search(open_pattern);
  assert(block_start >= 0, description);
  // The block closes at the first line holding only a brace at the opening
  // line's own indentation: top-level classes/impls close at column zero, and
  // an impl inside an inline module closes at the module body's indentation
  // rather than at the first indented closing brace of a method body.
  const open_line_start = source_text.lastIndexOf('\n', block_start) + 1;
  const open_line = source_text.slice(open_line_start).split('\n')[0];
  const open_line_indentation = open_line.match(/^\s*/)[0];
  const block_close_pattern = new RegExp(`^${open_line_indentation}\\}\\s*$`);
  const block_lines = [];
  for (const line of source_text.slice(block_start).split('\n').slice(1)) {
    if (block_close_pattern.test(line)) {
      break;
    }
    block_lines.push(line);
  }
  return block_lines.join('\n');
}

/**
 * Parses the hand-reviewed Rust wasm exports: the `#[wasm_bindgen]` methods
 * of `impl MapCamera` and `impl RouteSimulator` in `exports.rs`, the
 * `#[wasm_bindgen]` methods of `impl Navigator` in `navigation.rs`, and the
 * free helper functions.
 * @param {string} exports_text The raw `exports.rs` source.
 * @param {string} navigation_text The raw `navigation.rs` source.
 * @returns {WasmExports}
 */
function parse_wasm_exports(
  exports_text,
  navigation_text,
  canvas_text,
  live_providers_text,
  diagnostics_text,
) {
  const camera_method_names = declared_wasm_names(
    block_text_after(
      exports_text,
      WASM_CAMERA_IMPL_OPEN_PATTERN,
      'exports.rs declares the MapCamera implementation',
    ),
    WASM_METHOD_DECLARATION_PATTERN,
  );
  const route_simulator_method_names = declared_wasm_names(
    block_text_after(
      exports_text,
      WASM_ROUTE_SIMULATOR_IMPL_OPEN_PATTERN,
      'exports.rs declares the RouteSimulator implementation',
    ),
    WASM_METHOD_DECLARATION_PATTERN,
  );
  const navigator_method_names = declared_wasm_names(
    block_text_after(
      navigation_text,
      WASM_NAVIGATOR_IMPL_OPEN_PATTERN,
      'navigation.rs declares the Navigator implementation',
    ),
    WASM_METHOD_DECLARATION_PATTERN,
  );
  const map_view_method_names = declared_wasm_names(
    block_text_after(
      canvas_text,
      WASM_MAP_VIEW_IMPL_OPEN_PATTERN,
      'canvas.rs declares the MapView implementation',
    ),
    WASM_METHOD_DECLARATION_PATTERN,
  );
  // The provider surface is its own module, so its exports join the free
  // function set the contract and the generated declarations are read against.
  // That module also carries internal seams between the canvas and the
  // registry (no `js_name`, not exported to JavaScript), so only its declared
  // exports count.
  const free_function_names = [
    ...declared_wasm_names(exports_text, WASM_FREE_DECLARATION_PATTERN),
    ...declared_wasm_export_names(live_providers_text, WASM_FREE_DECLARATION_PATTERN),
    ...declared_wasm_export_names(diagnostics_text, WASM_FREE_DECLARATION_PATTERN),
  ];
  return {
    camera_method_names,
    route_simulator_method_names,
    navigator_method_names,
    map_view_method_names,
    free_function_names,
  };
}

/**
 * The JavaScript names a Rust wasm export source declares: every `pub fn`
 * with, when the item carries one, the `js_name` its `#[wasm_bindgen]`
 * attribute sets (the wasm surface uses camelCase names that differ from the
 * Rust spellings). The generated TypeScript declares these names, so the
 * source side must be read the same way or the two can never match.
 * @param {string} source_text The Rust source to read.
 * @returns {string[]}
 */
function declared_wasm_names(source_text, declaration_pattern) {
  const names = [];
  let pending_js_name = null;
  for (const line of source_text.split('\n')) {
    const js_name_match = line.match(WASM_JS_NAME_ATTRIBUTE_PATTERN);
    if (js_name_match !== null) {
      pending_js_name = js_name_match[1];
      continue;
    }
    const function_match = line.match(declaration_pattern);
    if (function_match === null) {
      if (line.trim() !== '') {
        pending_js_name = null;
      }
      continue;
    }
    names.push(pending_js_name ?? function_match[1]);
    pending_js_name = null;
  }
  return names;
}

/**
 * The JavaScript names a module declares as `wasm-bindgen` exports: the same
 * scan as [`declared_wasm_names`], restricted to functions that carry an
 * explicit `js_name`, so a module's internal Rust seams stay out of the
 * exported-name set.
 * @param {string} source_text The Rust source to read.
 * @param {RegExp} declaration_pattern The `pub fn` declaration pattern.
 * @returns {string[]}
 */
function declared_wasm_export_names(source_text, declaration_pattern) {
  const names = [];
  let pending_js_name = null;
  for (const line of source_text.split('\n')) {
    const js_name_match = line.match(WASM_JS_NAME_ATTRIBUTE_PATTERN);
    if (js_name_match !== null) {
      pending_js_name = js_name_match[1];
      continue;
    }
    const function_match = line.match(declaration_pattern);
    if (function_match === null) {
      if (line.trim() !== '') {
        pending_js_name = null;
      }
      continue;
    }
    if (pending_js_name !== null) {
      names.push(pending_js_name);
    }
    pending_js_name = null;
  }
  return names;
}

/**
 * Parses the pkg-generated wasm TypeScript declarations, when the build
 * produced them (the `pkg` directory is a build artifact, not source): the
 * declared `MapCamera` and `RouteSimulator` methods and the free helper
 * functions.
 * @param {string} generated_text The raw `rustic_maps_web_bindings.d.ts` source.
 * @returns {WasmExports}
 */
function parse_generated_wasm_typescript(generated_text) {
  const generated_class_methods = (open_pattern, description) =>
    [...block_text_after(generated_text, open_pattern, description)
      .matchAll(GENERATED_CAMERA_METHOD_PATTERN)]
      .map((match) => match[1])
      .filter((name) => name !== GENERATED_LIFECYCLE_METHOD_NAME);
  const camera_method_names = generated_class_methods(
    GENERATED_CAMERA_CLASS_OPEN_PATTERN,
    'generated pkg TypeScript declares the MapCamera class',
  );
  const route_simulator_method_names = generated_class_methods(
    GENERATED_ROUTE_SIMULATOR_CLASS_OPEN_PATTERN,
    'generated pkg TypeScript declares the RouteSimulator class',
  );
  const navigator_method_names = generated_class_methods(
    GENERATED_NAVIGATOR_CLASS_OPEN_PATTERN,
    'generated pkg TypeScript declares the Navigator class',
  );
  const free_function_names = [...generated_text.matchAll(GENERATED_FREE_FUNCTION_PATTERN)]
    .map((match) => match[1])
    .filter((name) => !GENERATED_INITIALIZER_EXPORT_NAMES.has(name));
  return {
    camera_method_names,
    route_simulator_method_names,
    navigator_method_names,
    free_function_names,
  };
}

// --- The contract-sync assertions -------------------------------------------

/** Asserts every member of `expected` sits in `actual`, with a named message. */
function assert_members_present(actual, expected, description) {
  const expected_set = new Set(actual);
  for (const name of expected) {
    assert(
      expected_set.has(name),
      `${description} misses the member "${name}".`,
    );
  }
}

/** Asserts member lists name exactly the same set (order-free). */
function assert_member_lists_equal(actual, expected, description) {
  assert.deepStrictEqual(
    [...new Set(actual)].sort(),
    [...new Set(expected)].sort(),
    `${description} must list the same members.`,
  );
}

/**
 * Compares every dictionary the TypeScript mirror declares against its UDL
 * dictionary: the exact field set (the documented surface-additive fields
 * apart), each field's type, and the UDL's nullable marker against the
 * mirror's `T | null` versus optional `?` spelling. Every mirror interface
 * must also be classified as either a verbatim dictionary mirror or a
 * documented projection, so a new interface cannot be added unchecked.
 * @param {ParsedContract} contract
 * @param {TypescriptMirror} mirror
 */
function assert_mirror_dictionaries_agree(contract, mirror) {
  // Classification completeness: no mirror interface may escape the check.
  for (const interface_name of mirror.interfaces.keys()) {
    const mirrors_dictionary = MIRROR_INTERFACE_CONTRACT_DICTIONARIES.has(interface_name);
    const is_projection = MIRROR_PROJECTION_INTERFACES.has(interface_name);
    assert(
      !(mirrors_dictionary && is_projection),
      `The TypeScript mirror interface "${interface_name}" is listed as both a`
      + ' dictionary mirror and a projection; keep it in exactly one table.',
    );
    assert(
      mirrors_dictionary || is_projection,
      `The TypeScript mirror interface "${interface_name}" is neither a`
      + ' dictionary mirror nor a documented projection; add it to'
      + ' MIRROR_INTERFACE_CONTRACT_DICTIONARIES or'
      + ' MIRROR_PROJECTION_INTERFACES.',
    );
  }
  // The documented tables must not outlive the interfaces they describe.
  for (const projection_name of MIRROR_PROJECTION_INTERFACES.keys()) {
    assert(
      mirror.interfaces.has(projection_name),
      `The projection table names "${projection_name}", which the TypeScript`
      + ' mirror no longer declares; drop the stale entry.',
    );
  }
  for (const enum_text_name of MIRROR_ENUM_TEXT_INTERFACE_NAMES) {
    assert(
      MIRROR_INTERFACE_CONTRACT_DICTIONARIES.has(enum_text_name),
      `The enum-text list names "${enum_text_name}", which is not a dictionary`
      + ' mirror; move it to MIRROR_PROJECTION_INTERFACES or drop it.',
    );
  }
  for (const additive_interface_name of MIRROR_SURFACE_ADDITIVE_FIELDS.keys()) {
    assert(
      MIRROR_INTERFACE_CONTRACT_DICTIONARIES.has(additive_interface_name),
      `The additive-field table names "${additive_interface_name}", which is`
      + ' not a dictionary mirror; drop the stale entry.',
    );
  }

  for (const [interface_name, dictionary_name] of MIRROR_INTERFACE_CONTRACT_DICTIONARIES) {
    const contract_fields = contract.dictionaries.get(dictionary_name);
    assert(
      contract_fields !== undefined,
      `The UDL contract must declare the dictionary "${dictionary_name}" the`
      + ` mirror interface "${interface_name}" mirrors.`,
    );
    const typescript_fields = mirror.interfaces.get(interface_name);
    assert(
      typescript_fields !== undefined,
      `The TypeScript mirror must declare the interface "${interface_name}".`,
    );

    const additive_field_names =
      MIRROR_SURFACE_ADDITIVE_FIELDS.get(interface_name) ?? new Set();
    const contract_field_names = contract_fields
      .map((field) => convert_contract_field_name_to_typescript(field.name));
    assert_member_lists_equal(
      [...typescript_fields.keys()],
      [...contract_field_names, ...additive_field_names],
      `The mirror for "${interface_name}"`,
    );
    // A surface-additive field that the contract has since adopted belongs in
    // the UDL comparison, not the additive list.
    for (const additive_field_name of additive_field_names) {
      assert(
        !contract_field_names.includes(additive_field_name),
        `The additive field "${interface_name}.${additive_field_name}" is now`
        + ' part of the UDL dictionary; drop it from'
        + ' MIRROR_SURFACE_ADDITIVE_FIELDS.',
      );
    }

    const enum_fields_are_text =
      MIRROR_ENUM_TEXT_INTERFACE_NAMES.has(interface_name);
    for (const field of contract_fields) {
      const field_name = convert_contract_field_name_to_typescript(field.name);
      const mirror_field = typescript_fields.get(field_name);
      assert(
        mirror_field !== undefined,
        `The mirror interface "${interface_name}" misses the contract field`
        + ` "${field_name}".`,
      );
      const expected_type = typescript_type_for_contract_field(
        field,
        contract,
        enum_fields_are_text,
      );
      assert(
        expected_type !== null,
        `The field "${interface_name}.${field_name}" has an unmappable UniFFI`
        + ` type "${field.typeName}".`,
      );

      // Nullability and optionality are distinct: the UDL's `?` is a present,
      // null-able field, while TypeScript's `?:` omits the property entirely.
      assert(
        !mirror_field.isOptional,
        field.isOptional
          ? `The mirror field "${interface_name}.${field_name}" is declared`
            + ` optional (a "?" property), but the UDL field is nullable:`
            + ` declare it as "${expected_type}" (present with null).`
          : `The mirror field "${interface_name}.${field_name}" is declared`
            + ` optional (a "?" property), but the UDL field is required:`
            + ` declare it as "${expected_type}".`,
      );
      const declared_type = normalized_typescript_type(mirror_field.type);
      const expected_normalized_type = normalized_typescript_type(expected_type);
      const declares_null = declared_type.split(' | ').includes('null');
      assert(
        field.isOptional || !declares_null,
        `The mirror field "${interface_name}.${field_name}" declares`
        + ` "${mirror_field.type}", but the UDL field is not nullable: drop`
        + ` "| null".`,
      );
      assert.strictEqual(
        declared_type,
        expected_normalized_type,
        `The mirror field "${interface_name}.${field_name}" must have the`
        + ` TypeScript type "${expected_type}", but declares`
        + ` "${mirror_field.type}".`,
      );
    }
  }
}

/**
 * @param {ParsedContract} contract
 * @param {TypescriptMirror} mirror
 */
function assert_error_variants_agree(contract, mirror) {
  const contract_variants = contract.interface_members.get(CONTRACT_ERROR_INTERFACE_NAME);
  assert(
    contract_variants !== undefined,
    `The UDL contract must declare the error interface "${CONTRACT_ERROR_INTERFACE_NAME}".`,
  );
  assert(
    mirror.error_variant_names !== null,
    `The TypeScript mirror must declare the "${CONTRACT_ERROR_INTERFACE_NAME}" union.`,
  );
  assert_member_lists_equal(
    mirror.error_variant_names,
    contract_variants,
    `The mirror error union "${CONTRACT_ERROR_INTERFACE_NAME}"`,
  );
}

/**
 * The UDL (snake_case) spelling of a JavaScript export name: the wasm surface
 * publishes camelCase names through `#[wasm_bindgen(js_name = …)]` while the
 * contract keeps snake_case, so the two are compared through this mapping.
 * @param {string} js_export_name The JavaScript name, lower camel case.
 * @returns {string}
 */
function contract_spelling_of(js_export_name) {
  return js_export_name.replace(
    /[A-Z]/g,
    (capital_letter) => `_${capital_letter.toLowerCase()}`,
  );
}

/**
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_camera_methods_agree(contract, wasm_exports) {
  const contract_methods = contract.interface_members.get(CONTRACT_CAMERA_INTERFACE_NAME);
  assert(
    contract_methods !== undefined,
    `The UDL contract must declare the camera interface "${CONTRACT_CAMERA_INTERFACE_NAME}".`,
  );
  assert_members_present(
    contract_methods,
    FROZEN_CAMERA_METHOD_NAMES.map(contract_spelling_of),
    `The UDL camera interface "${CONTRACT_CAMERA_INTERFACE_NAME}"`,
  );
  assert_members_present(
    wasm_exports.camera_method_names,
    FROZEN_CAMERA_METHOD_NAMES,
    'The wasm "MapCamera" class',
  );
  // Reverse, invention-only direction: whatever the wasm seam serves on the
  // camera class must be part of the contract (constructors apart, whose
  // wasm-bindgen name has no UDL method counterpart).
  for (const wasm_method of wasm_exports.camera_method_names) {
    if (wasm_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    // The contract's `fit_bounds` constructor is a constructor, so it has no
    // method-list counterpart; its own parity is asserted separately.
    if (wasm_method === WASM_BOUNDS_FITTING_EXPORT_NAME) {
      continue;
    }
    assert(
      contract_methods.includes(contract_spelling_of(wasm_method)),
      `The wasm "MapCamera" class invents the member "${wasm_method}", which the UDL contract lacks.`,
    );
  }
}

/**
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_route_simulator_methods_agree(contract, wasm_exports) {
  const contract_methods = contract.interface_members.get(
    CONTRACT_ROUTE_SIMULATOR_INTERFACE_NAME,
  );
  assert(
    contract_methods !== undefined,
    `The UDL contract must declare the simulated-trip interface`
    + ` "${CONTRACT_ROUTE_SIMULATOR_INTERFACE_NAME}".`,
  );
  assert_members_present(
    contract_methods,
    FROZEN_ROUTE_SIMULATOR_METHOD_NAMES.map(contract_spelling_of),
    `The UDL simulated-trip interface "${CONTRACT_ROUTE_SIMULATOR_INTERFACE_NAME}"`,
  );
  assert_members_present(
    wasm_exports.route_simulator_method_names,
    FROZEN_ROUTE_SIMULATOR_METHOD_NAMES,
    'The wasm "RouteSimulator" class',
  );
  // Reverse, invention-only direction: whatever the wasm seam serves on the
  // simulator must be part of the contract (the wasm-bindgen constructor name
  // has no UDL method counterpart).
  for (const wasm_method of wasm_exports.route_simulator_method_names) {
    if (wasm_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      contract_methods.includes(contract_spelling_of(wasm_method)),
      `The wasm "RouteSimulator" class invents the member "${wasm_method}",`
      + ` which the UDL contract lacks.`,
    );
  }
}

/**
 * The canvas `MapView` must not invent members: every member it serves is
 * either a UDL `MapView` member (camel to snake through the contract
 * spelling) or one of the documented canvas-only helpers. The members the
 * canvas does serve from the contract (overlays and the location indicator)
 * must all be present, so a refactor cannot silently drop one. Missing
 * contract members (surface lifecycle, vector source) are the audit's known
 * gap, not drift.
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_map_view_methods_agree(contract, wasm_exports) {
  const contract_methods = contract.interface_members.get(
    CONTRACT_MAP_VIEW_INTERFACE_NAME,
  );
  assert(
    contract_methods !== undefined,
    `The UDL contract must declare the rendering interface`
    + ` "${CONTRACT_MAP_VIEW_INTERFACE_NAME}".`,
  );
  const served_contract_members = [
    'setOverlays',
    'addOverlay',
    'updateOverlay',
    'removeOverlay',
    'clearOverlays',
    'setLocationIndicator',
    'clearLocationIndicator',
    // The styled vector base moved into the canvas (M31): the browser serves
    // the contract's source members instead of composing the base in JS.
    'setVectorTileSource',
    'clearVectorTileSource',
    'vectorTileSourceStatus',
  ];
  assert_members_present(
    wasm_exports.map_view_method_names,
    served_contract_members,
    'The wasm "MapView" class',
  );
  for (const wasm_method of wasm_exports.map_view_method_names) {
    if (wasm_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      contract_methods.includes(contract_spelling_of(wasm_method))
      || WASM_ONLY_MAP_VIEW_METHOD_NAMES.includes(wasm_method),
      `The wasm "MapView" class invents the member "${wasm_method}",`
      + ` which the UDL contract (or the documented canvas-only list) lacks.`,
    );
  }
}

/**
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_navigator_methods_agree(contract, wasm_exports) {
  const contract_methods = contract.interface_members.get(
    CONTRACT_NAVIGATOR_INTERFACE_NAME,
  );
  assert(
    contract_methods !== undefined,
    `The UDL contract must declare the navigation interface`
    + ` "${CONTRACT_NAVIGATOR_INTERFACE_NAME}".`,
  );
  assert_members_present(
    contract_methods,
    FROZEN_NAVIGATOR_METHOD_NAMES.map(contract_spelling_of),
    `The UDL navigation interface "${CONTRACT_NAVIGATOR_INTERFACE_NAME}"`,
  );
  assert_members_present(
    wasm_exports.navigator_method_names,
    FROZEN_NAVIGATOR_METHOD_NAMES,
    'The wasm "Navigator" class',
  );
  // Reverse, invention-only direction: whatever the wasm seam serves on the
  // navigator must be part of the contract, the documented wasm-only helpers
  // and the wasm-bindgen constructor apart.
  for (const wasm_method of wasm_exports.navigator_method_names) {
    if (wasm_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      contract_methods.includes(contract_spelling_of(wasm_method))
      || WASM_ONLY_NAVIGATOR_METHOD_NAMES.includes(wasm_method),
      `The wasm "Navigator" class invents the member "${wasm_method}",`
      + ` which the UDL contract lacks.`,
    );
  }
}

/**
 * The bounds-fitting camera is a UDL constructor, so it carries no
 * `interface_members` entry to compare against; its parity is asserted from
 * the raw sources: the contract declares the `[Name=fit_bounds]`
 * constructor on the camera interface and the wasm exports publish the
 * `fittingBounds` static beside the camera's other members.
 * @param {string} contract_text The raw UDL source.
 * @param {string} wasm_exports_text The raw `exports.rs` source.
 */
function assert_bounds_fitting_agrees(contract_text, wasm_exports_text) {
  assert(
    contract_text.includes(`Name=${CONTRACT_BOUNDS_FITTING_CONSTRUCTOR_NAME}`),
    `The UDL contract must declare the "${CONTRACT_BOUNDS_FITTING_CONSTRUCTOR_NAME}" camera constructor.`,
  );
  assert(
    wasm_exports_text.includes(`js_name = ${WASM_BOUNDS_FITTING_EXPORT_NAME}`),
    `The wasm "MapCamera" class must mirror the contract's`
    + ` "${CONTRACT_BOUNDS_FITTING_CONSTRUCTOR_NAME}" constructor as`
    + ` "${WASM_BOUNDS_FITTING_EXPORT_NAME}".`,
  );
}

/**
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_free_helpers_agree(contract, wasm_exports) {
  assert_members_present(
    contract.namespace_members,
    FROZEN_FREE_HELPER_NAMES.map(contract_spelling_of),
    'The UDL contract namespace',
  );
  assert_members_present(
    wasm_exports.free_function_names,
    FROZEN_FREE_HELPER_NAMES,
    'The wasm free helper exports',
  );
  // A free-function export may mirror a namespace free function or one of
  // the `MapSdk` members the browser surface spells as a free call.
  const map_sdk_members = contract.interface_members.get(CONTRACT_MAP_SDK_INTERFACE_NAME) ?? [];
  for (const wasm_helper of wasm_exports.free_function_names) {
    assert(
      contract.namespace_members.includes(contract_spelling_of(wasm_helper))
      || map_sdk_members.includes(contract_spelling_of(wasm_helper))
      || WASM_ONLY_FREE_HELPER_NAMES.includes(wasm_helper),
      `The wasm surface invents the free helper "${wasm_helper}", which the UDL contract lacks.`,
    );
  }
}

/** The UDL interface whose members the browser surface must serve. */
const CONTRACT_MAP_SDK_INTERFACE_NAME = 'MapSdk';

/**
 * Contract members the browser surface serves under a name its own casing rule
 * does not produce: the search calls read as the demo's `…Places` rows.
 */
const WASM_CONTRACT_MEMBER_SPELLINGS = new Map([
  ['suggest', ['suggestPlaces']],
  ['search', ['searchPlaces']],
]);

/**
 * Contract members the browser surface deliberately lacks, with the reason.
 * Each one is native-only by construction: a foreign callback trait cannot
 * cross the `wasm-bindgen` boundary, a browser page has no disk-backed tile
 * cache, and the failure diagnostics read back calls that only those foreign
 * adapters produce.
 */
const WASM_CONTRACT_MEMBER_EXCEPTIONS = new Map([
  ['register_geocoding_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_raster_tile_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider` or the URL-template source'],
  ['register_routing_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_distance_matrix_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_search_place_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_traffic_incident_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_traffic_flow_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['register_elevation_provider_from_foreign', 'a foreign callback trait cannot cross wasm-bindgen; a page registers through `configureProvider`'],
  ['set_provider_credential_with_tile_cache', 'the browser has no disk-backed tile cache to install'],
  ['set_raster_tile_cache_time_to_live', 'the browser has no disk-backed tile cache to tune'],
  ['raster_tile_cache_terms', 'the browser has no disk-backed tile cache to report'],
  ['latest_provider_failure_diagnostics', 'the readback describes the foreign-provider adapters, which the browser has none of'],
]);

/**
 * Every `MapSdk` member the UDL declares must have a browser counterpart: the
 * free-function export its name spells, or an entry in
 * [`WASM_CONTRACT_MEMBER_EXCEPTIONS`]. This is the gate that keeps the
 * hand-maintained façade from silently falling behind the frozen contract
 * again.
 * @param {ParsedContract} contract
 * @param {WasmExports} wasm_exports
 */
function assert_map_sdk_members_have_wasm_counterparts(contract, wasm_exports) {
  const map_sdk_members = contract.interface_members.get(CONTRACT_MAP_SDK_INTERFACE_NAME);
  assert(
    map_sdk_members !== undefined && map_sdk_members.length > 0,
    'The UDL contract declares the MapSdk interface.',
  );
  for (const contract_member of map_sdk_members) {
    const candidate_names = WASM_CONTRACT_MEMBER_SPELLINGS.get(contract_member)
      ?? [convert_contract_field_name_to_typescript(contract_member)];
    const is_served = candidate_names.some((candidate_name) =>
      wasm_exports.free_function_names.includes(candidate_name));
    if (is_served) {
      continue;
    }
    assert(
      WASM_CONTRACT_MEMBER_EXCEPTIONS.has(contract_member),
      `The UDL contract's MapSdk member "${contract_member}" has no wasm export`
      + ` (\`${candidate_names.join('` or `')}\`) and is not a listed exception.`,
    );
  }
  for (const exception_member of WASM_CONTRACT_MEMBER_EXCEPTIONS.keys()) {
    assert(
      map_sdk_members.includes(exception_member),
      `The wasm exception list names "${exception_member}", which the UDL`
      + ` contract's MapSdk no longer declares; drop the stale entry.`,
    );
  }
}

/**
 * @param {ParsedContract} contract
 * @param {WasmExports} generated_exports
 */
function assert_generated_exports_agree(contract, generated_exports) {
  const contract_methods = contract.interface_members.get(CONTRACT_CAMERA_INTERFACE_NAME);
  assert(contract_methods !== undefined, 'The UDL contract declares the camera interface.');
  assert_members_present(
    generated_exports.camera_method_names,
    FROZEN_CAMERA_METHOD_NAMES,
    'The generated pkg "MapCamera" class',
  );
  assert_members_present(
    generated_exports.free_function_names,
    FROZEN_FREE_HELPER_NAMES,
    'The generated pkg free helper functions',
  );
  for (const generated_method of generated_exports.camera_method_names) {
    if (generated_method === GENERATED_CONSTRUCTOR_METHOD_NAME
      || generated_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      contract_methods.includes(contract_spelling_of(generated_method)),
      `The generated pkg "MapCamera" class invents the member "${generated_method}".`,
    );
  }
  const generated_map_sdk_members =
    contract.interface_members.get(CONTRACT_MAP_SDK_INTERFACE_NAME) ?? [];
  for (const generated_helper of generated_exports.free_function_names) {
    assert(
      contract.namespace_members.includes(contract_spelling_of(generated_helper))
      || generated_map_sdk_members.includes(contract_spelling_of(generated_helper))
      || WASM_ONLY_FREE_HELPER_NAMES.includes(generated_helper),
      `The generated pkg invents the free helper "${generated_helper}".`,
    );
  }
  const route_simulator_methods = contract.interface_members.get(
    CONTRACT_ROUTE_SIMULATOR_INTERFACE_NAME,
  );
  assert(
    route_simulator_methods !== undefined,
    'The UDL contract declares the RouteSimulator interface.',
  );
  assert_members_present(
    generated_exports.route_simulator_method_names,
    FROZEN_ROUTE_SIMULATOR_METHOD_NAMES,
    'The generated pkg "RouteSimulator" class',
  );
  for (const generated_method of generated_exports.route_simulator_method_names) {
    if (generated_method === GENERATED_CONSTRUCTOR_METHOD_NAME
      || generated_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      route_simulator_methods.includes(contract_spelling_of(generated_method)),
      `The generated pkg "RouteSimulator" class invents the member`
      + ` "${generated_method}".`,
    );
  }
  const navigator_methods = contract.interface_members.get(
    CONTRACT_NAVIGATOR_INTERFACE_NAME,
  );
  assert(
    navigator_methods !== undefined,
    'The UDL contract declares the Navigator interface.',
  );
  assert_members_present(
    generated_exports.navigator_method_names,
    FROZEN_NAVIGATOR_METHOD_NAMES,
    'The generated pkg "Navigator" class',
  );
  for (const generated_method of generated_exports.navigator_method_names) {
    if (generated_method === GENERATED_CONSTRUCTOR_METHOD_NAME
      || generated_method === WASM_CONSTRUCTOR_METHOD_NAME) {
      continue;
    }
    assert(
      navigator_methods.includes(contract_spelling_of(generated_method))
      || WASM_ONLY_NAVIGATOR_METHOD_NAMES.includes(generated_method),
      `The generated pkg "Navigator" class invents the member`
      + ` "${generated_method}".`,
    );
  }
}

/**
 * Runs every contract-sync comparison; throws on the first drift. Shared by
 * the `node --test` registration and the Playwright `globalSetup`.
 */
function run_contract_sync_checks() {
  const contract = parse_uniffi_contract(readFileSync(UNIFFI_CONTRACT_PATH, 'utf8'));
  const mirror = parse_typescript_mirror(readFileSync(TYPESCRIPT_MIRROR_PATH, 'utf8'));
  const wasm_exports = parse_wasm_exports(
    readFileSync(WASM_EXPORTS_PATH, 'utf8'),
    readFileSync(WASM_NAVIGATION_EXPORTS_PATH, 'utf8'),
    readFileSync(WASM_CANVAS_EXPORTS_PATH, 'utf8'),
    readFileSync(WASM_LIVE_PROVIDERS_PATH, 'utf8'),
    readFileSync(WASM_DIAGNOSTICS_PATH, 'utf8'),
  );

  assert_mirror_dictionaries_agree(contract, mirror);
  assert_error_variants_agree(contract, mirror);
  assert_camera_methods_agree(contract, wasm_exports);
  assert_route_simulator_methods_agree(contract, wasm_exports);
  assert_navigator_methods_agree(contract, wasm_exports);
  assert_map_view_methods_agree(contract, wasm_exports);
  assert_bounds_fitting_agrees(
    readFileSync(UNIFFI_CONTRACT_PATH, 'utf8'),
    readFileSync(WASM_EXPORTS_PATH, 'utf8'),
  );
  assert_free_helpers_agree(contract, wasm_exports);
  assert_map_sdk_members_have_wasm_counterparts(contract, wasm_exports);
  // The generated pkg declarations are a build artifact and may be absent on
  // a fresh checkout; the parity is then already covered through exports.rs.
  let generated_exports = null;
  try {
    generated_exports = parse_generated_wasm_typescript(
      readFileSync(GENERATED_TYPESCRIPT_PATH, 'utf8'),
    );
  } catch (generated_is_absent) {
    generated_exports = null;
  }
  if (generated_exports !== null) {
    assert_generated_exports_agree(contract, generated_exports);
  }
}

export {
  convert_contract_field_name_to_typescript,
  parse_typescript_mirror,
  parse_uniffi_contract,
  run_contract_sync_checks,
};

/** The `node --test` suite name of the parity assertions. */
const CONTRACT_SYNC_TEST_NAME =
  'the wasm TypeScript surface mirrors the frozen UniFFI contract';

// Run the suite only when this file is the entry point; the Playwright
// `globalSetup` imports the exported runner instead.
const RUNNING_AS_ENTRY = process.argv[1] !== undefined
  && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;

if (RUNNING_AS_ENTRY) {
  test(CONTRACT_SYNC_TEST_NAME, () => {
    run_contract_sync_checks();
  });
}