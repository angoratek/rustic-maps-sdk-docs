// The wasm canvas' vector-source contract members (M31 round 76): the status
// readback is honest before an install, after a refused install, after a
// refused render, and after a clear, and the install path refuses malformed
// descriptors without throwing across the boundary as a panic. The status
// object is the UDL `VectorTileSourceStatus` mirror; the page's base-map line
// reads it every frame.
import { expect, test } from '@playwright/test';

/** The renderer-readiness budget (a slow first WebGPU init). */
const RENDERER_READINESS_TIMEOUT_MILLISECONDS = 30_000;

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => window.mapTestReady);
  await expect
    .poll(() => page.evaluate(() => window.mapRendererMode()), {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .toBe('gpu');
});

/** Builds an off-screen canvas bound to the page's SDK root. */
async function create_probe_view(page) {
  return page.evaluate(async () => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    canvas.style.position = 'fixed';
    canvas.style.left = '-10000px';
    document.body.appendChild(canvas);
    const map_view = new window.mapTest.MapView(canvas, window.mapTest.maps);
    await map_view.initialize();
    window.vectorSourceProbeView = map_view;
    return true;
  });
}

test('the status answers not-configured, configured and cleared in the contract shape', async ({
  page,
}) => {
  await create_probe_view(page);

  const status_before = await page.evaluate(() => {
    const status = window.vectorSourceProbeView.vectorTileSourceStatus();
    return {
      keys: Object.keys(status).sort(),
      isConfigured: status.isConfigured,
      styleId: status.styleId,
      sourceName: status.sourceName,
      attributionText: status.attributionText,
      maximumZoomLevel: status.maximumZoomLevel,
      drawnTileCount: status.drawnTileCount,
      failedTileCount: status.failedTileCount,
      lastFailureDetail: status.lastFailureDetail,
    };
  });
  // The UDL record's field set, in the seam's lower-camel spelling.
  expect(status_before.keys).toEqual([
    'attributionText',
    'drawnTileCount',
    'failedTileCount',
    'isConfigured',
    'lastFailureDetail',
    'maximumZoomLevel',
    'sourceName',
    'styleId',
  ]);
  expect(status_before.isConfigured).toBe(false);
  expect(status_before.styleId).toBe('');
  expect(status_before.sourceName).toBe('');
  expect(status_before.attributionText).toBe('');
  expect(status_before.maximumZoomLevel).toBe(0);
  expect(status_before.drawnTileCount).toBe(0);
  expect(status_before.failedTileCount).toBe(0);
  expect(status_before.lastFailureDetail).toBeNull();

  const install_outcome = await page.evaluate(() => {
    const map_view = window.vectorSourceProbeView;
    try {
      map_view.setVectorTileSource({
        urlTemplate: `${window.location.origin}/vector-source-probe/{z}/{x}/{y}.pbf`,
        sourceName: 'probe-tileset',
        attributionText: 'Probe attribution',
        styleId: 'bright-light',
        minimumZoomLevel: 0,
        maximumZoomLevel: 14,
      });
      return { accepted: true };
    } catch (install_failure) {
      return { accepted: false, detail: String(install_failure) };
    }
  });
  expect(install_outcome).toEqual({ accepted: true });

  const status_after = await page.evaluate(() => {
    const status = window.vectorSourceProbeView.vectorTileSourceStatus();
    return {
      isConfigured: status.isConfigured,
      styleId: status.styleId,
      sourceName: status.sourceName,
      attributionText: status.attributionText,
      maximumZoomLevel: status.maximumZoomLevel,
    };
  });
  expect(status_after).toEqual({
    isConfigured: true,
    styleId: 'bright-light',
    sourceName: 'probe-tileset',
    attributionText: 'Probe attribution',
    maximumZoomLevel: 14,
  });

  // A clear leaves the honest not-configured status behind.
  await page.evaluate(() => window.vectorSourceProbeView.clearVectorTileSource());
  const status_cleared = await page.evaluate(() => {
    const status = window.vectorSourceProbeView.vectorTileSourceStatus();
    return {
      isConfigured: status.isConfigured,
      styleId: status.styleId,
      drawnTileCount: status.drawnTileCount,
      lastFailureDetail: status.lastFailureDetail,
    };
  });
  expect(status_cleared).toEqual({
    isConfigured: false,
    styleId: '',
    drawnTileCount: 0,
    lastFailureDetail: null,
  });
});

test('a malformed descriptor is refused verbatim and leaves the previous source in force', async ({
  page,
}) => {
  await create_probe_view(page);
  const refusals = await page.evaluate(() => {
    const map_view = window.vectorSourceProbeView;
    const valid_source = {
      urlTemplate: `${window.location.origin}/vector-source-probe/{z}/{x}/{y}.pbf`,
      sourceName: 'probe-tileset',
      attributionText: 'Probe attribution',
      styleId: 'bright-light',
      minimumZoomLevel: 0,
      maximumZoomLevel: 14,
    };
    map_view.setVectorTileSource(valid_source);
    const attempts = [
      { ...valid_source, styleId: 'no-such-style' },
      { ...valid_source, sourceName: '' },
      { ...valid_source, minimumZoomLevel: 15, maximumZoomLevel: 14 },
      { ...valid_source, urlTemplate: 'not-a-tile-template' },
      { ...valid_source, maximumZoomLevel: 'fourteen' },
    ];
    const details = attempts.map(attempt => {
      try {
        map_view.setVectorTileSource(attempt);
        return 'unexpectedly accepted';
      } catch (refusal) {
        return String(refusal);
      }
    });
    return {
      details,
      stillConfigured: map_view.vectorTileSourceStatus().isConfigured,
      stillStyled: map_view.vectorTileSourceStatus().styleId,
    };
  });
  expect(refusals.details[0]).toContain('style the SDK does not carry');
  expect(refusals.details[1]).toContain('source name must be non-empty');
  expect(refusals.details[2]).toContain('inverted zoom range');
  expect(refusals.details[3]).toContain('lacks the');
  expect(refusals.details[4]).toContain('maximumZoomLevel');
  expect(refusals.stillConfigured).toBe(true);
  expect(refusals.stillStyled).toBe('bright-light');
});
