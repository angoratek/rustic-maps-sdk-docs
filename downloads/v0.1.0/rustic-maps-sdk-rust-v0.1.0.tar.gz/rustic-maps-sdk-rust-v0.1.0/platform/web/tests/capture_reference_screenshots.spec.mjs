// Captures the browser reference-application screenshots the documentation
// publishes: the plan sheet with both endpoints chosen, the provider section
// with every row's display name and credential state, and the navigation
// frame with the turn banner, planned polyline, ETA line and speed controls.
//
// The capture is opt-in so the ordinary suite stays read-only:
//
//   CAPTURE_REFERENCE_SCREENSHOTS=1 npx playwright test \
//     tests/capture_reference_screenshots.spec.mjs --workers=1
//
// Output lands under `tmp/reference-screenshots/web/` for review; only a
// reviewed set from one revision is copied into `site/book-src/img/`.
import { mkdir } from 'node:fs/promises';
import path from 'node:path';
import { test, expect } from '@playwright/test';

import { waitForMapTestReady } from './network_guard.mjs';

const OUTPUT_DIRECTORY = path.resolve(
  import.meta.dirname,
  '../../../tmp/reference-screenshots/web',
);
const OUTPUT_VIEWPORT = Object.freeze({ width: 1280, height: 1200 });
const ROUTE_SETTLE_TIMEOUT_MILLISECONDS = 15_000;
const CAPTURE_SETTLE_MILLISECONDS = 750;

const CAPTURE_ENABLED = process.env.CAPTURE_REFERENCE_SCREENSHOTS === '1';

/** Fills one plan field through its own Search action and assigns the row. */
async function assignPlace(page, fieldKey, value) {
  const input = page.locator(`#trip-${fieldKey}-input`);
  await input.fill(value);
  await page.locator(`#trip-${fieldKey}-search-control`).click();
  const results = page.locator('#trip-search-results');
  await expect(results).toBeVisible();
  const matching = results.getByRole('button', { name: new RegExp(value) }).first();
  await matching.click();
}

test.describe('reference application screenshot capture', () => {
  test.skip(!CAPTURE_ENABLED, 'capture-only; set CAPTURE_REFERENCE_SCREENSHOTS=1');

  test.use({ viewport: OUTPUT_VIEWPORT });

  test.beforeAll(async () => {
    await mkdir(OUTPUT_DIRECTORY, { recursive: true });
  });

  test('captures the plan sheet, provider section and navigation frame', async ({
    page,
  }) => {
    await page.goto('/');
    await waitForMapTestReady(page);

    await assignPlace(page, 'origin', 'Capitol Park');
    await assignPlace(page, 'destination', 'Tower Bridge');
    await page.locator('#trip-plan-route-control').click();
    await expect(page.locator('#trip-route-result')).toBeVisible({
      timeout: ROUTE_SETTLE_TIMEOUT_MILLISECONDS,
    });
    await page.waitForTimeout(CAPTURE_SETTLE_MILLISECONDS);
    await page.screenshot({
      path: path.join(OUTPUT_DIRECTORY, 'plan-sheet.png'),
    });

    await page.reload();
    await waitForMapTestReady(page);
    await page.locator('#settings-control').click();
    const settingsDialog = page.locator('#settings-dialog');
    await expect(settingsDialog).toBeVisible();
    // The row shows the composed `{display name} · {state}` text once a
    // provider serves; select the keyless routing choice, which registers
    // the descriptor's public demo deployment without a credential. The
    // capture shows the same row the reference apps render.
    const routingPicker = page.locator('#capability-provider-select-routing');
    const keylessRoutingKey = await routingPicker
      .locator('option[data-provider-role="keyless"]')
      .first()
      .getAttribute('value');
    await routingPicker.selectOption(keylessRoutingKey);
    await expect(page.locator('#capability-provider-serving-routing')).toContainText(
      '·',
      { timeout: ROUTE_SETTLE_TIMEOUT_MILLISECONDS },
    );
    // Bring the routing row and the demo-endpoint term it adds into frame.
    await page
      .locator('#capability-provider-endpoint-routing')
      .scrollIntoViewIfNeeded();
    await page.waitForTimeout(CAPTURE_SETTLE_MILLISECONDS);
    await page.screenshot({
      path: path.join(OUTPUT_DIRECTORY, 'provider-section.png'),
    });

    await page.reload();
    await waitForMapTestReady(page);
    await page.evaluate(() => window.runReferenceFlow('plan_and_navigate'));
    await expect
      .poll(() => page.evaluate(() => window.mapFollowDemoState?.().phase), {
        timeout: ROUTE_SETTLE_TIMEOUT_MILLISECONDS,
      })
      .toBe('engaged');
    // The trip drawer (ETA line, speed controls, pause and exit) sits at the
    // bottom of the floating panel; settle the panel there for the frame.
    await page.locator('#controls').evaluate((panel) => {
      panel.scrollTop = panel.scrollHeight;
    });
    await page.waitForTimeout(CAPTURE_SETTLE_MILLISECONDS);
    await page.screenshot({
      path: path.join(OUTPUT_DIRECTORY, 'navigation.png'),
    });
  });
});
