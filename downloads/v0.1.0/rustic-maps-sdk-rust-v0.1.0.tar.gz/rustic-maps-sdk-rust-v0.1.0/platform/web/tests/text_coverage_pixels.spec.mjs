// The browser half of the SDF edge proof (M30 Slice D): render one white `I`
// on the wasm canvas with the base map hidden and no halo, read the freshly
// presented frame back through a 2D canvas, and measure the same coverage
// profile the headless golden test measures. A 1× and a 2× display must both
// keep the stroke interior at ≥ 0.98 coverage and the transition beside the
// stroke at no more than two device pixels; the label's point size is the
// same at both ratios, only its device size doubles.
import { expect, test } from '@playwright/test';

/** The probe frame's CSS edge in pixels. */
const PROBE_CSS_EDGE_PIXELS = 256;
/** The text size the probe label declares (CSS/point pixels). */
const PROBE_TEXT_SIZE_PIXELS = 48;
/** Coverage a stroke interior must reach. */
const COVERAGE_INTERIOR_MINIMUM = 0.98;
/** Coverage below this is background. */
const COVERAGE_EDGE_MINIMUM = 0.05;
/** Coverage above this is plateau, not transition. */
const COVERAGE_EDGE_MAXIMUM = 0.95;
/** The widest transition a stroke edge may span, in device pixels. */
const MAXIMUM_EDGE_RUN_PIXELS = 2;
/** The camera the probe renders at (the fixture anchor). */
const PROBE_LATITUDE_DEGREES = 38.5766;
const PROBE_LONGITUDE_DEGREES = -121.4944;
const PROBE_ZOOM_LEVEL = 14;
/** The glyph range the harness serves same-origin. */
const GLYPH_RANGE_URL = './glyphs/Noto%20Sans%20Regular/0-255.pbf';

/** Renders the isolated label frame in-page and returns its pixels. */
async function probe_frame_pixels(page, device_pixel_ratio) {
  return page.evaluate(
    async ([css_edge, text_size, latitude, longitude, zoom, glyph_url, ratio]) => {
      const canvas = document.createElement('canvas');
      canvas.style.width = `${css_edge}px`;
      canvas.style.height = `${css_edge}px`;
      canvas.width = css_edge * ratio;
      canvas.height = css_edge * ratio;
      canvas.style.position = 'fixed';
      canvas.style.left = '-10000px';
      document.body.appendChild(canvas);

      const map_view = new window.mapTest.MapView(canvas, window.mapTest.maps);
      await map_view.initialize();
      map_view.setBaseMapVisible(false);
      map_view.setBackgroundColor(0, 0, 0, 1);
      const glyph_response = await fetch(glyph_url);
      if (!glyph_response.ok) {
        throw new Error(`the glyph range is not served: ${glyph_response.status}`);
      }
      map_view.setGlyphRange(
        new Uint8Array(await glyph_response.arrayBuffer()),
      );
      map_view.setLabels([{
        text: 'I',
        latitude,
        longitude,
        sizePixels: text_size,
        color: { red: 1, green: 1, blue: 1, alpha: 1 },
        haloWidthPixels: 0,
        priority: 0,
        rank: 0,
        styleOrder: 0,
        allowOverlap: true,
      }]);
      const camera = new window.mapTest.MapCamera(
        latitude, longitude, zoom, 0, 0);
      await map_view.renderFrame(camera, 60);
      // drawImage on a WebGPU canvas reads the freshly presented frame only;
      // sample the next animation frame's snapshot (the golden harness's
      // same rule).
      await new Promise((resolve) => requestAnimationFrame(resolve));
      const probe_canvas = document.createElement('canvas');
      probe_canvas.width = canvas.width;
      probe_canvas.height = canvas.height;
      const probe_context = probe_canvas.getContext('2d');
      probe_context.drawImage(canvas, 0, 0);
      const image_data = probe_context.getImageData(
        0, 0, probe_canvas.width, probe_canvas.height);
      canvas.remove();
      return {
        width: probe_canvas.width,
        height: probe_canvas.height,
        bytes: Array.from(image_data.data),
      };
    },
    [
      PROBE_CSS_EDGE_PIXELS,
      PROBE_TEXT_SIZE_PIXELS,
      PROBE_LATITUDE_DEGREES,
      PROBE_LONGITUDE_DEGREES,
      PROBE_ZOOM_LEVEL,
      GLYPH_RANGE_URL,
      device_pixel_ratio,
    ],
  );
}

/** The coverage profile of one frame, mirroring the headless test's math. */
function coverage_profile(frame) {
  const pixel_luminance = (offset) =>
    (frame.bytes[offset] + frame.bytes[offset + 1] + frame.bytes[offset + 2]) / 3;
  const pixel_count = frame.width * frame.height;
  const luminances = [];
  for (let pixel = 0; pixel < pixel_count; pixel += 1) {
    luminances.push(pixel_luminance(pixel * 4));
  }
  const corner_luminances = [
    luminances[0],
    luminances[frame.width - 1],
    luminances[(frame.height - 1) * frame.width],
    luminances[frame.height * frame.width - 1],
  ];
  const background =
    corner_luminances.reduce((sum, value) => sum + value, 0)
    / corner_luminances.length;
  const text = luminances.reduce(
    (maximum, value) => Math.max(maximum, value), background);
  expect(text).toBeGreaterThan(background + 1);
  const coverage = luminances.map(
    (value) => Math.min(1, Math.max(0, (value - background) / (text - background))));
  const coverage_at = (x, y) => coverage[y * frame.width + x];

  let best = null;
  for (let y = 0; y < frame.height; y += 1) {
    let x = 0;
    while (x < frame.width) {
      if (coverage_at(x, y) < COVERAGE_INTERIOR_MINIMUM) {
        x += 1;
        continue;
      }
      const run_start = x;
      while (x < frame.width && coverage_at(x, y) >= COVERAGE_INTERIOR_MINIMUM) {
        x += 1;
      }
      const run_length = x - run_start;
      if (best === null || run_length > best.run_length) {
        best = { run_length, run_start, row: y };
      }
    }
  }
  expect(best).not.toBeNull();

  let left_edge = 0;
  let left_x = best.run_start;
  while (
    left_x > 0
    && coverage_at(left_x - 1, best.row) > COVERAGE_EDGE_MINIMUM
    && coverage_at(left_x - 1, best.row) < COVERAGE_EDGE_MAXIMUM
  ) {
    left_edge += 1;
    left_x -= 1;
  }
  let right_x = best.run_start + best.run_length;
  let right_edge = 0;
  while (
    right_x < frame.width
    && coverage_at(right_x, best.row) > COVERAGE_EDGE_MINIMUM
    && coverage_at(right_x, best.row) < COVERAGE_EDGE_MAXIMUM
  ) {
    right_edge += 1;
    right_x += 1;
  }

  const interior_pixel_count = coverage.filter(
    (value) => value >= COVERAGE_INTERIOR_MINIMUM).length;
  return { interior_pixel_count, left_edge, right_edge };
}

/** Asserts the profile facts for one rendered probe frame. */
function expect_crisp_profile(frame, device_pixel_ratio) {
  expect(frame.width).toBe(PROBE_CSS_EDGE_PIXELS * device_pixel_ratio);
  const profile = coverage_profile(frame);
  expect(
    profile.interior_pixel_count,
    `the stroke must reach full coverage at ${device_pixel_ratio}×`,
  ).toBeGreaterThan(0);
  expect(
    profile.left_edge,
    `the left stroke edge at ${device_pixel_ratio}×`,
  ).toBeLessThanOrEqual(MAXIMUM_EDGE_RUN_PIXELS);
  expect(
    profile.right_edge,
    `the right stroke edge at ${device_pixel_ratio}×`,
  ).toBeLessThanOrEqual(MAXIMUM_EDGE_RUN_PIXELS);
}

test.describe('at a 1× display', () => {
  test.use({
    viewport: { width: 800, height: 600 },
    deviceScaleFactor: 1,
  });

  test('the wasm canvas draws a full-coverage stroke with a two-pixel edge', async ({
    page,
  }) => {
    await page.goto('/?advanced');
    await page.evaluate(() => window.mapTestReady);
    expect_crisp_profile(await probe_frame_pixels(page, 1), 1);
  });
});

test.describe('at a 2× display', () => {
  test.use({
    viewport: { width: 800, height: 600 },
    deviceScaleFactor: 2,
  });

  test('the same point size keeps its full interior and a device-pixel edge', async ({
    page,
  }) => {
    await page.goto('/?advanced');
    await page.evaluate(() => window.mapTestReady);
    expect_crisp_profile(await probe_frame_pixels(page, 2), 2);
  });
});
