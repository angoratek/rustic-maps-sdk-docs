// The on-map layer control and the device-location affordances
// (docs/design/MapControlsAndTrafficLayer.md): the panel's base-map rows, the
// traffic layer fetched from the committed flow fixture, the demo-scene
// switches, the keyboard contract, the remembered choices and the route
// fields' "My location" chips. Every provider fact comes from the shared
// registry and every payload is a committed fixture served same-origin, so no
// test touches the network.
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { expect, test, waitForMapTestReady } from './network_guard.mjs';

import {
  DEVICE_LOCATION_STATUS_IDENTIFIER,
  MAP_LAYER_BASE_ROW_IDENTIFIER_PREFIX,
  MAP_LAYER_SCENE_ROW_IDENTIFIER_PREFIX,
  MAP_LAYER_STYLE_ROW_IDENTIFIER_PREFIX,
  MAP_LAYER_TRAFFIC_IDENTIFIER,
  TRAFFIC_REFRESH_DEBOUNCE_MILLISECONDS,
} from '../map_layers.mjs';

const TEST_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));
const REPOSITORY_ROOT = path.resolve(TEST_DIRECTORY, '..', '..', '..');
const PREFERENCES_STORAGE_KEY = 'rustic-maps-demo-preferences';

/** The settle budget for a renderer-bound assertion. */
const RENDERER_READINESS_TIMEOUT_MILLISECONDS = 20_000;
/** The traffic debounce's own budget plus margin. */
const TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS =
  TRAFFIC_REFRESH_DEBOUNCE_MILLISECONDS + 10_000;
/** The stubbed device position, and its accuracy in meters. */
const DEVICE_LATITUDE_DEGREES = 38.5766;
const DEVICE_LONGITUDE_DEGREES = -121.4944;
const DEVICE_ACCURACY_METERS = 5;

const providers_registry = JSON.parse(
  readFileSync(path.join(REPOSITORY_ROOT, 'platform', 'providers.json'), 'utf8'),
);
const reference_scenes = JSON.parse(
  readFileSync(path.join(REPOSITORY_ROOT, 'platform', 'reference-scenes.json'), 'utf8'),
);

/** The first raster descriptor a base row is built from. */
const raster_base_descriptor = providers_registry.providers.find(
  (provider_descriptor) => (provider_descriptor.fixture_routes ?? []).some(
    (fixture_route) => fixture_route.purpose === 'raster_tiles'));

/** A vector descriptor offering committed styles and a vector-tile fixture. */
const vector_descriptor = providers_registry.providers.find(
  (provider_descriptor) =>
    typeof provider_descriptor.url_template === 'string'
    && (provider_descriptor.vector_styles ?? []).length > 0
    && (provider_descriptor.fixture_routes ?? []).some(
      (fixture_route) => fixture_route.purpose === 'vector_tiles'));
const VECTOR_STYLE = vector_descriptor.vector_styles[0];
const VECTOR_TILE_FIXTURE = readFileSync(path.join(
  REPOSITORY_ROOT,
  vector_descriptor.fixture_routes.find(
    (fixture_route) => fixture_route.purpose === 'vector_tiles').fixture,
));

/** The descriptor that declares the traffic-flow capability. */
const traffic_descriptor = providers_registry.providers.find(
  (provider_descriptor) =>
    (provider_descriptor.served_contracts ?? []).includes('traffic_flow'));
const TRAFFIC_REQUEST_PATH =
  `${providers_registry.fixture_base_path}/${traffic_descriptor.provider_key}`;

/** The first demo scene key and its label (the switch's row). */
const [SCENE_KEY, SCENE] = Object.entries(reference_scenes.overlay_scenes)[0];
const SCENE_LABEL = SCENE.label;

/** Answers vector-tile requests from the committed fixture. */
async function serve_vector_tiles(page) {
  const serves_protobuf = vector_descriptor.url_template.endsWith('.pbf');
  const content_type = serves_protobuf
    ? 'application/x-protobuf'
    : 'application/vnd.mapbox-vector-tile';
  await page.route(serves_protobuf ? '**/*.pbf' : '**/*.mvt', (route) =>
    route.fulfill({
      status: 200,
      contentType: content_type,
      body: VECTOR_TILE_FIXTURE,
    }));
}

/** Applies the traffic provider's credential through the page's own seam, so
 * the wasm registry serves the capability from the same-origin fixtures. */
async function apply_traffic_credential(page) {
  await page.locator('#settings-control').click();
  const credential_row = page.locator(
    `[data-provider-key="${traffic_descriptor.provider_key}"]`);
  await credential_row.locator('[data-provider-credential-input]').fill('test-key');
  await credential_row.locator('[data-provider-credential-apply]').click();
  await expect(
    credential_row.locator('.provider-applied-chip'),
  ).toBeVisible();
  await page.keyboard.press('Escape');
}

/** Waits until the renderer's mode is known (`gpu` or the 2D fallback). */
async function wait_for_renderer(page) {
  await expect
    .poll(() => page.evaluate(() => (typeof window.mapRendererMode === 'function' ? window.mapRendererMode() : null)), {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .not.toBeNull();
  return page.evaluate(() => (typeof window.mapRendererMode === 'function' ? window.mapRendererMode() : null));
}

/** Opens the map layers panel. */
async function open_map_layers_panel(page) {
  await page.locator('#map-layers-control').click();
  await expect(page.locator('#map-layers-panel')).toBeVisible();
}

/** The stored demo-preferences record. */
async function stored_preferences(page) {
  return page.evaluate((storage_key) => {
    const stored_text = window.localStorage.getItem(storage_key);
    return stored_text === null ? null : JSON.parse(stored_text);
  }, PREFERENCES_STORAGE_KEY);
}

test('the panel lists the sections in order and switches raster to a vector style', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await serve_vector_tiles(page);
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  const renderer_mode = await wait_for_renderer(page);
  if (renderer_mode !== 'gpu') {
    test.skip(true, 'headless WebGPU unavailable; the vector base needs the GPU renderer');
    return;
  }

  await open_map_layers_panel(page);
  const section_titles = await page
    .locator('#map-layers-panel > .map-layers-section > h3')
    .allTextContents();
  expect(section_titles.slice(0, 3)).toEqual(['Base map', 'Traffic', 'Overlays']);
  // The attribution notice is the live region a layer change is announced in.
  await expect(page.locator('#attribution-notice')).toHaveAttribute(
    'aria-live', 'polite');

  // The default raster row is the one serving.
  const raster_row = page.locator(
    `#${MAP_LAYER_BASE_ROW_IDENTIFIER_PREFIX}${raster_base_descriptor.provider_key}`);
  await expect(raster_row).toHaveAttribute('aria-pressed', 'true');
  await expect(raster_row).toContainText('Serving');

  // Select one committed vector style: the same switch the settings picker
  // performs, with the style applied.
  const style_row = page.locator(
    `#${MAP_LAYER_STYLE_ROW_IDENTIFIER_PREFIX}${VECTOR_STYLE.style_id}`);
  await style_row.click();
  await expect
    .poll(() => page.evaluate(() => window.mapTileMode()), {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .toBe('vector');
  expect(await page.evaluate(() => window.mapVectorProviderKey()))
    .toBe(vector_descriptor.provider_key);
  await expect(style_row).toHaveAttribute('aria-pressed', 'true');
  await expect(style_row).toContainText('Serving');
  await expect(raster_row).toHaveAttribute('aria-pressed', 'false');

  // The choice survives a reload.
  await page.reload();
  await waitForMapTestReady(page);
  await expect
    .poll(() => page.evaluate(() => window.mapTileMode()), {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .toBe('vector');
  expect(await page.evaluate(() => window.mapVectorProviderKey()))
    .toBe(vector_descriptor.provider_key);
  await open_map_layers_panel(page);
  await expect(page.locator(
    `#${MAP_LAYER_STYLE_ROW_IDENTIFIER_PREFIX}${VECTOR_STYLE.style_id}`,
  )).toHaveAttribute('aria-pressed', 'true');
});

test('switching a vector base back to raster clears its styled geometry', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await serve_vector_tiles(page);
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  const renderer_mode = await wait_for_renderer(page);
  if (renderer_mode !== 'gpu') {
    test.skip(true, 'headless WebGPU unavailable; the vector base needs the GPU renderer');
    return;
  }

  // The frame's overlay triangle count is what the renderer actually draws
  // over the base: the page's own overlays plus, while a vector base serves,
  // the style's fills and lines.
  const frame_overlay_triangles = () =>
    page.evaluate(() => window.mapLastFrameStats()?.overlayTriangles ?? 0);
  const raster_triangles = await frame_overlay_triangles();

  await open_map_layers_panel(page);
  const style_row = page.locator(
    `#${MAP_LAYER_STYLE_ROW_IDENTIFIER_PREFIX}${VECTOR_STYLE.style_id}`);
  await style_row.click();
  await expect
    .poll(frame_overlay_triangles, {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .toBeGreaterThan(raster_triangles);

  // Back to the raster base: the vector style's geometry must be gone from
  // the very next frames, not left painting over the tiles.
  const raster_row = page.locator(
    `#${MAP_LAYER_BASE_ROW_IDENTIFIER_PREFIX}${raster_base_descriptor.provider_key}`);
  await raster_row.click();
  await expect
    .poll(frame_overlay_triangles, {
      timeout: RENDERER_READINESS_TIMEOUT_MILLISECONDS,
    })
    .toBe(raster_triangles);
  // And it stays gone: a later frame carries the same geometry.
  await page.evaluate(() => new Promise((resolve) => {
    window.requestAnimationFrame(() => window.requestAnimationFrame(resolve));
  }));
  expect(await frame_overlay_triangles()).toBe(raster_triangles);
});

test('the traffic switch installs one overlay per settle and clears when off', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  await apply_traffic_credential(page);

  // Every traffic request must be the same-origin fixture route.
  const traffic_request_urls = [];
  page.on('request', (request) => {
    if (request.url().includes(TRAFFIC_REQUEST_PATH)) {
      traffic_request_urls.push(request.url());
    }
  });

  await open_map_layers_panel(page);
  const traffic_switch = page.locator(`#${MAP_LAYER_TRAFFIC_IDENTIFIER}`);
  await expect(traffic_switch).toHaveAttribute('role', 'switch');
  await expect(traffic_switch).toHaveAttribute('aria-checked', 'false');
  await traffic_switch.click();
  await expect(traffic_switch).toHaveAttribute('aria-checked', 'true');

  // One settle yields exactly one overlay install from the fixture.
  await expect
    .poll(
      () => page.evaluate(() => window.mapTrafficLayerState().overlayInstallCount),
      { timeout: TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS },
    )
    .toBe(1);
  const first_state = await page.evaluate(() => window.mapTrafficLayerState());
  expect(first_state.segmentCount).toBeGreaterThan(0);
  expect(traffic_request_urls.length).toBe(1);
  expect(traffic_request_urls[0].startsWith('http://127.0.0.1:8642')).toBe(true);
  expect(traffic_request_urls[0]).toContain(`${TRAFFIC_REQUEST_PATH}/`);
  // While the layer is on, its serving descriptor's attribution is present.
  await expect(page.locator('#attribution-notice')).toContainText(
    traffic_descriptor.attribution_text);

  // A small camera pan causes one more refresh after the debounce. It stays
  // inside the traffic cache's grid cell, so the page asks again but the
  // provider is not called again: the answer comes from memory.
  await page.locator('#map-overlay').focus();
  await page.keyboard.press('ArrowRight');
  await expect
    .poll(
      () => page.evaluate(() => window.mapTrafficLayerState().overlayInstallCount),
      { timeout: TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS },
    )
    .toBe(2);
  expect(await page.evaluate(() => window.mapTrafficLayerState().fetchCount)).toBe(2);
  expect(traffic_request_urls.length).toBe(1);
  const cache_statistics = await page.evaluate(
    () => window.mapTest.trafficFlowCacheStatistics(),
  );
  expect(cache_statistics.hitCount).toBe(1);
  expect(cache_statistics.missCount).toBe(1);

  // Turning the layer off clears the overlay.
  await traffic_switch.click();
  await expect(traffic_switch).toHaveAttribute('aria-checked', 'false');
  await expect
    .poll(() => page.evaluate(() => window.mapTrafficLayerState()))
    .toMatchObject({ enabled: false, segmentCount: 0 });
});

test('a remembered traffic choice restores only while a provider serves it', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);

  // Remember the key so the reload's registration path can restore the layer.
  await page.locator('#settings-control').click();
  await page.locator('#remember-provider-credential').check();
  const credential_row = page.locator(
    `[data-provider-key="${traffic_descriptor.provider_key}"]`);
  await credential_row.locator('[data-provider-credential-input]').fill('test-key');
  await credential_row.locator('[data-provider-credential-apply]').click();
  await expect(credential_row.locator('.provider-applied-chip')).toBeVisible();
  await page.keyboard.press('Escape');

  await open_map_layers_panel(page);
  await page.locator(`#${MAP_LAYER_TRAFFIC_IDENTIFIER}`).click();
  await expect
    .poll(
      () => page.evaluate(() => window.mapTrafficLayerState().enabled),
      { timeout: TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS },
    )
    .toBe(true);
  expect((await stored_preferences(page)).trafficLayerEnabled).toBe(true);

  // The reload re-applies the remembered key and then the layer.
  await page.reload();
  await waitForMapTestReady(page);
  await expect
    .poll(
      () => page.evaluate(() => window.mapTrafficLayerState().enabled),
      { timeout: TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS },
    )
    .toBe(true);
  await expect
    .poll(
      () => page.evaluate(() => window.mapTrafficLayerState().overlayInstallCount),
      { timeout: TRAFFIC_SETTLE_TIMEOUT_MILLISECONDS },
    )
    .toBeGreaterThan(0);

  // Clearing the remembered key removes the provider: the next visit starts
  // with traffic off instead of pretending the layer can be served.
  await page.locator('#settings-control').click();
  await credential_row.locator('[data-provider-credential-clear]').click();
  await page.keyboard.press('Escape');
  expect(await page.evaluate(() => window.mapTrafficLayerState().enabled)).toBe(false);
  await page.reload();
  await waitForMapTestReady(page);
  await open_map_layers_panel(page);
  await expect
    .poll(() => page.evaluate(() => window.mapTrafficLayerState().enabled))
    .toBe(false);
  await expect(page.locator(`#${MAP_LAYER_TRAFFIC_IDENTIFIER}`)).toContainText(
    `Needs ${traffic_descriptor.credential_label}`);
});

test('the traffic switch reads Needs <credential> while unconfigured', async ({
  page,
}) => {
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  await open_map_layers_panel(page);
  const traffic_switch = page.locator(`#${MAP_LAYER_TRAFFIC_IDENTIFIER}`);
  if (traffic_descriptor.credential_label.trim() === '') {
    test.skip(true, 'the registry declares a keyless traffic provider');
    return;
  }
  await expect(traffic_switch).toBeDisabled();
  await expect(traffic_switch).toContainText(
    `Needs ${traffic_descriptor.credential_label}`);
});

test('the traffic switch reads Not configured when no descriptor declares it', async ({
  page,
}) => {
  // A registry without the capability is served same-origin by this route, so
  // the page must not pretend a layer exists.
  const registry_without_traffic = {
    ...providers_registry,
    providers: providers_registry.providers.map((provider_descriptor) => ({
      ...provider_descriptor,
      served_contracts: (provider_descriptor.served_contracts ?? [])
        .filter((capability_name) => capability_name !== 'traffic_flow'),
    })),
  };
  await page.route('**/providers.json', (route) =>
    route.fulfill({ json: registry_without_traffic }));
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  await open_map_layers_panel(page);
  const traffic_switch = page.locator(`#${MAP_LAYER_TRAFFIC_IDENTIFIER}`);
  await expect(traffic_switch).toBeDisabled();
  await expect(traffic_switch).toContainText('Not configured');
});

test('a scene switch mirrors the settings toggle and its remembered choice', async ({
  page,
}) => {
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);
  await open_map_layers_panel(page);

  const scene_switch = page.locator(
    `#${MAP_LAYER_SCENE_ROW_IDENTIFIER_PREFIX}${SCENE_KEY}`);
  await expect(scene_switch).toContainText(SCENE_LABEL);
  await scene_switch.click();
  await expect(scene_switch).toHaveAttribute('aria-checked', 'true');
  await expect(page.locator(`#${SCENE_KEY}-overlay-control`)).toBeChecked();
  expect((await stored_preferences(page)).overlaySceneKeys).toContain(SCENE_KEY);

  // The settings toggle and the map switch are one choice.
  await scene_switch.click();
  await expect(scene_switch).toHaveAttribute('aria-checked', 'false');
  await expect(page.locator(`#${SCENE_KEY}-overlay-control`)).not.toBeChecked();
  expect((await stored_preferences(page)).overlaySceneKeys).not.toContain(SCENE_KEY);
});

test('the panel is keyboard operable and Escape returns focus to the button', async ({
  page,
}) => {
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);

  const layers_control = page.locator('#map-layers-control');
  await layers_control.focus();
  await page.keyboard.press('Enter');
  await expect(layers_control).toHaveAttribute('aria-expanded', 'true');
  await expect(page.locator('#map-layers-panel')).toBeVisible();

  // Tab moves through the panel's rows and switches, all real buttons.
  await page.keyboard.press('Tab');
  expect(await page.evaluate(
    () => document.getElementById('map-layers-panel').contains(document.activeElement),
  )).toBe(true);

  // Escape closes the panel and returns focus to the collapsed control.
  await page.keyboard.press('Escape');
  await expect(layers_control).toHaveAttribute('aria-expanded', 'false');
  await expect(page.locator('#map-layers-panel')).toBeHidden();
  await expect(layers_control).toBeFocused();

  // A row is activatable from the keyboard.
  await page.keyboard.press('Enter');
  const raster_row = page.locator(
    `#${MAP_LAYER_BASE_ROW_IDENTIFIER_PREFIX}${raster_base_descriptor.provider_key}`);
  await raster_row.focus();
  await page.keyboard.press('Enter');
  await expect(raster_row).toHaveAttribute('aria-pressed', 'true');
});

test('each My location chip fills only its own route field', async ({
  page,
  context,
}) => {
  await context.grantPermissions(['geolocation'], {
    origin: 'http://127.0.0.1:8642',
  });
  await context.setGeolocation({
    latitude: DEVICE_LATITUDE_DEGREES,
    longitude: DEVICE_LONGITUDE_DEGREES,
    accuracy: DEVICE_ACCURACY_METERS,
  });
  await page.goto('/?advanced&useProviderFixtures');
  await waitForMapTestReady(page);

  const origin_chip = page.locator('#origin-my-location');
  const destination_chip = page.locator('#destination-my-location');
  await expect(origin_chip).toBeEnabled();
  await expect(origin_chip).toHaveAttribute(
    'aria-label', 'Use my location as the origin');
  await expect(destination_chip).toHaveAttribute(
    'aria-label', 'Use my location as the destination');

  // The origin chip starts the source and fills only the origin.
  await origin_chip.click();
  await expect(page.locator('#trip-origin-input')).toHaveValue(
    /38\.57660, -121\.49440/, { timeout: 20_000 });
  await expect(page.locator('#trip-destination-input')).toHaveValue('');

  // The destination chip reuses the running source's latest fix.
  await destination_chip.click();
  await expect(page.locator('#trip-destination-input')).toHaveValue(
    /38\.57660, -121\.49440/);
  await expect(page.locator('#trip-origin-input')).toHaveValue(
    /38\.57660, -121\.49440/);

  // The panel's Device location row reports the running source.
  await open_map_layers_panel(page);
  await expect(page.locator(`#${DEVICE_LOCATION_STATUS_IDENTIFIER}`)).toHaveText(
    'Active');
});
