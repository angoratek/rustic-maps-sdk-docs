// The browser demo's remembered choices (M37): explicit theme, base-map,
// demo-plan, scene, camera-preset, speed and search-field selections survive a
// reload through one versioned localStorage record. Transient state (a route
// result, an open dialog, the live camera pose) is never restored, and the
// provider-key opt-in store is a separate record the reset row never touches.
// Every provider fact comes from the shared registry and every trace/tile
// payload is a committed fixture, so the suite touches no external network.
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { expect, test } from '@playwright/test';

const TEST_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));
const REPOSITORY_ROOT = path.resolve(TEST_DIRECTORY, '..', '..', '..');
const PREFERENCES_STORAGE_KEY = 'rustic-maps-demo-preferences';
const PREFERENCES_STORAGE_KEYS = [
  'baseMap',
  'cameraPresetId',
  'demoPlanScenario',
  'destinationText',
  'lastSearchFieldKey',
  'lastSearchQueryText',
  'originText',
  'overlaySceneKeys',
  'speedMultiplier',
  'themeChoice',
  'version',
];

const providers_registry = JSON.parse(
  readFileSync(path.join(REPOSITORY_ROOT, 'platform', 'providers.json'), 'utf8'),
);
const reference_scenes = JSON.parse(
  readFileSync(path.join(REPOSITORY_ROOT, 'platform', 'reference-scenes.json'), 'utf8'),
);

/** The first registry vector base offering more than one named style. */
const vector_provider_descriptor = providers_registry.providers.find(
  (provider_descriptor) =>
    typeof provider_descriptor.url_template === 'string'
    && (provider_descriptor.vector_styles ?? []).length > 1,
);
const VECTOR_PROVIDER_KEY = vector_provider_descriptor.provider_key;
const VECTOR_STYLE_ID = vector_provider_descriptor.vector_styles[1].style_id;
const VECTOR_TILE_BYTES = readFileSync(path.join(
  REPOSITORY_ROOT,
  vector_provider_descriptor.fixture_routes.find(
    (fixture_route) => fixture_route.purpose === 'vector_tiles',
  ).fixture,
));
const DEMO_PLAN_SCENARIO = reference_scenes.demo_plans[0].scenario;
const CAMERA_PRESET = reference_scenes.camera_presets[1];

/** Answers every vector-tile request from the committed fixture. */
async function serve_vector_tiles(page) {
  const content_type = vector_provider_descriptor.url_template.endsWith('.pbf')
    ? 'application/x-protobuf'
    : 'application/vnd.mapbox-vector-tile';
  const route_pattern = vector_provider_descriptor.url_template.endsWith('.pbf')
    ? '**/*.pbf'
    : '**/*.mvt';
  await page.route(route_pattern, (route) => route.fulfill({
    status: 200,
    contentType: content_type,
    body: VECTOR_TILE_BYTES,
  }));
}

/** The stored preferences record, read through the page's own origin. */
async function stored_preferences(page) {
  return page.evaluate((storage_key) => {
    const stored_text = window.localStorage.getItem(storage_key);
    return stored_text === null ? null : JSON.parse(stored_text);
  }, PREFERENCES_STORAGE_KEY);
}

test('explicit choices survive a reload', async ({ page }) => {
  // Two renderer initializations and a recorded-trace load: a software
  // renderer under a parallel suite needs more than the default budget.
  test.setTimeout(120_000);
  await serve_vector_tiles(page);
  await page.goto('/?advanced');
  await page.evaluate(() => window.mapTestReady);
  await expect
    .poll(() => page.evaluate(() => window.mapCameraState()), { timeout: 20_000 })
    .not.toBeNull();

  // Theme: Auto cycles to Light, an explicit choice.
  await page.click('#settings-control');
  await page.click('#theme-toggle-control');
  const remembered_theme_choice = await page.evaluate(
    () => document.documentElement.dataset.themeChoice);
  expect(remembered_theme_choice).toBe('light');
  await page.keyboard.press('Escape');

  // Base map: the registry's second vector source and its second style.
  await page.click('#settings-control');
  await page
    .locator(`#base-map-toggle [data-provider-key="${VECTOR_PROVIDER_KEY}"]`)
    .click();
  await expect
    .poll(() => page.evaluate(() => window.mapTileMode()), { timeout: 20_000 })
    .toBe('vector');
  await page.locator('#vector-style-select').selectOption(VECTOR_STYLE_ID);
  await expect(page.locator('#vector-style-select')).toHaveValue(VECTOR_STYLE_ID);
  await page.keyboard.press('Escape');

  // Demo plan: the picker loads a committed recorded trace.
  await page
    .locator(`#demo-plan-chips [data-demo-plan-scenario="${DEMO_PLAN_SCENARIO}"]`)
    .click();
  await expect
    .poll(
      () => page.evaluate(() => window.mapDemoPlanState()?.selectedScenario),
      { timeout: 20_000 },
    )
    .toBe(DEMO_PLAN_SCENARIO);

  // Camera preset: the second artifact pose, eased by the live control.
  await page
    .locator(`#camera-preset-controls [data-camera-preset-id="${CAMERA_PRESET.id}"]`)
    .click();
  await expect
    .poll(async () => {
      const state = await page.evaluate(() => window.mapCameraState());
      return Math.abs(state.latitude - CAMERA_PRESET.latitude_degrees) < 1e-3
        && Math.abs(state.longitude - CAMERA_PRESET.longitude_degrees) < 1e-3
        && Math.abs(state.zoom - CAMERA_PRESET.zoom_level) < 1e-3
        && Math.abs(state.bearing - CAMERA_PRESET.bearing_degrees) < 1e-3
        && Math.abs(state.pitch - CAMERA_PRESET.pitch_degrees) < 1e-3;
    }, { timeout: 5_000 })
    .toBe(true);

  // Search fields: a submitted query and the final endpoint texts.
  await page.locator('#trip-origin-input').fill('Capitol');
  await page.locator('#trip-origin-search-control').click();
  await page.locator('#trip-origin-input').fill('Capitol Park');
  await page.locator('#trip-destination-input').fill('Tower Bridge');

  // The record carries every explicit choice under its documented keys.
  const written_record = await stored_preferences(page);
  expect(written_record.version).toBe(1);
  expect(Object.keys(written_record).sort()).toEqual(PREFERENCES_STORAGE_KEYS);
  expect(written_record.themeChoice).toBe('light');
  expect(written_record.baseMap).toEqual({
    mode: 'vector',
    vectorProviderKey: VECTOR_PROVIDER_KEY,
    vectorStyleId: VECTOR_STYLE_ID,
  });
  expect(written_record.demoPlanScenario).toBe(DEMO_PLAN_SCENARIO);
  expect(written_record.cameraPresetId).toBe(CAMERA_PRESET.id);
  expect(written_record.originText).toBe('Capitol Park');
  expect(written_record.destinationText).toBe('Tower Bridge');
  expect(written_record.lastSearchFieldKey).toBe('origin');
  expect(written_record.lastSearchQueryText).toBe('Capitol');

  // Reload: each value is restored before the page is interactive.
  await page.reload();
  await page.evaluate(() => window.mapTestReady);
  await expect
    .poll(
      () => page.evaluate(() => document.documentElement.dataset.themeChoice),
      { timeout: 20_000 },
    )
    .toBe('light');
  await expect
    .poll(() => page.evaluate(() => window.mapTileMode()), { timeout: 20_000 })
    .toBe('vector');
  await expect
    .poll(() => page.evaluate(() => window.mapVectorProviderKey()))
    .toBe(VECTOR_PROVIDER_KEY);
  await expect(page.locator('#vector-style-select')).toHaveValue(VECTOR_STYLE_ID);
  await expect
    .poll(
      () => page.evaluate(() => window.mapDemoPlanState()?.selectedScenario),
      { timeout: 20_000 },
    )
    .toBe(DEMO_PLAN_SCENARIO);
  await expect(
    page.locator(
      `#camera-preset-controls [data-camera-preset-id="${CAMERA_PRESET.id}"]`,
    ),
  ).toHaveClass(/selected/);
  await expect
    .poll(async () => {
      const state = await page.evaluate(() => window.mapCameraState());
      return Math.abs(state.latitude - CAMERA_PRESET.latitude_degrees) < 1e-3
        && Math.abs(state.longitude - CAMERA_PRESET.longitude_degrees) < 1e-3
        && Math.abs(state.pitch - CAMERA_PRESET.pitch_degrees) < 1e-3;
    }, { timeout: 20_000 })
    .toBe(true);
  await expect(page.locator('#trip-origin-input')).toHaveValue('Capitol Park');
  await expect(page.locator('#trip-destination-input')).toHaveValue('Tower Bridge');
});

test('the reset row clears the record and a route result is never restored', async ({
  page,
}) => {
  await page.goto('/?useProviderFixtures');
  await page.evaluate(() => window.mapTestReady);

  // Plan a recorded demo route: its result is transient page state.
  await page.locator('#trip-origin-input').fill('Capitol Park');
  await page.locator('#trip-destination-input').fill('Tower Bridge');
  await page.locator('#trip-plan-route-control').click();
  await expect(page.locator('#trip-route-result')).toContainText(
    'Capitol Park → Tower Bridge');

  // Reload: the search texts return, the route result does not.
  await page.reload();
  await page.evaluate(() => window.mapTestReady);
  await expect(page.locator('#trip-origin-input')).toHaveValue('Capitol Park');
  await expect(page.locator('#trip-destination-input')).toHaveValue('Tower Bridge');
  await expect(page.locator('#trip-route-result')).toBeHidden();

  // Park a credential-store entry so the reset row's scope is provable.
  const provider_key = providers_registry.providers[0].provider_key;
  await page.evaluate((credential_provider_key) => {
    window.localStorage.setItem('rusticMapsSdk.rememberProviderCredentials', 'true');
    window.localStorage.setItem(
      `rusticMapsSdk.providerCredential.${credential_provider_key}`,
      'test-key',
    );
    // The older single-key theme store must never outlive the reset either.
    window.localStorage.setItem('rusticMapsSdk.themeChoice', 'dark');
  }, provider_key);

  // Reset clears the demo record and says so, leaving the credential store.
  await page.click('#settings-control');
  await page.click('#reset-remembered-choices-control');
  await expect(page.locator('#remembered-choices-status')).toHaveText(
    'Remembered choices cleared. Provider keys are unchanged.');
  expect(await stored_preferences(page)).toBeNull();
  expect(await page.evaluate(() => window.localStorage.getItem(
    'rusticMapsSdk.rememberProviderCredentials'))).toBe('true');
  expect(await page.evaluate((credential_provider_key) =>
    window.localStorage.getItem(
      `rusticMapsSdk.providerCredential.${credential_provider_key}`,
    ), provider_key)).toBe('test-key');
  expect(await page.evaluate(
    () => window.localStorage.getItem('rusticMapsSdk.themeChoice'))).toBeNull();

  // The next visit starts from the defaults, not the forgotten choices.
  await page.reload();
  await page.evaluate(() => window.mapTestReady);
  await expect(page.locator('#trip-origin-input')).toHaveValue('');
  await expect(page.locator('#trip-destination-input')).toHaveValue('');
  expect(await page.evaluate(
    () => document.documentElement.dataset.themeChoice)).toBe('auto');
  expect(await page.evaluate(() => window.mapTileMode())).toBe('raster');
  await expect(page.locator('#trip-route-result')).toBeHidden();
});

test('the settings sheet fits a small viewport and scrolls to its last row', async ({
  page,
}) => {
  const viewport = { width: 360, height: 640 };
  await page.setViewportSize(viewport);
  await page.goto('/?settings');
  await page.evaluate(() => window.mapTestReady);

  const dialog = page.locator('#settings-dialog');
  await expect(dialog).toBeVisible();
  const dialog_box = await dialog.boundingBox();
  expect(dialog_box.x).toBeGreaterThanOrEqual(0);
  expect(dialog_box.y).toBeGreaterThanOrEqual(0);
  expect(dialog_box.x + dialog_box.width).toBeLessThanOrEqual(viewport.width);
  expect(dialog_box.y + dialog_box.height).toBeLessThanOrEqual(viewport.height);

  // The content column scrolls inside the capped sheet.
  const body = page.locator('.settings-body');
  const scroll_metrics = await body.evaluate((element) => ({
    scroll_height: element.scrollHeight,
    client_height: element.clientHeight,
  }));
  expect(scroll_metrics.scroll_height).toBeGreaterThan(scroll_metrics.client_height);

  await body.evaluate((element) => {
    element.scrollTop = element.scrollHeight;
  });
  const reset_button_box = await page
    .locator('#reset-remembered-choices-control')
    .boundingBox();
  expect(reset_button_box.y + reset_button_box.height)
    .toBeLessThanOrEqual(viewport.height);
  expect(reset_button_box.y).toBeGreaterThanOrEqual(dialog_box.y);
  // The title and Close action stay pinned while the content scrolls.
  const title_box = await page.locator('#settings-title').boundingBox();
  expect(title_box.y).toBeGreaterThanOrEqual(dialog_box.y);
  expect(title_box.y + title_box.height)
    .toBeLessThanOrEqual(dialog_box.y + dialog_box.height);
  await expect(page.locator('#settings-close-control')).toBeVisible();
});

test('the header link targets the local mobile demo and is keyboard reachable', async ({
  page,
}) => {
  await page.route('**/demo-builds.json', (route) => route.fulfill({
    json: {
      sourceCommit: '0123456789abcdef0123456789abcdef01234567',
      builds: {
        android: { buildId: 'android-build-id', updatedAt: '2026-10-30T00:00:00Z' },
        ios: { buildId: 'ios-build-id', updatedAt: '2026-10-30T00:00:00Z' },
        reactNativeAndroid: { buildId: 'rn-build-id', updatedAt: '2026-10-30T00:00:00Z' },
      },
    },
  }));
  await page.goto('/');

  const mobile_demo_link = page.locator('#mobile-demo-link');
  await expect(mobile_demo_link).toBeVisible();
  await expect(mobile_demo_link).toHaveText('Mobile demo');
  await expect(mobile_demo_link).toHaveAttribute('href', 'mobile-demo/');

  // A keyboard visitor can reach it and follow it.
  await mobile_demo_link.focus();
  await expect(mobile_demo_link).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page).toHaveURL(/\/mobile-demo\/$/);
});
