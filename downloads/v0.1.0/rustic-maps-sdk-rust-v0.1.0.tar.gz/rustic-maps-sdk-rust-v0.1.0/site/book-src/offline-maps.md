# Offline maps

Keep map imagery and routing working without a network. Two independent
layers do it: a disk response cache that holds raster tile imagery under your
byte budget, and a compiled routing archive that returns routes with no
network round trip.

<div class="platform-tabs">
<div class="platform-tab-titles" role="tablist">
<button type="button" data-platform-tab="android">Android</button>
<button type="button" data-platform-tab="ios">iOS</button>
<button type="button" data-platform-tab="react-native">React Native</button>
<button type="button" data-platform-tab="wasm">WebAssembly</button>
</div>

<div class="platform-tab-panel" data-platform-panel="android">

### Register the providers with a tile cache

One registration call installs the map-platform provider set and wraps the
raster-tile contract in the disk response cache:

```kotlin
val tileCacheDatabaseFile = File(context.cacheDir, "reference-tile-cache.sqlite")
val tileCacheBudgetBytes = 16777216UL   // 16 MiB

mapSdk.setProviderCredentialWithTileCache(
    providerApiKey,
    tileCacheDatabaseFile.absolutePath,
    tileCacheBudgetBytes,
)
```

The call opens or creates the SQLite response cache at the path. A refusal,
such as an unusable path or a non-positive budget, returns the reason
verbatim.

### Read and tune the caching terms

The cache starts at the tiles category's default time-to-live of 30 calendar
days, the imagery-provider terms ceiling. Tune the live value and read the
value in force:

```kotlin
mapSdk.setRasterTileCacheTimeToLive(timeToLiveSeconds)
val terms = mapSdk.rasterTileCacheTerms()
// terms.effectiveTimeToLiveSeconds
// terms.providerTermsCeilingSeconds
// terms.defaultTimeToLiveSeconds

// The same calls through the offline facade:
// val offlineManager = OfflineManager(mapSdk)
// offlineManager.setTileTimeToLive(timeToLiveSeconds)
// val terms = offlineManager.tileCacheTerms()
```

A request above the provider's declared ceiling is accepted, and the
ceiling clamps what the cache retains; the readback shows the effective
value, so display it in your offline-maps settings screen.

### Pre-warm the tiles you need

Cached tile responses render whenever the network is unavailable: a
cache miss goes to the network and back-fills, and a cache hit comes from
disk. Render the regions your users expect to revisit once while
online, and the cache holds them until the budget or time-to-live says
otherwise.

### Route without the network

The offline routing layer runs inside the SDK: a compiled routing
archive — OpenStreetMap extract in, self-describing archive file out —
returns routes with A\* over the archive's graph, honoring recorded turn
restrictions and deriving maneuver text from the geometry's bearing change.

The contract carries the route call on every surface. Pass the archive bytes,
not a path, so the same call works on Android, iOS, React Native, and the
browser.

```kotlin
import uniffi.rustic_maps.GeographicCoordinate
import uniffi.rustic_maps.offlineRouteFromArchiveBytes

// The compiled RMOG archive's bytes, bundled with the app or downloaded.
val archiveBytes: ByteArray = archiveFile.readBytes()
val plannedRoute = offlineRouteFromArchiveBytes(
    archiveBytes,
    GeographicCoordinate(latitude = 0.001, longitude = 0.0),
    GeographicCoordinate(latitude = 0.001, longitude = 0.002),
)
```

The request uses the archive profile's default options: automobile, fastest,
metric. A corrupt archive throws `OfflineRoutingFailure`. The SDK does not
fall back to the archive when the online provider fails; catch the online
failure and call the archive route yourself. Maneuver texts stay honest where
the extract carries no street names.

</div>

<div class="platform-tab-panel" data-platform-panel="ios">

### Register the providers with a tile cache

```swift
let tileCacheDatabasePath = FileManager.default
    .urls(for: .cachesDirectory, in: .userDomainMask)[0]
    .appendingPathComponent("reference-tile-cache.sqlite")
    .path
let tileCacheBudgetBytes: UInt64 = 16_777_216   // 16 MiB

try mapSdk.setProviderCredentialWithTileCache(
    mapquestApiKey: providerApiKey,
    tileCacheDatabasePath: tileCacheDatabasePath,
    tileCacheAbsoluteMaximumBytes: tileCacheBudgetBytes
)
```

### Read and tune the caching terms

```swift
try mapSdk.setRasterTileCacheTimeToLive(timeToLiveSeconds: timeToLiveSeconds)
let terms = try mapSdk.rasterTileCacheTerms()
// terms.effectiveTimeToLiveSeconds
// terms.providerTermsCeilingSeconds
// terms.defaultTimeToLiveSeconds

// The same calls through the offline facade:
// let offlineManager = OfflineManager(mapSdk: mapSdk)
// try offlineManager.setTileTimeToLive(timeToLiveSeconds: timeToLiveSeconds)
// let terms = try offlineManager.tileCacheTerms()
```

### Pre-warm and render offline

Cached tiles render whenever the network is unavailable. Render the regions
your users revisit while online; the cache serves them from disk.

### Route without the network

The offline routing layer runs inside the SDK over a compiled archive:
A\* on the archive's graph, recorded turn restrictions honored, maneuver
text derived from the geometry. The contract call takes the archive bytes,
not a path, so the same call works on every platform:

```swift
// The compiled RMOG archive's bytes, bundled with the app or downloaded.
let archiveURL = URL(fileURLWithPath: "routing_grid.rmog")
let archiveBytes = try Data(contentsOf: archiveURL)
let plannedRoute = try await offlineRouteFromArchiveBytes(
    archiveBytes: archiveBytes,
    start: GeographicCoordinate(latitude: 0.001, longitude: 0.0),
    end: GeographicCoordinate(latitude: 0.001, longitude: 0.002)
)
```

The request uses the archive profile's default options: automobile, fastest,
metric. A corrupt archive throws `OfflineRoutingFailure`. The SDK does not
fall back to the archive when the online provider fails; catch the online
failure and call the archive route yourself.

</div>

<div class="platform-tab-panel" data-platform-panel="react-native">

### Register the providers with a tile cache

The package's SDK handle installs the provider set and wraps the raster-tile
contract in the disk response cache:

```js
import { MapsSdk } from '@angoratek/rustic-maps-sdk/MapsSdk';

async function createMapSdkWithTileCache(providerKey, providerApiKey) {
  const mapSdk = await MapsSdk.create();
  const registration = await mapSdk.setProviderCredentialWithTileCache(
    providerKey,
    providerApiKey,
  );
  if (!registration.isApplied) {
    throw new Error(registration.detailText);
  }
  return mapSdk;
}
```

The package opens (or creates) the cache under the application's caches
directory with a 16 MiB budget; JavaScript passes the provider key and the
credential, never a file path. A refusal resolves with `isApplied: false` and
the provider's verbatim `detailText`. Re-registration replaces the raster-tile
slot, cache included.

### Read and tune the caching terms

The cache starts at the tiles category's default time-to-live of 30 calendar
days, the imagery-provider terms ceiling. Tune the live value and read the
value in force:

```js
import { MapsSdk } from '@angoratek/rustic-maps-sdk/MapsSdk';

const mapSdk = await MapsSdk.create();
const oneWeekInSeconds = 7 * 24 * 60 * 60;
await mapSdk.setTileCacheTimeToLive(oneWeekInSeconds);
const terms = await mapSdk.tileCacheTerms();
if (terms !== null) {
  // terms.effectiveTimeToLiveSeconds
  // terms.providerTermsCeilingSeconds
  // terms.defaultTimeToLiveSeconds
}
```

A request above the provider's declared ceiling is accepted, and the ceiling
clamps what the cache retains; the readback shows the effective value, so
display it in your offline-maps settings screen.

### Pre-warm the tiles you need

Cached tile responses render whenever the network is unavailable: a cache miss
goes to the network and back-fills, and a cache hit answers from disk. Render
the regions your users expect to revisit once while online, and the cache
holds them until the budget or time-to-live says otherwise.

### Route without the network

The compiled routing archive returns routes with A\* over its graph, honoring
recorded turn restrictions and deriving maneuver text from the geometry. The
generated bindings carry the contract's archive-route call; pass the bytes,
not a path:

```js
import { offlineRouteFromArchiveBytes } from '@angoratek/rustic-maps-sdk';

// The compiled RMOG archive's bytes, bundled with the app or downloaded.
const archiveResponse = await fetch('routing_grid.rmog');
const archiveBytes = await archiveResponse.arrayBuffer();
const plannedOfflineRoute = await offlineRouteFromArchiveBytes(
  archiveBytes,
  { latitude: 0.001, longitude: 0.0 },
  { latitude: 0.001, longitude: 0.002 },
);
```

The request uses the archive profile's default options: automobile, fastest,
metric. A corrupt archive rejects with `OfflineRoutingFailure`. The SDK does
not fall back to the archive when an online route fails; handle that failure
in your own code.

</div>

<div class="platform-tab-panel" data-platform-panel="wasm">

### What the browser surface carries

The browser surface has no SDK-owned cache: there is no SQLite tile cache, no
byte budget, and no pack manager. The cache-terms and pre-warm steps of the
native tabs have no counterpart here. What the WebAssembly build carries is
the routing archive: archive bytes in, route records out, with no provider and
no network round trip. The same compiled archive serves the native platforms,
so one compile feeds every target.

### Route over the archive

```js
import { offlineRouteFromArchiveBytes } from './web/rustic_maps_web_bindings.js';

const archiveResponse = await fetch('/offline-graph/routing-grid.rmog');
const archiveBytes = new Uint8Array(await archiveResponse.arrayBuffer());

const plannedRoute = await offlineRouteFromArchiveBytes(
  archiveBytes,
  originLatitude,
  originLongitude,
  endLatitude,
  endLongitude,
);
```

The result is the same `Route`/`RouteLeg`/`RouteStep` record the live route
call returns, so the route overlay and framing steps from [Search and
routing](search-and-routing.md) apply unchanged. The call rejects with the
reason when the bytes fail archive validation, a coordinate falls outside
every node's snap tolerance, or the two points are not connected in the
graph.

Where the bytes come from is the page's decision: ship the archive with the
app, fetch it once and keep it in the browser's own storage, or read it from
`<input type="file">` for a local preview.

</div>

</div>
