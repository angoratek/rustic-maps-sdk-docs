# Add a provider

A provider is a set of implementations of the vendor-neutral contracts plus
one descriptor in the shared provider registry. The descriptor carries the
labels, availability, attribution, and tile sources; the implementations
carry the vendor's requests and status mapping. No credential is ever part of
either.

There are two implementation routes and one no-code route:

| Route | Use it when | What changes |
|---|---|---|
| Rust provider crate | The provider serves routing, search, distance matrix, traffic, elevation, or vector tiles, or needs its own HTTP policy | A crate implementing the traits, a descriptor, a dispatch arm, and a registration call on each target |
| Host implementation | The provider serves geocoding or raster tiles from code that already lives in the native app | A Kotlin or Swift class implementing the interface, a registration call, and a descriptor |
| URL-template source | The provider publishes ordinary `{z}/{x}/{y}` raster or vector tiles | A descriptor only; the SDK's generic source does the work |

## What every provider needs

1. **Implementations.** One struct or class per contract the provider serves.
2. **A descriptor.** The shared registry entry that every application reads.
3. **A dispatch arm.** The one place that maps the provider key to its
   registration call on a target.
4. **Committed sample responses.** The tests and the demo read provider
   payloads from committed sample data, never from the network.

## Route 1: a Rust provider crate

### Implement the contract

Implement the matching trait from `geospatial-traits`. The methods are async
and return `SDKError` on refusal or failure.

```rust
use async_trait::async_trait;
use geospatial_traits::RoutingProvider;
use geospatial_types::route::{RouteData, RouteOptions};
use geospatial_types::{GeographicCoordinate, SDKError};

struct MyRoutingProvider;

#[async_trait]
impl RoutingProvider for MyRoutingProvider {
    async fn calculate_route(
        &self,
        waypoints: &[GeographicCoordinate],
        route_options: &RouteOptions,
    ) -> Result<RouteData, SDKError> {
        let _ = (waypoints, route_options);
        // Build the provider request, execute it through the transport, and
        // parse the answer into RouteData.
        todo!("implement the provider request and parse")
    }
}
```

The traits are `GeocodingProvider`, `RoutingProvider`,
`DistanceMatrixProvider`, `SearchPlaceProvider`, `TrafficIncidentProvider`,
`TrafficFlowProvider`, `ElevationProvider`, `RasterTileProvider`,
`VectorTileProvider`, and `OfflineRoutingProvider`. A provider implements
only the ones it serves.

### Register it in the core

`ProviderRegistry` holds one slot per contract. Registering replaces the
slot; a call into an empty slot returns `ProviderNotConfigured`.

```rust
use std::sync::Arc;
use geospatial_traits::RoutingProvider;
use rustic_maps_core::ProviderRegistry;

fn registry_with(provider: Arc<dyn RoutingProvider>) -> ProviderRegistry {
    let mut registry = ProviderRegistry::new();
    registry.register_routing_provider(provider);
    registry
}
```

Use `provider-transport` for HTTP. It gives the native and browser builds one
request, retry, and rate-limit path, so a provider behaves the same on every
target.

### Expose it to an application target

1. **Add the descriptor.** One entry in the shared provider registry, with
   the capabilities the provider serves in `served_contracts`.
2. **Add the catalog row.** One entry in the SDK's provider catalog maps the
   provider key to the crate's construction call and the capabilities it
   serves. This row is what makes the key selectable; compiling the crate
   into a binding alone does not.
3. **Add committed sample responses.** Each served API gets a route pattern
   and a committed response under the provider's key. The test server and
   the demo use them; tests never reach the network.

An application then selects the provider by key. The call replaces one
capability and leaves every other capability serving, so one app can search
with one provider, route with another and draw tiles from a third.

```kotlin
val mapSdk = MapSdk()
mapSdk.configureProvider(
    contract = ProviderContract.Routing,
    providerKey = "my-provider",
    credential = "",
)
val routing = mapSdk.providerRegistrations()
    .first { it.contract == ProviderContract.Routing }
check(routing.registered && routing.providerKey == "my-provider")
```

```swift
let mapSdk = MapSdk()
try mapSdk.configureProvider(
    contract: .routing,
    providerKey: "my-provider",
    credential: ""
)
let routing = mapSdk.providerRegistrations()
    .first { $0.contract == .routing }
precondition(routing?.registered == true && routing?.providerKey == "my-provider")
```

`providerRegistrations()` answers every capability in the same order every
time — geocoding, routing, distance matrix, place search, traffic incidents,
traffic flow, elevation, raster tiles, vector tiles, offline routing — so a
settings surface can render one row per capability without knowing the list.
A capability with no provider reports `registered` false and an empty key.

A provider that needs no credential accepts an empty string; a provider with
a credential refuses a blank one and leaves the previously serving provider
in place. That is the whole integration: the application stores its own
choice (a key and, when needed, a credential) and calls `configureProvider`
at startup.

### Sample: a routing provider key in an app

The steps below are the complete path from a routing crate to a working
screen. The example uses the OSRM provider that ships with the SDK.

1. Add the crate to the binding. The SDK already carries it, so this step is
   the catalog row: `osrm` maps to `OsrmRoutingProvider::new`.
2. Give the provider its deployment address. OSRM is keyless, so the
   credential field carries the base URL of the deployment instead of a
   secret; an empty string targets a local server.
3. Choose it for routing at startup:

```kotlin
mapSdk.configureProvider(
    contract = ProviderContract.Routing,
    providerKey = "osrm",
    credential = "http://10.0.2.2:5000",
)
```

```swift
try mapSdk.configureProvider(
    contract: .routing,
    providerKey: "osrm",
    credential: "http://localhost:5000"
)
```

4. Plan a route. `RoutingFacade.calculateRoute` resolves the routing slot, so
   the result comes from the chosen provider and no other capability changes.

To let the reader switch providers, render one row per capability from
`providerRegistrations()`, list the descriptors whose `served_contracts`
contain that capability, and call `configureProvider` with the picked key.

### Constraints

- A provider type is `Send + Sync`; trait methods are async.
- The crate owns its vendor URL, credential handling, status mapping, and
  error detail. It does not name another vendor.
- Map transport failures to `NetworkRequestFailed`, unparseable payloads to
  `ResponseParsingFailure`, documented application refusals to
  `ProviderRequestRejected`, and an exhausted limiter to
  `RateLimitExhausted`. Keep the provider's detail text verbatim.
- A vector source's `source_name` is its cache namespace. Two tilesets must
  never share one name.
- The provider name appears only in its crate, its sample-data directory,
  the shared descriptor, and the dispatch arms; the provider-name guard
  enforces that boundary.

## Route 2: a host implementation

Android and iOS can implement two contracts directly in application code:
`GeocodingProvider` and `RasterTileProvider`. Register the implementation on
the `MapSdk` object that the map view and every provider call use.

### Geocoding in Kotlin

```kotlin
import uniffi.rustic_maps.GeocodingProvider
import uniffi.rustic_maps.GeographicCoordinate
import uniffi.rustic_maps.MapSdk
import uniffi.rustic_maps.Place

class AppGeocodingProvider : GeocodingProvider {
    override suspend fun forwardGeocode(addressText: String): List<Place> {
        return emptyList()
    }

    override suspend fun reverseGeocode(
        coordinate: GeographicCoordinate,
    ): List<Place> {
        return emptyList()
    }
}

val mapSdk = MapSdk()
mapSdk.registerGeocodingProviderFromForeign(AppGeocodingProvider())
```

### Geocoding in Swift

```swift
import RusticMapsSDK

final class AppGeocodingProvider: GeocodingProvider {
    func forwardGeocode(addressText: String) async throws -> [Place] {
        return []
    }

    func reverseGeocode(coordinate: GeographicCoordinate) async throws -> [Place] {
        return []
    }
}

let mapSdk = MapSdk()
try mapSdk.registerGeocodingProviderFromForeign(
    geocodingProvider: AppGeocodingProvider()
)
```

### Raster tiles in Kotlin

```kotlin
import uniffi.rustic_maps.MapSdk
import uniffi.rustic_maps.RasterImageFormat
import uniffi.rustic_maps.RasterTileData
import uniffi.rustic_maps.RasterTileProvider
import uniffi.rustic_maps.RasterTileResolution

class AppRasterTileProvider : RasterTileProvider {
    override suspend fun fetchRasterTile(
        tileX: UInt,
        tileY: UInt,
        zoomLevel: UByte,
        imageFormat: RasterImageFormat,
        tileResolution: RasterTileResolution,
    ): RasterTileData {
        TODO("fetch the encoded tile from your service")
    }
}

val mapSdk = MapSdk()
mapSdk.registerRasterTileProviderFromForeign(AppRasterTileProvider())
```

### Raster tiles in Swift

```swift
import RusticMapsSDK

final class AppRasterTileProvider: RasterTileProvider {
    func fetchRasterTile(
        tileX: UInt32,
        tileY: UInt32,
        zoomLevel: UInt8,
        imageFormat: RasterImageFormat,
        tileResolution: RasterTileResolution
    ) async throws -> RasterTileData {
        fatalError("fetch the encoded tile from your service")
    }
}

let mapSdk = MapSdk()
try mapSdk.registerRasterTileProviderFromForeign(
    rasterTileProvider: AppRasterTileProvider()
)
```

### Constraints

- Only geocoding and raster tiles have host-implementable interfaces. Every
  other contract needs a Rust provider crate.
- The implementation runs on the foreign runtime and calls back into the
  SDK. Do not block; hand long work to your own queue or coroutine scope.
- A failure must be one of the contract's `SdkError` variants. An
  unclassified failure still reaches the typed refusal at the call, and the
  SDK records it for `latestProviderFailureDiagnostics()`.
- Registration is per `MapSdk` object and replaces that slot. The other
  slots keep serving. There is no unregister call; a restart returns the
  registry to its empty state.
- The package handle on React Native does not expose these interfaces, and
  the browser has no host-provided provider path. Use a Rust provider crate
  there.
- The provider's attribution and terms still belong in the descriptor, not
  in the class.

## Route 3: a URL-template source

A plain XYZ tileset needs no provider code. Add a descriptor with the
tileset's template, zoom span, and terms, then register the source once at
startup.

| Platform | Raster source | Styled vector base |
|---|---|---|
| Android | `MapSdk.registerUrlTemplateRasterTileSource(source)` | `MapView.setVectorTileSource(source)` |
| iOS | `MapSdk.registerUrlTemplateRasterTileSource(source:)` | `MapView.setVectorTileSource(_:)` |
| React Native | `MapsSdk.registerUrlTemplateRasterTileSource(source)` | `MapViewHandle.setVectorTileSource(source)` |
| WebAssembly | `MapView.setRasterTileSource(template, maximumZoomLevel)` as the live fallback | `MapView.setVectorTileSource(source)` |
| Rust | `UrlTemplateRasterTileProvider::new(source, transport)` | `UrlTemplateVectorTileProvider::new(template, descriptor, transport)` |

A raster source declares its image format, pixel resolution, and the
`User-Agent` its requests carry. A vector source declares the committed
style id it paints with. Templates must be absolute `http` or `https` URLs
carrying `{z}`, `{x}`, and `{y}` and no other placeholders; the zoom span
must not be inverted; the style id must name a committed style. A refused
source keeps the previously serving base.

## The descriptor

One descriptor per provider lives in the shared registry. Every application,
the test server, and the demo read it by name; none of them hardcode a
provider.

| Field | Meaning |
|---|---|
| `provider_key` | Stable key used by every dispatch arm and every provider-keyed route |
| `display_name` | Name the settings surface shows |
| `credential_label` | Label for the credential field; blank for a keyless provider |
| `registration_available` | Whether each target registers the provider: `android`, `ios`, `react_native`, `wasm` |
| `attribution_text` | The line every shell displays wherever the imagery appears |
| `terms_note` | The provider's rate limits, caching ceiling, or usage terms |
| `settings_hint` | Where the reader creates a credential |
| `wasm_registration` | The browser dispatch key, or null when the browser has no registration |
| `fixture_routes` | The request patterns and committed sample responses for each served API |
| `raster_url_template` | The keyless raster source, when the provider publishes one |
| `maximum_zoom_level` | The highest zoom the tileset serves |
| `url_template` | The vector tileset, when the provider publishes one |
| `glyphs_url_template` | The glyph endpoint when the tileset publishes one |
| `vector_style` | The tile schema the vector tileset carries |
| `vector_styles` | The style id, display name, theme, and attribution of each offered style |

A descriptor never carries a credential value.

## What the reader sees

- The settings surface renders one credential row per descriptor, with the
  provider's display name, credential label, hint, attribution, and terms.
- The base-map section renders the keyless raster sources and one row per
  vector style.
- A keyless start is a first-class state: the app renders the recorded demo
  until a credential is applied, and a provider-dependent call returns
  `ProviderNotConfigured` verbatim.
- Clearing a credential removes it from memory and the secure store, but the
  running SDK keeps its registered providers; tell the reader that a restart
  returns the session to the keyless state.

## Verify the addition

1. The descriptor renders on every target's settings surface.
2. The provider's sample responses serve through its provider key; no test
   reaches the network.
3. The provider-name guard passes: the name appears only in the provider's
   crate, its sample-data directory, the descriptor, and the dispatch arms.
4. The platform builds and the provider's own tests pass on the exact tree
   you ship.

## Where to go next

- [Android](provider-capabilities-android.md), [iOS](provider-capabilities-ios.md),
  [React Native](provider-capabilities-react-native.md),
  [WebAssembly](provider-capabilities-wasm.md), and
  [Rust](provider-capabilities-rust.md) list the calls each target exposes.
- [Your first map](first-map.md) shows the runtime credential path in a
  complete app.
- [Offline maps](offline-maps.md) covers the tile cache and archive routing a
  provider-backed app can add.
