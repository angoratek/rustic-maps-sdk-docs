# Provider capabilities on WebAssembly

WebAssembly exposes the browser surface: live provider calls over `fetch`, a
styled vector base painted by the canvas, the offline routing archive, and
the navigation driving core. It has no native view and no disk cache. This
page lists the registry's providers, the public JavaScript calls each
capability uses, and the code that switches a base map or registers a
provider.

## What you need

- A Chromium-based browser with WebGPU, and the WebAssembly package served
  from the page's own origin over HTTPS or localhost.
- A provider credential only for the live provider APIs. Read it at runtime;
  never place it in the bundle.

## Providers available on WebAssembly

| Provider | Key | Credential | Form on WebAssembly | Serves |
|---|---|---|---|---|
| MapQuest | `mapquest` | API key | Live provider | Geocoding (forward only), search and suggestions, routing, distance matrix, traffic incidents and flow, raster tiles |
| OpenStreetMap Standard | `openstreetmap` | None | Raster fallback | Raster tiles |
| OpenStreetMap US | `osmus` | None | Vector base | Vector tiles with Carto Light and Carto Dark |
| OpenFreeMap | `openfreemap` | None | Vector base | Vector tiles with Bright, Fiord, and Positron |

MapQuest registers through `registerProvider`. OpenStreetMap Standard's
template feeds the canvas's live raster fallback. OpenStreetMap US and
OpenFreeMap are served by `MapView.setVectorTileSource` and need no
registration call.

| Provider | Attribution line | Terms |
|---|---|---|
| MapQuest | Map data © OpenStreetMap contributors (ODbL) — tile imagery © MapQuest | MapQuest terms apply: rate limits and a 30-day raster-tile caching ceiling. |
| OpenStreetMap Standard | Map data © OpenStreetMap contributors (ODbL) — raster tiles © OpenStreetMap contributors | OpenStreetMap tile usage policy applies: low-volume use only, with attribution. |
| OpenStreetMap US | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenStreetMap US | OpenStreetMap US tileservice terms apply: free for low-volume, non-commercial use with attribution. |
| OpenFreeMap | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenFreeMap and OpenMapTiles | OpenFreeMap terms apply: free public use with attribution; bulk downloads are limited to 3,000 tiles or 50 MB per download. |
| OSRM | Map data © OpenStreetMap contributors (ODbL) — routing by OSRM | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |
| Valhalla | Map data © OpenStreetMap contributors (ODbL) — routing by Valhalla | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |

Each vector style also carries its own attribution line. The style ids are
`carto-light` and `carto-dark` (OpenStreetMap US), and `bright-light`,
`fiord-dark`, and `positron-light` (OpenFreeMap). The status readback returns
the active style's line, so display it verbatim.

## What you can call

| Capability | Public JavaScript call |
|---|---|
| Forward geocoding | `forwardGeocode(queryText)` |
| Suggestions and search | `suggestPlaces(queryText)`, `suggestPlacesInBoundary(...)`, `searchPlaces(queryText)`, `searchPlacesInBoundary(...)` |
| Routing with options | `calculateRoute(originLatitude, originLongitude, destinationLatitude, destinationLongitude)`, `calculateRouteWithOptions(..., options)` |
| Distance matrix | `calculateDistanceMatrix(originCoordinates, destinationCoordinates, transportationMode)` |
| Traffic incidents and flow | `fetchTrafficIncidents(...)`, `fetchTrafficFlow(...)` |
| Raster tiles | `fetchRasterTile(zoomLevel, tileX, tileY)` through the live provider; `MapView.setRasterTileSource(template, maximumZoomLevel)` for the live fallback |
| Vector tiles and styles | `MapView.setVectorTileSource(source)`, `MapView.clearVectorTileSource()`, `MapView.vectorTileSourceStatus()` |
| Offline routing | `offlineRouteFromArchiveBytes(archiveBytes, startLatitude, startLongitude, endLatitude, endLongitude)` |
| Navigation | `Navigator.startNavigation(...)`, `Navigator.updateLocation(...)`, `Navigator.applyReroute(...)`, `Navigator.stopNavigation()`, `Navigator.currentTripState()`, `Navigator.hasActiveTrip()`; `RouteSimulator` |
| Provider registration | `registerProvider(providerKey, credential, baseUrl?)`, `clearProvider()`, `setProviderCredential(apiKey, baseUrl?)` |

There is no reverse-geocoding export, no disk tile cache, and no
host-implemented provider registration on this surface. Calls reject with
the provider's verbatim message when no provider is registered or the
provider refuses.

## Switch the base map

### A styled vector base

The registry's keyless vector base for OpenFreeMap is Bright. Install it on
the canvas; every following frame draws the styled base beneath your
overlays.

<!-- data-platform-panel="wasm" -->
```js
mapView.setVectorTileSource({
  urlTemplate: 'https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf',
  sourceName: 'openfreemap',
  attributionText:
    'Map data © OpenStreetMap contributors (ODbL) · style Bright from OpenFreeMap styles, design CC BY 4.0',
  styleId: 'bright-light',
  minimumZoomLevel: 0,
  maximumZoomLevel: 14,
});
const status = mapView.vectorTileSourceStatus();
```

While a vector source is installed, the canvas hides the raster layer and
paints the style's own background. The status readback reports whether a
source is configured, the style id, the source name, the attribution line,
the zoom ceiling, and the last frame's drawn and failed tile counts. A failed
count above zero with a `lastFailureDetail` means the tileset refused some
tiles; the base stays installed and the next frame retries.

The install is refused while a frame is resolving. Call it outside
`renderFrame`, or retry after the frame settles. Return to the raster layer
with `clearVectorTileSource()`.

```js
mapView.clearVectorTileSource();
```

### The raster fallback

The canvas draws its same-origin recorded tiles first. A registry raster
template supplies a live fallback for addresses those tiles do not cover; a
registered live provider is consulted before the template.

```js
mapView.setRasterTileSource(
  'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  19,
);
```

The template must carry `{z}`, `{x}`, and `{y}`; the maximum zoom level must
be between 1 and 24. A blank template clears the fallback.

## Register a provider

Provider registration is a free call whose first argument is the provider
key from the shared registry. The credential lives in module memory only;
it is never persisted or logged.

```js
import init, { MapsSdk, registerProvider } from './web/rustic_maps_web_bindings.js';

await init();
const mapSdk = await MapsSdk.create();
registerProvider('mapquest', providerCredential);
```

`registerProvider` dispatches the key to a provider implementation compiled
into the WebAssembly module. A key with no compiled provider is refused with
a message naming the key. `clearProvider()` removes the registration; the
page then answers from recorded data and the raster fallback.

A refused credential or a key with no dispatch arm throws with the verbatim
detail. Apply the credential through a settings form or a test's runtime
environment; never compile it into the bundle.

## What you should see

After the vector install, `vectorTileSourceStatus()` reports a configured
source with the `bright-light` style id and the OpenFreeMap source name.
After `registerProvider`, the live calls resolve; before it, they reject with
the registration refusal. The canvas keeps drawing the keyless base and its
recorded tiles in either case.

## Constraints

- The module must be initialized and `MapsSdk.create()` resolved before a
  `MapView` is constructed.
- The browser surface has no reverse geocoding, no tile cache, and no
  host-implemented provider registration. A provider that needs those
  contracts is a compiled provider crate, covered in
  [Add a provider](adding-a-provider.md).
- `MapView.setVectorTileSource` refuses while a frame is resolving; retry
  after the frame settles.
- Tests never reach the network. Recorded tiles and provider responses are
  served from the page's own origin.

## Where to go next

- [Add a provider](adding-a-provider.md) for the two implementation routes.
- [Search and routing](search-and-routing.md) for the provider calls in a
  complete flow.
- [Offline maps](offline-maps.md) for archive routing in the browser.
