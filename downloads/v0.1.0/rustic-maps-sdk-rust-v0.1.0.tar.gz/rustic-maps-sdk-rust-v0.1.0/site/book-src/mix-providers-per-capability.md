# Mix providers per capability

You can serve each capability of the map from a different provider. A typical
application searches with one vendor, routes with a self-hosted engine and
draws its base map from a public tileset. This page shows how selection
works, what the SDK reports back, and what the reference apps put on screen.

## What you get

- One call per capability, so a choice never disturbs the rest of the map.
- A readback that names the serving provider for every capability.
- A refused choice that leaves the previous provider serving, so a bad
  credential never leaves the app without a provider.

## How selection works

The SDK keeps one slot per capability. A call into an empty slot fails with
`ProviderNotConfigured` naming the capability, never with another provider's
answer. Two calls fill the slots:

| Call | Effect |
|---|---|
| `setProviderCredential(key)` | Fills every capability the vendor serves, in one call |
| `configureProvider(contract, providerKey, credential)` | Fills exactly one capability |

Both are addition-safe: calling either replaces only the slots it names.

## A worked mix

The example is an Android application in Kotlin. It serves geocoding from
MapQuest, draws OpenStreetMap US vector tiles, and routes through a
self-hosted OSRM deployment. The same three calls exist on every target.

1. **Set the vendor credential.** This fills geocoding, routing, distance
   matrix, place search, traffic incidents, traffic flow and raster tiles.

   ```kotlin
   mapSdk.setProviderCredential(mapQuestApiKey)
   ```

2. **Replace routing with the self-hosted engine.** The routing slot now
   serves OSRM; every other capability keeps its provider.

   ```kotlin
   mapSdk.configureProvider(
       contract = ProviderContract.Routing,
       providerKey = "osrm",
       credential = "http://10.0.2.2:5000",
   )
   ```

3. **Install the vector base.** The base map is a surface registration, not a
   registry slot, so it does not disturb any capability.

   ```kotlin
   mapView.setVectorTileSource(openStreetMapUnitedStatesSource)
   ```

4. **Read the result.** `providerRegistrations()` reports one entry per
   capability in a stable order.

```kotlin
mapSdk.providerRegistrations().forEach { registration ->
    println("${registration.contract}: ${registration.displayName.ifEmpty { "not configured" }}")
}
// Geocoding: MapQuest
// Routing: OSRM
// DistanceMatrix: MapQuest
// PlaceSearch: MapQuest
// TrafficIncidents: MapQuest
// TrafficFlow: MapQuest
// Elevation: not configured
// RasterTiles: MapQuest
// VectorTiles: OpenStreetMap US
// OfflineRouting: not configured
```

## Keyless providers

A self-hosted routing engine has no credential. Pass an empty string, or pass
the deployment's base URL, which the provider reads as its address:

| Provider | Credential field |
|---|---|
| OSRM | Base URL of the deployment; empty for a local server on port 5000 |
| Valhalla | Base URL of the deployment; empty for a local server on port 8002 |

A provider that declares a credential refuses a blank one and keeps the
previous provider serving.

## What the reference apps show

Every reference app renders one settings row per capability, in the order the
readback returns. Each row shows the serving provider's display name and a
picker limited to the providers that declare that capability. The choice is
remembered across launches with the app's other remembered choices; a
capability with no provider reads "Not configured".

## Rules to keep

- A provider's name belongs in its crate, its sample-data directory, the
  shared registry descriptor and the catalog row. Nothing else names it.
- Sample responses are committed fixtures served under
  `/providers/{provider_key}/…`; tests never reach the network.
- Changing a capability never silently changes another. If a call would
  replace more than the capability it names, it is not this API.

## Next

- [Add a provider](adding-a-provider.md) walks the crate, descriptor and
  catalog row.
- [Search and routing](search-and-routing.md) covers the calls the
  capabilities serve.
- [Provider capabilities in Rust](provider-capabilities-rust.md) lists the
  traits each capability maps to.
