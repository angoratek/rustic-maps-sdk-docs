# Screenshots

Each capture below comes from the reference application for that platform,
on the same recorded Capitol Park ⇔ Tower Bridge trip, in the same state:
the turn-by-turn banner with the next maneuver, the planned route polyline
with its A and B pins, the ETA-distance line, the playback-speed controls
and the exit control. All four were taken from one revision of the SDK
without a provider credential stored in the build.

## Android — Kotlin and Jetpack Compose

![The Android reference application during a simulated trip through downtown Sacramento: the maneuver banner and then-line at the top of the map, the planned route polyline, the map control cluster with the N compass, the scale bar, and the navigation drawer with the ETA-distance line, the phase, the speed chips, voice guidance, pause and exit](img/android-reference-app.png)

## iOS — Swift and SwiftUI

![The iOS reference application in the same simulated trip: the maneuver banner and then-line at the top of the map, the planned route polyline, the map control cluster with the N compass, the scale bar, and the navigation drawer with the ETA-distance line, the phase, the speed chips, voice guidance, pause and exit](img/ios-reference-app.png)

## React Native — one TypeScript surface, two native shells

![The React Native reference application in the same simulated trip inside the shared TypeScript shell: the maneuver banner and then-line, the planned route polyline with its destination pin, the map control cluster with the N compass, the scale bar, and the navigation drawer with the ETA-distance line, the phase, the speed chips, voice guidance, pause and exit](img/react-native-reference-app.png)

## WebAssembly — the browser build

![The WebAssembly reference application in the same simulated trip: the maneuver banner and then-line at the top of the map, the planned route polyline, the map control cluster with the N compass, the scale bar, the trip card with the ETA-distance line and the speed chips, and the exit control](img/wasm-reference-app.png)

The browser build runs the SDK's own WebAssembly module and draws through
WebGPU, so it is the same core rather than a simulation. The capture shows
its consumer surface: the trip planner with both endpoints chosen, the route
summary, and the live guidance on the map. It is served keyless at
[the live demo](live-demo.md).

## Vector base with place labels

![The browser demo drawing the OpenFreeMap Bright vector base: streets named along their own lines — Capital City Freeway, H Street, J Street, Broadway, El Dorado Freeway — and places named above them, Sacramento, Downtown, Midtown, East Sacramento, all drawn from the glyph atlas with halos over the styled roads and parks](img/vector-labels.png)

Labels are renderer output, not page markup: the decoder hands the renderer
the `place` and `transportation_name` features, the style's symbol layers
name the text, and the embedded glyph atlas supplies the shapes. Street
names ride their own roads, rotated to the road's bearing and skipped when
the text would not fit; place names sit above them, and a collision pass
keeps one from covering another. They arrive with the vector base; a raster
base carries its imagery's own labels instead. Every surface draws them.

## Reading the screenshots

The captures share one design language and show the same moment of the same
flow: readiness, search, a planned route, and the simulated trip. They also
share one vocabulary: *maneuver banner*, *then line*, *route polyline*,
*map control cluster*, *compass*, *scale bar*, *navigation drawer*, and the
browser's *trip card*. Differences are the platform's own chrome:
Compose's Material surface on Android, SwiftUI's safe-area handling on iOS,
the React Native host view, and the browser's WebGPU canvas. The map
content, the guidance, the control cluster and the scale ladder are the
same.
