# Provider capabilities in Rust

The Rust crates are the SDK's implementation layer. A provider is a struct
that implements one or more of the vendor-neutral traits in
`geospatial-traits`; the core resolves it through `rustic_maps_core::ProviderRegistry`.
The four application targets bind this same core through the contract.

The repository publishes the Rust API reference, but it does not publish a
Rust application package or a public Rust `MapsSdk`/`MapView` object. The
downloadable artifacts are the Android, iOS, React Native, and WebAssembly
targets. If you build inside the repository, the traits, registry, provider
crates, renderer, navigation reducer, and offline archive APIs are available
directly.

## What you need

- Rust 1.87 or newer, with the repository's Cargo workspace.
- A provider credential only for the live provider APIs, read at runtime and
  never stored in the crate, a sample response, or a log.

## Providers available in Rust

| Provider | Key | Credential | Form in Rust | Serves |
|---|---|---|---|---|
| MapQuest | `mapquest` | API key | `mapquest-provider` implementations | Geocoding (forward and reverse), search and suggestions, routing, distance matrix, traffic incidents and flow, raster tiles |
| OpenStreetMap Standard | `openstreetmap` | None | `UrlTemplateRasterTileProvider` with the registry template | Raster tiles |
| OpenStreetMap US | `osmus` | None | `OpenStreetMapUsVectorTileProvider` | Vector tiles with Carto Light and Carto Dark |
| OpenFreeMap | `openfreemap` | None | `UrlTemplateVectorTileProvider` with the registry template | Vector tiles with Bright, Fiord, and Positron |
| OSRM | `osrm` | None | `osrm-provider` | Routing |
| Valhalla | `valhalla` | None | `valhalla-provider` | Routing |

| Provider | Attribution line | Terms |
|---|---|---|
| MapQuest | Map data © OpenStreetMap contributors (ODbL) — tile imagery © MapQuest | MapQuest terms apply: rate limits and a 30-day raster-tile caching ceiling. |
| OpenStreetMap Standard | Map data © OpenStreetMap contributors (ODbL) — raster tiles © OpenStreetMap contributors | OpenStreetMap tile usage policy applies: low-volume use only, with attribution. |
| OpenStreetMap US | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenStreetMap US | OpenStreetMap US tileservice terms apply: free for low-volume, non-commercial use with attribution. |
| OpenFreeMap | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenFreeMap and OpenMapTiles | OpenFreeMap terms apply: free public use with attribution; bulk downloads are limited to 3,000 tiles or 50 MB per download. |
| OSRM | Map data © OpenStreetMap contributors (ODbL) — routing by OSRM | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |
| Valhalla | Map data © OpenStreetMap contributors (ODbL) — routing by Valhalla | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |

Each vector style also carries its own attribution line. The style ids are
`carto-light` and `carto-dark` (OpenStreetMap US), and `bright-light`,
`fiord-dark`, and `positron-light` (OpenFreeMap). The vector source's status
readback reports the active style's line.

Whether a provider is reachable from a shipped target depends on that
target's dispatch table. The browser target registers MapQuest; the vector
base reaches every target through the generic URL-template vector provider.

## What you can call

| Capability | Rust surface |
|---|---|
| Forward and reverse geocoding | `GeocodingProvider`; `MapQuestGeocodingProvider` |
| Suggestions and search | `SearchPlaceProvider`; `MapQuestSearchPlaceProvider` |
| Routing with options | `RoutingProvider`; `MapQuestRoutingProvider` |
| Distance matrix | `DistanceMatrixProvider`; `MapQuestDistanceMatrixProvider` |
| Traffic incidents and flow | `TrafficIncidentProvider`, `TrafficFlowProvider`; the MapQuest implementations |
| Elevation | `ElevationProvider`; no shipped implementation |
| Raster tiles | `RasterTileProvider`; `MapQuestRasterTileProvider`, `UrlTemplateRasterTileProvider` |
| Vector tiles | `VectorTileProvider`; `UrlTemplateVectorTileProvider`, `OpenStreetMapUsVectorTileProvider` |
| Offline routing | `OfflineRoutingProvider`, `ArchiveOfflineRoutingProvider`, `calculate_offline_route_from_archive_bytes` |
| Navigation | `rustic-maps-navigation`: reducer, policies, `RouteWalk`, `SimulatedTripPace` |
| Rendering | `rustic-maps-rendering`: `MapCamera`, headless renderer, surface renderer, committed vector styles |

The crates that carry these surfaces:

| Crate | Role |
|---|---|
| `geospatial-types` | Coordinates, bounding boxes, route records, tile data, and `SDKError` |
| `geospatial-traits` | The vendor-neutral provider traits |
| `rustic-maps-core` | `ProviderRegistry`, cache-then-network policy, offline routing, and the offline routing fallback |
| `provider-transport` | The portable HTTP transport seam: native `reqwest`, browser `fetch` |
| `mapquest-provider` | The MapQuest implementations of every supported contract |
| `url-template-raster-provider` | A raster-tile provider over any `{z}/{x}/{y}` template |
| `url-template-vector-provider` | A vector-tile provider over any `{z}/{x}/{y}` template |
| `openstreetmap-us-vector-provider` | The OpenStreetMap US Sourdough vector tileset |
| `rustic-maps-cache` | The disk response cache and byte budget |
| `rustic-maps-rendering` | The `wgpu` renderer, camera, and vector styles |
| `rustic-maps-vector-tiles` | The MVT decoder |
| `rustic-maps-glyphs` | The glyph reader, range cache, and atlas packer |
| `rustic-maps-navigation` | The navigation reducer, policies, speech pacing, and route walk |
| `rustic-maps-offline-graph-archive` | The reader for compiled routing archives |
| `rustic-maps-offline-graph-compiler` | The OpenStreetMap to archive compiler |
| `rustic-maps-native-core` | The UniFFI binding crate behind the native targets |
| `rustic-maps-web-bindings` | The WebAssembly binding crate |

## Implement a contract

A provider implements the trait for the contract it serves. The trait methods
are async and return `SDKError` when the provider refuses or fails.

```rust
use async_trait::async_trait;
use geospatial_traits::RoutingProvider;
use geospatial_types::route::{RouteData, RouteOptions};
use geospatial_types::{GeographicCoordinate, SDKError};

struct MyRoutingProvider;

#[async_trait]
impl RoutingProvider for MyRoutingProvider {
    async fn calculate_route(
        &self,
        waypoints: &[GeographicCoordinate],
        route_options: &RouteOptions,
    ) -> Result<RouteData, SDKError> {
        let _ = (waypoints, route_options);
        // Build the provider request, execute it through the transport, and
        // parse the answer into RouteData.
        todo!("implement the provider request and parse")
    }
}
```

## Register the provider

`ProviderRegistry` holds one optional slot per contract. Registering replaces
that slot; `require_*` answers `ProviderNotConfigured` with the contract name
when a slot is empty.

```rust
use std::sync::Arc;
use geospatial_traits::RoutingProvider;
use rustic_maps_core::ProviderRegistry;

fn registry_with(provider: Arc<dyn RoutingProvider>) -> ProviderRegistry {
    let mut registry = ProviderRegistry::new();
    registry.register_routing_provider(provider);
    registry
}
```

The shipped provider crates construct the same way. A URL-template raster
source takes the registry's template, zoom span, image format, resolution,
and user agent, plus the shared transport.

```rust
use geospatial_types::{RasterImageFormat, RasterTileResolution, SDKError};
use provider_transport::default_transport;
use url_template_raster_provider::{
    UrlTemplateRasterTileProvider, UrlTemplateRasterTileSource,
};

fn open_street_map_raster_source() -> Result<UrlTemplateRasterTileProvider, SDKError> {
    let transport = default_transport()?;
    UrlTemplateRasterTileProvider::new(
        UrlTemplateRasterTileSource {
            url_template: "https://tile.openstreetmap.org/{z}/{x}/{y}.png".to_string(),
            source_name: "openstreetmap".to_string(),
            minimum_zoom_level: 0,
            maximum_zoom_level: 19,
            image_format: RasterImageFormat::Png,
            tile_resolution: RasterTileResolution::Standard,
            user_agent: "MyMapApp/1.0 (+https://example.com)".to_string(),
        },
        transport,
    )
}
```

## Route without the network

The offline routing archive is the self-describing container compiled from
an OpenStreetMap extract. The helper takes the archive bytes, so the same
call serves every target.

```rust
use geospatial_types::{GeographicCoordinate, SDKError};
use rustic_maps_core::calculate_offline_route_from_archive_bytes;

async fn route_over_archive(archive_bytes: &[u8]) -> Result<(), SDKError> {
    let start = GeographicCoordinate {
        latitude: 0.001,
        longitude: 0.0,
    };
    let end = GeographicCoordinate {
        latitude: 0.001,
        longitude: 0.002,
    };
    let route =
        calculate_offline_route_from_archive_bytes(archive_bytes, &start, &end).await?;
    let _ = route.distance_meters;
    Ok(())
}
```

The request uses the archive profile's default options: automobile, fastest,
metric. A corrupt archive returns `OfflineRoutingFailure`; a coordinate
outside the graph's snap tolerance or a pair the graph cannot connect is
refused, never guessed.

## What you should see

After registering a provider, `require_*` answers the implementation and the
contract calls run through it. An empty slot returns
`ProviderNotConfigured` with the contract name. The offline helper returns a
`RouteData` on a connected pair, and a typed `SDKError` on a corrupt archive
or an unconnectable pair.

## Constraints

- A provider crate implements one or more of the traits and returns the
  contract's error types. It owns its vendor URL, credential handling, status
  mapping, attribution, and terms.
- Provider types must be `Send + Sync`; trait methods are async.
- Use `provider-transport` for HTTP so the native and browser builds share
  one request, retry, and rate-limit path.
- A new provider crate becomes reachable from a shipped target through that
  target's dispatch table and a registry descriptor. A contract with no
  registration call on the FFI surface needs an addition-only contract change
  before a native or browser application can select it.
- Tests never reach the network. Provider responses in tests come from
  committed sample data served under the provider's key.

## Where to go next

- [Add a provider](adding-a-provider.md) for the descriptor and dispatch
  work around a provider crate.
- [The FFI contract](udl-contract.md) for the surface the application
  targets bind.
- [Offline maps](offline-maps.md) for the archive and tile-cache story.
