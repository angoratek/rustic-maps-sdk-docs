# Requirements and distributions

The SDK ships as release archives that you download and install into your
project. This page lists the minimum platform versions, the artifact each
platform installs, and what each artifact weighs. [Downloads](downloads.md)
lists the released files and their checksums.

## Android

| Requirement | Value |
|---|---|
| Minimum API level | 24 |
| Compile SDK | 36 |
| Android Gradle Plugin | 9.0.0 (Gradle wrapper 9.5.1) |
| Kotlin binding runtime | `net.java.dev.jna:jna:5.18.1@aar` (UniFFI runtime) |
| Coroutines | `org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2` |

The release ships two AARs:

- `rustic-maps-sdk-android-v0.1.0.aar` — the Kotlin bindings and the Rust
  library for arm64-v8a, armeabi-v7a, and x86_64. The bindings AAR measures
  16 MiB; its stripped libraries measure 12 MiB for arm64-v8a, 8.7 MiB for
  armeabi-v7a, and 13 MiB for x86_64.
- `rustic-maps-sdk-android-ui-v0.1.0.aar` — the `MapView` and its Compose
  wrapper. It depends on the bindings AAR, so add both.

## iOS

| Requirement | Value |
|---|---|
| Deployment target | iOS 17 or higher |
| Swift tooling | `swift-tools-version: 5.10` (Swift 5 language mode) |
| Architectures | arm64 (device) and arm64 (simulator) |

The artifact is
`rustic-maps-sdk-ios-v0.1.0.xcframework.zip`: the XCFramework containing the
static library, its headers, and module maps, packaged for a Swift Package
Manager binary target. Each slice measures 217 MiB, and 207 MiB after
`strip -x`. A static archive carries every compiled object, and your final
link discards unused code, so these archive sizes are not the size your
application adds.

## React Native

The artifact is `rustic-maps-sdk-rn-v0.1.0.tgz`, the TurboModule source
package (`@angoratek/rustic-maps-sdk`). It carries the generated TypeScript
surface, the JSI C++ glue, and the podspec and CMake wiring.

- **React Native and React versions.** The generated glue targets React
  Native 0.88 or later and React 19 or later. For another version, regenerate
  the glue with a matching generator version.
- **Source package.** The compiled native payload is optional. With it, the
  package installs ready to run. Without it, your project builds the Rust code
  on the first build.

## WebAssembly

The wasm artifacts are:

- `rustic-maps-sdk-web-v0.1.0.tar.gz` — the wasm module, its JavaScript shim,
  and both type files.
- `rustic-maps-sdk-web-v0.1.0.tgz` — the same module with the npm manifest,
  licenses, and notices.

The package downloads 3.6 MiB, of which the wasm module is 3.4 MiB.

The browser surface renders through WebGPU. Chromium-based browsers support it
flag-free since 113 (2023), Safari from version 26, and Firefox since 141 with
desktop first. WebGPU is a secure-context API, so serve your page over HTTPS
or from localhost, and test for `navigator.gpu` rather than sniffing the
user agent. MDN's WebGPU page carries the live compatibility table.

## Notices

`rustic-maps-sdk-notices-v0.1.0.md` carries the third-party dependency notices
that accompany your own distribution.

## Versions policy

- **Pin exact versions.** Release archives are immutable and carry a version
  in the file name, for example `rustic-maps-sdk-android-v0.1.0.aar`. Keep the
  version you validated against, and upgrade deliberately.
- **One version line.** The Cargo workspace version is the single source of
  truth: the Android Maven publication, the npm packages, and the Swift
  manifest are all stamped from it at release time. The compiled SDK also
  returns its version through `getSdkCompiledVersion` across the FFI, so your
  diagnostics screen can verify the loaded library matches the artifacts you
  shipped.
- **The FFI contract changes addition-only.** Existing members keep their
  signature and meaning, so a minor-version upgrade keeps your compiled
  bindings valid. Packaging changes, such as an artifact-set change or a
  renamed target, bump the minor version while the release is 0.x.
- **Semantic versioning from 0.1.0.** A `vX.Y.Z` tag triggers a release. Tags
  are never moved, and a broken release is superseded by a new tag.
- **Checksums and signatures.** Every release carries a per-asset SHA-256
  checksum, an aggregated checksum manifest, and Sigstore signature bundles.
  Verifying them is part of the [Downloads](downloads.md) flow.

The sizes above are measured from the 0.1.0 artifacts.
