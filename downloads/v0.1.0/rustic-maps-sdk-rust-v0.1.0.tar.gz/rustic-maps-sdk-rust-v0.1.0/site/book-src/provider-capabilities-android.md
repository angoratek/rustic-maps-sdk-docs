# Provider capabilities on Android

Android exposes the full SDK surface: live provider APIs, keyless raster and
vector base maps, the disk tile cache, offline routing and turn-by-turn
navigation. This page lists the providers the shared registry declares, the
public Kotlin calls each capability uses, and the code that switches a base
map or registers a provider.

## What you need

- The Android bindings artifact and the `MapView` artifact, with
  `minSdk = 24`.
- A provider credential only for the live provider APIs. Read it at runtime;
  never place it in a build field, a resource, or source.

## Providers available on Android

| Provider | Key | Credential | Form on Android | Serves |
|---|---|---|---|---|
| MapQuest | `mapquest` | API key | Live provider | Geocoding (forward and reverse), search and suggestions, routing, distance matrix, traffic incidents and flow, raster tiles |
| OpenStreetMap Standard | `openstreetmap` | None | Raster base | Raster tiles |
| OpenStreetMap US | `osmus` | None | Vector base | Vector tiles with Carto Light and Carto Dark |
| OpenFreeMap | `openfreemap` | None | Vector base | Vector tiles with Bright, Fiord, and Positron |
| OSRM | `osrm` | None | Selectable routing provider | Routing |
| Valhalla | `valhalla` | None | Selectable routing provider | Routing |

MapQuest registers through a runtime credential. OpenStreetMap Standard
registers through the provider-neutral URL-template raster call.
OpenStreetMap US and OpenFreeMap are served by the shipped `MapView`'s vector
base member and need no registration call.

| Provider | Attribution line | Terms |
|---|---|---|
| MapQuest | Map data © OpenStreetMap contributors (ODbL) — tile imagery © MapQuest | MapQuest terms apply: rate limits and a 30-day raster-tile caching ceiling. |
| OpenStreetMap Standard | Map data © OpenStreetMap contributors (ODbL) — raster tiles © OpenStreetMap contributors | OpenStreetMap tile usage policy applies: low-volume use only, with attribution. |
| OpenStreetMap US | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenStreetMap US | OpenStreetMap US tileservice terms apply: free for low-volume, non-commercial use with attribution. |
| OpenFreeMap | Map data © OpenStreetMap contributors (ODbL) — vector tiles © OpenFreeMap and OpenMapTiles | OpenFreeMap terms apply: free public use with attribution; bulk downloads are limited to 3,000 tiles or 50 MB per download. |
| OSRM | Map data © OpenStreetMap contributors (ODbL) — routing by OSRM | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |
| Valhalla | Map data © OpenStreetMap contributors (ODbL) — routing by Valhalla | A self-hosted deployment follows its operator's terms; public demo servers are rate-limited and not for production use. |

Each vector style also carries its own attribution line. The style ids are
`carto-light` and `carto-dark` (OpenStreetMap US), and `bright-light`,
`fiord-dark`, and `positron-light` (OpenFreeMap). The status readback returns
the active style's line, so display it verbatim.

## What you can call

| Capability | Public Kotlin call |
|---|---|
| Forward and reverse geocoding | `MapSdk.forwardGeocode(addressText)`, `MapSdk.reverseGeocode(coordinate)` |
| Suggestions and search | `MapSdk.suggest(queryText, searchBoundary)`, `MapSdk.search(queryText, searchBoundary)` |
| Routing with options | `MapSdk.calculateRoute(waypoints, routeOptions)` |
| Distance matrix | `MapSdk.calculateDistanceMatrix(origins, destinations, transportationMode)` |
| Traffic incidents and flow | `MapSdk.fetchTrafficIncidents(boundingBox)`, `MapSdk.fetchTrafficFlow(boundingBox)` |
| Raster tiles | `MapSdk.fetchRasterTile(...)`, `MapSdk.registerUrlTemplateRasterTileSource(source)`; the `MapView` draws them |
| Disk tile cache | `MapSdk.setProviderCredentialWithTileCache(...)`, `MapSdk.setRasterTileCacheTimeToLive(...)`, `MapSdk.rasterTileCacheTerms()` |
| Vector tiles and styles | `MapView.setVectorTileSource(source)`, `MapView.clearVectorTileSource()`, `MapView.vectorTileSourceStatus()` |
| Offline routing | `offlineRouteFromArchiveBytes(archiveBytes, start, end)` |
| Navigation | `Navigator.startNavigation(...)`, `Navigator.updateLocation(...)`, `Navigator.addNavigationListener(...)`, `Navigator.applyReroute(...)`, `Navigator.stopNavigation()`; `RouteSimulator` |
| Host-implemented provider | `MapSdk.registerGeocodingProviderFromForeign(...)`, `MapSdk.registerRasterTileProviderFromForeign(...)` |

Every provider query on `MapSdk` is a `suspend fun`; run it from a coroutine
scope. Calls into a contract with no registered provider throw
`SdkException` with `ProviderNotConfigured` and the contract name.

## Switch the base map

### A styled vector base

The registry's keyless vector base for OpenFreeMap is Bright. Install it on
the shipped view; every following frame draws the styled base beneath your
overlays.

```kotlin
import uniffi.rustic_maps.UrlTemplateVectorTileSource

val openFreeMapBright = UrlTemplateVectorTileSource(
    urlTemplate = "https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf",
    sourceName = "openfreemap",
    attributionText = "Map data © OpenStreetMap contributors (ODbL) · style Bright from OpenFreeMap styles, design CC BY 4.0",
    styleId = "bright-light",
    minimumZoomLevel = 0u,
    maximumZoomLevel = 14u,
)
if (mapView.setVectorTileSource(openFreeMapBright)) {
    val status = mapView.vectorTileSourceStatus()
}
```

While a vector base is installed, the raster layer is hidden so its imagery
and labels cannot show through the style's translucent fills. The status
readback reports `isConfigured`, the style id, the source name, the
attribution line, the zoom ceiling, and the last frame's drawn and failed
tile counts. A failed count above zero with a `lastFailureDetail` means the
tileset refused some tiles; the base stays installed and the next frame
retries.

Return to the registered raster source with `clearVectorTileSource()`.

```kotlin
mapView.clearVectorTileSource()
```

### A URL-template raster base

Any web-mercator XYZ raster tileset with a `{z}/{x}/{y}` template serves
without provider code. OpenStreetMap Standard is the registry's keyless
raster source.

```kotlin
import uniffi.rustic_maps.RasterImageFormat
import uniffi.rustic_maps.RasterTileResolution
import uniffi.rustic_maps.UrlTemplateRasterTileSource

mapSdk.registerUrlTemplateRasterTileSource(
    UrlTemplateRasterTileSource(
        urlTemplate = "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        sourceName = "openstreetmap",
        minimumZoomLevel = 0u,
        maximumZoomLevel = 19u,
        imageFormat = RasterImageFormat.PNG,
        tileResolution = RasterTileResolution.STANDARD,
        userAgent = "MyMapApp/1.0 (+https://example.com)",
    ),
)
mapView.reloadRasterTileSource()
```

The registration replaces the raster-tile slot only; geocoding, routing,
search, and traffic keep serving. It drops an installed tile cache, because
the cache terms belong to the provider that installed it. `MapView`
resolves its raster provider when it attaches and keeps tiles by coordinate,
so call `reloadRasterTileSource()` after the registration to make the new
source serve the next frame.

## Register a provider

MapQuest registers from one runtime credential. The contract call installs
the shipped provider set with the SDK's rate-limit and retry defaults.

```kotlin
import uniffi.rustic_maps.MapSdk

val mapSdk = MapSdk()
mapSdk.setProviderCredential(providerApiKey)
```

A refused key throws `SdkException` with the provider's verbatim detail.
Apply the credential through your settings surface or a launch-time
automation seam; never compile it into the app.

To keep registration generic over provider keys, the shipped facade
dispatches the key to the matching SDK call. The facade's `nativeSdk` is the
one object the map view and every provider call use.

```kotlin
import com.rusticmaps.sdk.MapsSdkFacade

val facade = MapsSdkFacade()
facade.applyProviderCredential("mapquest", providerApiKey)
val mapSdk = facade.nativeSdk
```

A provider key with no dispatch arm is refused by name rather than pretending
to work. Adding an arm is covered in [Add a provider](adding-a-provider.md).

## What you should see

After the vector install, `vectorTileSourceStatus()` reports
`isConfigured = true`, the `bright-light` style id, and the OpenFreeMap
source name. After the raster registration and the view reload, the next
frame draws the OpenStreetMap tiles. After a credential registration, search,
routing, and traffic answer; without one, those calls throw `SdkException`
with `ProviderNotConfigured` while the keyless base still draws.

## Constraints

- `setProviderCredential` installs the shipped provider set; the provider
  key in the facade selects the registration arm, not a provider inside the
  SDK.
- Only geocoding and raster tiles have host-implemented interfaces. Routing,
  search, distance matrix, traffic, elevation, vector tiles, and offline
  routing need a Rust provider crate.
- Re-registration replaces every slot on the `MapSdk` object. A second
  `MapSdk` needs its own registration.
- Tests never reach the network. Provider responses in tests come from
  committed sample data served under the provider's key.

## Where to go next

- [Add a provider](adding-a-provider.md) for the two implementation routes.
- [Search and routing](search-and-routing.md) for the provider calls in a
  complete flow.
- [Offline maps](offline-maps.md) for the tile cache and archive routing.
