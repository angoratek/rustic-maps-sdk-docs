# Downloads

Every package is published under this site's own versioned path,
`/downloads/vX.Y.Z/`, and mirrored to an immutable release record: the version
page lists the exact files, and a new version never rewrites an existing one.
There is no Maven Central, npm registry or Swift Package Manager registry
entry — the files served from this site are the artifacts you install.

<!-- downloads-version:begin -->## Version 0.1.0<!-- downloads-version:end -->

The files below are built from this repository and served from this site.
Every file carries a `.sha256` sidecar, and
[`SHA256SUMS.txt`](downloads/v0.1.0/SHA256SUMS.txt) covers the set.

<!-- downloads-table:begin -->
| Platform | Artifact |
|---|---|
| Android (bindings) | [`rustic-maps-sdk-android-v0.1.0.aar`](downloads/v0.1.0/rustic-maps-sdk-android-v0.1.0.aar) |
<!-- downloads-table:end -->

Each artifact file and `SHA256SUMS.txt` also have a `.sigstore.json`
signature bundle, attached by the release workflow when it publishes a
release; the checksum files above are always present.

## What accompanies every release

Every version carries a per-file `.sha256` sidecar, an aggregated
`SHA256SUMS.txt` manifest covering all files, and a Sigstore signature bundle
(`.sigstore.json`) per file and for `SHA256SUMS.txt` itself. A published
version is immutable: a problem is fixed by a new version, never by replacing a
file.

## Verifying an artifact

Verify the checksum first, then the signature. The signature bundles bind the
file to the release workflow and the `vX.Y.Z` tag, so the verification command
pins both:

```bash
sha256sum --check SHA256SUMS.txt --ignore-missing

cosign verify-blob <artifact-file> \
  --bundle <artifact-file>.sigstore.json \
  --certificate-identity-regexp "<the identity printed by your download page>" \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

The version page prints the exact identity string for its own tag. The
`--ignore-missing` flag keeps the `sha256sum` run to the files you actually
downloaded.

### Rust

The Rust archive carries the workspace crates at this version. Unpack it and
point a path dependency at the crates you use:

```toml
[dependencies]
rustic-maps-rendering = { path = "rustic-maps-sdk-rust-v0.1.0/crates/rustic-maps-rendering" }
rustic-maps-navigation = { path = "rustic-maps-sdk-rust-v0.1.0/crates/rustic-maps-navigation" }
```

The [Rust guide](rust.md) walks the same map, routing and navigation steps the
other platforms use. A crates.io registry entry is not part of this version;
the archive is the source of truth.

## Installing from a release

The [tutorials](first-map.md) carry the per-platform install steps against
these exact artifact names: the AAR for Android, the checksummed zip for the
Swift Package Manager binary target, and the module archive for the wasm
package. The npm packages ship the same generated trees with a manifest,
licenses and notices.

To build the same packages from a checkout, each one has a script that
produces the artifact the tutorials install —

| Package | Script | Output |
|---|---|---|
| Android | `scripts/build-android.sh` | the bindings AAR and the `MapView` wrapper AAR |
| iOS | `scripts/build-ios.sh` | the XCFramework and the verified Swift package |
| React Native | `scripts/build-rn.sh` | the generated TurboModule sources and native payload |
| WebAssembly | `scripts/package-web-npm.sh` | the npm tarball (build the wasm package first) |

The scripts print their prerequisites when one is missing; they are the same
steps the release pipeline runs.
