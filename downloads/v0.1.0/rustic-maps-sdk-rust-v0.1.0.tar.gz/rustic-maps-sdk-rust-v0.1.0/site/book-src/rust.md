# Use the SDK from Rust

The map SDK is a Rust workspace. The same crates that back the Android, iOS,
React Native and WebAssembly bindings can be used directly by a Rust
application: the renderer, the camera and projection math, the provider
traits, the navigation controller and the offline routing graph all live in
Rust and have no platform dependency.

## Crates

| Crate | What it provides |
|---|---|
| `rustic-maps-rendering` | The camera and projection model, the raster tile scheduler, overlays, labels and the headless `wgpu` renderer |
| `rustic-maps-core` | The provider registry, provider contracts, offline routing and the shared SDK operations |
| `geospatial-types` | Coordinates, tiles, records and the shared error type |
| `geospatial-traits` | The vendor-neutral provider traits a tileset, routing or geocoding service implements |
| `rustic-maps-navigation` | Route walking, instruction generation, deviation and reroute policy |
| `rustic-maps-positioning` | Position validation, course smoothing and the simulated position source |
| `rustic-maps-vector-tiles` / `rustic-maps-glyphs` | Mapbox Vector Tile decoding and glyph-atlas packing |
| `rustic-maps-offline-graph-archive` | Reading compiled offline routing graphs |

The crates are consumed from the SDK source today; a registry package follows
the first Rust release.

## Camera and projection without a GPU

Camera math and projection are pure Rust and run anywhere:

```rust
use geospatial_types::GeographicCoordinate;
use rustic_maps_rendering::{DEFAULT_FIELD_OF_VIEW_DEGREES, MapCamera, ViewportPixels};

let center = GeographicCoordinate::from_degrees(38.5766, -121.4944)?;
let camera = MapCamera::new(center, 12.0, 0.0, 0.0);
let viewport = ViewportPixels::new(1280.0, 720.0)
    .map_err(|detail| format!("invalid viewport: {detail}"))?;

let screen_point = camera.project_to_screen(
    &center,
    &viewport,
    DEFAULT_FIELD_OF_VIEW_DEGREES,
);
```

## Rendering a frame

`rustic-maps-rendering`'s headless renderer draws into an offscreen `wgpu` target:
create a `HeadlessTileRenderer` over a `GraphicsContext`, resolve the camera's
visible tiles through a `TileScheduler`, and read the frame back as RGBA
bytes. The renderer is the same one the native surfaces use, so what you see
offscreen matches what a platform view presents.

The browser uses the same camera, overlay, label and vector-style modules; it
binds them through a WebAssembly canvas adapter rather than a Rust surface.

## Providers

Implement the vendor-neutral traits from `geospatial-traits` — a raster or
vector tileset, a routing engine, a geocoding service, a distance matrix or
traffic — and register them in the `rustic-maps-core` registry. The registry is what
the SDK's operations dispatch through, so a Rust application and a platform
binding share the same provider story. See
[Add a provider](adding-a-provider.md) for the descriptor fields and the
registration path.

## Positioning

`rustic-maps-positioning::PositionController` validates the fixes your OS source
reports, smooths their course and tracks staleness, so a Rust application can
feed the same stream to the renderer's location layer, a follow camera and
the navigation controller. `SimulatedPositionSource` walks a route for tests
and demos:

```bash
cargo run -p rustic-maps-positioning --example simulated_walk
```
