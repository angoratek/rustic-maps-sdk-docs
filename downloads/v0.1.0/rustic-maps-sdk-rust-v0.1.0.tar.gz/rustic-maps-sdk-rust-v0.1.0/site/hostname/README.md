# `sdk.mapquest.live` proxy project

A deployment of this directory is the Vercel project behind
`sdk.mapquest.live`. `vercel.json` **rewrites** every path to the published
SDK documentation on GitHub Pages, preserving the subpath. A rewrite proxies
the response server-side, so the browser keeps `sdk.mapquest.live/…` in the
address bar (a redirect would replace it with the GitHub Pages URL).

```bash
# one-time link and production deploy (from this directory)
vercel link --project rustic-maps-sdk-docs-redirect
vercel --prod
# attach the hostname (Vercel-managed DNS creates the record)
vercel domains add sdk.mapquest.live
```

Verify:

```bash
curl -s -o /dev/null -w '%{http_code}\n' https://sdk.mapquest.live/
curl -s https://sdk.mapquest.live/ | grep -o '<title>[^<]*</title>'
curl -s -o /dev/null -w '%{http_code}\n' https://sdk.mapquest.live/demo/
```

Expected: `200` and the docs site's title for the root and every subpath
(`/`, `/first-map.html`, `/demo/`), with no `location` header. The design
note, alternatives and risks live in `docs/DocsHostname.md`; the milestone is
M14 in `PLAN.md`.
