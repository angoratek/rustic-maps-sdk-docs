# PLAN.md — Rustic Maps SDK

Structure and maintenance rules live in `CLAUDE.md` §4: completed milestones are `[x]` one-liners; each active milestone carries a status header, a `> Verify:` line and checkbox work items; residuals of closed milestones sit in §2; the progress log keeps the current rounds detailed and older ones compressed to a dated line; owner questions live in §5.

**Last updated:** 2026-11-02 (round 130: MapLibre line, fill/circle and symbol-text slices; the raster-fallback defect specced as M53).
**Status:** §1 is authoritative. Its milestone order, each `> Verify:` line and its checkbox state are the status.

---

## 0. Founding gate

- [x] Product decisions locked with the product owner (PRD §6): UDL-first UniFFI; own minimal `wgpu` raster renderer first; custom self-describing offline graph from OSM; wasm first-class target.
- [x] REVIEW GATE: PRD/PLAN approved (2026-10-27) — "perfect let's move forward".
- [x] `git init` (2026-10-27); first commit `ed76125`.

---

## 1. Milestones

**Execution order for the open work:** M54 → M55 → M56 → M57 → M61 → M58 → M59 → M60. Every item below is pickable on its own; a round lands a coherent slice and records it in §4 and `CHANGELOG.md`.

### Completed milestones

One line each; the full record is in `CHANGELOG.md` and git history.

- [x] **M0 — Foundations** (2026-10-27, `ed76125`): workspace, nine provider contracts + mocks, registry + cache-then-network seam, property tests, CI.
- [x] **M1 — MapQuest provider** (2026-10-27, `48b4ef5`): rate limiter, retries, status mapping, seven APIs, fixtures + wiremock tests, live smoke. Elevation absent by provider retirement.
- [x] **M2 — Disk cache** (2026-10-27, `05b6b2a`): SHA-256 fingerprints, per-category TTLs, SQLite WAL store, LRU byte quota, cached wrappers; tile TTL 30 d with a provider-terms ceiling.
- [x] **M3 — Raster renderer** (rounds 3–13): web-mercator core, anchored camera, frustum tile listing, scheduler + texture cache, overlays, indicator, goldens, device fixes.
- [x] **M4 — Binding layer** (rounds 4–13): frozen UDL, `MapSdk`, camera + statistics, navigation controller, cache terms, diagnostics rings, Kotlin/Swift/ubrn/wasm packaging.
- [x] **M6 — Turn-by-turn navigation** (rounds 7–12): pure reducer, Ferrostar batches 1–3, UDL wiring, three recorded traces + replay tests.
- [x] **M7 — Offline routing** (rounds 13–14): `RMOG` compiler, validating reader, A* provider, maneuvers, pack manager, wasm path.
- [x] **M8 — WebAssembly and browser loop** (rounds 8–14): wasm-bindgen surface, WebGPU canvas with byte-identical WGSL, playground, Playwright suite, offline-routing seam.
- [x] **RF-1…3 — Field-feedback fixes** (round 14): gesture direction per layer, instruction anchoring, the documentation tone guide; each pinned by its own tests.
- [x] **M9 — Vector tiles** (rounds 15–44): MVT decoder, style/render pipeline, hole fills, batching, provider-neutral URL-template source, native base-map switch, symbol/text pipeline. Residual: `reload_tile_source` (M55).
- [x] **M10 — Packaging and release** (rounds 22–129): tag-driven GitHub Release, four platform packages + checksums + notices, docs-site downloads. Residuals: M57.
- [x] **M11 — Doc-site product** (rounds 16–98): feature guides, four-platform tutorials, live keyless demo, downloads with checksums. Residual: built refapp artifacts (M57).
- [x] **M13 — Runtime credentials** (rounds 19–129): runtime key entry on all targets, Keychain/Keystore persistence, keyless honesty, hosted-demo key ruled. Residuals: future descriptors and keyed CI (M56).
- [x] **M14 — Docs hostname `sdk.mapquest.live`** (2026-10-29): live, proxied, valid certificate.
- [x] **M15 — Provider genericity** (2026-10-29): provider crate + registry descriptor + one dispatch arm; fixture router by key; name guard.
- [x] **M16 — CI/CD efficiency** (rounds 17–129): path filters, concurrency cancellation, local gate authoritative. Residuals: release `if` gates and the owner billing alert (M57).
- [x] **M17 — SDK API v2** (rounds 29–34): one `MapView` on all four targets, contract namespace `rustic_maps`, crate renames, regenerated bindings in the same commits.
- [x] **M18 — Documentation DX** (rounds 28–98): shareable platform URLs, one scenario per platform, snippet extraction and gates, downloads, screenshots page.
- [x] **M19 — Trip planning parity** (round 95): two fields, pins, fit margin, keyless demo plans.
- [x] **M20 — Canvas interaction** (round 44): overlay compositing and focal double-tap zoom.
- [x] **M21 — Vector cartography** (rounds 36–44): Bright/Fiord/Positron, three-way theme with Auto default.
- [x] **M22 — Native vector base** (rounds 37–44): one Rust pipeline on every app, styles selected from the registry.
- [x] **M23 — Browser render performance** (rounds 40–109): frame-budget harness, fetch/decode off the presenting frame, world-space overlays, persistent buffers, GPU timestamps. Residual: one instanced tile draw (M55).
- [x] **M24 — Hosted mobile demo** (rounds 39–40): Appetize tabs, click-to-start, budget endpoint, dedicated hosted key ruling.
- [x] **M25 — Tutorial overhaul** (rounds 36–77): extracted snippets, one worked example, concepts + quickstart tracks, four-platform gates.
- [x] **M26 — Product identity** (rounds 41–120): `com.rusticmaps.sdk.*` ids, display names, aligned descriptions; published package identities unchanged.
- [x] **M27 — Simulated trips** (round 42): distance-parameterised along the planned route on every platform.
- [x] **M28 — One vocabulary** (rounds 41): shared `ui_labels`, generated copy table, blocking drift gate.
- [x] **M29 — Live guidance on wasm** (round 43): reducer-driven panel, banner, deviations, follow camera.
- [x] **M30 — Crisp text** (round 56): measured SDF edge, 2× point-size parity, halos.
- [x] **M31 — Four-platform parity** (rounds 46–129): capability matrix, accessible web demo, keyboard model. Residual: retire the wasm label exports (M56).
- [x] **M32 — Documentation overhaul** (rounds 82–98): product voice, platform stories, generated API references, screenshots. Residual: Rust source archive publication (M57).
- [x] **M33 — Device positioning** (rounds 83–106): Rust `PositionController`, Android/iOS/RN/wasm sources, controls, device-driven navigation.
- [x] **M36 — Vector style refinement** (rounds 104–115): road hierarchy, width stops, z9 recording, native regional golden. Residuals: browser golden + numbers (M55).
- [x] **M37 — Reference-app settings** (round 125): remembered choices, sizing, browser↔mobile link, tests on all targets.
- [x] **M45 — Browser contract parity** (round 129): contract-shaped registry, legacy calls retired, parity gate, docs.
- [x] **M48 — Self-contained distributions** (round 129): RN tarball payload, `verify-rn-package.mjs`, guides.

### M54 — Close the reported base-layer and provider-fallback defects (M49, M50, M53) · *status: open (owner-reported 2026-11-01/02; PRD §6 items 43, 44, 47)*
> Verify: each reported scenario has a regression proof that fails on the old behaviour — the raster fallback never receives a request in a keyed session, a keyless session still draws live tiles, a base-map switch leaves no geometry or label from the previous base on any target, and a revisited traffic area answers from a bounded cache on Android/iOS as well as the browser.

- [x] M53 design note (`docs/design/BrowserRasterFallback.md`): fallback lifecycle, precedence, resolution order and the browser forbidden-header rule; indexed from `docs/README.md`.
- [x] M53 forbidden headers: the browser transport drops `User-Agent` and the Fetch specification's other forbidden request-header names before `fetch` (a portable predicate with native-runnable tests); the URL-template provider keeps its user agent for native; a browser case proves no forbidden header is sent.
- [x] M53 registry precedence (browser only): a fallback raster slot beside the registry; `registerUrlTemplateRasterTileSource` fills only the fallback; the canvas resolves the configured `RasterTiles` provider first and the fallback second; `clearProviderRegistrations` leaves the fallback; add `clearUrlTemplateRasterTileSource` (wasm export, `.d.ts`, parity gate). Tests: a keyed session makes zero fallback requests, a keyless session uses it, clearing returns to it.
- [x] M53 demo and proof: stop passing `userAgent`; register the fallback once; Playwright cases count request origins — a keyed vector → raster switch must contact only the keyed provider, and a keyless session must use the fallback.
- [x] M53 docs: the browser-provider guide states the precedence and lifecycle.
- [ ] M49 native proof: an application-level case clears the vector base during a draw and sees the raster return on the next frame.
- [ ] M49 vector → vector: a browser case asserts the first frame after a style change carries no geometry from the previous style.
- [ ] M49 cross-platform: the raster → vector → raster and vector → vector sequences asserted by the Android, iOS and RN UI suites.
- [ ] M50 native proof: one Android or iOS case asserts two settles and one provider call, plus a scripted-pan case proving the cache never exceeds its budget.

### M55 — Finish the MapLibre style adoption (M9, M23, M36, M51) · *status: open (owner-directed 2026-11-01; PRD §6 item 45)*
> Verify: the demotiles style — its labels, icons, dashes, casings and zoom rules — renders recognisably the same as MapLibre on a committed fixture, every remaining line/fill/circle/symbol property in the specification is honoured or explicitly diagnosed, and the road hierarchy and label density match the reference engines at city and regional zooms.

- [ ] Symbol layout completion (M51 Phase 6 remainder; transform, tokens, `text-offset`, line-center, avoid-edges, ignore-placement, declared spacing and, round 131, `text-max-width` wrapping with line height, letter spacing and justification landed): `text-anchor`, `text-radial-offset` and `text-variable-anchor`; `text-rotation-alignment`, `text-keep-upright`, `text-max-angle`; `icon-*` with a sprite atlas; a persistent collision index across frames; the demotiles end-to-end golden with its committed tile fixture and recorded attribution.
- [ ] M51 attribution: commit the licence texts and notices for the demotiles style and any font material in the phase that introduces them.
- [ ] M51 Phase 5 residual: `fill-sort-key` and `circle-sort-key` ordering, `fill-translate-anchor`, and style transitions/cross-fade.
- [ ] M36 proof: the browser regional golden beside the native Carto golden, and the before/after numbers recorded in `docs/design/VectorStyleRefinement.md`.
- [ ] M36 follow-up (only if data proves insufficient): an optional per-stop interpolation exponent in the artifact schema, additive.
- [ ] M39 collision padding, per-glyph boxes and priority ordering (class before rank; shields before names); regional thinning by rank and zoom; a typography audit against Bright; a native label golden plus an iOS capture.
- [ ] M38 motion grading: draw from cache during gestures and resolve style/label assembly after the settle.
- [ ] M9 residual: one additive contract member `MapView.reload_tile_source()` replacing the per-platform raster reload methods, with regenerated bindings and the wasm mirror in the same change.
- [ ] M23 residual: one instanced tile draw over a `texture_2d_array` with cached bind groups (cleanliness; measured 0.1–0.2 ms a frame at the harness scene size).
- [ ] Label coverage backlog: record a POI layer fixture + symbol layer + golden; decide route shields (text refs vs a shield overlay kind); add an artifact audit that reports named/ref-bearing source layers no style paints.

### M56 — Every target and reference app tells the same story (M5, M12, M13, M31, M34, M40, M41, M42, M44, M47) · *status: open (owner-directed 2026-10-30 → 2026-11-01)*
> Verify: every capability a reference app shows is reachable on all four targets with the same wording and flow; the shared refapp math exists once; the native and browser suites assert the same behaviours; and the screenshots page carries one revision's scenes for every platform.

- [ ] M12 Phase 1 `map-refapp-core`: follow-camera state machine, circular course median, smoothstep/exponential easing, scale-bar ladder and trace cursor, wasm-safe, with property tests.
- [ ] M12 Phase 2 wasm adoption: export the crate from `rustic-maps-web-bindings`, delete the mirrored math in `map_controls.mjs`, keep the Playwright assertions.
- [ ] M12 Phase 3 native bindings: `map_refapp_core.udl` + `scripts/build-refapp-core.sh`; Android then iOS adopt and delete their copies; refapp-only targets.
- [ ] M12 Phase 4 RN: generate the second ubrn module when ubrn is 0.32-aligned; until then keep the pinned copies.
- [ ] M12 Phase 5: route trace replay through the C1 contract additions; record the rejections (shared app state machine, surface host in the refapp crate).
- [ ] M5 RN shell follow-ups: a general edge-to-edge surface-height answer, drop the prebuilt-AAR `flatDir` consumption, and shrink the APK's two Rust copies.
- [ ] M5 surface host: thin the RN controller onto the shared wrapper helper.
- [ ] M5 trace fixture + replay driver into the contract: addition-only UDL records and `start_trip_from_trace`-shaped members, wasm mirror and contract sync in the same change.
- [ ] M5 RN Detox suite over the refapp feature checklist.
- [ ] M5 smoke CI: a keyed Espresso/XCUITest smoke job (with M13) and a wasm smoke job.
- [ ] M13 future provider descriptors: HERE, Google, TomTom, Mapbox and Radar rows + registration dispatch + terms, each with its provider crate.
- [ ] M13 keyed CI: the Android Espresso and iOS XCUITest suites keyed from a repository secret when configured; default jobs stay keyless.
- [ ] M31 labels: retire the wasm-only `setLabels`/`clearLabels`/`setGlyphRange` once the SDF coverage probe moves onto a vector-source fixture.
- [ ] M34 platform gates on the aligned tree: Android Espresso, iOS XCUITest, RN jest + Android build, wasm build + the full Playwright suite.
- [ ] M40 RN settings rows per capability from `provider_registrations()`, remembered like Android/iOS.
- [ ] M40 proof: a browser and a native case switch routing to OSRM, plan from fixtures, relaunch and see the restored choice.
- [ ] M40 docs: the *Mix providers per capability* page and the Rust source-archive note.
- [ ] M41 settings convergence: Base map and Overlay scenes become one-line pointers to the map control; the sheet keeps credentials and uncovered capabilities.
- [ ] M41 documentation: a *Map layers and traffic* chapter for all platforms; `ReferenceAppUX.md` §4 gains the component; recaptured screenshots with the panel closed and open.
- [ ] M41 proof: a browser and a native case show a style switch, a traffic overlay and a centered fix surviving a relaunch.
- [ ] M42 ferry regression case with the reference apps; a chapter section on mode/strategy honouring.
- [ ] M44 RN plan-flow audit against the iOS reference pattern, with the version string in the evidence; then the evidence series per target.
- [ ] M47 screenshots: capture the navigation frame plus the settings, layers and plan sheets on each target from one revision; rebuild the page; add the developer-console scene once M58 lands.

### M57 — Every distribution is generated and self-contained (M10, M11, M16, M32, M35, M46) · *status: open (owner-directed 2026-11-01; PRD §6 items 27, 40, 42)*
> Verify: a fresh install of every published artifact runs without a toolchain or a second Rust build; the browser and React Native surfaces are generated from the UDL rather than hand-maintained; and a published API reference cannot lag the revision it documents.

- [ ] M10 RN TurboModule identifier rename: `ubrn.config.yaml` name, codegen `MapsSdkRn`, `javaPackageName com.mapssdkrn` and the app-shell `file:` alias in one coordinated regeneration.
- [ ] M10 RN package native inputs at release: the release `rn` job ships the payload, and the RN iOS app-shell build gets past Xcode 26's explicit-module scan of `React-Core-prebuilt` (or the prebuilt is upgraded).
- [ ] M10 demo code leaves the shipped SDK packages: move the demo scenes loader and UX theme out of the AAR and `MapNativeCoreUI` (audit C10).
- [ ] M11 downloads: Android APK, the wasm demo and an iOS simulator build behind the documented owner ruling.
- [ ] M16 release efficiency: job-level `if` gates so an unchanged platform artifact is not rebuilt on a release re-run.
- [ ] M16 owner billing action: the account-level GitHub spending limit and notification alert (queued; not a code task).
- [ ] M35 wasm generation: load the generated `wasm2` module with its async init, migrate pages and tests, retires the hand-written types (or re-scopes `contract_sync.mjs` to the generated types).
- [ ] M35 RN generation: replace the hand-curated wrappers where the generated bindings suffice; re-run the shell on the emulator.
- [x] One WebAssembly package (2026-11-02): the npm tarball is the only wasm asset — it already carries the module, its shim, both type files, the manifest, licences and notices — and the plain `.tar.gz` is retired; the guides show `npm install` and extract-and-serve-`package/` paths.
- [ ] M35 generated docs: build the WebAssembly API reference from the generated TypeScript and update the guides.
- [ ] M46 generation gate: mark generated pages, fail the site build on a missing or stale page, and assert a publish used the current revision.
- [ ] M46 republish at every contract/rustdoc/reference round and record the published revision. A publish must follow a **full** artifact assembly: a locally staged partial set (for example an Android-and-wasm-only rebuild) must never replace the published downloads.
- [ ] M46 publish this round's guide changes once a full artifact set is assembled (the local staging from the packaging round is partial and was not published).
- [ ] M32 Rust distribution: publish the `rustic-maps-sdk-rust-v<version>.tar.gz` source archive with checksums and the install note at the next version.

### M58 — Developer console on every target (M43, with M50 rows) · *status: open (owner-directed 2026-11-01; PRD §6 item 37)*
> Verify: every reference app and the browser demo opens one developer console from a floating control; it shows the scrubbed event stream at Error/Warning/Info, a detail sheet with the provider request trace, cache hit/miss rows and an export through the platform share sheet; a credential never appears in the stream or the export.

- [ ] Contract wave: `ProviderRequestTrace` and the optional `provider_request_trace` field on `LogEvent`, addition-only, with regenerated surfaces in the same change.
- [ ] Transport emission completion: MapQuest and the URL-template clients wrap their transports; the observer bridges into the diagnostics ring.
- [ ] Console surface: floating control, level filter, detail sheet and download on web; share sheet on Android and iOS; React Native; a Warning/Error dot; read-only over the SDK stream.
- [ ] Traffic cache rows: the frame diagnostics and the console show the traffic cache's counters beside the tile cache's (M50 residual).
- [ ] Documentation: a chapter on reading the console and what each field means.

### M59 — Finish the documentation set (M52) · *status: open (owner-directed 2026-11-01; PRD §6 item 46)*
> Verify: every file under `docs/` answers a reader question that is still true, superseded material is consolidated or deleted, and every cross-reference from `CLAUDE.md`, `README.md`, `PRD.md`, `PLAN.md` and the scripts resolves.

- [ ] M52 apply: merge the duplicate style guides, consolidate the positioning and route-planning designs, move dated audits to `docs/history/`, fix the load-bearing passages the critics found, and update every reference in the same change.

### M60 — Housekeeping and backlog · *status: open*
> Verify: each item closes with its own test or gate; nothing here silently changes behaviour.

- [ ] Every public identifier full-name (no abbreviations), enforced by review and a clippy lint where possible.
- [ ] Commit the Open Sans / Noto Sans OFL text under `docs/THIRD_PARTY_LICENSES/` beside the glyph fixtures; extend the notices' prior-art section.
- [ ] Thin the contract-sync parser (audit C5): a machine-readable UDL dump replaces the hand-rolled reader.
- [ ] Sacramento fixture sweep: the remaining Zurich/Berlin data families and the recorded provider payload anchors.
- [ ] Capture-free `snapshot()` for deterministic tests without a WebGPU re-present.
- [ ] Wasm fetch-shim / IndexedDB tile-cache seams.
- [ ] Native `CameraInteraction` FFI wiring (round-13 §5 item 1): decide the answer shape, then implement.
- [ ] Binding-surface consolidation audit: lean on the Rust base + UDL generation maximally.
- [ ] Repo-wide refinement critic sweep.
- [ ] Next addition-only contract wave: `start_trip_with_arrival_policy`, `course_heading_degrees` + `CourseFiltering`, `NavigationRecorder` start/stop/drain, a typed `CameraPose`-answer `CameraInteraction`, and proper `SdkError` variants for offline/cache failures; each ships the UDL + wasm mirror + four wrapper regens in one commit.

### M61 — One Android artifact · *status: open (owner-directed 2026-11-02; PRD §6 item 48)*
> Verify: an Android application depends on one published artifact carrying the generated Kotlin bindings, the per-ABI Rust libraries and the `MapView`/Compose wrapper; the downloads page, the release notes and the first-map tutorial each name that single file; the reference application builds against it; and the release assembly publishes exactly one Android AAR, rejects the retired second file, and checks the artifact's contents.

- [x] Merge the wrapper into one artifact: either fold `:map-sdk-native`'s generated Kotlin and `jniLibs` into `:maps-sdk`, or add a deterministic fat-AAR merge step (bindings classes, `jni/<abi>`, consumer rules, manifest) that fails loudly when an input is missing. Keep `com.angoratek:rustic-maps-sdk` as the one published identity and `com.rusticmaps.sdk` as the namespace.
- [x] Release assembly: `scripts/assemble-release-artifacts.sh` stages one `rustic-maps-sdk-android-v<version>.aar`; `.github/workflows/release.yml`'s artifact set and `scripts/generate-release-readme.sh` follow; a verification step asserts the AAR contains the bindings classes, the three ABIs and the wrapper classes, and rejects the retired `android-ui` file.
- [x] Reference application: it depends on `:maps-sdk` (unchanged) and `:reference-application:assembleDebug` builds against the merged artifact; the Espresso suite rides with M54/M56 device work.
- [x] Docs and tutorials: `site/book-src/first-map.md#android`, `requirements.md`, `downloads.md`, `versions-and-support.md`, `docs/PackagingAndRelease.md` and `scripts/build-docs-site.sh` each show one dependency line and one download row; the docs build and the snippet gates pass.
- [ ] Proof: a clean Android application outside this repository adds the one artifact and renders a `MapView`, with the evidence path recorded; the smoke-jvm module covers the same call path.

## 2. Backlog & cross-cutting

- [ ] Nothing outstanding beyond §1's M60; new findings land as M60 checkboxes with their evidence.

## 3. Risks & mitigations

| Risk | Mitigation |
|---|---|
| A provider name or URL shape leaks outside its crate/registry | `provider_name_guard.mjs` in `globalSetup` and `node --test`; ask "would this work unchanged for a second provider?" |
| A credential reaches a build, fixture, log, doc or screenshot | Runtime entry only; `ProviderCredentialsAndBrowserProviders.md` §6 grep gates; the one hosted-demo exception is bounded in §6.1 |
| A test reaches the network | Committed fixtures under `/providers/{provider_key}/…`; the GPU harness runs outside `npm test` |
| A stale base layer or fallback serves the wrong provider | M54's precedence rule and origin-counting proofs; the renderer invalidates its vector cache on install/clear |
| Generated surfaces drift from the UDL | `contract_sync.mjs` plus the M57 generation gate |
| PLAN/CHANGELOG drift from the tree | This prune (2026-11-02): checklists only, one-liners for completed work, dated log |

## 4. Progress log

Older rounds are compressed to one dated line; the full record is `CHANGELOG.md` and git history.

- **2026-10-27 → 10-28** — Foundations through the raster renderer and the contract binding; four product decisions locked; first CI and hooks.
- **2026-10-29** — Navigation, offline graph, vector tiles, provider genericity, runtime credentials, docs hostname; the field-feedback fixes.
- **2026-10-30** — API v2, docs DX, the live-demo review milestones, the shared vector base, the hosted mobile demo, browser performance work.
- **2026-10-31** — Four-platform parity, SDF text quality, the worked example, positioning on every target, generated downloads and screenshots.
- **2026-11-01** — Per-capability providers, settings persistence, direction modes, the on-map layers panel, the traffic cache, the browser contract parity, self-contained RN packages.
- **2026-11-02 (round 130, M51)** — The MapLibre adoption in four slices, each verified and pushed:
  - Phase 1: `rustic-maps-style` — version-8 document model, expressions, filters, colours, demotiles parsing with zero unsupported properties.
  - Phase 2: compiled render plans, the seven styles converted by a byte-stable script, global layer order across tiles; no golden regenerated.
  - Phase 3: sources bound to providers, deterministic GeoJSON tiling, raster style layers routed to the raster scheduler; the browser suite 149/149.
  - Phase 4 (`8b2d8e5`): `PolylineStroke` line semantics — miter/bevel/round joins (limit 2), butt/square/round caps, dashes in width units, offsets, casing gaps, blur fringe and `line-sort-key`; the new `line_semantics_strokes.png` golden; existing goldens unchanged.
  - Phase 5 (`689ff5f`): fill outlines/antialias/translate, circle strokes/blur/translate and `circle-pitch-*`; a translated fill or ground-pitched circle joins the camera-space assembly; the new `fill_and_circle_paint.png` golden.
  - Phase 6a (`230308f`): symbol text resolution (transform, `{token}` substitution, flattened `format`) and placement options (`text-offset`, avoid-edges, ignore-placement, line-center, declared spacing).
  - Owner-reported raster fallback defect root-caused (M53): the keyless URL-template source and `setProviderCredential` share one registry slot, so a remembered key can be replaced by the start-up fallback; the URL-template provider's `User-Agent` is also forwarded by the browser transport, failing OSM's CORS preflight. Design note written; M54 carries the fix.
  - Wrapped label text (round 131): `text-max-width` wraps point-placed labels on word boundaries (line-placed names stay single-line); `text-line-height`, `text-letter-spacing` and `text-justify` control the stack, advance and alignment; the collision box uses the block's width and height, and rotated names apply the same layout in their frame. Defaults reproduce the previous centering, so every label golden is unchanged.
  - Packaging consolidation: the Android release is one AAR now (generated bindings, three ABIs and the `MapView`/Compose wrapper in `:maps-sdk`, with `:map-sdk-native` an internal source holder and no publication); the assembly and workflow verify its contents and the reference app builds against it. The WebAssembly release is one npm tarball — it already carries the module, shim, types, manifest, licences and notices — and the plain `.tar.gz` is retired; the guides show `npm install` and extract-and-serve-`package/`. The downloads renderer, release README and tutorial/requirements pages follow.
  - M54 fix slice: the URL-template source became a true fallback in its own slot, resolved after the configured provider by the canvas and `fetchRasterTile`, with `clearUrlTemplateRasterTileSource` added; the browser transport filters the Fetch specification's forbidden request headers while native keeps the declared user agent; the demo stopped passing a user agent. Browser cases pin a keyless fallback fetch, a configured provider leaving the fallback untouched, the readback not calling the fallback configured, and a declared user agent never reaching the request. The M54 native and cross-platform base-layer proofs and the native traffic-cache proof stay open.
  - The agent worktrees were cleaned (83 GB freed); two trees with unpicked 2026-11-01 commits remain for review.

## 5. Queued owner questions

1. (Round 130) The keyless raster fallback never replaces a provider configured for raster tiles; an explicitly registered URL-template raster source is also a fallback, so a page that wants it to serve clears registrations first. Confirm, or rule that an explicit registration may opt in to overriding a configured provider.
2. (Round 129) Traffic cache defaults: zoom-12 cells (about 10 km), 64 cells and five minutes of freshness; confirm or name different ones.
3. (Round 129) The committed Noto Sans glyph fixture carries no OFL text under `docs/THIRD_PARTY_LICENSES/`; confirm the licence file should be committed (also tracked in M60).
4. (Round 11) Drain-poll release (0.5 s poll) vs event-driven drain — confirm.
5. (Round 11) Reroute gate with no fix reference yet passes — confirm as default.
6. (Round 11) Cooldown anchors at calculation start (Ferrostar ordering) — confirm.
7. (Round 11) Movement gate measures raw fixes deliberately — confirm.
8. (Round 11) The phase channel stays payloadless — confirm.
9. (Round 11 / B4 platform) iOS last-seen-id dedup vs bounded set; focus-loss untestable without a rival audio holder; the consecutive-trigger drop at close cadence under the distance-only-refresh guard; Compose renders the suppressed countdown as an empty string — confirm each.
10. (Round 14) Maneuver text re-anchor: confirm the text-only end-anchoring convention (structured `ManeuverType` stays head-anchored; the roundabout residual folds into the maneuver-label ask), and the documented offline pre-arrival divergence.
