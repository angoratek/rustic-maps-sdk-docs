#!/usr/bin/env bash
# Builds the release artifact set locally and writes checksums, so a release
# can be assembled on a workstation when the hosted CI is unavailable and the
# docs build can publish real downloads.
#
# Output: target/release-artifacts/v<version>/ containing
#   - rustic-maps-sdk-android-v<version>.aar           (Kotlin bindings + Rust)
#   - rustic-maps-sdk-android-ui-v<version>.aar        (MapView wrapper)
#   - rustic-maps-sdk-ios-v<version>.xcframework.zip   (device + simulator)
#   - rustic-maps-sdk-web-v<version>.tar.gz            (wasm module)
#   - rustic-maps-sdk-web-v<version>.tgz               (npm package)
#   - rustic-maps-sdk-rn-v<version>.tgz                (npm package)
#   - rustic-maps-sdk-rust-v<version>.tar.gz           (Rust workspace sources)
#   - rustic-maps-sdk-notices-v<version>.md            (third-party notices)
#   - one `.sha256` sidecar per file and SHA256SUMS.txt
#
# Every file is built from the current checkout by the same scripts the
# release workflow runs. Sigstore bundles are not produced here (they need
# the release workflow's OIDC identity); the downloads page states that.
#
# Usage:
#   scripts/assemble-release-artifacts.sh
#   scripts/assemble-release-artifacts.sh --skip-android --skip-ios
#   scripts/assemble-release-artifacts.sh --skip-rust
#
# Prerequisites: the toolchains each build script checks (Rust targets, Xcode,
# Android SDK/NDK, Node/npm). Missing tools abort the relevant step.
set -euo pipefail

readonly REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly WORKSPACE_VERSION="$(
    sed -n 's/^version = "\(.*\)"/\1/p' "${REPO_ROOT}/Cargo.toml" | head -n 1
)"
readonly OUTPUT_DIR="${REPO_ROOT}/target/release-artifacts/v${WORKSPACE_VERSION}"

skip_android=false
skip_ios=false
skip_wasm=false
skip_rn=false
skip_rust=false
for argument in "$@"; do
    case "$argument" in
        --skip-android) skip_android=true ;;
        --skip-ios) skip_ios=true ;;
        --skip-wasm) skip_wasm=true ;;
        --skip-rn) skip_rn=true ;;
        --skip-rust) skip_rust=true ;;
        *) printf 'assemble-release-artifacts: unknown argument %s\n' "$argument" >&2; exit 1 ;;
    esac
done

log_step() {
    printf '\n==> %s\n' "$1"
}

mkdir -p "$OUTPUT_DIR"

if [ "$skip_android" = false ]; then
    log_step "building the Android bindings and MapView AARs"
    "${REPO_ROOT}/scripts/build-android.sh"
    cp "${REPO_ROOT}/platform/android/map-sdk-native/build/outputs/aar/map-sdk-native-release.aar" \
        "${OUTPUT_DIR}/rustic-maps-sdk-android-v${WORKSPACE_VERSION}.aar"
    cp "${REPO_ROOT}/platform/android/maps-sdk/build/outputs/aar/maps-sdk-release.aar" \
        "${OUTPUT_DIR}/rustic-maps-sdk-android-ui-v${WORKSPACE_VERSION}.aar"
fi

if [ "$skip_ios" = false ]; then
    log_step "building the iOS XCFramework"
    "${REPO_ROOT}/scripts/build-ios.sh"
    (
        cd "${REPO_ROOT}/platform/ios/artifacts"
        ditto -c -k --sequesterRsrc --keepParent rustic_mapsFFI.xcframework \
            "${OUTPUT_DIR}/rustic-maps-sdk-ios-v${WORKSPACE_VERSION}.xcframework.zip"
    )
fi

if [ "$skip_wasm" = false ]; then
    log_step "building and packaging the WebAssembly module"
    "${REPO_ROOT}/scripts/build-wasm.sh"
    tar -czf "${OUTPUT_DIR}/rustic-maps-sdk-web-v${WORKSPACE_VERSION}.tar.gz" \
        -C "${REPO_ROOT}/platform/web" pkg
    "${REPO_ROOT}/scripts/package-web-npm.sh" --output-dir "$OUTPUT_DIR"
fi

if [ "$skip_rn" = false ]; then
    log_step "packaging the React Native npm package"
    "${REPO_ROOT}/scripts/package-rn-npm.sh" --output-dir "$OUTPUT_DIR"
fi

if [ "$skip_rust" = false ]; then
    log_step "archiving the Rust workspace sources"
    # The crates are path-linked, so a registry package cannot resolve them;
    # the archive is the release-commit source tree, unpacked and consumed by
    # path dependency (the Rust guide's install note says how).
    git -C "$REPO_ROOT" archive --format=tar.gz \
        --prefix="rustic-maps-sdk-rust-v${WORKSPACE_VERSION}/" \
        -o "${OUTPUT_DIR}/rustic-maps-sdk-rust-v${WORKSPACE_VERSION}.tar.gz" HEAD
fi

log_step "copying notices and writing checksums"
cp "${REPO_ROOT}/docs/THIRD_PARTY_NOTICES.md" \
    "${OUTPUT_DIR}/rustic-maps-sdk-notices-v${WORKSPACE_VERSION}.md"
(
    cd "$OUTPUT_DIR"
    shasum -a 256 ./* | grep -v '\.sha256' | grep -v 'SHA256SUMS.txt' \
        | sed 's|  \./|  |' | sort -k2 > SHA256SUMS.txt
    while read -r checksum file_name; do
        printf '%s  %s\n' "$checksum" "$file_name" > "${file_name}.sha256"
    done < SHA256SUMS.txt
)

# The manifest the docs build renders the downloads table from, so a new
# version never edits prose (name, size and checksum per artifact).
node - "$OUTPUT_DIR" "$WORKSPACE_VERSION" <<'NODE'
const { readFileSync, writeFileSync, readdirSync } = require('node:fs');
const { join } = require('node:path');
const [outputDirectory, version] = process.argv.slice(2);
const files = readdirSync(outputDirectory)
  .filter(name => !name.endsWith('.sha256') && name !== 'SHA256SUMS.txt' && name !== 'downloads.json')
  .sort()
  .map(name => ({
    name,
    bytes: Number(readFileSync(join(outputDirectory, name)).byteLength),
    sha256: readFileSync(join(outputDirectory, `${name}.sha256`), 'utf8').trim().split(/\s+/)[0],
  }));
writeFileSync(
  join(outputDirectory, 'downloads.json'),
  `${JSON.stringify({ version, files }, null, 2)}\n`,
);
NODE

printf '\nartifacts ready: %s\n' "$OUTPUT_DIR"
ls -1 "$OUTPUT_DIR"
