#!/usr/bin/env bash
# Generates the React Native binding package's sources from the frozen UDL
# with `ubrn`: the JSI TypeScript + C++ bindings, then the TurboModule glue
# (`src/NativeMapsSdkRn.ts`, `src/index.ts`, `cpp/<package>.{h,cpp}`).
#
# The generated trees are gitignored build artifacts, so every consumer that
# needs them (the app build, the jest/TypeScript gate) generates them here
# rather than assuming a local run.
#
# Usage:
#   scripts/generate-rn-bindings.sh                  # both steps
#   scripts/generate-rn-bindings.sh --bindings       # JSI bindings only
#   scripts/generate-rn-bindings.sh --turbo-module   # TurboModule glue only
#
# Prerequisites: `npm ci` in `platform/rn` (the `ubrn` binary), a Rust
# toolchain (ubrn resolves the crate through `cargo metadata`).
set -euo pipefail

readonly REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly RN_PROJECT_ROOT="${REPO_ROOT}/platform/rn"
readonly BINDING_CRATE_DIR="${REPO_ROOT}/crates/rustic-maps-native-core"
readonly BINDING_CRATE_NAME="rustic-maps-native-core"
readonly FROZEN_UDL_PATH="${BINDING_CRATE_DIR}/src/rustic_maps.udl"
readonly UNIFFI_NAMESPACE_NAME="rustic_maps"
readonly GENERATED_TS_DIR="src/generated"
readonly GENERATED_CPP_DIR="cpp/generated"
readonly UBRN_COMMAND="${RN_PROJECT_ROOT}/node_modules/.bin/ubrn"

run_bindings=false
run_turbo_module=false
for argument in "$@"; do
    case "$argument" in
        --bindings) run_bindings=true ;;
        --turbo-module) run_turbo_module=true ;;
        *) printf 'generate-rn-bindings: unknown argument %s\n' "$argument" >&2; exit 1 ;;
    esac
done
if [ "$run_bindings" = false ] && [ "$run_turbo_module" = false ]; then
    run_bindings=true
    run_turbo_module=true
fi

if [ ! -x "$UBRN_COMMAND" ]; then
    printf 'generate-rn-bindings: %s is missing; run npm ci in platform/rn first\n' "$UBRN_COMMAND" >&2
    exit 1
fi

if [ "$run_bindings" = true ]; then
    # Both output directories hold nothing but generated sources, and their
    # file names derive from the contract namespace: wipe them so a namespace
    # from an earlier contract state cannot linger beside the current one.
    rm -rf "${RN_PROJECT_ROOT}/${GENERATED_TS_DIR}" "${RN_PROJECT_ROOT}/${GENERATED_CPP_DIR}"
    (
        cd "$BINDING_CRATE_DIR"
        "$UBRN_COMMAND" generate jsi bindings "$FROZEN_UDL_PATH" \
            --crate "$BINDING_CRATE_NAME" \
            --ts-dir "${RN_PROJECT_ROOT}/${GENERATED_TS_DIR}" \
            --cpp-dir "${RN_PROJECT_ROOT}/${GENERATED_CPP_DIR}"
    )
fi

if [ "$run_turbo_module" = true ]; then
    (
        cd "$RN_PROJECT_ROOT"
        "$UBRN_COMMAND" generate jsi turbo-module "$UNIFFI_NAMESPACE_NAME" \
            --config ubrn.config.yaml
    )
fi

printf 'react native bindings generated under %s\n' "$RN_PROJECT_ROOT"
