#!/usr/bin/env bash
# Build the one Android AAR: the generated Kotlin bindings, the per-ABI Rust
# libraries and the `MapView`/Compose wrapper together.
#
# Pipeline: per-ABI Rust release builds of `rustic-maps-native-core` (cdylib)
# with the Android NDK clang linkers -> uniffi Kotlin bindings generated from
# the frozen UDL metadata embedded in the built cdylib -> the Kotlin sources
# and the per-ABI `librustic_maps.so` files land in the internal source-holder
# module (platform/android/map-sdk-native) -> `gradle :maps-sdk:assembleRelease`
# compiles them into the one published AAR, and `gradle :smoke-jvm:smokeRun`
# exercises the generated Kotlin against the host dylib.
#
# Toolchain prerequisites (validated matrix):
#   - Rust 1.99.0 / cargo 1.99.0 with the `rust-std` components for the three
#     Android targets below (installed on demand by this script).
#   - ANDROID_HOME pointing at an SDK with `cmdline-tools/latest/bin`
#     (sdkmanager), `platforms/android-36` and an NDK
#     (`ndk;28.2.13676358` was used; any NDK 27+ works for the API-24
#     linker binaries).
#   - Java 21 (e.g. Temurin 21) for the Android Gradle Plugin; resolved via
#     /usr/libexec/java_home when present.
#   - Gradle 9.5.1 on PATH; the wrapper below is regenerated at the same
#     version.
# Validated plugin matrix: AGP 9.0.0, Kotlin Android plugin 2.2.21.
#
# Idempotent: every step is a no-op or self-overwriting on re-run.
set -euo pipefail

readonly REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly BINDING_CRATE_NAME="rustic-maps-native-core"
readonly BINDING_CRATE_FFI_LIBRARY_NAME="librustic_maps.so"
readonly GRADLE_ROOT="${REPO_ROOT}/platform/android"
readonly GRADLE_MODULE_PATH="${GRADLE_ROOT}/map-sdk-native"
readonly KOTLIN_GENERATED_SOURCES_DIR="${GRADLE_MODULE_PATH}/src/main/kotlin"
readonly JNILIBS_DIR="${GRADLE_MODULE_PATH}/src/main/jniLibs"
# Package-level notices (docs/PackagingAndRelease.md §4.4). The module's
# build.gradle.kts adds this directory as an assets source, so the AAR carries
# `assets/licenses/{LICENSE-MIT,LICENSE-APACHE,THIRD_PARTY_NOTICES.md}`.
readonly LICENSE_NOTICES_ASSETS_DIR="${GRADLE_MODULE_PATH}/build/generated/sdk-licenses/licenses"
readonly MIT_LICENSE_PATH="${REPO_ROOT}/LICENSE-MIT"
readonly APACHE_LICENSE_PATH="${REPO_ROOT}/LICENSE-APACHE"
readonly NOTICES_PATH="${REPO_ROOT}/docs/THIRD_PARTY_NOTICES.md"
readonly ANDROID_NDK_VERSION="28.2.13676358"
# Lowest Android API level the NDK linker binaries below target; kept in sync
# with `minSdk` in the module's build.gradle.kts.
readonly MIN_ANDROID_API_LEVEL="24"
# ABI -> Rust target -> NDK triple prefix (linker binary base name). Note the
# NDK spells the armv7 triple `armv7a-linux-androideabi` while the Rust
# target is `armv7-linux-androideabi`.
readonly SUPPORTED_ANDROID_ABIS=(
    "arm64-v8a aarch64-linux-android aarch64-linux-android"
    "armeabi-v7a armv7-linux-androideabi armv7a-linux-androideabi"
    "x86_64 x86_64-linux-android x86_64-linux-android"
)

require_tool() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "error: required tool '$1' was not found on PATH" >&2
        exit 1
    fi
}

install_android_target_if_missing() {
    local rust_target="$1"
    if ! rustup target list --installed | grep -qx "${rust_target}"; then
        rustup target add "${rust_target}"
    fi
}

cargo_target_environment_name() {
    # `aarch64-linux-android` -> `CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER`.
    echo "CARGO_TARGET_$(echo "$1" | tr '[:lower:]-' '[:upper:]_')_LINKER"
}

cc_environment_name() {
    # `aarch64-linux-android` -> `CC_aarch64_linux_android` (lowercase, dashes
    # underscored), the variable the `cc` crate reads for the C dependency
    # builds (e.g. `ring`) on this target; the NDK ships only the API-suffixed
    # compiler wrappers, so the plain `<triple>-clang` binary `cc` probes by
    # default does not exist.
    echo "CC_$(echo "$1" | tr '-' '_')"
}

ar_environment_name() {
    # `aarch64-linux-android` -> `AR_aarch64_linux_android` (same convention
    # as the `cc` crate's compiler variable above).
    echo "AR_$(echo "$1" | tr '-' '_')"
}

build_android_cdylib() {
    local rust_target="$1"
    local ndk_triple="$2"
    local ndk_toolchain_bin_dir
    # The NDK prebuilt directory name carries the host OS and its
    # architecture ("darwin-x86_64", "linux-x86_64"); the unquoted x86_64
    # glob covers both hosts this script runs on (local macOS, CI Linux).
    ndk_toolchain_bin_dir="$(ls -d "${ANDROID_HOME}/ndk/${ANDROID_NDK_VERSION}/toolchains/llvm/prebuilt/"*-x86_64"/bin" | head -n 1)"
    local linker_binary
    linker_binary="$(ls "${ndk_toolchain_bin_dir}/${ndk_triple}${MIN_ANDROID_API_LEVEL}-clang" | head -n 1)"
    if [ ! -x "${linker_binary}" ]; then
        echo "error: NDK linker binary not found: ${linker_binary}" >&2
        exit 1
    fi
    env \
        "$(cargo_target_environment_name "${rust_target}")=${linker_binary}" \
        "$(cc_environment_name "${rust_target}")=${linker_binary}" \
        "$(ar_environment_name "${rust_target}")=${ndk_toolchain_bin_dir}/llvm-ar" \
        cargo build --release -p "${BINDING_CRATE_NAME}" --target "${rust_target}"
}

readonly HOST_CARGO_TARGET_TRIPLE="$(rustc -vV | awk '/^host:/ {print $2}')"
readonly METADATA_CARGO_TARGET_TRIPLE="${HOST_CARGO_TARGET_TRIPLE}"
# Rust's cdylib suffix follows the host OS: `.dylib` on macOS, `.so` on
# Linux (the CI runner). The host-artifact paths below stay host-independent
# through this constant.
if [ "$(uname)" = "Darwin" ]; then
    readonly HOST_CDYLIB_SUFFIX="dylib"
else
    readonly HOST_CDYLIB_SUFFIX="so"
fi

generate_kotlin_bindings() {
    # Generate from the metadata embedded in a built artifact of this same
    # workspace (the host cdylib is enough; the metadata is target-
    # independent, and the build of the Android arm64 cdylib above already
    # proved the Rust side compiles). The build is unconditional: a host
    # artifact left behind by an earlier contract state must never feed the
    # generation.
    # The library file name on disk is the crate's declared `[lib] name`
    # (`rustic_maps`), which the contract-bound Kotlin loader also loads.
    local host_cdylib="${REPO_ROOT}/target/${METADATA_CARGO_TARGET_TRIPLE}/release/librustic_maps.${HOST_CDYLIB_SUFFIX}"
    cargo build --quiet --release -p "${BINDING_CRATE_NAME}" --target "${METADATA_CARGO_TARGET_TRIPLE}"
    if [ ! -f "${host_cdylib}" ]; then
        echo "error: host cdylib was not produced at ${host_cdylib}" >&2
        exit 1
    fi
    # The generation directory holds nothing but generated sources, and the
    # package path is derived from the contract namespace: wipe it so a
    # namespace from an earlier contract state cannot linger beside the
    # current one.
    rm -rf "${KOTLIN_GENERATED_SOURCES_DIR}/uniffi"
    cargo run --quiet --bin uniffi-bindgen -- generate \
        --library "${host_cdylib}" \
        --language kotlin \
        --out-dir "${KOTLIN_GENERATED_SOURCES_DIR}" \
        --no-format
}

stage_ffi_libraries_into_jni_libs() {
    rm -rf "${JNILIBS_DIR}"
    for abi_and_target in "${SUPPORTED_ANDROID_ABIS[@]}"; do
        local android_abi="$(echo "${abi_and_target}" | cut -d' ' -f1)"
        local rust_target="$(echo "${abi_and_target}" | cut -d' ' -f2)"
        local source_library="${REPO_ROOT}/target/${rust_target}/release/${BINDING_CRATE_FFI_LIBRARY_NAME}"
        if [ ! -f "${source_library}" ]; then
            echo "error: missing cdylib ${source_library}" >&2
            exit 1
        fi
        mkdir -p "${JNILIBS_DIR}/${android_abi}"
        cp "${source_library}" "${JNILIBS_DIR}/${android_abi}/"
    done
}

stage_license_notices_assets() {
    # Deterministic copies from their single sources; the AAR's assets tree is
    # generated under build/ on every run, so a stale notice cannot linger.
    rm -rf "${LICENSE_NOTICES_ASSETS_DIR}"
    mkdir -p "${LICENSE_NOTICES_ASSETS_DIR}"
    cp "${MIT_LICENSE_PATH}" "${APACHE_LICENSE_PATH}" "${NOTICES_PATH}" "${LICENSE_NOTICES_ASSETS_DIR}/"
}

stage_host_library_for_smoke() {
    # The `:smoke-jvm` module loads the Apple-host cdylib through JNA to run
    # the generated Kotlin bindings on the JVM; the Android `.so` libraries
    # run only on Android.
    local smoke_jni_dir="${REPO_ROOT}/platform/android/smoke-jvm/jni"
    mkdir -p "${smoke_jni_dir}"
    cp "${REPO_ROOT}/target/${METADATA_CARGO_TARGET_TRIPLE}/release/librustic_maps.${HOST_CDYLIB_SUFFIX}" "${smoke_jni_dir}/"
}

main() {
    echo "==> checking toolchain"
    require_tool cargo
    require_tool gradle
    : "${ANDROID_HOME:?error: ANDROID_HOME must point at the Android SDK}"
    if [ ! -d "${ANDROID_HOME}/ndk/${ANDROID_NDK_VERSION}" ]; then
        yes | "${ANDROID_HOME}/cmdline-tools/latest/bin/sdkmanager" --install "ndk;${ANDROID_NDK_VERSION}" > /dev/null
    fi
    if [ "$(uname)" = "Darwin" ] && /usr/libexec/java_home -v 21 > /dev/null 2>&1; then
        export JAVA_HOME="$(/usr/libexec/java_home -v 21)"
    fi

    echo "==> installing Rust Android targets (no-op when present)"
    for abi_and_target in "${SUPPORTED_ANDROID_ABIS[@]}"; do
        install_android_target_if_missing "$(echo "${abi_and_target}" | cut -d' ' -f2)"
    done

    echo "==> building release cdylibs per ABI"
    for abi_and_target in "${SUPPORTED_ANDROID_ABIS[@]}"; do
        build_android_cdylib "$(echo "${abi_and_target}" | cut -d' ' -f2)" "$(echo "${abi_and_target}" | cut -d' ' -f3)"
    done

    echo "==> generating Kotlin bindings from the frozen UDL"
    generate_kotlin_bindings

    echo "==> staging jniLibs into the Gradle module"
    stage_ffi_libraries_into_jni_libs
    stage_host_library_for_smoke

    echo "==> staging the licenses and third-party notices for the AAR"
    stage_license_notices_assets

    echo "==> regenerating the Gradle wrapper at 9.5.1"
    (cd "${GRADLE_ROOT}" && gradle --no-daemon -q wrapper --gradle-version 9.5.1)

    echo "==> assembling the one AAR"
    # `:maps-sdk` compiles the generated bindings, the ABI libraries and the
    # wrapper into a single artifact; `:map-sdk-native` is a source holder.
    (cd "${GRADLE_ROOT}" && ./gradlew --no-daemon :maps-sdk:assembleRelease)

    echo "==> running the JVM smoke against the Apple-host cdylib"
    (cd "${GRADLE_ROOT}" && ./gradlew --no-daemon :smoke-jvm:smokeRun)

    echo "done: $(ls "${GRADLE_ROOT}/maps-sdk/build/outputs/aar/"*.aar)"
}

main "$@"