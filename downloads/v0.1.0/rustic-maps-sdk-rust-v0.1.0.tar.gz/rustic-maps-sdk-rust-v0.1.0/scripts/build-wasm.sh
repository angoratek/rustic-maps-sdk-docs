#!/usr/bin/env bash
# Builds the WebAssembly package the browser harness and npm artifact use:
# a release wasm32 build of `rustic-maps-web-bindings`, the wasm-bindgen `web` emit,
# and — when binaryen's `wasm-opt` is installed — a size/speed optimization
# pass over the module.
#
# The CLI version must match the `wasm-bindgen` crate version (0.2.129);
# wasm-bindgen refuses a mismatch.
#
# Usage:
#   scripts/build-wasm.sh                # optimize when wasm-opt exists
#   scripts/build-wasm.sh --no-optimize  # skip wasm-opt
set -euo pipefail

readonly REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly PACKAGE_DIRECTORY="${REPO_ROOT}/platform/web/pkg"
readonly WASM_PATH="${REPO_ROOT}/target/wasm32-unknown-unknown/release/rustic_maps_web_bindings.wasm"
# `-Oz` favors size; the flag set enables the features Rust's wasm targets
# emit (bulk memory, non-trapping float conversions, sign extension) and
# mutable globals/reference types used by the JS glue.
readonly WASM_OPT_FLAGS=(-Oz --enable-bulk-memory --enable-nontrapping-float-to-int --enable-sign-ext --enable-mutable-globals --enable-reference-types)

optimize=true
for argument in "$@"; do
    case "$argument" in
        --no-optimize) optimize=false ;;
        *) printf 'build-wasm: unknown argument %s\n' "$argument" >&2; exit 1 ;;
    esac
done

(
    cd "$REPO_ROOT"
    cargo build -p rustic-maps-web-bindings --release --target wasm32-unknown-unknown
    # The package directory holds only generated output: clear it so a
    # renamed module (or a failed earlier emit) cannot leave a stale file
    # beside the current one.
    rm -rf "$PACKAGE_DIRECTORY"
    wasm-bindgen --target web --out-dir "$PACKAGE_DIRECTORY" "$WASM_PATH"
)

readonly MODULE_PATH="${PACKAGE_DIRECTORY}/rustic_maps_web_bindings_bg.wasm"
if [ "$optimize" = true ] && command -v wasm-opt >/dev/null 2>&1; then
    local_before_bytes="$(wc -c < "$MODULE_PATH" | tr -d ' ')"
    wasm-opt "${WASM_OPT_FLAGS[@]}" "$MODULE_PATH" -o "${MODULE_PATH}.optimized"
    mv "${MODULE_PATH}.optimized" "$MODULE_PATH"
    local_after_bytes="$(wc -c < "$MODULE_PATH" | tr -d ' ')"
    printf 'wasm-opt: %s -> %s bytes (%s%% of the unoptimized module)\n' \
        "$local_before_bytes" "$local_after_bytes" \
        "$(awk -v before="$local_before_bytes" -v after="$local_after_bytes" 'BEGIN { printf "%.1f", (after / before) * 100 }')"
else
    printf 'wasm-opt: skipped (not installed or --no-optimize)\n'
fi
printf 'wasm package ready: %s\n' "$PACKAGE_DIRECTORY"
