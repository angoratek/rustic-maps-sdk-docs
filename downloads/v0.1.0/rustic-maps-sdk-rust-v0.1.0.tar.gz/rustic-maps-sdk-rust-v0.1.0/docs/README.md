# Repository documentation

This folder holds the engineering documents behind the SDK: the frozen API
shape, the provider and credential rules, how each subsystem works, the
current and in-flight designs, and dated records of past investigations.
Published documentation lives in `site/book-src/` and is not indexed here.
Everything in
`history/` is a frozen record from the date in its title or status line; it
describes the tree as it was then, not today. Superseded documents were removed
from the tree and remain in git history.

## Root

| File | Question it answers |
|---|---|
| `PublicApiV2.md` | What public API shape did the SDK adopt, and what does each vendor call the same concept? |
| `ReferenceAppUX.md` | How must every reference app look and behave? |
| `PackagingAndRelease.md` | How is a release produced, signed and published? |
| `ProviderCredentialsAndBrowserProviders.md` | How do provider credentials work on native and in the browser, and why? |
| `ProviderGenericity.md` | How is provider genericity enforced at every layer? |
| `DocsStyleGuide.md` | What standard must published pages, screenshots and public documentation comments meet? |
| `THIRD_PARTY_NOTICES.md` | Which third-party licenses does the distribution carry? |
| `THIRD_PARTY_LICENSES/` | The full license texts the notices cite. |
| `doc-snippets.json` | Which reference-application roots the snippet generator scans and which chapters it rewrites. |
| `browser-map.png`, `playground.png`, `rendered-map.png` | The README's screenshots. |

## reference — how subsystems work today

| File | Question it answers |
|---|---|
| `reference/BrowserLoop.md` | How do I build the wasm `pkg`, serve it, test it and use the browser harness? |
| `reference/BrowserRenderPerformance.md` | How is the browser frame measured, and what are the current numbers? |
| `reference/BrowserRasterFallback.md` | When may a page's live raster source serve tiles, and how does a configured provider stay authoritative? |
| `reference/TrafficLayerCaching.md` | How are traffic-layer answers cached, bounded and released? |
| `reference/OfflineGraphCompilation.md` | How is the RMOG offline routing graph compiled from OpenStreetMap? |
| `reference/MobileDemoOperations.md` | How is the hosted Appetize mobile demo operated? |
| `reference/DocumentationSnippets.md` | How are tutorial code blocks generated from compiled source and checked? |

## design — current and in-flight designs

| File | Question it answers |
|---|---|
| `design/DirectionsModesAndStrategy.md` | How do applications choose transport mode and route strategy, and what may a provider honour? |
| `design/DeveloperConsole.md` | What does the in-app developer console show, and which half is still open? |
| `design/MapControlsAndTrafficLayer.md` | How does the on-map layer, traffic and device-location control work, per target? |
| `design/PositioningAndRouteUx.md` | How do positioning feedback and the plan flow align across all four targets? |
| `design/ProviderSelectionPerCapability.md` | Can one map mix providers per capability, and how does an app select them? |
| `design/ReferenceApplicationBehavior.md` | What must every reference application do, step by step, and how is that one behavior model enforced across Android, iOS, React Native and the web demo? |
| `design/ReferenceAppSettingsAndPersistence.md` | What do the reference apps remember across relaunches, and how is the settings surface sized? |
| `design/TilePackManager.md` | How do offline raster regions download, resume, report progress, persist and evict on every target? |
| `design/VectorStyleRefinement.md` | Why did the regional road hierarchy look thick, and how is the style data fixed? |
| `design/VectorStyleSpecification.md` | How does the renderer adopt the MapLibre source and layer model, and in which phases? |
| `design/VectorTileLatencyAndLabels.md` | Why did vector tiles feel slow and labels thin, and what shipped? |

## history — dated records

| File | Question it answers |
|---|---|
| `history/FourPlatformParityAudit.md` | What was the four-target capability and UX parity state on 2026-10-31? |
| `history/RefappCoreCentralization.md` | Should reference-application core logic move into Rust, and what did that study recommend? |
| `history/DocsHostname.md` | How was the `sdk.mapquest.live` documentation hostname set up? |
| `history/PositioningResearch.md` | What did the device-positioning platforms offer, and what split was chosen? |
| `history/research/browser-render-performance.md` | What was the 2026-10-30 browser performance evidence and plan? |
| `history/research/hosted-mobile-demo-appetize.md` | What did the Appetize plans and embedding options allow? |
| `history/research/reference-app-copy-audit.md` | Where did the four apps' user-visible copy diverge on 2026-10-30? |
