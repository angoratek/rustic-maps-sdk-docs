# Browser render performance: the harness and the recipe

Date: 2026-11-01 (M23). Scope: the browser path (`rustic-maps-web-bindings` → wgpu over
WebGPU). The research that ranked the work is
`docs/history/research/browser-render-performance.md`; this document is the
measurement it asks for, and the numbers the performance chapter quotes.

## What the harness measures

`platform/web/perf/run-frame-budget.mjs` drives one frozen scenario through the
page's own frame path and reports percentiles, not a single screenshot.

| Metric | What it is | Why it is the one to watch |
|---|---|---|
| `renderFrame` | the whole wasm frame call, as the page awaits it | the work the integration adds to the main thread |
| `animation frame` | the interval between animation frames during the pan | the cadence a visitor sees; it stays pinned at the display's refresh even when frames are being dropped, so it is a floor, never a promise |
| `stageMilliseconds.tilePipeline` | camera listing, tile fetch start, scheduler warm pass, quad assembly, texture resolution | the raster path's cost |
| `stageMilliseconds.overlayGeometry` | overlay and location-indicator tessellation through the camera pose | the vector base's cost; the overlay path is what a vector map spends its frame on |
| `stageMilliseconds.encode` | vertex/index encoding into GPU buffers | vertex traffic |
| `stageMilliseconds.submit` | surface acquisition, render pass, queue submission | driver and IPC cost |
| `gpuPassMilliseconds` | the render pass's own GPU time from timestamp queries, read one frame after it was written | the part of a frame the CPU cannot attribute; absent when the adapter does not support timestamp queries |

The stage spans are `performance.now()` reads inside `renderFrame` itself,
reported on the frame's statistics object, so they need no profiler attached
(and Chrome tiers wasm down when DevTools is open, which makes in-page timing
the honest instrument for absolute comparisons).

The ring never cancels or remaps a buffer whose map is still pending: a
pending slot is left alone, only completed maps are read, and a frame with no
free slot carries no sample. That is not an optimisation but a portability
rule — Firefox's stricter WebGPU validation rejects a cancelled-then-remapped
buffer ("still mapped", "already mapped", "map is pending"), which floods the
console and can stop the frame loop presenting. The browser suite's
`frame_loop_cleanliness.spec.mjs` drives a trip and a pan and asserts that no
such error is emitted.

The frame statistics also carry `gpuBufferAllocations`, the canvas' cumulative
count of vertex and index buffer allocations. A steady frame reuses the
buffers it already owns, so the count must stop growing once every layer has
been seen at its largest payload; the browser suite asserts exactly that on a
settled golden scene, which turns the zero-allocation rule from a code-review
claim into a regression test.

### How the GPU pass time is measured

The canvas requests WebGPU's timestamp-query feature only when the adapter
advertises it and is neither the noop backend nor a CPU fallback adapter;
otherwise the frame simply omits `gpuPassMilliseconds` and everything else
behaves as before. When the feature is present, each frame's render pass
writes a begin and an end timestamp. After the pass, the query set resolves into a small buffer and the
result copies into one of two `MAP_READ` readback buffers; the frame then maps
that buffer and presents without waiting. At the start of the next frame the
previous map is read, unmapped and reported as `gpuPassMilliseconds`, while
the map that is still pending is dropped rather than allowed to delay the
frame. The two slots alternate so a frame always reads the other slot's
completed result.

The value therefore describes the **previous** frame's pass, which is the
price of never blocking the present. WebGPU implementations quantize
timestamps; Chromium's step is commonly 100 µs and is platform-dependent, so
the distribution is a quantized sample of a sub-millisecond pass, not a
cycle-exact figure. Read the row next to `renderFrame`, never instead of it.

## The frozen scenario

- A **vector base** (the recorded fixtures) over a 1920 × 1080 canvas at device
  scale 1, or the **raster base** for the tile path — `--layer` selects.
- A settle, then a warm-up pass (shader compilation, first uploads and the
  initial vector reload are one-time costs), then the measured pass.
- A constant **600 device px/s pan for 4 s**, out and back, so the camera
  returns to where it started and the scenario never leaves the recorded tile
  fixtures — an unmapped edge would report a smaller draw list and flatter
  numbers.
- 60 Hz budget: p95 ≤ 16.7 ms, p99 ≤ 33 ms, no frame > 50 ms.

## Running it

```sh
cd platform/web
npm run perf                                        # the vector base
node perf/run-frame-budget.mjs                      # the same, with flags
node perf/run-frame-budget.mjs --layer raster       # the tile path
node perf/run-frame-budget.mjs --json report.json   # keep the report
node perf/run-frame-budget.mjs --headed             # watch the pan
```

The runner starts the harness's static server itself (or reuses one already on
the port) and launches the host's Chromium with hardware WebGPU. It is
deliberately **not** part of `npm test`: the Playwright suite runs under
SwiftShader so CI is deterministic, and SwiftShader's absolute frame times say
nothing about a GPU (the research's §3.3 measurement trap: MapLibre's benchmark
under-reported by ~390× there). A number without the machine is not a
measurement, so the report carries the browser build and the `GPUAdapter.info`
descriptor.

## Measured baseline

Apple Silicon host (`GPUAdapter.info`: `apple · metal-3`), headless Chromium
(system channel) with hardware WebGPU,
1920 × 1080 at device scale 1, vector base over the recorded fixtures — the
scenario above, 120 measured frames:

Measurement of 2026-11-01 (the canvas-owned vector base, the world-space
overlay cache warm, every upload buffer reused from its high-water mark):

| Metric | p50 | p95 | p99 | max |
|---|---|---|---|---|
| `renderFrame` | 1.4 ms | 1.5 ms | 8.2 ms | 9.8 ms |
| `animation frame` | 16.7 ms | 16.8 ms | 16.8 ms | 16.8 ms |
| `overlayGeometry` | 0.0 ms | 0.1 ms | 7.2 ms | 8.5 ms |
| `encode` | 0.0 ms | 0.0 ms | 0.0 ms | 0.0 ms |
| `submit` | 0.0 ms | 0.1 ms | 0.1 ms | 0.2 ms |
| `gpuPassMilliseconds` | 0.8 ms | 0.82 ms | 0.89 ms | 0.89 ms |

Every measured frame stayed inside the 60 Hz budget (0 of 120 over 16.7 ms).
The p99 tail is the overlay-revision pass: the world-space tessellation runs
on the frame that sees a new overlay list, which is what the pan does at its
start, while the vertex upload now writes into the existing high-water-mark
allocation. The next performance change should move the tessellation off the
presenting frame rather than shave the steady state.

Run-to-run spread on this host is about ±0.2 ms at the median; the p95 and p99
samples move more because a single tail frame sets them. Compare runs on the
same machine and in the same power state, never across machines.

The raster base over the same ground is not the bottleneck: `renderFrame`
p50 is 0.2 ms with 15 tiles drawn, because its payloads are pooled, its
textures cached and its vertex and index buffers reused — the frame only
projects quads and writes them into buffers it already owns. Its GPU pass is
correspondingly smaller: `gpuPassMilliseconds` p50 0.15 ms, p95 0.21 ms, p99
0.21 ms over the same 120 frames.

Two conclusions drive the remaining M23 work:

1. **The steady vector frame is inside the budget by a wide margin.** With
   the world-space overlay cache warm, projection, encoding and submission
   are each under a millisecond at the median, and every upload reuses its
   buffer.
2. **The tail is the overlay-revision pass.** The p99 sample is the frame
   that re-tessellates the overlay layer; moving that tessellation off the
   presenting frame is the remaining work, not general micro-optimization.
   The raster path is not a bottleneck (p50 0.2 ms with 15 tiles drawn).

## What changed in this milestone

- **Frame stage instrumentation.** `renderFrame` reports
  `stageMilliseconds`, and the page's diagnostics render them as frame facts.
- **Allocation-free window clipping for overlays.** `filled_polygon_triangles`
  clipped every triangle against all three world-copy windows and allocated
  two `Vec`s per triangle per window; it now pre-culls a triangle by its
  x-extent (exact: a triangle outside both half-planes clips to fewer than
  three corners and draws nothing) and clips into fixed arrays; a triangle
  wholly inside one window skips both clip passes and projects its own three
  corners. Vertices are byte-identical — the golden fixtures and the browser
  golden compare prove it. 6.6 → 5.9 ms p50.
- **One decode per tile payload.** The staging pass decoded each PNG to
  validate it and threw the result away; the upload decoded it again. The
  staging decode now runs on the fetch task, is kept (fingerprinted against
  the encoded bytes, so a re-fetched payload never serves a stale decode) and
  the upload consumes it. The upload still decodes when a pooled payload
  outlived its decoded form — a texture evicted and later re-uploaded — which
  is not the steady path.
- **No fetch inside a presenting frame.** `renderFrame` started the missing
  tiles' fetches and awaited them, up to 32 sequential round trips while the
  draw state was borrowed. It now starts them on their own tasks and returns;
  a landed payload dispatches `map-tile-arrived` on the canvas, which the page
  turns into one more render. The frame draws what it has and reports the
  rest as missing — the scheduler's deferral model, now actually used.
- **One codegen unit per crate.** `codegen-units = 1` in the release profile:
  the browser package is 3,699,729 bytes, 10.6 % smaller than 4,137,073.
- **GPU pass timing in the frame statistics.** The render pass writes a begin
  and an end timestamp into a query set; the resolved pair copies into an
  alternating readback buffer and is reported one frame later as
  `gpuPassMilliseconds`. Nothing awaits the map, and an adapter without
  timestamp queries reports no field.
- **Persistent upload buffers.** Every vertex and index buffer (tile quads,
  world-space overlays, label halo and text, location indicator) lives in a
  reusable slot that grows only when a payload outgrows its capacity; a
  steady frame writes into an allocation it already owns. The frame
  statistics expose the cumulative allocation count and the browser suite
  asserts it does not move across settled frames.

## What is not done yet

- **One instanced tile draw over a `texture_2d_array`.** The buffers are now
  persistent and reused, but each tile still binds its own texture and draws
  a quad per tile. Cheap and correct either way: the raster path already
  measures 0.2 ms, so this is a cleanliness change at this scene size.
- **Moving the overlay-revision tessellation off the presenting frame**, the
  remaining tail cost the p99 column attributes.

The `wasm-opt` step has landed: `scripts/build-wasm.sh` runs `wasm-opt -Oz`
after `wasm-bindgen` and the browser package is 91.1 % of the unoptimized
module.
