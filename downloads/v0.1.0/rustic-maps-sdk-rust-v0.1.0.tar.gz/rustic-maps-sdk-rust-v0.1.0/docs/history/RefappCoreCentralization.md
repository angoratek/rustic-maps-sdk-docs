# Centralizing the reference applications' core in Rust

**Status: historical study.** Recorded during the four-target parity work and
kept for its option comparison; the recommendation it proposed became M12 and
the landed pieces live in the shared artifacts and the parity gate.

This study answers one owner question: can the reference applications' non-UI
logic move into a Rust crate, bound again with UniFFI to Android, iOS, React
Native and the wasm demo, so the duplicated app logic shrinks while the UI
stays platform-specific? It inventories the duplication with measured line
counts, classifies what could move, compares four options, and proposes a
milestone if the answer is yes. It is a design document, not a plan change. The
owner questions this study raises belong in `PLAN.md` §5.

**Recommendation in one sentence.** Adopt the cheap half now (single-source
data, strings and a machine-checked parity matrix) and a narrow version of the
crate (pure decision math plus trace pacing, bound through a refapp-only UDL and
compiled directly into wasm); reject a shared cross-platform application state
machine and keep UI, voice, gestures, surfaces, lifecycle and launch automation
platform-specific.

## 1. Executive summary and recommendation

The verdict is **partially adopt, narrowly**.

- The pure decision logic really is duplicated three to four times, and the
  copies have already drifted. The clearest evidence: iOS shows the rate-limit
  detail as the bare variant name `RateLimitExhausted` while Android and React
  Native show a sentence (`ReferenceApplicationModel.swift:509-520`,
  `ReferenceApplicationState.kt:158-168`,
  `ReferenceMapController.kt:424-437`); Android and React Native show the
  provider-not-configured detail as the contract name while iOS wraps it in a
  sentence; the scale-bar ladder spans decades −2…9 on Android and the web but
  0…6 on iOS (`ScaleBarModel.kt:25-26`,
  `MapControlsSupport.swift:35`); and Android, React Native and the web compute
  a circular course median while iOS sorts the window and takes the middle
  value (`FollowCamera.kt:188-225`, `MapControlsSupport.swift:161-170`).
- The duplication that matters is bounded. Roughly 900–1,100 lines of unique
  pure logic (including the owner-gated speech decision) exist three to four
  times, about 3,000–4,000 lines in the tree.
  The bulk of the app code is UI and platform I/O: 5,637 lines of Compose,
  6,181 lines of SwiftUI, 3,384 plus 3,383 lines of RN native glue, and 2,387
  lines of web source. Moving that mass across an FFI boundary would cost more
  than it saves.
- UniFFI is a poor fit for the expensive half and a good fit for the cheap
  half. An application state machine needs callbacks, async provider calls and
  observable state; this project has already paid for those constraints
  (`runtime.rs`'s reactor handback, fire-and-forget listeners that must not
  block — the earlier ubrn/uniffi checksum disagreement was resolved by the
  2026-11-01 alignment on 0.31.2). A pure,
  synchronous crate needs none of them: no async, no callbacks, no reactor, no
  threading rules.
- The wasm target makes the crate idea cheaper, not harder. PRD §4.7 rules
  there is no UniFFI on wasm, so a Rust crate compiled into
  `rustic-maps-web-bindings` shares the logic with the browser demo for free. The
  native platforms are the ones that need bindings.
- A second UDL cannot reuse `rustic-maps-native-core`'s records. UniFFI record types are
  namespace-scoped, and this repository's recorded verdict is that FFI records
  are crate-local mirrors with explicit converters. A refapp UDL must therefore
  exchange primitives or duplicate records. That constraint is why the crate
  should own primitives only and why trace route decoding belongs on the
  existing contract (backlog item C1), not in the new crate.
- The frozen public contract should not absorb demo policy. Follow zoom 17.5,
  a 20× playback factor and picker labels are demo choices, not SDK policy.
  Adding them to `rustic-maps-native-core.udl` would ship demo behavior in the AAR and
  XCFramework, against the recorded direction that demo code leaves the shipped
  packages (backlog item C10).
- The cheapest work comes first. Single-sourcing the scene artifact, the
  demo-plan triple, the consumer strings and the design tokens, then asserting
  parity mechanically, removes the drift that already exists without a new
  binding surface. That work is backlog items C3 and the demo-plan item, and it
  should land before any crate.

## 2. Duplication inventory

The measurements below come from `wc -l` and `rg -n` on the current tree; the
commands are in Appendix A. Line counts are for the named files or the cited
line ranges. Generated bindings, `node_modules`, `build/` and `Pods` are
excluded. Test files are counted separately because they are where much of the
behavior is pinned.

### 2.1 Whole-tree sizes under comparison

| Tree | Lines | Files |
| --- | --- | --- |
| Compose reference app (`platform/android/reference-application/src/main`) | 5,637 | 13 Kotlin files |
| Kotlin SDK wrapper (`platform/android/maps-sdk/src/main`) | 608 | 5 Kotlin files |
| SwiftUI reference app (`platform/ios/reference-application/Sources`) | 6,181 | 20 Swift files |
| Swift `MapNativeCoreUI` package (`platform/ios/Sources`) | 1,049 | 6 Swift files |
| RN TypeScript (`App.tsx` plus `src/`) | 2,138 | 6 files |
| RN Android native (`refapprn/*.kt`) | 3,384 | 14 Kotlin files |
| RN iOS native (`MapsSdkRefappRn/*.swift`) | 3,383 | 9 Swift files |
| Web reference app (`index.html`, `map_controls.mjs`, `overlay_scenes.mjs`, `main.mjs`) | 2,387 | 4 files |
| Shared today: `rustic-maps-native-core` (including the 1,682-line UDL and 2,043-line `records.rs`) | 11,726 | 14 Rust files |
| Shared today: `rustic-maps-navigation/src/trace_fixture.rs` | 1,438 | 1 Rust file |
| Shared today: `platform/reference-scenes.json` | 138 | 1 JSON file, copied to iOS `Resources` |

The test surface that pins this behavior is also duplicated: Espresso 503
lines, XCUITest 1,141 lines, jest 295 lines, and 2,783 lines across six
Playwright spec files (`offline_routing`, `map_pan_direction`,
`golden_compare`, `map_cluster_and_indicator`, `contract_sync`, `sdk_core`).

### 2.2 Camera control cluster, scale bar, and compass

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `map/MapControlCluster.kt` 305; `map/ScaleBarModel.kt` 91; `map/CameraEasing.kt` 152; `ReferenceApplicationState.kt:478-540` (63) | Cluster view, zoom/my-location/2D-3D/compass handlers, ladder selection and label, easing primitives |
| SwiftUI | `MapControlClusterView.swift` 278; `MapControlsSupport.swift` 170; `ReferenceApplicationModel.swift:1550-1700` (151) | Cluster view, handlers, its own ladder selection and label, compass ease |
| React Native | `RefappCameraEasing.kt` 59 and `RefappCameraEasing.swift` 60; `ReferenceMapController.kt:727-910` (184) | Camera plumbing only; no control cluster exists (backlog D1/D2) |
| Web | `map_controls.mjs` 537; `index.html:1182-1382` (201) | Token mirror, ladder selection and label, off-north helper, cluster markup and handlers |

Pure logic: the ladder selection and label, the off-north distance, the zoom
step, the smoothstep progress. Platform I/O: buttons, press-and-hold repeat,
gesture plumbing, and the camera object rebuild. The divergence is behavioral,
not cosmetic: the Android and web ladder scans decades −2…9 and requires the
chosen width to reach the 50 px minimum, while iOS scans 0…6 and falls back to
the smallest candidate when nothing fits (`ScaleBarModel.kt:46-76`,
`map_controls.mjs:366-405`, `MapControlsSupport.swift:50-67`).

### 2.3 Follow camera, bearing chase, and pitch swing

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `map/FollowCamera.kt` 225; `CameraEasing.kt` 152; `ReferenceApplicationState.kt:410-475` (66) and `1129-1307` (179) | Phase machine, circular median, zoom ramp, pre-trip snapshot, pump application |
| SwiftUI | `MapControlsSupport.swift` 170 (compass ease and course median); `ReferenceApplicationModel.swift:1411-1530` (120) | Pre-trip snapshot, follow application, sorted-middle course median |
| React Native | `RefappCameraEasing.kt` 59 and `.swift` 60; `ReferenceMapController.kt:1334-1440` (107) | Phase state, zoom ramp, bearing chase |
| Web | `map_controls.mjs:238-347` (110 classes plus helpers); `index.html:1382-1485` (104) | Phase machine, chase, circular median, demo driver |

Pure logic: the phase transitions, the target values, the zoom ramp, the
course smoothing, the exponential chase, the pre-trip snapshot. Platform I/O:
the frame clock and the camera object. This cluster has the clearest drift:
Android, React Native and the web use the circular median that minimizes the
sum of angular distances, so a window straddling 0°/360° behaves; iOS sorts the
window and takes the upper middle, which a wrap defeats
(`FollowCamera.kt:200-221`, `MapControlsSupport.swift:165-170`). The web has no
navigation controller (docs/ReferenceAppUX.md §12), so its follow demo walks a
polyline instead of replaying a trip.

### 2.4 Trace replay and playback driver

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `navigation/SimulatedTripDriver.kt` 446 | Fixture decode, sample cursor, dispatch interval, course, reroute anchoring |
| SwiftUI | `RecordedTraceJourney.swift` 142; `JourneyReplayPlan.swift` 227; `ReferenceApplicationModel.swift:1236-1330` (95) | Fixture decode, planned-route walk, timer pump |
| React Native | `RefappTraceReplay.kt` 452; `RefappTraceReplay.swift` 507 | Two full ports of the same driver, one per platform |
| Web | `map_controls.mjs:425-538` (114); `index.html:1382-1485` | Polyline walk, no route decode, no navigation controller |
| Rust, unused by apps | `crates/rustic-maps-navigation/src/trace_fixture.rs` 1,438 | The generator and fixture model, declared `pub(crate)` and used only by Rust tests |

Pure logic: fixture decode into a route plus samples, cumulative distance,
interpolation, the dispatch interval (recorded interval divided by the playback
factor), course from consecutive samples. Platform I/O: `AssetManager`/`Data`/
Metro `require`, the timer, and the `Navigator` calls. Backlog
item C1 records the same finding in round terms (about 1,100 lines across three
platforms). The measurements here put the Compose driver at 446 lines, the
SwiftUI decode and replay files at 464, and the RN shell at 959 across its two
ports. The RN shell carries two copies because it ships both a Kotlin and a
Swift controller.

### 2.5 Demo scenes and plans artifact consumption

| Copy | Measured size | Contents |
| --- | --- | --- |
| Shared artifact | `platform/reference-scenes.json` 138; the identical copy under `platform/ios/Sources/MapNativeCoreUI/Resources/` 138 | Presets, overlay scenes, navigation demo, wasm seam status |
| Compose | `ReferenceScenesLoader.kt` 152 (in the shipped SDK wrapper); `ReferenceApplicationState.kt:765-935` (171); `ReferenceApplicationConstants.kt:89-116` | Loader, descriptor mapping, demo plans |
| SwiftUI | `ReferenceScenesCatalog.swift` 154 and `ReferenceScenesCatalogLoader.swift` 223 (in `MapNativeCoreUI`); `ReferenceDemoPlans.swift` 145; `ReferenceApplicationModel.swift:930-1049` | Loader, catalog, demo plans, descriptor mapping |
| React Native | `src/referenceScenes.ts` 136; `RefappScenesLoader.kt` 110 and `.swift` 213; `src/theme.ts:146-154` | Loader, scene keys, demo plans |
| Web | `overlay_scenes.mjs` 114; `index.html` preset and overlay wiring (about 140) | Artifact adapter, labels, preset buttons |

Pure logic: scene and preset mapping, demo-plan selection, labels and
descriptions. Platform I/O: asset loading and file paths. The demo-plan triple
is copied verbatim three times: `ReferenceApplicationConstants.kt:99-107`,
`ReferenceApplicationConfiguration.swift:118-133` and `src/theme.ts:146-154`.
The loaders also sit inside the shipped packages: 491 of the 608 Android
wrapper lines and 377 of the 1,049 `MapNativeCoreUI` lines are demo code. That
is backlog item C10, not a new finding.

### 2.6 Speech decision consumer and TTS glue

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `speech/SpeechGuidanceSpeaker.kt` 368 | TextToSpeech engine, audio focus, utterance-id dedup, verbatim rule |
| SwiftUI | `NavigationSpeechEngine.swift` 310 | AVSpeechSynthesizer, AVAudioSession, dedup, queue policy |
| React Native | `src/speechConsumer.ts` 182 (pure, jest-tested) plus `RefappSpeechSpeaker.kt` 299 and `.swift` 212 | Decision consumer separated from the two native voices |
| Web | none | No speech on the wasm seam |

Pure logic: the decision. The RN consumer is the cleanest form in the tree:
arrival notes without speaking, toggle-off skips, empty text skips, a repeated
contract `utterance_id` drops, anything else speaks
(`src/speechConsumer.ts:112-147`). Platform I/O: the engines, audio focus or
session, drain-aware abandon, and the engine's own utterance identity.

### 2.7 Plan, search, and route orchestration

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `ReferenceApplicationState.kt:936-1129` (194) | Field assignment, forward geocode, waypoint assembly, route options, route summary |
| SwiftUI | `ReferenceApplicationModel.swift:821-1049` (229) | The same flow in async Swift |
| React Native | `ReferenceMapController.kt:910-1145` (236) | The same flow across the bridge |
| Web | not implemented | Blocked on the `MapSdk` wasm seam (docs/ReferenceAppUX.md §12 ask 2) |

Pure logic: which field is active, result selection, waypoint ordering, the
route options record. Platform I/O: async provider calls, in-flight state, and
promise or task bridging. The web's absence is the concrete proof that this
flow cannot be fully shared until the wasm seam grows.

### 2.8 Readiness ladder and error presentation

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `ReferenceApplicationState.kt:136-190` (55) and `1406-1500` (95) | Ladder states, variant label, detail mapping, frame/attach outcomes |
| SwiftUI | `ReferenceApplicationModel.swift:21-35`, `466-552` (87) and `597-665` (69) | Ladder states, error report, surface outcomes |
| React Native | `ReferenceMapController.kt:97-130` (34) and `398-460` (63) | Emitter events, failure mapping |
| Web | `index.html` status and readiness wiring (about 80) | Readiness hooks and error strip |

Pure logic: the ladder transitions and the error-to-label/detail mapping.
Platform I/O: event delivery and rendering. This cluster holds the two live
divergences named in §1: `ProviderNotConfigured` and `RateLimitExhausted` read
differently on iOS than on the other three platforms. The backlog already
carries the unify-error-text item; this study adds that the mapping, not only
the sentence, is duplicated.

### 2.9 Diagnostics

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `map/CollectingDiagnosticEventListener.kt` 72 | Snapshot-list ring, 50-event window, backlog count |
| SwiftUI | `SdkDiagnosticEventsFeed.swift` 93 | Main-actor buffer with a 2 Hz merge cadence |
| React Native | `ReferenceMapController.kt:1768-1813` (46) | Diagnostic line emitter |
| Web | `index.html:1488-1560` (73) | Facts line, event ring refresh |

Almost all of this is platform I/O: thread hops, cadence, and reactive state.
The only shared decision is the display window and the oldest-first order. The
two native implementations deliberately differ (Compose appends from any
thread into snapshot state; iOS hops to the main actor and merges on a timer),
which is the platform-idiomatic part working as intended.

### 2.10 Theme and tokens

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `ux/ReferenceAppUXTheme.kt` 215 and `ux/ReferenceAppUXDimensions.kt` 124 (both in the SDK wrapper) | Color tokens, typography, dimensions, durations |
| SwiftUI | `ReferenceAppUXTheme.swift` 268 and `AppLayout.swift` 115 | Color tokens, typography, layout constants |
| React Native | `src/theme.ts` 172 and `src/screenStyles.ts` 379 | Color tokens, strings, spacing, radii, styles |
| Web | `map_controls.mjs:24-125` (102) and the page's CSS variables | Behavior constants and token mirror |

Pure data, no I/O. The tokens are already prose-locked by
`docs/ReferenceAppUX.md` §2 and partially mirrored; backlog item C3 proposes
`platform/reference-tokens.json` plus a parity test. This is the cheapest
centralization available and needs no Rust.

### 2.11 Surface host and frame pump

| Copy | Measured size | Contents |
| --- | --- | --- |
| Compose | `map/MapSurfaceHost.kt` 375 | SurfaceView holder, attach/resize/detach, `withFrameNanos` pump, backpressure outcomes |
| SwiftUI | `MapSurfaceDisplayView.swift` 282 | `CAMetalLayer` view, `CADisplayLink` pump, 2048 px drawable clamp |
| React Native | `ReferenceMapController.kt:469-727` (259); `RefappMapHostView.kt` 55 and `.swift` 241 | Host views, Choreographer pump, attach retry |
| Web | `index.html:964-1181` (218) | `GpuMapCanvas` setup, render step, settled-frame pump |

Almost entirely platform I/O: native surface handles, display links, lifecycle
callbacks and the attach retry. The only pure logic is the outcome
classification and the settle decision, and the settle decision already lives
in the SDK (`frame_settled`). Backlog item C2 takes this code into the shipped
wrappers, the opposite direction from a refapp core.

## 3. Classification

The boundary this study recommends runs between four kinds of code, not
between "app" and "SDK".

### (a) Pure decision and state math that could live in Rust

This is the candidate set. It has no I/O, no clocks of its own, no UI
framework, and no SDK object.

- The follow-camera phase machine, target values, zoom ramp and pre-trip
  snapshot (`FollowCamera.kt` 225; the fullest native form).
- The circular course median (`FollowCamera.kt:188-225`), about 40 lines.
- Smoothstep and exponential easing primitives (`CameraEasing.kt` 152), driven
  by timestamps the caller supplies.
- The scale-bar ladder selection and label (`ScaleBarModel.kt` 91).
- The compass off-north distance and visibility threshold
  (`CameraEasing.kt:22-29`).
- The speech decision (`src/speechConsumer.ts` 182 is the reference shape).
  This item is owner-gated: the recorded ruling keeps dedup and flush
  platform-side, so the study treats it as a question rather than a Phase 1
  deliverable (see §5.5).
- Trace pacing: fixture decode, cumulative distance, interpolation and the
  dispatch interval (`SimulatedTripDriver.kt` 446, of which roughly 150 lines
  are pacing and the rest is SDK calls and asset I/O).
- Readiness ladder transitions and the error variant-to-detail policy
  (roughly 60 lines across the three native copies).
- Demo-plan selection and control step math (roughly 90 lines).

The unique total is about 900–1,100 lines. In the tree it appears three to four
times, about 3,000–4,000 lines. Excluding the owner-gated speech item leaves
about 720–920 unique lines.

### (b) SDK-facing glue that is already contract-adjacent

This code talks to `rustic-maps-native-core`, already has a stable shape, and should
stay in the platform wrappers where backlog item C2 puts it.

- Camera value application and `MapCamera` rebuild
  (`ReferenceApplicationState.kt:297-410`; `ReferenceApplicationModel.swift:565-680`;
  `ReferenceMapController.kt:710-787`).
- Overlay descriptor building and the location-indicator state push
  (`ReferenceApplicationState.kt:815-935`; `ReferenceApplicationModel.swift:930-1034`;
  `ReferenceMapController.kt:1146-1332`).
- Route polyline overlay and route preview framing.
- Tile-cache registration (`ReferenceApplicationState.kt:1348-1371`).
- Diagnostics listener registration and the navigation listener subscriptions.

Moving this into a refapp crate would duplicate the contract's own records and
converters, which is exactly what UniFFI does not allow cleanly.

### (c) Platform I/O that must stay native

- Voice: Android `TextToSpeech`, iOS `AVSpeechSynthesizer`.
- Audio focus and sessions: `AudioFocusRequest`, `AVAudioSession`.
- Surfaces and GPU handles: `SurfaceView`/`ANativeWindow`, `CAMetalLayer`,
  the WebGPU canvas.
- Frame clocks: `Choreographer`/`withFrameNanos`, `CADisplayLink`,
  `requestAnimationFrame`.
- Lifecycle: attach, resize, detach, background and resume.
- Gestures: drag, pinch, rotate, and the content-follows-pointer algebra.
- Asset loading and file paths.
- Launch-argument automation on iOS and the instrumentation mirror on Android.

None of this is portable, and none of it is the bottleneck.

### (d) Genuine UI rendering

Compose `ReferenceApplicationScreen.kt` 1,552 and `MapControlCluster.kt` 305;
SwiftUI views (about 2,200 lines across `HomeSheetView`, `SheetContentComponents`,
`NavigationDrawer`, `NavigationCardsView`, `ReadinessAndDiagnosticsViews`,
`PanelPrimitives`, `MapControlClusterView`); RN `App.tsx` 1,055 and
`screenStyles.ts` 379; the web markup and CSS. PRD §4.9 locks this as
idiomatic per platform ("Kotlin app uses Compose; Swift app uses SwiftUI; RN
app uses React Native primitives"), so it is out of scope by decision, not by
difficulty.

## 4. Options analysis

Four options were compared against the same dimensions: contract impact,
packaging and release impact, UniFFI constraints, the wasm path, testability,
debugging and observability, build complexity, version-skew risk, and owner
effort.

### Option A: a new `map-refapp-core` crate with its own UDL

The crate holds the non-gated pure logic of §3(a). A separate refapp UDL and generated
Kotlin, Swift and RN bindings deliver it to the apps. The wasm demo links the
crate directly with no FFI. The artifacts ship only in refapp builds.

| Dimension | Assessment |
| --- | --- |
| Contract impact | None to `rustic-maps-native-core`. A second namespace cannot reuse its records, so the crate exchanges primitives; the converters live in a thin binding crate |
| Packaging | A new refapp-only artifact set. Must be excluded from the AAR and XCFramework by file-set assertions, or it becomes the C10 violation |
| UniFFI | Good fit if the surface stays synchronous: no async, no callbacks, no reactor handback, no callback threading rules |
| ubrn | The 0.31.2 alignment resolved the checksum disagreement (0 of 108 items disagree now); the second module is unblocked on the toolchain |
| Wasm | Best path: `map-refapp-core` compiles into `rustic-maps-web-bindings` directly |
| Testability | Rust unit and property tests cover the math once; per-platform tests still pin the binding glue |
| Debugging | Cross-FFI state is harder to inspect than app-local state, but the surface is small and pure |
| Build complexity | One more UDL, one more generation script, and two more refapp artifacts |
| Version skew | The crate can drift from contract semantics unless it exchanges primitives only |
| Owner effort | High, but bounded by the small surface |

### Option B: addition-only extensions to the frozen `rustic-maps-native-core` UDL

The helpers ship in the public SDK.

| Dimension | Assessment |
| --- | --- |
| Contract impact | Grows the public contract with demo policy (follow zoom 17.5, 20× playback, picker labels). Wrong layer for those items |
| Packaging | Ships in the AAR and XCFramework, directly against the C10 direction |
| UniFFI | Understood constraints, but every addition pays the four-wrapper regeneration cost |
| Wasm | Every addition must be mirrored in `contract_sync.mjs`, and the navigation controller is still absent from the wasm seam |
| Testability | Strong: generation markers and e2e tests already exist |
| Debugging | Unchanged |
| Build complexity | No new target, but a permanently larger public surface |
| Version skew | Lowest: one contract |
| Owner effort | Medium per item, high cumulative scope risk |

Option B is right for the genuinely SDK-level items already queued: the trace
start helper (C1) and the error variants in the next contract wave. It is wrong
for follow-camera policy and demo labels.

### Option C: single-source data, constants and schema

Keep the logic platform-side, but generate or assert it from one source. This
extends the `reference-scenes.json` precedent to tokens, strings and demo
plans, and adds a machine-checked parity matrix.

| Dimension | Assessment |
| --- | --- |
| Contract impact | None |
| Packaging | None, though release file sets should exclude the app-only data |
| UniFFI | None |
| Wasm | JSON import already works (`overlay_scenes.mjs:15`, `referenceScenes.ts:8`) |
| Testability | Strong: a dependency-free assertion test in the `contract_sync.mjs` pattern |
| Debugging | Trivial; the data is readable |
| Build complexity | Minimal |
| Version skew | Drift is caught mechanically, which is the point |
| Owner effort | Low |

Option C fixes the drift that exists today (error text, demo-plan strings,
token hex values) and cannot fix behavioral math. It is the correct first
phase regardless of the crate decision.

### Option D: status quo

No effort. Drift continues: four known behavioral or textual divergences,
about 3,000–4,000 replicated lines, and no mechanical guard beyond the existing
per-platform tests, which pin each platform's own behavior rather than
agreement between them.

### Comparison

| Criterion | A (crate plus UDL) | B (extend contract) | C (single source) | D (status quo) |
| --- | --- | --- | --- | --- |
| Removes behavioral drift | Yes, for the pure set | Yes | Data and text only | No |
| Removes replicated pure logic | Yes | Partly | No | No |
| Public contract growth | None | High | None | None |
| Ships demo code in SDK packages | Only if packaging leaks | Yes | Not applicable | Yes, today |
| Wasm cost | Low (direct link) | Medium (mirror each addition) | None | None |
| Callback and async risk | Low if kept synchronous | Low (already solved) | None | None |
| ubrn gate | A second module | None new | None | None |
| Effort | High | Medium per item | Low | Zero |

## 5. Proposed architecture (if adopted)

### 5.1 Crate boundaries

Two crates, mirroring the existing `rustic-maps-native-core` pattern:

- `crates/map-refapp-core`: pure Rust, no SDK dependencies, no I/O, no clocks,
  no logging, `no_std`-friendly if cheap. It compiles into `rustic-maps-web-bindings`
  and into the native binding crate.
- `crates/map-refapp-native`: the UniFFI face. It owns
  `src/map_refapp_core.udl`, the FFI records, and the explicit converters to and
  from `map-refapp-core`'s types. It depends on `uniffi 0.31.2` and is excluded
  from the shipped SDK artifact sets.

Keeping the pure crate free of UniFFI means the wasm build never pays for
scaffolding, and the native binding crate can be added or dropped without
touching the math.

### 5.2 Records, callbacks and the event stream

The surface is synchronous and pull-based. There are no callbacks, no async
methods and no reactor handback.

- The platform owns the clock and passes monotonic timestamps into
  `advance(now)`.
- The platform owns the event loop and calls `on_fix(fix)` when a fix arrives.
- The platform pulls targets after a fix or a frame with `targets()`.
- The speech decision, if the owner revisits the platform-side ruling, returns
  an enum value; the platform decides whether and how to speak.
- The trace cursor advances one sample per tick; the platform owns the timer.

That shape sidesteps the two hardest recorded constraints: exported async
methods must hand reactor work through `runtime.rs`, and foreign listeners are
fire-and-forget and must not block.

### 5.3 UDL sketch

The sketch below is notation, not a frozen contract. It shows the shape and the
primitive-only boundary. Follow-zoom policy is passed in rather than baked in,
which keeps demo policy out of the crate and honors the no-magic-numbers rule.

```udl
namespace map_refapp_core {
    /// The 1-2-3-5-10 ladder's selection for one ground answer.
    ScaleBarSelection? select_scale_bar_scale(
        double ground_meters_per_screen_pixel,
        double minimum_width_pixels,
        double maximum_width_pixels
    );

    /// The shortest off-north angular distance, always in [0, 180].
    double bearing_off_north_degrees(double bearing_degrees);

    /// The demo dispatch interval for a recorded cadence and playback factor.
    u64 trace_dispatch_interval_milliseconds(
        double recorded_sample_interval_seconds,
        double playback_acceleration_factor
    );
};

dictionary ScaleBarSelection {
    double distance_meters;
    double width_pixels;
};

dictionary FollowFix {
    double latitude_degrees;
    double longitude_degrees;
    double? course_heading_degrees;
    double remaining_distance_fraction;
};

dictionary FollowCameraTargets {
    double center_latitude_degrees;
    double center_longitude_degrees;
    double zoom_level;
    double? bearing_degrees;
};

dictionary PreTripCamera {
    double center_latitude_degrees;
    double center_longitude_degrees;
    double zoom_level;
    double bearing_degrees;
    double pitch_degrees;
};

enum FollowPhase {
    "Disengaged",
    "Engaged",
    "BrokenByGesture",
};

interface FollowCamera {
    constructor(u32 course_smoothing_window_fixes);

    /// Captures the pre-trip camera and sets the in-trip target zoom.
    void engage_trip(
        double current_center_latitude_degrees,
        double current_center_longitude_degrees,
        double current_zoom_level,
        double current_bearing_degrees,
        double current_pitch_degrees,
        double follow_zoom_level,
        double follow_zoom_maximum
    );

    void break_on_gesture();
    void on_fix(FollowFix fix);
    void reengage();

    /// Returns the captured camera and disengages, or null outside a trip.
    PreTripCamera? restore_pre_trip_camera();

    FollowPhase phase();
    FollowCameraTargets targets();
};

dictionary EaseStep {
    double value;
    boolean finished;
};

interface TimedEase {
    constructor(u64 duration_nanoseconds);
    void begin(u64 start_nanoseconds, double from_value, double to_value);
    void reset();
    EaseStep advance(u64 now_nanoseconds);
};

interface ExponentialChase {
    constructor(double time_constant_nanoseconds);
    void reset();
    double advance(double current_value, double target_value, u64 now_nanoseconds);
};

// Owner-gated: the recorded ruling keeps speech dedup and flush
// platform-side. Shown to define the boundary, not as a Phase 1 deliverable.
enum SpeechDeliveryDecision {
    "Spoken",
    "ReDeliveryDropped",
    "ArrivalNoted",
    "ToggledOffSkipped",
    "NoSpeechTextSkipped",
};

interface SpeechDecisionConsumer {
    constructor();
    void set_speech_enabled(boolean enabled);
    SpeechDeliveryDecision consume_delivery(
        string? speech_text,
        u64? speech_instruction_id,
        string instruction_kind
    );
};

dictionary TraceSample {
    double latitude_degrees;
    double longitude_degrees;
    double horizontal_accuracy_meters;
    double timestamp_offset_seconds;
};

interface TraceCursor {
    /// Samples are primitives, never contract or SDK records.
    constructor(
        sequence<TraceSample> samples,
        double sample_interval_seconds,
        double playback_acceleration_factor
    );
    boolean is_finished();
    TraceSample advance();
};
```

The trace route does not appear here on purpose. `RouteData` is a
`rustic-maps-native-core` record, UniFFI cannot share it across namespaces, and
duplicating it in the refapp UDL would add a second route record. The route
decode belongs to the contract (backlog item C1); the refapp crate receives
samples as primitives.

The speech interface is shown to define the boundary and is not part of the
default Phase 1 set. The recorded ruling keeps speech dedup and flush
platform-side, so shipping that interface needs an owner decision first.

### 5.4 Per-platform responsibility matrix

| Concern | `map-refapp-core` | Android | iOS | RN | Web |
| --- | --- | --- | --- | --- | --- |
| Follow targets, phases, zoom ramp | Owns | Applies to camera values | Applies to camera values | Applies to camera values | Applies to page state |
| Course smoothing and easing | Owns | Passes frame timestamps | Passes display-link timestamps | Passes Choreographer timestamps | Passes `performance.now()` |
| Camera object construction | No | `MapCamera` | `MapCamera` | `MapCamera` | `MapCamera` |
| Surface attach, resize, detach | No | `SurfaceView` | `CAMetalLayer` | Host view | `GpuMapCanvas` |
| Gestures | No | Compose pointer input | SwiftUI gestures | RN pan responder | Pointer and wheel |
| Voice | No | `TextToSpeech` | `AVSpeechSynthesizer` | Native speaker | None |
| Audio focus or session | No | `AudioFocusRequest` | `AVAudioSession` | Native speaker | None |
| Speech decision | Owner-gated | Platform decision | Platform decision | Platform decision | None |
| Trace timer | No | Coroutine delay | `Timer` | Handler or interval | `setInterval` |
| Trace route decode | No | Contract C1 | Contract C1 | Contract C1 | Contract C1 |
| Readiness transitions | Owns the ladder | Events and rendering | Events and rendering | Emitter events | Hooks and rendering |
| Error detail policy | Owns the mapping | Rendering | Rendering | Emitter | Rendering |
| Consumer strings and tokens | No | Parity-tested mirror | Parity-tested mirror | Parity-tested mirror | Parity-tested mirror |
| Views and layout | No | Compose | SwiftUI | RN | HTML and CSS |
| Launch automation | No | Instrumentation mirror | Launch arguments | None | URL parameters |

### 5.5 The tricky cases

**Per-frame events.** Do not emit a callback per frame. The platform already
runs a pump on every platform (`withFrameNanos`, `CADisplayLink`,
`Choreographer`, `requestAnimationFrame`) and already calls `draw` or
`frame_settled` once per frame. A synchronous `advance(now)` and a `targets()`
pull fit that cadence with no new event stream and no callback thread.

**Camera ease driven by platform frame clocks.** The crate must never read a
clock. Android passes `frameTimeNanos` from the choreographer; iOS passes
`CACurrentMediaTime()` scaled to nanoseconds; the web passes
`performance.now()` scaled the same way. The existing implementations already
take caller-supplied timestamps (`CameraEasing.kt:47-87`), so the port is
mechanical.

**Speech dedup versus voice-engine ownership.** This is the one boundary the
recorded ruling already decided: speech dedup and flush stay platform-side.
The study does not overturn that, and the speech interface in §5.3 is shown to
define the boundary, not as a Phase 1 deliverable. If the owner revisits the
ruling later, only the decision could move ("speak, drop, note arrival, skip");
the engine utterance id, the flush, the queue and the audio focus stay native,
because those are properties of the voice engine. The RN consumer's
`platformUtteranceIdentifier` already shows the split: the decision is pure,
the engine identity belongs to the platform.

**Trace replay timing.** The crate owns the sample cursor, the interpolation and
the next-dispatch-interval arithmetic. The platform owns the timer and the
`provide_location_update` call. The decode of the recorded fixture into route
plus samples belongs to the contract's C1 addition, because that is where
`RouteData` lives. The web demo has no navigation controller, so its cursor
feeds the visual follow demo only.

**Cross-namespace records.** The refapp binding crate converts primitives to
its own records. No FFI trait crosses the crate boundary; the recorded orphan
rule and the crate-local mirror rule both apply unchanged.

## 6. Phased migration plan

The phases are ordered so that every one compiles and tests standalone, and so
the cheapest risk reduction lands first.

### Prerequisites

- Backlog C3 (design-schema parity) and the demo-plan triple: Phase 0.
- Backlog C1 (trace fixture plus replay driver on the contract): Phase 5. It is
  the right home for trace route decoding and may render `TraceCursor`
  unnecessary.
- Backlog C2 (surface host into the shipped wrappers): Phase 5. It proves the
  I/O boundary and must not be pulled into the crate.
- The ubrn alignment: Phase 4 (unblocked 2026-11-01 by the 0.31.2 alignment).

### Phase 0: parity floor, no Rust

Land C3's `platform/reference-tokens.json`, the demo-plan section in
`platform/reference-scenes.json`, and the unified error text. Extend the
`contract_sync.mjs` pattern to consumer strings and behavior constants.

Success: an injected drift in any platform mirror fails the test; the four
apps render identical strings and tokens.

### Phase 1: `map-refapp-core`, pure and unbound

Build the crate and its Rust unit and property tests. It must build for
`wasm32` with no feature flags that pull I/O.

Success: the follow camera, easing, ladder and trace cursor match the current
Android behavior in property tests; `cargo clippy` is clean for the wasm
closure. Speech stays out of this phase under the platform-side ruling.

### Phase 2: wasm adoption

Export the crate from `rustic-maps-web-bindings` and delete the mirrored math from
`map_controls.mjs`. The page keeps its presentation code.

Success: the Playwright suite stays green with the same assertions; the page imports
the crate's values rather than its own copies.

### Phase 3: native bindings

Add `map_refapp_core.udl` and `scripts/build-refapp-core.sh`. Generate Kotlin
and Swift into refapp-only targets. Port Android, then iOS. Delete each ported
copy in the same change.

Success: each platform's UI tests stay green; a parity test pins values against
the Rust crate; the AAR and XCFramework file sets exclude the refapp artifacts.

### Phase 4: React Native

Generate the second ubrn module; the toolchain is aligned (0.31.2). Until then the RN
copies stay and the Phase 0 parity test pins their constants.

Success: jest 15/15 plus on-device parity; no second behavior implementation.

### Phase 5: evaluate the remainder

Route trace replay through C1's contract additions. Keep the surface host in
C2. Raise the speech decision as an owner question against the platform-side
ruling. Record the non-goals of §8 as decisions.

Success: the C1 and C2 items close on their own terms; the refapp crate stays
at the pure set.

### Proposed milestone block

The block below is proposed for `PLAN.md` and is not edited into it by this
study.

```markdown
### M12 — Reference-app core centralization (partial, evidence-gated) · *status: proposed (design study `docs/history/RefappCoreCentralization.md`, 2026-10-29)*
> Verify: the shared demo artifact, consumer strings and design tokens are machine-checked across all four apps with zero unexplained drift; the pure refapp math (follow-camera state machine, circular course median, easing, scale-bar ladder, trace pacing) exists once in `map-refapp-core`, compiles into the wasm demo without FFI, and reaches Android and iOS through a refapp-only UDL that never enters the shipped SDK packages; each ported copy is deleted and the Espresso/XCUITest/jest/Playwright suites stay green; `rustic-maps-native-core.udl` changes only through the separately tracked C1 additions.

- [ ] **Phase 0 — parity floor (no Rust)**: land C3 `platform/reference-tokens.json` plus the four-platform parity test, the demo-plan triple into `platform/reference-scenes.json`, and the unified error text; extend the parity test to consumer strings and behavior constants. Success: an injected drift in any platform mirror fails the test.
- [ ] **Phase 1 — `map-refapp-core` (pure, no UDL)**: follow-camera state machine, circular course median, smoothstep and exponential easing, scale-bar ladder, trace cursor; Rust unit and property tests; wasm-safe, no I/O, no clocks. Speech stays out under the platform-side ruling.
- [ ] **Phase 2 — wasm adoption**: `rustic-maps-web-bindings` exports the crate directly; the web refapp deletes its mirrored math in `map_controls.mjs`; the Playwright suite stays green with the same assertions.
- [ ] **Phase 3 — native bindings**: `map_refapp_core.udl` plus `scripts/build-refapp-core.sh` generating Kotlin and Swift into refapp-only targets; Android then iOS adopt, delete their copies, and pin value parity in their own tests; the AAR and XCFramework file sets exclude the crate.
- [ ] **Phase 4 — RN**: generate the second ubrn module (the toolchain gate is cleared by the 2026-11-01 alignment); until it lands the RN copies stay and the parity test pins their constants.
- [ ] **Phase 5 — evaluate the remainder**: trace replay routes through C1's contract additions rather than the refapp crate; the surface host stays SDK-side (C2); raise the speech decision as an owner question against the platform-side ruling; UI, TTS, gestures, audio focus, lifecycle and launch automation stay platform-specific; record the rejection of a shared app state machine.
```

## 7. Risks and mitigations

| Risk | Mitigation |
| --- | --- |
| Frozen-contract creep | The refapp logic lives in its own UDL. `rustic-maps-native-core` grows only through C1 and the queued contract wave |
| Demo code in release artifacts | Refapp-only targets plus release file-set assertions; the C10 item stays the tracking ticket; the crate is never a dependency of the AAR or the shipped XCFramework |
| uniffi and ubrn version friction | Resolved by the 2026-11-01 alignment on uniffi 0.31.2: ubrn 0.31.0-6's generated TypeScript and the Rust scaffolding agree on all checksum items, so Phase 4 is no longer version-gated |
| Callback and threading | No callbacks in the first surface. If a later need appears, follow the recorded listener rules: fire-and-forget, never block, hop to the platform's UI thread on the platform side |
| Wasm-direct versus FFI divergence | One pure crate feeds both paths. The UDL wraps the same functions, and parity tests compare the binding results with the Rust values |
| Over-abstraction | Hard non-goals in §8; a small pure crate, not a framework. If the crate needs a clock, a thread or a logger, the design has slipped |
| Observability and debugging | The crate stays pure and log-free. Platforms keep their logs and diagnostics; unit tests pin behavior. Cross-FFI state is small enough to inspect through the app's own readout |
| Moving UI-adjacent state | Do not move it. The state classes are 1,611 and 1,729 lines and are entangled with reactive UI; the cost is documented in §8 |
| Version skew between the crate and contract semantics | Exchange primitives only; never mirror `RouteData`; pin shared constants with the Phase 0 parity test |

## 8. Explicit non-goals and what not to centralize

These pieces should stay platform-specific, and the reasons are structural, not
a matter of taste.

**Views and layout.** Compose, SwiftUI and React Native views are the
UI-test hosts and the demonstration of the design language. PRD §4.9 requires
idiomatic implementation per platform. Cross-platform UI toolkits are a
different, much larger decision that this study does not make.

**Native TTS and audio focus.** `TextToSpeech` and `AVSpeechSynthesizer` have
different queue, interruption and focus models. The iOS engine already
implements a flush-and-interrupt policy that Android expresses through audio
focus (`NavigationSpeechEngine.swift:20-90`,
`SpeechGuidanceSpeaker.kt:18-95`). A shared voice abstraction would flatten
those differences into the lowest common denominator and lose the platform
behavior the UX doc requires.

**Gestures.** The content-follows-pointer algebra, the rotate sign and the
pinch anchoring are per-platform event models. The project already paid for a
gesture-direction defect that existed only on iOS (RF-1); the fix was
per-layer, not shared.

**Lifecycle and surfaces.** `SurfaceView`, `CAMetalLayer`, host views and the
WebGPU canvas cannot cross an FFI boundary. The attach-retry policy and the
frame pump are platform code by construction, and C2 puts them in the SDK
wrappers where they belong.

**Launch-argument automation and the instrumentation mirror.** `simctl` has no
touch injection, so iOS drives the same user-path methods from launch
arguments; Android drives them from instrumentation. Both are test plumbing,
not product logic.

**A shared application state machine.** This is the expensive version of the
question and should be rejected explicitly. `ReferenceApplicationState.kt`
(1,611 lines), `ReferenceApplicationModel.swift` (1,729 lines) and
`ReferenceMapController.kt` (1,850 lines) are not bags of pure functions. They
own observable state for Compose snapshots, SwiftUI `@Published` values and RN
emitter events; they hold SDK objects, surfaces and subscriptions; and they are
rewritten whenever the demo UX changes, which is most rounds. Moving them
would require mirroring every observable value across the boundary, crossing
FFI on every gesture and frame, and turning every UI experiment into a
binding change. It would also make the UI-test host harder to debug, which is
the opposite of its purpose. The narrow crate of §5 captures most of the real
duplication at a fraction of the cost.

## Appendix A: commands run

All commands ran from the worktree root:
an isolated worktree of the repository.

Line counts per feature area:

```bash
find platform/android/reference-application/src/main -name '*.kt' | xargs wc -l
find platform/android/maps-sdk/src -name '*.kt' | xargs wc -l
find platform/ios/reference-application/Sources -name '*.swift' | xargs wc -l
find platform/ios/Sources -name '*.swift' | xargs wc -l
wc -l platform/rn/app-shell/App.tsx platform/rn/app-shell/src/*.ts
find platform/rn/app-shell/android/app/src/main/java -name '*.kt' | xargs wc -l
find platform/rn/app-shell/ios -name '*.swift' | xargs wc -l
wc -l platform/web/*.mjs platform/web/*.html platform/web/tests/*.mjs
find platform/android/reference-application/src/test \
  platform/android/reference-application/src/androidTest -name '*.kt' | xargs wc -l
find platform/ios/reference-application/Tests -name '*.swift' | xargs wc -l
wc -l platform/rn/app-shell/__tests__/*
wc -l crates/rustic-maps-navigation/src/trace_fixture.rs crates/rustic-maps-native-core/src/*.rs \
  crates/rustic-maps-native-core/src/rustic_maps.udl
wc -l platform/reference-scenes.json \
  platform/ios/Sources/MapNativeCoreUI/Resources/reference-scenes.json
cmp platform/reference-scenes.json \
  platform/ios/Sources/MapNativeCoreUI/Resources/reference-scenes.json
```

Structure, member lines and divergence evidence:

```bash
rg -n '^(namespace|interface|dictionary|enum|typedef|\[)' \
  crates/rustic-maps-native-core/src/rustic_maps.udl
rg -n '^(pub (struct|enum|fn)|^impl)' crates/rustic-maps-navigation/src/trace_fixture.rs
rg -n 'class |fun |data class|enum class|val ' \
  platform/android/reference-application/src/main/kotlin/com/angoratek/rusticmaps/referenceapplication/ReferenceApplicationState.kt
rg -n 'class |struct |enum |func |@Published' \
  platform/ios/reference-application/Sources/ReferenceApplicationModel.swift
rg -n 'class |fun |private val |@ReactMethod' \
  platform/rn/app-shell/android/app/src/main/java/com/angoratek/rusticmaps/refapprn/ReferenceMapController.kt
rg -n 'pub (struct|enum|fn|const)|^impl' \
  crates/rustic-maps-navigation/src/trace_fixture.rs
rg -n 'pub (async )?fn|pub struct|wasm_bindgen' crates/rustic-maps-web-bindings/src/*.rs
rg -n --fixed-strings 'rate limit exhausted' platform/
rg -n 'ProviderNotConfigured|RateLimitExhausted' platform/
rg -n 'distanceLadderDecadeRange|LADDER_DECADE_SCAN_RANGE' platform/
rg -n 'CourseMedianSmoother|medianCourseHeadingDegrees|sortedCourses' platform/
rg -n --fixed-strings 'Clean walk' platform/
rg -n --fixed-strings 'Voice guidance' platform/
rg -n 'const val|static let|export const|appStrings' \
  platform/android/reference-application/src/main/kotlin/com/angoratek/rusticmaps/referenceapplication/ReferenceApplicationConstants.kt \
  platform/ios/reference-application/Sources/ReferenceApplicationConfiguration.swift \
  platform/rn/app-shell/src/theme.ts
```

Artifact schema:

```bash
python3 -c "import json; d=json.load(open('platform/reference-scenes.json')); \
print(list(d.keys())); print(list(d.get('navigation_demo', {}).keys()))"
```

Repository context read for the constraints and the backlog:
`CLAUDE.md` (UniFFI verdicts, rendering and packaging facts), `PRD.md` §4.7,
§4.9 and §6, `PLAN.md` §1 and §2 (items C1, C2, C3, C10), and
`docs/ReferenceAppUX.md` §10–§12.

The document is the only changed file:

```bash
git status --short
git diff --stat --cached
```
