# Reference-application copy audit (2026-10-30)

Why the four reference applications say the same thing in different words, and
what to do about it. Read alongside `docs/ReferenceAppUX.md` (the design
language) and `platform/reference-tokens.json` (the shared token artifact).

The product owner's report: the Android application offers **"Start demo
navigation"**, the iOS application offers **"Plan a route"**, and the same
search field reads "Where to?" on one platform and "Destination" on another.

## 1. Method

Every user-visible string of the four surfaces was read in source: rendered
text, placeholders, accessibility labels and text composed with values. Strings
that only appear in comments, logs or tests are excluded. Counts are
**inventory roles** — one conceptual string per row, deduplicated per platform.

Paths:

- `A/` — `platform/android/reference-application/src/main/kotlin/com/angoratek/rusticmaps/referenceapplication/`
- `I/` — `platform/ios/reference-application/Sources/`
- `IU/` — `platform/ios/Sources/MapNativeCoreUI/`
- `N/` — `platform/rn/app-shell/`
- `NH/` — the React Native native hosts (`android/app/src/main/java/…/refapprn`, `ios/MapsSdkRefappRn/`)
- `W/` — `platform/web/`

Δ legend: **=** identical · **≈** near (punctuation, casing, ordering) · **≠**
different wording · **—** absent · **1×** only one platform has the role.

## 2. Findings

### 2.1 The scale

- Android: 92 roles (≈110 raw literals; two constants are unused).
- iOS: 88 roles (≈95 raw).
- React Native: 91 in `App.tsx` + `theme.ts`, **plus ~25 duplicated
  user-visible strings in the native hosts** (`NH/RefappConstants.kt` and
  `.swift`) = ~116 effective; nine `appStrings` entries are dead.
- Web: 79 in the playground/`index.html`, plus ~20 in `mobile-demo/` = ~99.
- **46 genuinely different** wordings, **25 near-identical**, out of 104
  compared roles. 26 identical, 7 single-platform.

### 2.2 The three worst offenders

1. **The peek's primary action** — Android `"Start demo navigation"`
   (`A/ReferenceApplicationScreen.kt:550`), iOS `"Plan a route"`
   (`I/ReferenceApplicationConfiguration.swift:616`), React Native
   `"Start simulated navigation"` (`N/src/theme.ts:215`), web
   `"Start simulated trip"` / `"Simulate the trip"` (`W/index.html:89`,
   `W/playground.mjs:2539`). Four labels, three intents.
2. **The search vocabulary** — `"Where to?"` vs `"Search a destination"` vs
   `"Destination"`, and `"Search an origin"` vs `"Origin"`
   (`A/ReferenceApplicationConstants.kt:116-117`, `A/…Screen.kt:569,576`;
   `I/…Configuration.swift:613`, `I/ReferenceApplicationModel.swift:1641`;
   `N/src/theme.ts:221-222`; `W/index.html:49,62`).
3. **The navigation drawer** — exit is `"Exit"` / `"Stop"` / `"Done"` /
   `"Stop the trip"`; the phase reads `"Phase: OffRoute"` on Android, `"Off
   route"` on iOS, raw `"OffRoute"` on RN; the ETA line is
   distance-then-duration on Android and RN but duration-then-distance on iOS.

The deviation alert has three genuinely different sentences
(`A/…Screen.kt:1122-1123`, `I/NavigationCardsView.swift:138`,
`platform/reference-scenes.json:186-188`).

### 2.3 The divergence matrix (roles, canonical rows only)

Columns: Android · iOS · React Native · Web.

| Role | Android | iOS | RN | Web | Δ |
|---|---|---|---|---|---|
| Readiness · ready | `Ready · gpu` | `Ready` | `Ready · gpu` | `Ready` | ≈ |
| Readiness · loading | `Loading…` | `Loading…` | `Loading…` | `Starting the map…` | ≠ |
| Readiness · degraded | `Degraded: <detail>` | `Degraded: <detail>` | `Degraded: <detail>` | `Fallback: 2D grid` | ≠ |
| Readiness · failed | `Failed: <detail>` | `Failed: <detail>` | `Failed: <detail>` | `Failed: <detail>` | ≈ |
| Keyless prompt | `Set a provider key to load live map data` | chip `Set provider key` | same as Android | `No provider key — using demo places…` | ≠ |
| Settings · gear a11y | `Open provider settings` | `Settings` | `Open settings` | `Settings` | ≠ |
| Settings · close | `Close` | `Close` | `Done` | `Close settings` | ≠ |
| Credential · applied | `<name> key applied` | `Applied` | `Key applied` | `Key applied` | ≠ |
| Credential · not applied | `<name> key not applied` | `Not applied` | `No key set` | — | ≠ |
| Credential · restart note | `Cleared. This session keeps its providers until the app restarts.` | `Key cleared. Restart the app …` | `Clearing a key removes it from this device. Restart the app …` | `Cleared — back to the demo places.` | ≠ |
| Diagnostics title | `Diagnostics` | `Diagnostics` | `Diagnostics` | `Performance and diagnostics` | ≈ |
| Tile statistics | `requested N, drawn N, fallback N, deferred N, missing N, overlay triangles N` | six separate rows | `Tiles requested N · drawn N · fallback N` | `tiles requested N / drawn N / missing N / fragments N` | ≠ |
| Destination field | `Where to?` | `Where to?` | `Where to?` | `Destination` | ≠ |
| **Peek primary action** | `Start demo navigation` | `Plan a route` | `Start simulated navigation` | `Start simulated trip` | **≠** |
| Search heading | — | `Plan a route` | — | `Plan a trip` | ≠ |
| Origin field | `Origin` / `Search an origin` | `Search an origin` | `Origin` | `Origin` | ≠ |
| Destination placeholder | `Search a destination` | `Where to?` | `Where to?` | `Destination` | ≠ |
| Planning in flight | `Planning the route…` | `Planning…` | `Planning the route…` | `Planning…` | ≈ |
| Empty-list hint | long destination hint | `No results yet; search a place above.` | origin-and-destination hint | `Enter an origin and a destination…` | ≠ |
| Start simulated navigation | `Start simulated navigation` | same | same | `Start simulated trip` | ≈ |
| Demo scenes heading | `Demo scenes` | `Demo scenes` | `Demo scenes` | `Scene overlays (3D only)` | ≠ |
| Clear scenes | `Clear` | `Clear overlays` | `Clear` | `Clear overlays` | ≈ |
| Camera presets heading | — | `Camera presets` | `Framing` | `Camera` | ≠ |
| Theme | 2-way switch | 2-way | 2-way | 3-way incl. Auto | ≠ |
| Exit control | `Exit` | `Stop` / `Done` | `Exit` | `Stop the trip` | ≠ |
| Voice toggle | `Voice guidance` | `Voice` | `Voice guidance` | — | ≈ |
| ETA line | `Distance remaining X · Duration remaining Y` | `<duration> · <distance> remaining` | `ETA: Distance remaining X · Duration remaining Y` | three labelled rows | ≠ |
| Phase | `Phase: Navigating` / `OffRoute` / `Arrived` | `Navigating` / `Off route` / `Arrived` | `Navigating` / `OffRoute` / `Arrived` | `Phase Navigating` | ≠ |
| Deviation alert | one sentence | `Off route entered — … is frozen.` | Android's | artifact preview sentence | ≠ |
| Error label | `SdkException.<Variant>` | bare `<Variant>` | bare variant | `<origin>: <detail>` | ≠ |

Rows not in this table are either identical on all four surfaces (zoom,
my-location, 2D/3D, compass, attribution — the map control cluster is the one
component that was unified early) or single-platform.

### 2.4 Why

1. **The shared token artifact owns no UI copy.** `reference-tokens.json`
   carries colours, type, spacing, behaviour and exactly two error sentences;
   `check_ux_parity.mjs` checks those and nothing else. Section headings,
   buttons, placeholders and a11y labels have no shared source, so they are
   copied by hand into five constant sets (the RN native hosts are the fifth).
2. **Content labels *are* shared.** Camera presets, scene labels, demo plans and
   places all come from `reference-scenes.json` and are identical wherever
   consumed. Every divergence above is *chrome*, not content.
3. **Copy written at different times.** Android's own peek says "Start demo
   navigation" while its route summary says "Start simulated navigation" — the
   same app, two vocabularies. iOS's peek says "Plan a route" because that
   action opens search, not a trip.
4. **Some text is legitimately contract-owned**: maneuver instructions, the
   speech channel, provider display names, and verbatim error details. Distance
   phrases and unit formatting are platform-owned.
5. **Platform conventions**: the Android back affordance, iOS's HIG "Back", SF
   Symbols for map controls.
6. **A deliberate v1/v2 split**: `docs/ReferenceAppUX.md` keeps the web
   playground on the v1 floating-panel interface, so some of its headings are
   older by design.

## 3. Resolution

### 3.1 One shared strings source

Extend `platform/reference-tokens.json` with a top-level `ui_labels` section
beside the existing `strings` (which stays the SDK error-detail channel):

```json
"ui_labels": {
  "peek.destination_hint": { "text": "Where to?" },
  "peek.primary_plan":     { "text": "Plan a route" },
  "route.start":           { "text": "Start simulated navigation" },
  "nav.exit":              { "text": "Exit" },
  "settings.close":        { "text": "Close", "platform_overrides": { "ios": "Done" } }
}
```

`text` is canonical; `platform_overrides` is explicit, documented and
allow-listed; placeholders use one syntax and the gate normalizes each
platform's interpolation. Content labels stay in `reference-scenes.json`,
registry rows in `platform/providers.json`, error details in
`reference-tokens.json.strings`.

`docs/ReferenceAppUX.md` gains a generated **§2.5 Consumer copy** table so the
document and the artifact cannot drift.

### 3.2 Gate

Extend `scripts/check_ux_parity.mjs` (or add `check_strings_parity.mjs` and run
it from the same entry point): read `ui_labels`, add string adapters for
`A/ReferenceApplicationConstants.kt`, `I/ReferenceApplicationConfiguration.swift`,
`N/src/theme.ts`, `N/App.tsx`, both RN native host constant files, and a new
`W/ui_strings.mjs`; compare exact text after interpolation normalization; print
omissions rather than passing them silently; self-test by mutating one artifact
value and one platform mirror. The gate lands report-only first and turns
blocking once every platform is migrated.

### 3.3 Must not be unified

- Contract text: maneuver instructions, speech, provider display names, error
  **details** (echoed verbatim).
- Value formatting: `m`/`km`/`ft`/`mi`, "Now", minute/second phrasing, locale
  and pluralization.
- The Android system back affordance; iOS SF Symbol *glyphs* (their a11y
  labels are canonical).
- Diagnostics jargon — SDK vocabulary is deliberately allowed there.
- Registry rows: provider names, credential labels, hints, attribution.
- The mobile-demo launcher's session vocabulary, unless the owner asks.

## 4. Migration order

1. Artifact + documentation + gate (report-only), recording the 46 divergences.
2. Android: re-point the constants file, delete the two unused constants.
3. iOS: re-point the configuration file; add Auto to the theme model.
4. React Native: re-point `theme.ts`, remove the nine dead strings, unify the
   two native host constant files.
5. Web: introduce `ui_strings.mjs`, migrate the consumer rows; keep documented
   v1 debug overrides.
6. Flip the gate to blocking and update the four platforms' UI-test assertions.

## 5. Baseline at introduction (2026-10-30, M28 slice 1)

The shared source now carries **37 canonical `ui_labels`** and **one allow-listed
override** (`navigation.phase_off_route` → `rn: "OffRoute"`, the contract
`RoutePhase` enum spelling rendered verbatim until the FFI label-normalization
ask is decided). `scripts/check_ux_parity.mjs` reports, and does not yet fail,
**17 consumer-copy divergences** across the four surfaces:

| Surface | Canonical matches | Omitted (not yet extractable) | Divergences |
| --- | --- | --- | --- |
| Android | 19/37 | 16 | 2 |
| iOS | 20/37 | 11 | 6 |
| React Native | 25/37 | 3 | 9 |
| Web | 37/37 | 0 | 0 |

Omissions are rows whose text lives inline in a view rather than in the
constants file this slice reads; the migration slices move each one into its
platform's single string source. The web module
(`platform/web/ui_strings.mjs`) already carries every canonical value, but the
page does not consume it until slice 5. The gate flips to blocking in slice 6.
