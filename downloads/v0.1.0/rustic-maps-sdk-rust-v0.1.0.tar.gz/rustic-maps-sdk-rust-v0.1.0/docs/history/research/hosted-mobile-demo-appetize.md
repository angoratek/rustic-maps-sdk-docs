# Appetize.io for browser-hosted Android / iOS / React Native demos

Research date 2026-10-30. Primary sources: `docs.appetize.io`, `appetize.io/pricing`, `support.appetize.io`. Quoted text is verbatim.

## Recommendation

1. **Do not run an always-on public live demo on Free.** Free is 30 min/month, 3-minute sessions, 2 active devices — about **10 full sessions per month**. That is a reviewer link, not a public feature.
2. **Budget a paid plan for public use.** Starter/Premium include 500 min/month then $0.06/min, with unlimited session length. At 60–90 s per run that is hundreds of demos/month. Still add a hard budget guard.
3. **Architecture:** static `/demo/mobile` with Android / iOS / React Native tabs, poster + “Start demo”, **no iframe and no session until click**. A serverless endpoint checks budget + per-IP/cookie rate limit, then returns the public build ID. The API token never reaches the browser.
4. **Keys:** current Appetize has **no private embed key**. `publicKey`/`buildId` is the public identifier that grants run access; the only secret is the API token (`X-API-KEY`), kept in CI/edge-function secrets. Never resurrect a legacy `privateKey`.
5. **Validate GPU early.** Appetize runs on Android emulators and iOS Simulators and documents nothing about GPU/Metal/OpenGL/WebGL. Smoke-test wgpu on the exact devices before promising the demo (§4).

---

## 1. REST API v1: upload / update

- Create: `POST https://api.appetize.io/v1/apps`
- Update in place: `POST https://api.appetize.io/v1/apps/{app_publicKey}`
- Auth: `X-API-KEY: <token>` — “Use an API token for authentication via X-API-KEY header.” Tokens live under Organization → API Token; “You must be an organization admin to create or view tokens.” JSON requests need `Content-Type: application/json`; “All responses are in JSON format.”
- Default body is JSON. A binary can instead be sent as `multipart/form-data`: send it “in the `file` field rather than the `url` field”; “All other field names stay the same.” Flatten nested permissions (`appPermissions.run`); an empty value removes a field (`-F "field="`).

Fields (same names in JSON and multipart):

| Field | Values / meaning |
|---|---|
| `platform` **required** | `ios` \| `android` |
| `url` / `file` | public `.zip`/`.tar.gz`/`.apk` URL, or multipart file |
| `fileType` | `zip` \| `tar.gz` \| `apk` (default zip iOS, apk Android) |
| `timeout` | inactivity seconds: 30, 60, 90, 120, 180, 300, 600, 1800, 3600, 7200; default 120 |
| `timeLimit` | max session duration, seconds |
| `maxConcurrent` | max concurrent sessions for the app |
| `referrerHostnamesRestricted` | allowed embedding hostnames (array) |
| `disabled` | “disables streaming” — remote kill switch |
| `buttonText` / `postSessionButtonText` | start prompt, default `"Tap to play"` |
| `launchUrl` | deep link at launch |
| `appPermissions` | `run`, `networkProxy`, `networkIntercept`, `debugLog`, `adbConnect`, `androidPackageManager`; each `authenticated` \| `public` \| `null` |

Response (create/update) contains **only**:

```json
{"publicKey":"p7nww3n6ubq73r1nh9jtauqy8w","created":"...Z","updated":"...Z","platform":"ios","versionCode":1}
```

No `privateKey`, no nested app/build. `versionCode` “Increments with each update of the app”; `buildId` is “previously known as `publicKey`”, and “the buildId and the publicKey will be interchangeable.”

**Verified 2026-10-31 (round 41): an array field does not survive a multipart upload.** The uploader sent `referrerHostnamesRestricted[]=<host>` beside the `file` field for both the create and the update, and both apps came back reporting `referrerHostnamesRestricted: []` — the demo was embeddable from any site, silently. Repeating the field without brackets, sending a JSON string in the field, and indexing the entries made no difference. Posting the same fields as a **JSON body** to `POST /v1/apps/{buildId}` sets the list, so the restriction is applied in its own JSON call after the multipart upload, and the uploader reads the app back and fails when the list does not match. Treat multipart as the file transport only and JSON as the settings transport.

**Verified 2026-10-31 (round 44): the account's own host must be in the list too.** With `referrerHostnamesRestricted` set to the two documentation hosts and `autoplay=true`, a visitor opening the app page from either docs host got a player refusal reading **"This app may not be embedded on this website"** — captured over the player's own websocket as a `userError` frame. The app page's `/api/session/request` is same-origin, so its referer is `appetize.io`; a list without that host refuses Appetize's own page, and `autoplay=true` makes the first request immediately. Two consequences the hosted demo must honour: the allow-list includes **`appetize.io`** beside the docs hosts, and the public link **does not set `autoplay`** — the app page's own Start demo button is the click-to-start gate (loading the page is free; only the stream counts). The uploader now applies both.

```bash
# Create from URL
curl -X POST https://api.appetize.io/v1/apps \
  -H "X-API-KEY: $APPETIZE_API_TOKEN" -H "Content-Type: application/json" \
  -d '{"platform":"ios","url":"https://example.com/RusticMaps.zip","fileType":"zip",
       "timeout":60,"timeLimit":90,"maxConcurrent":1,
       "referrerHostnamesRestricted":["docs.example.com"],"buttonText":"Start iOS demo"}'

# Create/replace by direct multipart (same endpoint + publicKey for update)
curl -X POST https://api.appetize.io/v1/apps/$APPETIZE_PUBLIC_KEY \
  -H "X-API-KEY: $APPETIZE_API_TOKEN" \
  -F "file=@app-debug.apk" -F "platform=android" -F "timeout=60" -F "timeLimit=90" -F "maxConcurrent=1"
```

CLI (documented for React Native): `npm i -g @appetize/cli`; `appetize build upload <apk|zip> --wait`. The upload “prints an `id`. That is `<build-id>`.”

**Artifacts:** Android `.apk`/`.apks`; RN uses `./gradlew assembleDebug -PreactNativeArchitectures=x86_64`. iOS is a `.zip`/`.tar.gz` containing a **Simulator** `.app` (`zip -r MyApp.zip MyApp.app`); “AppStore distribution device builds (.ipa) are not currently supported”; ARM simulator builds recommended. RN: “an Android x86_64 debug APK, or on a Mac a zipped iOS simulator `.app`” — treat as two builds behind one tab.

**Sizes/timing:** no per-file cap is documented; only “if total storage of uploaded apps exceeds 10GB, we reserve the right to pass through our S3 storage costs.” No official upload/processing time; `--wait` and the `updated` field are the only signals. Uploads/API calls are not listed as billable.

---

## 2. Embedding and session control

- Iframe: `https://appetize.io/embed/{buildId}` (old publicKey also accepted).
- SDK: `<script src="https://js.appetize.io/embed.js">`; `window.appetize.getClient(selector, config)`; `await client.startSession()`. Config uses `buildId`, `device`, `osVersion`, `scale`, `autoPlay` (capital P), `orientation`, `launchUrl`, `launchArgs`, `params`.
- `data-appetize-url` supports a custom/private base URL.

Key query params (`docs.appetize.io/platform/query-params-reference`): `device`; `osVersion` (docs recommend omitting in embeds); `scale` (10–100 or `auto`); `orientation` (`portrait` default); `autoplay` (`true`/`false`, **default false**); `screenOnly`; `deviceColor`; `centered`; `debug`; `launchUrl`; `launchArgs` (iOS JSON array); `params` (JSON object passed to the app); `grantPermissions`; `language`/`locale`/`timezone`; `appearance` (`light` default); `codec` (`h264` default, `jpeg` fallback); `record`, `audio`, `enableAdb`, `androidPackageManager`; `region` (`us`/`eu`).

Not documented as query params: `autostart`, `launchEnv`, `timeout`, `buttonText`, `privateKey`, `token`, `embedded`. `autoplay` is the autostart switch (`autoPlay` in the SDK). Session defaults “are enforced by Appetize … no query parameter overrides them” — set `timeout`, `timeLimit`, `maxConcurrent`, `referrerHostnamesRestricted`, `buttonText` via the API at upload time.

**publicKey vs privateKey.** Current docs contain no `privateKey`; `publicKey` was renamed `buildId`, and embeds use it openly. Build links are public by default: “anybody who has your app's Build Identifier link” “will have permission to run your app”; app-identifier links are limited to signed-in organization users. Legacy v1 integrations (e.g. the Jenkins plugin) returned both keys, but the iframe used `publicKey`; `privateKey` was only a guard, never a URL parameter. **There is no signed/tokenized embed-session mechanism in the docs** — no pre-authorized embed JWT or token. Controls are: `appPermissions.run` = `public`/`authenticated`; Embed Domains / `referrerHostnamesRestricted` (hostname match against the browser `Referer`, wildcards, empty = unrestricted); IP Access rules (which explicitly do not apply to API-token requests). A public demo therefore exposes a public build ID by design; protect minutes with budgets, not secrecy.

---

## 3. Free plan, billing, and not burning minutes

Official Free numbers (`appetize.io/pricing`): **“30 minutes refilled monthly”**, **“2 active devices maximum”**, **“3 minutes”** session duration, **“Throttled capacity”**. Paid reference: Starter/Premium “500 minutes included, then $0.06/min”; Starter 3 / Premium 16 active devices; paid sessions “Unlimited” (length). “Active device” = “number of devices that can be used simultaneously”; when none is free users wait in a “virtual ‘queue’.”

Billable streaming time “begins when a user starts streaming an app” and “ends when the user leaves the page or the session times out due to inactivity.” **Loading the embed costs nothing; only an active stream counts.** No upload/API fee is documented; storage is free below 10 GB.

Timeouts: default inactivity is “2 minutes”; configurable 30 s–2 h; precedence = build setting → organization default → Appetize fallback. Free’s 3-minute ceiling applies regardless of a larger `timeLimit`. SDK exposes `inactivityWarning` (`{secondsRemaining}`), `heartbeat()`, and `session.end()`.

**Budget math:** 30 min ÷ 3 min = **10 maximum sessions/month** (fewer in practice). At a 60 s cap, ~30 sessions/month ≈ one per day.

**Designing against quota burn.** There is no Appetize “demo mode”; build it yourself:

1. **Click-to-start:** `autoplay=false` / SDK `autoPlay:false`; do not inject the iframe before click. Appetize’s `buttonText` (“Tap to play”) plus `postSessionButtonText` can be the in-embed gate.
2. **Short sessions:** `timeLimit` 60–90 s, inactivity `timeout` 30–60 s; `session.end()` on `pagehide`.
3. **Server budget guard:** `GET /v1/usageSummary?startMonth=YYYY-MM` returns `month`, `publicKey`, `numSessions`, `minutes`, `hasMore`, `nextKey` — **no remaining field**, so sum and compare to ~80% of plan; add a KV counter for in-flight sessions because reporting can lag.
4. **Rate-limit by IP + signed cookie** at the edge: e.g. one session/IP/10 min, N/day, plus a global daily cap.
5. **“Demo is resting”:** render a recorded video/GIF when budget is hit; set `disabled:true` via API for a hard stop.
6. **Anti-hotlink:** `referrerHostnamesRestricted` / Embed Domains.
7. **Cache the page, not the session:** CDN-cache static HTML; never autoplay in cached HTML.
8. **Serialize:** `maxConcurrent:1` per build (Free only has 2 devices anyway).

---

## 4. Practical constraints and GPU risk

- “The Appetize service is powered by Android emulators and iOS Simulators.” Camera/Bluetooth/NFC unavailable, must be mocked.
- **Android:** OS 8.1, 9, 10, 11, 12, 13, 14, 15, 16 (API 27–36 by standard mapping, derived); Nexus 5 → Pixel 9 Pro / Pixel Tablet / Galaxy Tab S7.
- **iOS:** runtimes 17.2, 18.2, 26.0, 27.2; iPhone 11 Pro → 17 Pro Max and iPads. Simulator `.app` only; `.ipa` rejected. Default PIN 1111.
- **Sizes:** no documented per-file cap; 10 GB account threshold. Processing time undocumented.
- **GPU/Metal/OpenGL/WebGL/WebGPU:** Appetize publishes **no statement** and has no GPU article. iOS Simulator translates Metal to the **host Mac GPU** and exposes roughly `MTLGPUFamily.apple2`; some newer Metal features are unsupported, and Apple recommends Simulator for prototyping, not pipeline tuning. Android emulators normally use SwiftShader/ANGLE (host/software GLES); our own emulator work already needs `WGPU_BACKEND=gl`, and Vulkan is unlikely. **Smoke-test wgpu on the exact Appetize devices; keep a fallback screen if surface creation fails.**
- **Codec:** missing H.264 support can produce a black screen; documented workaround `codec=jpeg`. Test Chromium/Firefox/Safari. The browser receives a video stream, so map pan/zoom is softer than local 60 fps; no official numbers.

---

## 5. Alternatives

**BrowserStack App Live**, **AWS Device Farm remote access**, and **Sauce Labs** offer interactive real-device sessions but no credential-free embeddable public demo: App Live’s “integration URL” is a dashboard URL requiring an entitled login; Device Farm exposes short-lived signed `wss://` endpoints bound to the AWS console origin; Sauce live testing requires an account. **Corellium Webplayer** is the one real embeddable alternative — JS client plus a backend exchanging an API token for a short-lived JWT (`expiresIn` ≥ 900 s), domain allowlisted, enterprise sales. It is virtual-device infrastructure, not a free drop-in. Appetize remains the lowest-friction public embed.

---

## 6. Recommended architecture

```
/demo/mobile
  [Android] [iOS] [React Native]
  poster + "Start demo" (no iframe until click)
  "Build updated <date> · <commit>"
  state: ready | resting | rate-limited | error
```

- One build ID per tab from a generated `demo-builds.json` (public data). Never inline the API token.
- Click → `GET /api/demo/claim?platform=android` → server checks budget + IP/cookie limit → `{state:"ok",buildId,device,osVersion,params}` or `{state:"resting"}`.
- Then inject the iframe / `client.startSession()`. Register `sessionError` and `error` before starting, `end` to restore the poster, and call `session.end()` on `pagehide`.
- Use `params`/`launchArgs` for demo mode (fixture provider, mock location, demo route) — never real provider credentials; they are visible in the iframe URL.

**Upload path.** CI (preferred): GitHub Actions matrix — Android `./gradlew assembleDebug`; iOS `xcodebuild -sdk iphonesimulator` then `ditto -c -k --keepParent App.app App.zip`; RN `./gradlew assembleDebug -PreactNativeArchitectures=x86_64` plus an iOS simulator build. Upload with `POST /v1/apps/{publicKey}` (multipart) or `appetize build upload <file> --wait`; fail if the response lacks `versionCode`. Use a `concurrency` group. Manual uploads use the same curl/CLI against the same keys. **Keys:** `APPETIZE_API_TOKEN` only in CI secrets and the edge-function env; `APPETIZE_PUBLIC_KEY_*` in repo variables (not secret); provider keys not at all — the public demo runs a mock provider selected by `params`. **Staleness:** update-in-place keeps the build ID stable; CI writes a public JSON with `versionCode`, `updated`, source commit; a nightly job refreshes it.

**Risks.** Leaked private/API key → none exists for embeds; never ship a legacy `privateKey`, keep the API token server-side. Free-minute exhaustion → click-to-start, 60–90 s sessions, budget guard, per-IP/cookie limits, resting fallback, paid plan. Hotlinking → referrer restriction. Stale build → CI update-in-place + visible version/commit. GPU incompatibility → smoke-test, `WGPU_BACKEND=gl` on Android, fallback screen. Black screen → `codec=jpeg`. Queue → show queued state / paid capacity. iOS `.ipa` by mistake → CI asserts a simulator `.app` zip.

---

## Sources

- https://docs.appetize.io/rest-api · /rest-api/v1/create-new-app · /update-existing-app · /direct-file-uploads · /usage-summary · /api-tokens
- https://docs.appetize.io/platform/embedding-apps · /query-params-reference · /javascript-sdk (+ /configuration, /api-reference/session)
- https://docs.appetize.io/platform/app-management/uploading-apps/ios · /android · /platform/sharing-apps · /app-permissions
- https://docs.appetize.io/account/access-rules · /session-defaults · /platform/session-inactivity-timeout
- https://docs.appetize.io/features/devices-and-os-versions · /guides-and-samples/development-loop/react-native
- https://appetize.io/pricing
- https://support.appetize.io/does-appetize.io-use-emulators-or-physical-devices · /black-screen-when-starting-session · /do-you-charge-for-storage-of-uploaded-apps
- https://support.corellium.com/sdk/webplayer/ · https://www.browserstack.com/docs/app-live/get-started/integration-url · https://docs.aws.amazon.com/devicefarm/latest/developerguide/remote-access.html · https://docs.saucelabs.com/mobile-apps/live-testing/live-mobile-app-testing/
