# Modern Map SDK Design Inspiration

**Purpose:** Survey of the API surfaces and architectures of leading map/navigation/offline SDKs, distilled into concrete patterns worth borrowing for maps-sdk-rs. Read alongside `PRD.md` §1.1 and the crates in `PRD.md` §3.
**Date:** 2026-10-27. Sources are linked inline and listed at the end.

---

## Part A — Per-SDK survey

### A.1 MapLibre Native (Android / iOS)

Architecture: a cross-platform C++ core with thin platform wrappers in one monorepo, so core API changes and SDK updates land together ([MAPLIBRE-NATIVE-ARCH]).

**Threading model (the most transferable idea):** three thread classes with *zero shared memory state* ([MAPLIBRE-NATIVE-ARCH]):

| Thread | Responsibility |
|---|---|
| Main | owns `Map` + `Style`, serves the public API, renders, must never block |
| Worker (≈4 per `Style`) | tile parsing, text layout, geometry buffer generation (dispatched per tile) |
| FileSource | network requests for styles/tiles + **SQLite I/O for offline and cache**, results delivered asynchronously |

- Style data is passed to the render side as **immutable snapshots** (`Immutable<T>` — shared const data). The render thread holds mutable `RenderStyle`/`RenderLayer`/`RenderSource` wrappers and **derives changes by diffing consecutive snapshots**; identical inner pointers mean "unchanged". This gets style cross-fades (light → dark) for free, because changes are *computed* rather than *announced*.
- Cancellation is by object destruction: cancelling an `AsyncTask` destroys it, aborts the callback and the work.

**Camera API shape** ([MAPLIBRE-NATIVE-ANDROID-CAMERA], [FLUTTER-BINDING-SOURCE]):

- `MapLibreMap.jumpTo(cameraOptions)` — instant; `easeCamera(cameraOptions, duration, easingOption)`; `flyTo(cameraOptions, duration)`. Identical verbs exist in MapLibre GL JS, so one camera vocabulary covers web and native.
- Camera change events are coarse-grained: `regionWillChangeAnimated`, `regionIsChanging`, `regionDidChangeAnimated` — *animated vs. not* is part of the event, not the API name.
- `CameraOptions` = `{ anchor, zoom, bearing, pitch, padding }`; bounds fitting is `cameraForLatLngBounds(bounds, insets)` returning the camera that shows the bounds with padding.

**Offline region packs** ([MAPLIBRE-OFFLINE] — the Mapbox GL heritage that MapLibre inherited):

```
OfflineManager.createOfflineRegion(
    definition: OfflineRegionDefinition { styleURL, geometry: Polygon bounds, minZoom, maxZoom },
    metadata: ByteArray
) → OfflineRegion, then download(OfflineRegionObserver)
OfflineRegionObserver.onStatus(status: OfflineRegionStatus)
   // completedTileCount, completedTileSize, requiredResourceCount, downloadState
OfflineManager.invalidateAmbientCache() / clearAmbientCache() / setOfflineMapboxTileCountLimit(n)
```

- A region is **(style, geometry, zoom range)**; downloads are resumed and observed per state; status exposes *tile counts and byte counts* during download — the UI never has to estimate.
- The offline cache is a plain `cache.db` (side-loadable); offline tiles and on-demand cached tiles live in the same store, so the renderer is unaware of provenance. This is exactly the `map-cache`-oriented design the PRD already chose.
- Snapshots: `MapView.snapshot()` and a synchronous `snapshotSync` variant ([MAPLIBRE-NATIVE-ANDROID-CAMERA]).

### A.2 MapLibre GL JS

- `Map.jumpTo / easeTo / flyTo(options)` where options carry `center, zoom, bearing, pitch, padding, offset, curve, easing, duration`; `flyTo` interpolates zoom with an exponential curve so long jumps feel natural ([GLJS-CAMERA]).
- `fitBounds(bounds, { padding, maxZoom, linear, duration })` vs. `cameraForBounds` — one convenience with a `maxZoom` clamp is what integrators actually use.
- The **`idle` event** fires when the map has no more pending tile loads/animations — invaluable for deterministic golden-image testing (render → await idle → capture).
- `renderWorldCopies` toggles antimeridian world duplication; tile logic treats the world as infinitely repeated horizontally.

### A.3 Mapbox Maps SDK v10/v11

**Declarative viewport (camera states) — the cleanest follow-mode design anywhere** ([MBX-VIEWPORT], [MBX-NAV-CAMERA]):

```
mapView.viewport = plugin with states:
  IdleCameraState
  FollowPuckViewportState(FollowPuckViewportStateOptions { bearing, pitch, zoom, padding: EdgeInsets })
  OverviewViewportState(OverviewViewportStateOptions { geometry, padding })
viewport.transitionTo(state, transitionOptions)         // animated between states
```

Each option is optional, so a state only *constrains the camera properties it cares about* — the plugin reconciles all camera properties (zoom, bearing, pitch, padding, anchor) continuously as location changes. This replaces the imperative "camera update factory flood" of v9/v10.

- **EdgeInsets/padding is a first-class camera property** everywhere (not a UI hack): `EdgeInsets(top, left, bottom, right)`, typically density-scaled.
- **Camera animation objects** (`easeCamera(options){}` / `animateCamera(options){}` with an `AnimatorListener`) expose *cancel/finish* on running animations — integrators can preempt user gestures.
- **Gestures are plugins** with per-gesture controls (`move`, `scroll`, `rotate`, `quickZoom`, `doubleTap`, `scale`, `pitch`), each individually enabled/disabled with thresholds ([MBX-GESTURES]). A `NavigationBasicGesturesHandler` breaks camera follow on any user pan/rotate.

**Location puck** ([MBX-LOCATION]): `LocationPuck2D { topImage, bearingImage, shadowImage, scale }` or `LocationPuck3D` (model + accents); puck position/heading update from a single `locationComponentPlugin` consumer. Splitting "location data" (provider) from "puck visuals" (style) keeps the renderer dumb.

**Annotations vs. style layers — Mapbox's published decision matrix** ([MBX-DATA], [MBX-VIEWANNOT]):

| Mechanism | Scale | Use |
|---|---|---|
| Markers / point annotations | ≤ a few hundred | pins, clustering supported |
| View annotations (platform views drawn above the map, bound to geometry or to a layer feature) | **< 100 good, > 250 poor** | rich popups/callouts in native UI code |
| Style layers (`addLayer`) | tens of thousands | bulk data, data-driven styling |

- `ViewAnnotationManager` API: `addViewAnnotation(view, options { geometry | annotatedLayerFeature, anchor, offset, width/height, allowOverlap, priority, visibility })`, `updateViewAnnotation`, `removeViewAnnotation`, update modes `MAP_SYNCHRONIZED` vs `MAP_FIXED_DELAY`, and `cameraForAnnotations`. View annotations can bind to a *symbol layer feature id* so their visibility follows that symbol's collision state.
- **Lesson:** an SDK for mobile will be asked for "draw my Kotlin/Swift view at a coordinate" — it cannot be avoided, only bounded (count limits, priority/allow-overlap flags, explicit sync modes).

**Offline: shared TileStore + style packs + tile regions** ([MBX-OFFLINE]):

- One `TileStore` instance is shared by the Maps SDK and the Navigation routing tiles (`MapboxMapsOptions.tileStore` + `RoutingTilesOptions.tileStore`) — a single disk account for map + routing.
- `OfflineManager.loadStylePack(styleUri, options)` (styling resources) is separate from `loadTileRegion(geometry, TileRegionLoadOptions { tilesetDescriptors, resolution })` (render tiles). Both report progress (bytes, tile counts) and support pause/resume, version pinning (`TilesetVersionManager`) and disk quota (`TileStoreOptions.DISK_QUOTA`).
- Service quota caution: Mapbox caps offline tile packs at 750 cumulative (their service, not a technical limit).

### A.4 Mapbox Navigation SDK (camera modes, off-route, reroute, voice)

**Camera: producer/executor split** ([MBX-NAV-CAMERA]):

- `MapboxNavigationViewportDataSource` = *producer*: given route geometry + location, emits framing targets. Has independent `followingPadding` / `overviewPadding`.
- `NavigationCamera` = *executor* with explicit states: `IDLE → TRANSITION_TO_FOLLOWING → FOLLOWING → TRANSITION_TO_OVERVIEW → OVERVIEW`; commands like `requestNavigationCameraToFollowing()`.
- `FocalPoint` (0.0–1.0 x/y factors within the padded area) controls where the puck sits on screen (nudge the puck below screen center under an instruction card); `FollowingFrameOptions { defaultPitch, maxZoom, maximizeViewableGeometryWhenPitchZero }` tunes framing.

**Observer pattern — many small, single-purpose observers** ([MBX-NAV-REROUTE], [MBX-NAV-TBT]):

```
LocationObserver, RouteProgressObserver, RoutesObserver,
OffRouteObserver { onOffRouteStateChanged(offRoute: Boolean) },
RerouteStateObserver { idle → fetchingRoute → interrupted → error },
VoiceInstructionsObserver, BannerInstructionsObserver,
ArrivalObserver, AlternativeRoutesObserver, FallBackObserver
```

All registered on one `MapboxNavigation` object. Separation by topic (not one god-listener) makes partial implementations trivial and keeps callback payloads small.

**Off-route & reroute flow** ([MBX-NAV-REROUTE]):

- Off-route detection is internal (accuracy-aware); a boolean *state transition* (`offRoute == true/false`) is exposed, decoupling detection from action.
- A `RerouteController` performs the request; its lifecycle is observed via state (fetching/interrupted/error), so UI can show a spinner.
- Reroutes are disabled with `setRerouteEnabled(false)` for custom behavior — the framework always accepts integrator-supplied routes too.
- **Route refresh**: periodic (default 5 min, `RouteRefreshOptions.intervalMillis`), only when opted in (`RouteOptions.enableRefresh`), updates traffic/durations on the *existing* geometry — distinct event from a full reroute (no user-visible route jump).
- **Alternative routes**: tracked automatically; invalidated when the vehicle passes the fork point, retried on an interval (`RouteAlternativesOptions.intervalMillis`, default 5 min).

**Route-line rendering** ([MBX-ROUTE-LINE]): `MapboxRouteLineApi` (state) + `MapboxRouteLineView` (drawing); the traveled portion is a **vanishing route line** driven by `RouteProgressObserver` (`updateTraveledRouteLine(fraction)`); layer insertion is explicit (`routeLineBelowLayerId`, e.g. below `road-label`) — a documented gotcha when styles differ in label layer ids.

**Voice instruction model** ([MBX-NAV-VIA-TBT]):

```
VoiceInstructionsObserver.onNewVoiceInstructions(voiceInstruction:
    { ssmlAnnouncement, announcement, distanceAlongGeometry, distanceMeters, ... })
→ MapboxSpeechApi.generate(voiceInstruction)          // cloud TTS → prefetchable audio file
→ on success MapboxVoiceInstructionsPlayer.play(instructions)
→ on SpeechError use error.fallback with on-device TTS   // graceful degradation chain
→ speechApi.clean(prompt) // delete cached audio after playback
```

Structured, ordered instruction list per step (with distances-before-geometry), SSML + plain text, and an explicit **online → fallback degradation chain**. The SDK emits *audio files or text*, never plays sound itself.

### A.5 Google Maps Platform (Maps SDK + Navigation SDK)

**Camera position model** ([GOOG-CAMERA]):

```
CameraPosition { target: LatLng, zoom: Float, tilt: Float, bearing: Float }
map.moveCamera(update)                    // instant
map.animateCamera(update, durationMs, callback)  // animated, no cancel API
CameraUpdateFactory.newCameraPosition / newLatLngZoom / newLatLngBounds(bounds, paddingPx) /
    scrollBy / zoomBy(1, focusPoint)
```

- Simpler than Mapbox (no padding in the camera position itself; padding = `GoogleMap.setPadding`), no flyTo curve — Mapbox/MapLibre's model is strictly richer and worth being the internal superset.
- `OnCameraMoveStartedListener(reason: gesture|api-animation|api)`, `OnCameraMoveListener`, `OnCameraIdleListener` — a *reason* on move-start is a nice detail for distinguishing user pans from API animations.
- Gesture settings: one `UISettings` object with boolean toggles per gesture; map padding shifts the (invisible) camera focal point and overlays.

**Google Navigation SDK** ([GOOG-NAV-INTRO], [GOOG-NAV-NAVIGATOR]):

- `Navigator` object: `setDestination(waypoint)/setDestinations(...)`, `startGuidance()`, `stopGuidance()`; **listener surface**: `ReroutingListener` (automatic reroute after off-route), `RouteChangedListener`, `TrafficUpdatedListener`, `RemainingTimeOrDistanceChangedListener(thresholdSeconds, thresholdMeters)` (event only when the change is user-meaningful — suppresses callback spam), `ArrivalListener`.
- **Audio guidance**: `navigator.setAudioGuidanceSettings(AudioGuidanceSettings)` with `GuidanceMode.VOICE_ALERTS_AND_GUIDANCE` and `VolumeLevel` (older API: flag bitmask incl. vibration/Bluetooth routing). Google's insight: **guidance verbosity is a mode, not a per-instruction choice.**
- `RoutingOptions.RoutingStrategy` (default/fastest/shortest) applies to both initial routing *and* rerouting — reroutes inherit the original strategy.
- Speed: `setSpeedAlertOptions(SpeedAlertOptions { minor/major speed thresholds })` with a `SpeedingListener`; traffic-aware durations ride along with `RouteSegment`/`NavigationTrafficData`.
- Road-snapped location is produced by the SDK itself (Google-owned matching); the navigation UI (turn cards, speedometer, night mode) is all themeable.

Lessons to copy: `RemainingTimeOrDistanceChangedListener` thresholds; reroute/traffic listeners as separate interfaces; guidance mode as a first-class enum. Lessons to skip: opaque route objects (we want inspectable pure data, ferrostar-style), Google's closed rerouter.

### A.6 Apple MapKit (modern SwiftUI era)

- **Camera position is a value type usable declaratively:** iOS 17 `Map(initialPosition: MapCameraPosition, bounds: MapCameraBounds, interactionModes:)` with position cases `.region / .rect / .camera(MapCamera) / .item / .automatic / .userLocation` ([SWIFTUI-MAPKIT], [MAPKIT-SWIFTUI-REF]). `MapCameraCameraPosition.userLocation` is literally a *camera that tracks the user* — tracking is a camera position, not a flag.
- `MapCamera { distance, heading, pitch }`; `MapCameraBounds { minCenterCoordinateDistance, maxCenterCoordinateDistance }` give zoom clamping elegantly. Legacy UIKit: `MKMapCamera { centerCoordinate, heading, pitch, altitude }`, `setVisibleMapRect(_:edgePadding:animated:)` for bounds+pacing.
- `userTrackingMode`: `.none / .follow / .followWithHeading / .followWithCourse` (course = last direction of travel — very useful under tunnels) ([MAPKIT-SWIFTUI-REF], [APP-CAMERA-CONFLICT]).
- Overlays are declarative content with system-chosen renderers: `MapPolyline`, `MapPolygon`, `MapCircle` in SwiftUI `MapContentBuilder`; UIKit-era `MKOverlayRenderer` per-annotation factories. Annotations (`Marker`, `Annotation`) are content, not views.
- Region monitoring: `CLCircularRegion` (≤ 20 monitored regions per app, `notifyOnEntry/notifyOnExit`), now superseded by async `CLMonitor` + `CLServiceSession` on iOS 17/18 ([GEOFENCE-TUTORIAL], [APP-CAMERA-CONFLICT]).
- Map style configurations: `MKStandardMapConfiguration / ElevationRealistic / HybridImagery` plus POI filters — style is configuration, not code.

### A.7 Ferrostar (the closest cousin: Rust + UniFFI navigation SDK)

Architecture ([FERROSTAR-ARCH], [FERROSTAR-UNIFFI]):

- **Hexagonal layering:** a *functional core* in Rust (models, spatial algorithms, pure navigation state machine) → UniFFI bindings → imperative platform wrappers (SwiftUI / Compose + MapLibre, networking, sensors live in platform code).
- State machine is fully pure: every location update maps `NavState → NavState`:

```
NavState { tripState: TripState, stepAdvanceCondition: StepAdvanceCondition }
TripState: Idle | Navigating { remainingSteps, remainingWaypoints, snappedUserLocation,
                              progress, deviationStatus, visualInstruction, spokenInstruction } | Complete
trait StepAdvanceCondition { ... }   // DistanceToEndOfStep, DistanceFromStep, DistanceEntryAndExit,
                                     // ManualStep, Or(...) / And(...) combinators
WaypointAdvanceMode                  // waypoint completion decoupled from step advance
NavigationController::update(userIdLocation) -> NavState
```

- `StepAdvanceCondition` as an *exported trait with foreign implementations* is a masterstroke: integrators inject custom advancement rules in Kotlin/Swift without touching the core.
- UniFFI learnings documented by the maintainers ([FERROSTAR-UNIFFI]): Rust `Result` → Swift `throws` / Kotlin exceptions automatically; `with_foreign` traits enable callbacks-in; **no `&mut self` on exported objects (interior mutability required)**; proc macros are more ergonomic than UDL but UDL keeps surface parity (our locked decision) — both work; the real cost is packaging (XCFramework/SPM, Maven), not bindings.

### A.8 Offline engines: Valhalla, GraphHopper, OsmAnd

**Valhalla** ([VALL-TILES], [VALL-WHY], [VALL-EXTRACT]):

- 3-level global tile hierarchy — coarse levels only carry major roads, bounding A* memory during long queries:

| Level | Degrees | Content |
|---|---|---|
| 0 | 4.0° | motorway, trunk, primary |
| 1 | 1.0° | secondary, tertiary |
| 2 | 0.25° | unclassified, residential, service |

- `GraphId` bit-fields: 3 bits level | 22 bits tile index | 21 bits in-tile id (`/2/000/756/425.gph` file layout). Cheap O(1) address arithmetic everywhere.
- Regional extracts are packaged as a **tar archive + `index.bin`** (tile id → byte offset), i.e. a fixed-size index over an mmap-able blob — Switzerland ≈ 100 MB. `valhalla_build_extract` subsets by bbox / GeoJSON polygon / named region.
- **`traffic.tar` pattern:** a *separate* archive with fixed-size per-directed-edge traffic records, shipped/updated independently of the base graph — live traffic as an overlay keyed by GraphId, no graph rebuild.
- Costing models (auto, truck, bicycle, pedestrian, motor scooter, motorcycle, bus, taxi, transit) are pluggable edge-cost function sets over the same tiles; elevation comes from a parallel elevation tile product rather than the routing graph.
- Offline rerouting ("return to route") works because the same local tiles contain maneuver/exit metadata — richness lives *in the tiles*, not in a server.

**GraphHopper** ([GH-STORAGE]): `GraphHopperStorage` = base graph + separate CH graphs (physical separation of shortcut edges from base edges ≈ 10% less memory); storage behind a `DataAccess` abstraction with `RAMDataAccess / MMapDataAccess (mmap) / UnsafeDataAccess` implementations, selected at runtime via `DAType`; a `Directory` object owns the collection of DataAccess blobs. Per-edge "encoded values" (speed, access, surface…) are flag-packed integers — a compact property-column storage worth mirroring in our flatdata schema.

**OsmAnd** ([OSMAND-FORMAT], [OSMAND-ROUTING-XML]):

- `.obf` extracts are protobuf-based, **sectioned (map / routing / address / POI / transport) with spatial-tree indexes**, so a device reads only needed tiles.
- The standout idea: **`routing.xml` contains 100% of profile definition** — zero hardcoded routing constants. Seven penalty groups (access, speed, priority, oneway, road-class transition penalties, obstacle, obstacle_time); tags referenced as `$maxheight`; user parameters as `:height`. Tuning a profile = editing data, not code; profiles are even user-customizable.
- Engine: bidirectional A* plus a precomputed Highway-Hierarchy layer for long distances; incremental hourly diffs (OsmAnd Live) patch the base extract.

---

## Part B — Gaps & opportunities for maps-sdk-rs

Mapping each borrowed pattern onto the crates of `PRD.md` §3. Items marked **P1/P2/P3** = adopt before UniFFI binding milestone / during navigation milestone / later phases.

### B.1 `map-rendering`

| # | Item | Inspiration | Notes |
|---|---|---|---|
| P1 | Add **snapshot rendering + an `idle` render-state signal** (all pending tiles done, no animation running) | GLJS `idle` event; MapLibre `snapshotSync` | Makes Playwright *and* native golden-image tests deterministic; cheap: tile-scheduler already knows pending counts |
| P1 | **EdgeInsets as a first-class camera property** + `fit_bounds(bounds, padding, max_zoom)` with a clamped zoom | Mapbox `CameraOptions.padding`, GLJS `fitBounds` | Our camera already has padding fields; expose bounds-fitting math + clamp, and honor padding in frustum tile listing |
| P1 | Fly-to **zoom interpolation curve** (exponential along a virtual great-circle path) as a standard animation | GLJS `flyTo(curve)` | Long route-preview jumps feel wrong with linear easing |
| P2 | **Viewport state machine**: `Idle / FollowPuck / Overview` states with transition animations, each state carrying *optional* (zoom, bearing, pitch, padding, focal point) | Mapbox `ViewportPlugin`, Nav `NavigationCamera` | This is the single biggest UX-quality borrow for navigation; camera animators should be *cancelable* (AnimatorListener pattern) |
| P2 | Named **overlay layer ordering constants** (route pipeline inserted below a future label layer) and a `vanishing_route_line` progress input | Mapbox `routeLineBelowLayerId`, `updateTraveledRouteLine` | Raster phase: route polyline pipeline needs an explicit z-order vocabulary; vanishing line = trim by progress fraction |
| P3 | Bounded **view-annotation surface** (counts < 100, priority/allow-overlap flags, sync modes) exposed per platform wrapper | Mapbox `ViewAnnotationManager` | Own the contract in `map-native-core`; platform hosts their real views |
| P3 | Immutable-snapshot + diff ingestion for the future style/layer system (Arc-swap snapshots; renderer diffs by pointer identity) | MapLibre `Immutable<T>` + snapshot diffing | Maps 1:1 to Rust `Arc<Layer>` handles; free cross-fades in vector phase |

### B.2 `map-navigation`

| # | Item | Inspiration | Notes |
|---|---|---|---|
| P1 | Refactor the state machine toward **pure `NavState → NavState`** with `TripState` carrying snapped location, progress, deviation status, current visual+spoken instruction | Ferrostar | PRD already says ferrostar-inspired; make state construction pure and testable with recorded location streams |
| P1 | **`StepAdvanceCondition` trait + combinators** (distance-from-step-end, distance-from-step-start, entry-and-exit, manual, or/and) and separate `WaypointAdvanceMode` | Ferrostar | Export over UniFFI as `with_foreign`-style hook or enum-with-params (see FFI section) |
| P1 | Observer set split by topic: route progress, routes changed, off-route **state change** (boolean), reroute lifecycle (fetched/interrupted/error), voice instructions, banner/maneuver instructions, arrival | Mapbox observers | One listener per concern on the navigation session object |
| P2 | **Voice instruction model**: ordered per-step spoken instructions each carrying *distance before the maneuver + text (+ optional SSML)*, plus an explicit **online TTS → platform TTS fallback chain**; SDK returns strings/files, platforms own playback | Mapbox `VoiceInstruction { ssmlAnnouncement, announcement, distanceAlongGeometry }`, `MapboxSpeechApi` | Matches PRD's "SDK emits TTS strings" rule; add the distance-along-geometry field now — it defines *when* to speak |
| P2 | **Reroute controller lifecycle** decoupled from detection: off-route threshold triggers state change; a separate controller fetches (online first, offline graph fallback), reports lifecycle, and can be disabled for integrator-supplied routes | Mapbox `RerouteController`/`RerouteStateObserver` | PRD's online→offline degradation falls out naturally |
| P2 | **Route refresh** (periodic same-geometry traffic/duration update, opt-in, e.g. default 5 min) distinct from full reroute | Mapbox `RouteRefreshOptions` | Requires `RoutingProvider` to support refresh-by-route-token or re-request with same waypoints; keep traffic-aware durations on the existing shape |
| P2 | **Alternative-routes tracking**: invalidate alternatives at fork points, re-request on interval | Mapbox `RouteAlternativesOptions` | Only viable once provider trait returns alternatives; design space in `RouteData` |
| P2 | **`RemainingTimeOrDistanceChangedListener`-style threshold**: emit progress events only when Δt > s or Δd > m (configurable) | Google `RemainingTimeOrDistanceChangedListener` | Cuts FFI callback spam and battery cost |
| P2 | **Guidance mode enum**（alerts-only / alerts+guidance / mute) instead of per-instruction toggles | Google `AudioGuidanceSettings` | Maps to platform volume/vibration routing |
| P3 | **Speed alerts** (minor/major speed thresholds + speeding listener) | Google `SpeedAlertOptions` | Needs posted speed limits in route data or graph |

### B.3 `map-offline-graph-compiler`

| # | Item | Inspiration | Notes |
|---|---|---|---|
| P2 | Adopt a **multi-level tile hierarchy** (e.g. 4° / 1° / 0.25° levels holding major/arterial/local road classes) with bit-packed ids into the flatdata schema | Valhalla | Bounds A* memory for long-distance offline queries on phones; our single-level design will degrade on country-scale extracts |
| P2 | Package extracts as **tar-like blob + fixed-size index (tile id → offset)** to keep mmap single-file simplicity | Valhalla `index.bin` | Check against the alignment-bounds-validation safety story in FR-F |
| P3 | Move routing profile constants into a **data-driven profile config** (penalty groups: access, speed, priority, oneway, road-class transition, obstacle) compiled against tag mappings — no hardcoded penalties | OsmAnd `routing.xml` | Keeps "custom flatdata graph, richness grows incrementally" decision intact while making tuning a data edit |
| P3 | Reserve a **fixed-size per-edge traffic overlay** (separate file keyed by edge id) for future live traffic without graph rebuilds | Valhalla `traffic.tar` | Tiny schema addition now, big later |
| P3 | Store per-edge **encoded value columns** (speed, access, surface, class) as packed integers | GraphHopper encoded values | Fits flatdata's array-of-structs; keeps routing hot path branch-free |

### B.4 `map-core` / `map-cache`

| # | Item | Inspiration | Notes |
|---|---|---|---|
| P1 | Present **one cache store to map tiles and routing tiles** (single disk account, single quota, shared eviction) | Mapbox shared `TileStore` | `map-cache` should expose an API used by both the tile scheduler and (later) navigation prefetch |
| P2 | **Predictive/pre-fetch along navigation**: cache tiles ahead along the active route within configurable radii (location radius, route buffer radius, destination radius) | Mapbox `PredictiveCacheController` | Reuse the tile scheduler's fetch budget machinery for prefetch instead of a parallel system |
| P2 | Progress-reporting **tile region downloads** (tile counts + bytes seen by the caller, pause/resume), matching the planned `TilePackManager` FR-F shape | Mapbox `TileRegion`/`OfflineRegionStatus`, MapLibre `OfflineRegionObserver` | Our SQLite store already gives byte counts cheaply |

### B.5 `geospatial-traits`

| # | Item | Inspiration | Notes |
|---|---|---|---|
| P1 | `RouteOptions` gains an explicit **route strategy** field (default/fastest/shortest) applied to initial routing *and* rerouting | Google `RoutingStrategy` | PRD's `AvoidFlags` etc. stay; add strategy enum |
| P2 | Route model carries what the renderer needs for route-line + progress: per-step distances/geometry slice metadata (progress-fraction friendly), and per-step **voice instruction list with distances** | Mapbox route line + voice model | Prevents a breaking record change after UniFFI M4 ships |
| P3 | Future `TrafficFlowProvider` shape to align with a **per-edge overlay** consumption model | Valhalla traffic overlay | Traffic traits exist; think about feeding an index overlay rather than free-form speeds |

---

## Part C — Cross-cutting FFI design lessons for the UniFFI UDL contract

Grounded in the UniFFI internals docs ([UNIFFI-ASYNC-FFI], [UNIFFI-ASYNC-OV], [UNIFFI-FUTURES], [UNIFFI-FOREIGN]) and ferrostar's production experience ([FERROSTAR-UNIFFI]).

1. **Async: Rust-promise surface, callbacks stay synchronous.** UniFFI async methods compile to `rust_future_poll/complete/free` machinery; Kotlin gets `suspend`, Swift gets `async`, JS gets Promises, with no runtime required in Rust ([UNIFFI-ASYNC-OV]). Rule: mark provider-driven and offline-routing methods `async` in UDL; keep **callback-interface methods synchronous** (location samples, listeners). Foreign→Rust *async* callbacks bring a 3-extra-arg completion protocol and dropped-callback plumbing that ubrn and hand-written TS mirroring would have to replicate — avoid entirely ([UNIFFI-ASYNC-FFI]).
2. **No built-in cancellation — design it in.** `rust_future_cancel` exists but user-level cancellation must be an explicit API ([UNIFFI-FUTURES]). Recommendation: long-running objects get `cancel()` methods (`RouteSession.cancel()`, tile region download `pause()/resume()`), and cancel surfaces as a dedicated error variant, mirroring Mapbox's reroute lifecycle.
3. **Errors: flat, well-named enums per crate; no panics across the boundary.** Rust `Result` maps to Swift `throws` / Kotlin exceptions automatically; *unexpected* errors (panics) surface only if converted, otherwise generated code panics ([UNIFFI-FOREIGN]). Recommendations: one error enum per crate in `geospatial-types`/crate-local definitions; every exported method returns `Result<T, ThatCrateError>`; keep `catch_unwind` at object-construction and method dispatch edges (already in NFR reliability); give every variant a stable discriminant name — UDL enums are flat, so map nested Rust errors to a `reason` string field or flatten deliberately.
4. **Object model:** exported `Object`s are opaque handles on an `Arc`; **no `&mut self`** — wrap interior state (`Mutex`/atomics) inside objects (`NavigationController`, `TilePackManager`) because foreign callers can invoke from any thread ([FERROSTAR-UNIFFI]). Document thread affinity per object: render-view objects are documented main-thread-affine; engine internals keep their own dedicated threads following the MapLibre main/worker/filesource split.
5. **Listeners: small per-topic callback interfaces, not god-delegates.** Mapbox's split observers translate cleanly into UDL `callback interface`s. Deliver *immutable snapshot records* (progress, `NavState`, camera change reasons) — never live objects — and document that callbacks arrive on the caller's thread; platform glue wraps main-thread dispatch (MapLibre's rule: main thread never blocks, everything is async-callback).
6. **`with_foreign` traits vs UDL callback interfaces.** UniFFI soft-deprecates bare callback interfaces in favor of `#[uniffi::export(with_foreign)]` traits ([UNIFFI-FOREIGN]); under the locked UDL-first decision, stay with UDL `callback interface` — it remains supported, keeps UDL the single source of truth, and ubrn consumes the same file. Reserve `with_foreign` for Rust-core-internal flexibility (e.g. `StepAdvanceCondition`) only if a gap appears; be aware Rust↔foreign object cycles leak ([UNIFFI-FOREIGN]).
7. **Versioning and integrity:** expose `get_sdk_compiled_version()` (crate version + git hash) and a graph/archive `validate()` entry point so corrupt offline packages fail as typed `OfflineGraphInvalid`, never UB (PRD FR-F/FR-H).
8. **Snapshot the wasm contract from the same shapes:** the hand-checked TS surface should be generated *from* the UDL (records/enums/objects, identical names), with the contract-test asserting sync (PRD FR-G) — ferrostar proves the value-type-heavy surface survives all four targets when it stays record/enum based ([FERROSTAR-ARCH]).

---

## Part D — Top takeaways (one-screen summary)

1. **Camera padding is a camera property; bounds-fitting with clamp is core math** — expose `fit_bounds(bounds, padding, max_zoom)` and EdgeInsets everywhere before the UniFFI milestone.
2. **The viewport state machine (Idle / FollowPuck / Overview)** is the single pattern that makes navigation camera UX clean; adopt in `map-rendering` before `map-navigation` builds on it.
3. **Pure navigation state machine with pluggable step-advance conditions** (ferrostar) plus Mapbox's split observer set — do both in `map-navigation` now, before the UDL freezes them.
4. **Voice instructions need distance-triggered, ordered structured data + an online→platform-TTS fallback chain**, decided now to avoid record churn.
5. **A multi-level offline tile hierarchy + tar/index packaging + data-driven profile config** (Valhalla, OsmAnd) are the three structural upgrades for `map-offline-graph-compiler`.
6. **The `idle` event + `snapshot()`** make render tests deterministic on every platform.
7. **UniFFI:** async methods for I/O, sync callbacks, explicit `cancel()` methods, flat error enums, small per-topic listener interfaces, no `&mut self` objects.

---

## Sources

- [MAPLIBRE-NATIVE-ARCH] MapLibre Native ARCHITECTURE.md: https://github.com/maplibre/maplibre-native/blob/main/ARCHITECTURE.md
- [MAPLIBRE-NATIVE-ANDROID-CAMERA] MapLibre Android API (MapLibreMap / OfflineManager): https://maplibre.org/maplibre-native/android/api/
- [MAPLIBRE-OFFLINE] Mapbox GL offline region lifecycle (inherited by MapLibre), e.g. OfflineManager/OfflineRegionStatus in mapbox-gl-native: https://github.com/mapbox/mapbox-gl-native and CameraListener/RegionDidChange behavior: https://github.com/mapbox/mapbox-gl-native/issues/7782
- [FLUTTER-BINDING-SOURCE] flutter-maplibre-gl jumpTo/flyTo mapping: https://github.com/maplibre/flutter-maplibre-gl
- [GLJS-CAMERA] MapLibre GL JS Map camera docs (jumpTo/easeTo/flyTo/fitBounds/renderWorldCopies/idle): https://maplibre.org/maplibre-gl-js/docs/API/
- [MBX-VIEWPORT] Mapbox FollowPuckViewportStateOptions: https://docs.mapbox.com/android/maps/api/latest/mapbox-maps-android/com.mapbox.maps.plugin.viewport.data/-follow-puck-viewport-state-options/
- [MBX-NAV-CAMERA] Mapbox Navigation camera guide (NavigationCamera, padding, FocalPoint): https://docs.mapbox.com/android/navigation/guides/ui-components/camera/
- [MBX-LOCATION] Mapbox user location guide (LocationPuck2D/3D): https://docs.mapbox.com/android/maps/guides/user-location/location-on-map/
- [MBX-GESTURES] Mapbox gestures (viewport interaction, gesture handlers): https://docs.mapbox.com/android/maps/guides/user-interaction/gestures/
- [MBX-DATA] Mapbox "Add your data to the map" decision matrix: https://docs.mapbox.com/android/maps/guides/add-your-data/
- [MBX-VIEWANNOT] Mapbox ViewAnnotationManager guide: https://docs.mapbox.com/android/maps/guides/add-your-data/view-annotations/ and API: https://docs.mapbox.com/android/maps/api/latest/mapbox-maps-android/com.mapbox.maps.viewannotation/-view-annotation-manager/
- [MBX-OFFLINE] Mapbox offline (shared TileStore, style packs, tile regions, predictive caches): https://docs.mapbox.com/android/maps/guides/offline/ and https://docs.mapbox.com/android/navigation/guides/advanced/offline/
- [MBX-NAV-REROUTE] Mapbox off-route detection & rerouting guide: https://docs.mapbox.com/android/navigation/guides/turn-by-turn-navigation/rerouting-and-refresh.md
- [MBX-NAV-TBT] Mapbox complete turn-by-turn example (SpeechApi, VoiceInstructionsPlayer): https://docs.mapbox.com/android/navigation/examples/turn-by-turn-experience/
- [MBX-ROUTE-LINE] Mapbox route line guide (MapboxRouteLineApi, vanishing line, routeLineBelowLayerId): https://docs.mapbox.com/android/navigation/guides/ui-components/route-line/
- [GOOG-CAMERA] Google Maps Android SDK camera (CameraPosition, CameraUpdateFactory, padding, listeners): https://developers.google.com/maps/documentation/android-sdk/camera
- [GOOG-NAV-INTRO] Google Navigation SDK navigation experience: https://developers.google.com/maps/documentation/navigation/android-sdk/intro-google-nav
- [GOOG-NAV-NAVIGATOR] Google Navigator API (listeners, ReroutingListener, TrafficUpdatedListener, RemainingTimeOrDistanceChangedListener): https://developers.google.com/maps/documentation/navigation/android-sdk/reference/com/google/android/libraries/navigation/Navigator
- [SWIFTUI-MAPKIT] MapKit + SwiftUI camera positions and interaction modes: https://swiftprogramming.com/mapkit-swiftui/
- [MAPKIT-SWIFTUI-REF] _MapKit_SwiftUI API reference (MapCameraPosition, MapCameraBounds, UserAnnotation): https://onestack.dev/ios-reference/_MapKit_SwiftUI
- [APP-CAMERA-CONFLICT] MKCamera vs userTrackingMode conflict: https://stackoverflow.com/questions/36589837/
- [GEOFENCE-TUTORIAL] CLCircularRegion region monitoring limits and CLMonitor: https://www.appcoda.com/geo-targeting-ios/
- [FERROSTAR-ARCH] Ferrostar architecture overview: https://stadiamaps.github.io/ferrostar/architecture.html
- [FERROSTAR-UNIFFI] Cross-platform nav SDK in Rust with UniFFI (Stadia Maps): https://stadiamaps.com/blog/ferrostar-building-a-cross-platform-navigation-sdk-in-rust-part-1/
- [FERROSTAR-STATE] Ferrostar navigation controller models: https://docs.rs/ferrostar/latest/src/ferrostar/navigation_controller/models.rs.html
- [VALL-TILES] Valhalla tile structure (levels, GraphId): https://valhalla.github.io/valhalla/concepts/tiles/
- [VALL-WHY] Valhalla why-tiles (offline extracts, rerouting, THOR): https://valhalla.github.io/valhalla/concepts/why-tiles/
- [VALL-EXTRACT] valhalla_build_extract (tar + index.bin, traffic.tar): https://github.com/valhalla/valhalla/blob/master/scripts/valhalla_build_extract
- [GH-STORAGE] GraphHopper storage (GraphHopperStorage / CHGraph / DataAccess / MMapDataAccess): https://github.com/graphhopper/graphhopper/pull/447 and https://javadoc.io/static/com.graphhopper/graphhopper-core/0.10.alpha3795/com/graphhopper/storage/package-summary.html
- [OSMAND-FORMAT] OsmAnd file formats (OBF sections, protobuf, spatial indexes): https://osmand.net/docs/technical/osmand-file-formats/
- [OSMAND-ROUTING-XML] OsmAnd routing.xml (data-driven profiles, penalty groups): https://github.com/osmandapp/OsmAnd-resources/blob/master/routing/routing.xml and https://github.com/osmandapp/web/blob/e6c663b1/main/docs/technical/build-osmand/routing.md
- [UNIFFI-ASYNC-FFI] UniFFI async FFI details: https://mozilla.github.io/uniffi-rs/latest/internals/async-ffi.html
- [UNIFFI-ASYNC-OV] UniFFI async overview: https://mozilla.github.io/uniffi-rs/latest/internals/async-overview.html
- [UNIFFI-FUTURES] UniFFI async/future support: https://mozilla.github.io/uniffi-rs/latest/futures.html
- [UNIFFI-FOREIGN] UniFFI foreign traits & error model: https://mozilla.github.io/uniffi-rs/latest/foreign_traits.html