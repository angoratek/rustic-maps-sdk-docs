# Text-rendering quality: why the vector-base labels read as fog

Date: 2026-10-31. Scope: the glyph path of `map-glyphs` / `map-rendering`, the wasm
canvas in `map-web-bindings`, and the browser demo in `platform/web`.

This is a source-grounded study of MapLibre Native, MapLibre GL JS, Mapbox GL JS,
node-fontnik, Navara and maplibre-rs, compared against our pipeline. It ends with
a ranked cause list, a concrete shader/constant proposal, and a test strategy.
No file other than this one was modified.

## TL;DR

Three independent defects compound in the live demo:

1. The WebGPU canvas backing store is sized in **CSS pixels** (`innerWidth x
   innerHeight`), while its CSS box is `100vw x 100vh`. On a Retina display the
   compositor upscales the whole frame 2x, so every glyph edge is bilinearly
   smeared. This is the dominant cause and is independent of the shader.
2. The halo pass thresholds at **0.32**, which is *outside* the distance range the
   glyph protocol actually stores (its 3-pixel border bottoms out near
   `0.372`). Combined with inflating the halo quad by `halo_width` and clamping
   the sampler at the bitmap edge, the halo becomes a solid white bloom roughly
   `text_size/8 + halo_width` CSS pixels wide (about 2.7-3.8 px around 10-18 px
   labels) instead of a `halo_width`-wide outline.
3. The text threshold is **0.5**, but the protocol's zero-distance contour is
   **0.75**. Every glyph is therefore dilated by `(0.75 - 0.5) * 8 = 2` atlas
   pixels, which is `text_size/12` CSS pixels per side (1.0 px at 12 px, 1.5 px
   at 18 px). Counters close and stems merge with the halo.

The fixes are: size the backing store in device pixels while keeping layout in
CSS pixels; set the text edge to 0.75; replace the fixed ±0.05 smoothing band with
MapLibre's DPR- and font-scale-derived gamma; and derive the halo threshold from
the halo width with the same formula MapLibre uses, without inflating the quad.

## 0. What our pipeline does today

### 0.1 Decode and atlas

- The Mapbox glyph PBF reader assumes a 3-pixel SDF border on each side
  (`crates/map-glyphs/src/glyph.rs:23-29`):
  `pub const GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS: u32 = 3;`.
- The packer copies each padded bitmap into an `R8Unorm` page, one byte per pixel,
  zero-filled background (`crates/map-glyphs/src/atlas.rs:241-271`, `:308-339`).
  The default page is 1024x1024 (`atlas.rs:24-27`) and the inter-glyph packing
  padding is **1 pixel** (`atlas.rs:39`), in addition to each bitmap's own 3-pixel
  SDF border.
- The committed fixture is a real OpenFreeMap `Noto Sans Regular` `0-255` range,
  rasterized by the protocol at a 24-pixel em with a 3-pixel border
  (`crates/map-rendering/fixtures/render/glyphs/README.md`).

### 0.2 The atlas texture and sampler

Both renderers upload a single-mip `R8Unorm` texture and sample it with a
linear, clamp-to-edge sampler:

- wasm: `mip_level_count: 1` and `GLYPH_ATLAS_TEXTURE_FORMAT` at
  `crates/map-web-bindings/src/canvas.rs:855-885`; the sampler at `:2881-2894`.
- native surface path: `mip_level_count: 1` at `crates/map-rendering/src/surface.rs:1174-1177`;
  the sampler at `:1673-1690`.
- headless: `GLYPH_ATLAS_TEXTURE_FILTER = Linear` (`headless.rs:170-178`) and the
  sampler at `:700-711`.

`mipmap_filter: Nearest` is a no-op with a single mip level; there is no mip
chain anywhere in the glyph path. The filtering decision therefore matches
MapLibre (linear mag/min, clamp, no mips), which is fine: the problem is not
the filter, it is the sampling rate and the field thresholds.

### 0.3 The shader and its thresholds

The shader is duplicated almost verbatim in two places (the native source is
re-used by `surface.rs`, the wasm source is an independent copy):

- `crates/map-rendering/src/headless.rs:184-226` (used by `surface.rs:1560-1571`)
- `crates/map-web-bindings/src/canvas.rs:551-598`

```wgsl
const GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING: f32 = 0.05;
...
let signed_distance = textureSample(glyph_atlas, glyph_sampler, vertex.texture_coordinates).r;
let coverage = smoothstep(
    vertex.signed_distance_threshold - GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING,
    vertex.signed_distance_threshold + GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING,
    signed_distance);
return vec4<f32>(vertex.rgba_color.rgb, vertex.rgba_color.a * coverage);
```

The per-vertex threshold is produced in
`crates/map-rendering/src/labels.rs`:

```rust
pub const GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD: f32 = 0.5;
pub const GLYPH_HALO_SIGNED_DISTANCE_THRESHOLD: f32 = 0.32;
```

The text quad is the glyph's bitmap rectangle. The halo quad is the same
rectangle **inflated by `halo_width_pixels` while keeping the same texture
window** (`labels.rs:499-509`, `:553-583`). The doc comment states the intent:
"which stretches the bitmap's soft edge outward; the fragment stage's lower
halo threshold turns that stretched edge into the outline"
(`labels.rs:502-505`). The implementation, however, does not merely stretch a
soft edge: at threshold 0.32 the border texels are already above the threshold,
so the inflation paints solid coverage (see 1.4).

### 0.4 Label sizes and colors

At the demo zoom (14) the Bright style declares (`crates/map-rendering/fixtures/render/vector-style-bright-light.json:36-43`):

- place labels: 13 px, halo 1.5 px, text `[0.196, 0.196, 0.196, 1]`, halo white `[1, 1, 1, 1]`;
- POI labels: 10 px, halo 1.5 px, text `[0.349, 0.349, 0.349, 1]`;
- road names: 10-14 px, halo 1.3 px, text `[0.286, 0.278, 0.271, 1]`.

All style colors have alpha 1.0, so translucency is not the cause. The sizes are
10-18 CSS px, well under the atlas' 24-pixel em; the scale is `size / 24`
(`labels.rs:265`, `:545`).

### 0.5 The browser canvas

`platform/web/playground.mjs:3386-3389`:

```js
function resize_canvases() {
  map_canvas.width = window.innerWidth; map_canvas.height = window.innerHeight;
  overlay_canvas.width = window.innerWidth; overlay_canvas.height = window.innerHeight;
}
```

`platform/web/styles/playground.css:116` gives the canvas `width: 100vw; height: 100vh`.
The backing store and the CSS box are therefore both in CSS pixels. The device
pixel ratio is only consulted to pick the `@2x` tile fixtures
(`playground.mjs:3402-3420`), so the tile imagery is fetched at 2x but the frame
it is drawn into is 1x and then upscaled by the compositor.

`renderFrame` reads the backing store as the viewport
(`crates/map-web-bindings/src/canvas.rs:1554-1557`), and the surface is configured
at that extent (`:2419-2489`), so nothing downstream knows about DPR either.

The Playwright suite runs at `deviceScaleFactor: 1`
(`platform/web/playwright.config.mjs:37-38`), and the one retina test only checks
that `@2x` tile URLs are fetched and that `window.devicePixelRatio` is 2
(`platform/web/tests/sdk_core.spec.mjs:571-584`, `:615-617`). No automated test
ever renders text at device resolution, which is why the defect shipped.

## 1. The glyph protocol: fontnik, SDF_PX and the 0.75 edge

### 1.1 The generator

node-fontnik is the canonical generator of Mapbox glyph PBFs. Its range writer
calls (`src/glyphs.cpp`, the `AsyncRange` path; [source](https://github.com/mapbox/node-fontnik/blob/master/src/glyphs.cpp)):

```cpp
sdf_glyph_foundry::RenderSDF(glyph, 24, 3, 0.25, ft_face);
```

so: **font size 24 px, buffer 3 px, cutoff 0.25**. `RenderSDF` is implemented in
`include/mapbox/glyph_foundry_impl.hpp`
([source](https://github.com/mapbox/node-fontnik/blob/master/include/mapbox/glyph_foundry_impl.hpp)).
The relevant loop (lines 333-387) is:

```cpp
float offset = 0.5;
int radius = 8;
int radius_by_256 = (256 / radius);       // 32
...
double d = MinDistanceToLineSegment(tree, pt, radius) * radius_by_256;
const bool inside = PolyContainsPoint(user.rings, pt);
if (inside) { d = -d; }
d += cutoff * 256;                        // + 64
int n = (int)(std::min(std::max(d, 0.0), 255.0));
glyph.bitmap[i] = (char)(255 - n);
```

### 1.2 The exact encoding

With `distance_px` positive outside the outline:

```
value = 255 - clamp(32 * distance_px + 64, 0, 255)      (0..255, then /255)
      = 191/255 - distance_px/8                          while 0 <= distance_px <= 3
```

Consequences a consumer must assume:

- **The zero-distance contour is `191/255 = 0.74902`**, which MapLibre rounds to
  `(256 - 64)/256 = 0.75`.
- **One field unit = 8 pixels**; one pixel = `32/255 = 0.12549` field units. This
  is what `SDF_PX` means: not the em, not the texture size, but the linear scale
  between signed distance in font pixels and the normalised byte. fontnik's
  `radius = 8` and the shader's `#define SDF_PX 8.0` are the same number.
- **Only 3 pixels of exterior distance are stored** (the border). The largest
  outside distance inside a bitmap is about 3 px on a straight edge and about 4-5
  px diagonally at a corner.
- **The interior saturates 2 pixels inside the edge** (the cutoff only leaves 64
  units = 2 px of negative space). A stem narrower than 4 px never reaches 1.0.
- Values are clamped, so `1.0` does not mean "very inside", and `0.0` does not
  mean "very outside".

The proto documents only the 3-pixel border
([glyphs.proto](https://github.com/mapbox/fontnik/blob/master/proto/glyphs.proto)):

```proto
// A signed distance field of the glyph with a border of 3 pixels.
optional bytes bitmap = 2;
```

The pure-JS fontnik (used for sprites) implements the same mapping with the same
`radius = 8`, `offset = 0.5`, `cutoff * 256` shift and `255 - d`
([lib/sdf.js](https://github.com/mapbox/fontnik/blob/master/lib/sdf.js)).

### 1.3 Verification against our committed fixture

Decoding `crates/map-rendering/fixtures/render/glyphs/noto_sans_regular_0-255.pbf`
and reading glyph `H` (13x17 ink box, 19x23 padded bitmap):

```
middle row:  [101, 133, 165, 197, 227, 207, 207, ..., 209, 221, 189, 157, 125]
```

The ramp steps by 32 per pixel (0.125 per pixel), the edge crossing 191 lies
between 165 (0.81 px outside) and 197 (0.19 px inside), and the interior maximum
is 227 (`0.89`) because the stems are only about 2 px from edge to edge at the
24 px em. The bitmap's straight-edge border values are 95-101 (`0.37-0.40`).
The fixture therefore matches fontnik's encoding exactly.

### 1.4 What our thresholds mean in this encoding

For a label rendered at `T` CSS px, let `f = T / 24`:

```
threshold t  ->  distance_atlas_px = (0.75 - t) * 8
             ->  distance_css_px  = (0.75 - t) * 8 * f
```

| t | atlas px outside edge | CSS px at T=12 | CSS px at T=18 | within the 3 px buffer? |
|---|---|---|---|---|
| 0.75 (protocol edge) | 0 | 0 | 0 | yes |
| 0.50 (our text) | 2.00 | 1.00 | 1.50 | yes |
| 0.32 (our halo) | 3.44 | 1.72 | 2.58 | **no** (the buffer is 3 atlas px) |

The last row is the key: the threshold asks for 3.44 atlas px of exterior distance,
but the maximum *stored* outward distance is 3 atlas px, whose value is
`0.75 - 3/8 = 0.375`. A threshold of 0.32 is below every border
value on a straight edge, so `smoothstep(0.27, 0.37, value)` evaluates to
approximately 1.0 across the whole border ring. In addition, the halo quad is
inflated by `halo_width_pixels`, and the sampler is `ClampToEdge`, which repeats
the outermost border value (about 0.37-0.40) into the inflated ring. The halo
paint therefore reaches

```
T/8 + halo_width_css   CSS pixels beyond the ink edge
```

which is 2.75-3.13 px for the 10-14 px demo labels with 1.3-1.5 px halos, and it
ends at the inflated quad boundary with near-full alpha. The visual result is a
solid white glow that merges between adjacent glyphs: "fog".

## 2. MapLibre Native and MapLibre / Mapbox GL JS

### 2.1 The fragment shader (MapLibre Native, GLSL)

Source: `shaders/symbol_sdf.fragment.glsl`
([link](https://github.com/maplibre/maplibre-native/blob/main/shaders/symbol_sdf.fragment.glsl)).
The whole relevant block, verbatim:

```glsl
#define SDF_PX 8.0
...
float EDGE_GAMMA = 0.105 / DEVICE_PIXEL_RATIO;
...
float fontScale = u_is_text ? size / 24.0 : size;

lowp vec4 color = fill_color;
highp float gamma = EDGE_GAMMA / (fontScale * u_gamma_scale);
lowp float inner_edge = (256.0 - 64.0) / 256.0;
if (u_is_halo) {
    color = halo_color;
    gamma = (halo_blur * 1.19 / SDF_PX + EDGE_GAMMA) / (fontScale * u_gamma_scale);
    inner_edge = inner_edge + gamma * gamma_scale;
}

lowp float dist = texture(u_texture, tex).a;
highp float gamma_scaled = gamma * gamma_scale;
highp float alpha = smoothstep(inner_edge - gamma_scaled, inner_edge + gamma_scaled, dist);
if (u_is_halo) {
    // When drawing halos, we want the inside of the halo to be transparent as well
    // in case the text fill is transparent.
    lowp float halo_edge = (6.0 - halo_width / fontScale) / SDF_PX;
    alpha = min(smoothstep(halo_edge - gamma_scaled, halo_edge + gamma_scaled, dist), 1.0 - alpha);
}

fragColor = color * (alpha * opacity * fade_opacity);
```

Meaning of each term:

- `SDF_PX = 8.0` is the protocol's spread (`radius` in fontnik), used only in the
  halo formulas: `1/SDF_PX` converts atlas pixels to normalised field units.
- `fontScale = size / 24.0` converts the style's text size into the atlas' em
  scale. It is also used in the vertex shader to place quads
  (`a_offset / 32.0 * fontScale`, see the vertex source below).
- `inner_edge = (256 - 64)/256 = 0.75` is the protocol's zero-distance contour.
  This is the constant our code gets wrong.
- `gamma = EDGE_GAMMA / (fontScale * u_gamma_scale)`: the half-width of the
  smoothstep band, in normalised field units. `EDGE_GAMMA = 0.105 / DPR`, so
  `gamma` corresponds to `0.105 * 8 / (DPR * fontScale) = 0.84 / (DPR * fontScale)`
  atlas px, `0.84 / DPR` CSS px and **0.84 device px**. The half-band is therefore
  0.84 device pixels regardless of DPR or text size; the full transition is 1.68
  device px.
- `gamma_scale` is the clip-space `w` of the label vertex (`gl_Position.w`),
  compensating labels that are perspective-scaled; for our screen-space quads it
  is 1.
- Halo: `halo_edge = (6 - halo_width/fontScale)/8 = 0.75 - (halo_width/fontScale)/8`.
  Since `1/8` field units is one atlas px, `halo_width/fontScale` is exactly the
  halo width in **atlas px**, and the resulting distance in CSS px is exactly
  `halo_width`. The halo quad is *not* inflated; only the threshold moves.
- The halo's inner edge is shifted by `gamma * gamma_scale` and the result is
  `min(..., 1 - alpha)` so the halo never paints over the text's own antialiased
  body; this matters when the fill is translucent.
- Output is premultiplied (`color * alpha`), unlike our straight-alpha shader;
  either convention is fine as long as the blend state matches.

The `DEVICE_PIXEL_RATIO` define is injected at program build time from the
renderer's pixel ratio
([program_parameters.cpp](https://github.com/maplibre/maplibre-native/blob/main/src/mln/shaders/program_parameters.cpp)).

### 2.2 The vertex shader

Source: `shaders/symbol_sdf.vertex.glsl`
([link](https://github.com/maplibre/maplibre-native/blob/main/shaders/symbol_sdf.vertex.glsl)).
Key lines:

```glsl
float fontScale = u_is_text_prop ? size / 24.0 : size;
...
gl_Position = u_coord_matrix * vec4(projected_pos.xy / projected_pos.w + rotation_matrix * (a_offset / 32.0 * fontScale + a_pxoffset), 0.0, 1.0);
float gamma_scale = gl_Position.w;
...
v_data1 = vec3(gamma_scale, size, interpolated_fade_opacity);
```

So the same `size / 24` scales the glyph bearing offsets (`a_offset / 32`
because the offsets are stored in 1/32 px units) and the coverage gamma. Our
geometry already does the former (`labels.rs:545-565`); it does not do the
latter.

### 2.3 The WebGPU (WGSL) variant

MapLibre Native's WebGPU backend states the same math in WGSL, which makes the
port mechanical
([webgpu/symbol.hpp](https://github.com/maplibre/maplibre-native/blob/main/include/mln/shaders/webgpu/symbol.hpp),
[webgpu/common.hpp](https://github.com/maplibre/maplibre-native/blob/main/include/mln/shaders/webgpu/common.hpp)):

```wgsl
const SDF_PX: f32 = 8.0;
...
let EDGE_GAMMA = 0.105 / paintParams.pixel_ratio;
let fontGamma = in.fontScale * tileProps.gamma_scale;
let gamma = (select(0.0, halo_blur * 1.19 / SDF_PX, tileProps.is_halo != 0u) + EDGE_GAMMA) / fontGamma;
let gamma_scaled = gamma * in.gamma_scale;
var inner_edge = (256.0 - 64.0) / 256.0;
if (tileProps.is_halo != 0u) {
    inner_edge = inner_edge + gamma_scaled;
}
let sample = textureSample(glyph_atlas, texture_sampler, in.tex);
let dist = select(sample.a, sample.r, tileProps.is_text != 0u);
var alpha = smoothstep(inner_edge - gamma_scaled, inner_edge + gamma_scaled, dist);
if (tileProps.is_halo != 0u) {
    let halo_edge = (6.0 - halo_width / in.fontScale) / SDF_PX;
    alpha = min(smoothstep(halo_edge - gamma_scaled, halo_edge + gamma_scaled, dist), 1.0 - alpha);
}
let coverage = alpha * opacity * in.fade_opacity;
let outAlpha = color.a * coverage;
return vec4<f32>(color.rgb * coverage, outAlpha);
```

This is the closest reference for our shader: WGSL, one texture, per-vertex
`fontScale`, uniform pixel ratio.

### 2.4 MapLibre GL JS / Mapbox GL JS

MapLibre GL JS's `symbol_text_and_icon.fragment.glsl`
([link](https://github.com/maplibre/maplibre-gl-js/blob/main/src/shaders/glsl/symbol_text_and_icon.fragment.glsl))
is the same math:

```glsl
#define SDF_PX 8.0
...
float EDGE_GAMMA = 0.105 / u_device_pixel_ratio;
float fontScale = size / 24.0;
highp float gamma = EDGE_GAMMA / (fontScale * u_gamma_scale);
lowp float buff = (256.0 - 64.0) / 256.0;
...
highp float gamma_scaled = gamma * gamma_scale;
highp float alpha = smoothstep(buff - gamma_scaled, buff + gamma_scaled, dist);
...
highp float gamma_halo = (halo_blur * 1.19 / SDF_PX + EDGE_GAMMA) / (fontScale * u_gamma_scale);
lowp float buff_halo = (6.0 - halo_width / fontScale) / SDF_PX;
```

GL JS draws halo and text as two passes and composites them; the halo pass is a
filled shape and the text pass covers it (the shader also has a combined
text+halo output path: `color_alpha_out + (1. - color_alpha_out.a) *
color_alpha_out_halo`). The modern Mapbox GL JS `symbol.fragment.glsl`
([link](https://github.com/mapbox/mapbox-gl-js/blob/main/src/shaders/symbol.fragment.glsl))
keeps the same formulas, with `u_scale_factor` folded into the halo width and
blur:

```glsl
float EDGE_GAMMA = 0.105 / u_device_pixel_ratio;
float fontScale = u_is_text ? size / 24.0 : size;
highp float gamma = EDGE_GAMMA / (fontScale * u_gamma_scale);
lowp float buff = (256.0 - 64.0) / 256.0;
if (draw_halo) {
    out_color = halo_color;
    gamma = (halo_blur * u_scale_factor * 1.19 / SDF_PX + EDGE_GAMMA) / (fontScale * u_gamma_scale);
    buff = (6.0 - halo_width * u_scale_factor / fontScale) / SDF_PX;
}
```

The vertex shaders (`symbol_text_and_icon.vertex.glsl`,
`symbol.vertex.glsl`) agree on `fontScale = size / 24.0`, on
`a_offset / 32.0 * fontScale`, and on passing `gamma_scale = finalPos.w`.

### 2.5 The historical uniform form (`sdfPx`, `u_buffer`, `u_gamma`, alpha)

The older shader pair (Mapbox GL JS v0.30.0) exposes the same quantities as
uniforms, which is the clearest statement of what each one means. In
`js/render/draw_symbol.js`
([source](https://github.com/mapbox/mapbox-gl-js/blob/v0.30.0/js/render/draw_symbol.js)):

```js
const sdfPx = 8;
const blurOffset = 1.19;
const haloOffset = 6;
const gamma = 0.105 / browser.devicePixelRatio;
...
const fontScale = size / (isText ? 24 : 1);
...
if (haloWidth) { // Draw halo underneath the text.
    gl.uniform1f(program.u_gamma, (haloBlur * blurOffset / sdfPx + gamma) / gammaScale);
    gl.uniform1f(program.u_buffer, (haloOffset - haloWidth / fontScale) / sdfPx);
    ...
}
gl.uniform1f(program.u_gamma, gamma / gammaScale);
gl.uniform1f(program.u_buffer, (256 - 64) / 256);
```

and the fragment shader
([source](https://github.com/mapbox/mapbox-gl-js/blob/v0.30.0/shaders/symbol_sdf.fragment.glsl)):

```glsl
lowp float dist = texture2D(u_texture, v_tex).a;
lowp float gamma = u_gamma * v_gamma_scale;
lowp float alpha = smoothstep(u_buffer - gamma, u_buffer + gamma, dist) * fade_alpha;
gl_FragColor = u_color * (alpha * u_opacity);
```

This is exactly the role mapping the task asks about: the SDF spread is
`sdfPx = 8`; the smoothing half-band is `gamma = 0.105 / DPR`, divided by
`fontScale` and the perspective `gammaScale`; the edge is `u_buffer` (0.75 for
text, `0.75 - haloWidth / (8 * fontScale)` for the halo); and alpha is the
coverage multiplying the fill color. The halo is explicitly drawn as a separate
pass "underneath the text", with the same quad and a lower edge - the scheme our
renderer already uses, and the one the proposal below keeps.

### 2.6 Filtering, mipmaps and atlas padding

- GL JS binds the text atlas with `gl.LINEAR` regardless of motion
  ([draw_symbol.ts](https://github.com/maplibre/maplibre-gl-js/blob/main/src/webgl/draw/draw_symbol.ts), lines 356-359)
  and never enables mipmaps for glyph textures (`Texture` defaults
  `useMipmap` to false, and `generateMipmap` only runs when it is set;
  [texture.ts](https://github.com/maplibre/maplibre-gl-js/blob/main/src/webgl/texture.ts), lines 63 and 120-122).
- The glyph atlas copies each bitmap with **1 px of zero padding** on top of the
  bitmap's own 3 px SDF border
  ([glyph_atlas.ts](https://github.com/maplibre/maplibre-gl-js/blob/main/src/render/glyph_atlas.ts), lines 7 and 50-73).
- MapLibre Native sets the glyph atlas sampler to linear filtering with clamp
  wrapping ([drawable_atlases_tweaker.cpp](https://github.com/maplibre/maplibre-native/blob/main/src/mln/gfx/drawable_atlases_tweaker.cpp), lines 13-18).

Our choices (linear, clamp, 1 px packing padding, no mips) are therefore
consistent with both references. The fog is not a filtering-regime difference.

## 3. Navara and maplibre-rs: what a Rust/wgpu text renderer does

### 3.1 Navara (the current MapLibre Rust engine)

Navara renders text in a dedicated font worker and draws it with an
MSDF/MTSDF-capable shader:

- Atlas rasterization is **64 px** (`SDF_PX_SIZE: f32 = 64.0`), with a **12 px SDF
  buffer** and a **35 px SDF radius** for the single-channel path; the atlas packs
  glyphs with **1 px zero padding** and grows up to 8192 px
  ([atlas.rs](https://github.com/maplibre/navara/blob/main/crates/navara_wasm_font_worker/src/atlas.rs),
  lines 8-16, 32-39, 66-74).
- The MSDF path is a 4-channel MTSDF (RGB median plus a true SDF in alpha) with
  an **8 px physical padding** and a **16 px encoded range**; the code explains
  why the range must be twice the padding: "fdsm's range is the full signed
  interval, so using 8 for both values saturates the field after only 4 px of
  exterior distance and leaves the outer half of this padding unable to fade
  thick outlines"
  ([msdf.rs](https://github.com/maplibre/navara/blob/main/crates/navara_wasm_font_worker/src/msdf.rs), lines 25-39).
- The shader derives the distance-field range in **screen pixels from UV
  derivatives**, not from a DPR uniform:

```glsl
vec2 uvDx = dFdx(vAtlasUv);
vec2 uvDy = dFdy(vAtlasUv);
vec2 uvGradient = sqrt(uvDx * uvDx + uvDy * uvDy);
vec2 screenTexSize = vec2(1.0) / max(uvGradient, vec2(1e-6));
vec2 unitRange = vec2(float(NVR_SDF_PX_RANGE)) / max(uSdfAtlasSize, vec2(1.0));
return max(0.5 * dot(unitRange, screenTexSize), 1.0);
...
return clamp(screenPxRange * (distanceValue - edge) + 0.5, 0.0, 1.0);
```

  with the documented rationale: "Unlike smoothstep(threshold ± fwidth), this does
  not accidentally spend two pixels on the transition"
  ([sdfText.frag.glsl](https://github.com/maplibre/navara/blob/main/shaders/glsl/sdfText.frag.glsl), lines 66-118).
- The shader clamps UVs to the glyph rectangle and explains the trap our inflated
  halo quad falls into: "Moving the clamp half a texel inward would instead repeat
  the outermost distance texel, making the rectangular glyph quad faintly
  visible" (lines 83-90).
- It adds small-text compensation: up to 0.15 px of stem darkening and up to four
  taps of area supersampling, both faded out by 32 ppem, because "correct area
  coverage can make a subpixel stem mathematically accurate but perceptually too
  light" (lines 193-230).

### 3.2 maplibre-rs (archived predecessor)

maplibre-rs decoded the same 3-px-buffer PBFs, packed them into a 4096 px page in
one row, and used a much simpler shader
([text.rs](https://github.com/maplibre/maplibre-rs/blob/main/maplibre/src/sdf/text.rs),
[sdf.fragment.wgsl](https://github.com/maplibre/maplibre-rs/blob/main/maplibre/src/render/shaders/sdf.fragment.wgsl)):

```wgsl
let buffer_width: f32 = 0.25;
let buffer_center_outline: f32 = 0.8;
let outline_center_offset: f32 = -0.25;
let buffer_center: f32 = buffer_center_outline + outline_center_offset;   // 0.55
let alpha: f32 = smoothstep(buffer_center - buffer_width / 2.0, buffer_center + buffer_width / 2.0, dist);
```

The shader's own comment block reproduces MapLibre's constants, including
`buff = (256.0 - 64.0) / 256.0`. maplibre-rs's 0.55 edge is the same class of
error as our 0.5: it is not the protocol edge. It also draws an outline at 0.8.
This is a useful warning: a Rust/wgpu port that does not carry the protocol
constants across will reproduce our exact fog.

### 3.3 What is portable for us

- **Do not adopt MSDF yet.** Our PBFs are single-channel SDF; MSDF would require
  a different glyph generator and a 4-channel atlas. The measurable defect is not
  corner sharpness.
- **Do adopt the screen-space coverage idea** (derivative- or DPR-derived): it
  makes the antialias band one device pixel at any DPR and scale, which is exactly
  what our fixed ±0.05 band fails to do.
- **Do adopt the UV clamp / no-quad-inflation lesson.** Navara explicitly avoids
  repeating the border texel because it makes the quad visible; our inflated halo
  does exactly that.
- **Consider Navara's small-text stem darkening later**, but only after the
  protocol edge is correct; it is a perceptual compensation, not a substitute for
  the right threshold.

## 4. Browser canvas and device-pixel-ratio practice

The standard failure is documented plainly: "You may find that canvas items
appear blurry on higher-resolution displays. While many solutions may exist, a
simple first step is to scale the canvas size up and down simultaneously, using
its attributes, styling, and its context's scale"
([MDN, Optimizing canvas](https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Optimizing_canvas)):

```js
const dpr = window.devicePixelRatio;
const rect = canvas.getBoundingClientRect();
canvas.width = rect.width * dpr;
canvas.height = rect.height * dpr;
ctx.scale(dpr, dpr);
canvas.style.width = `${rect.width}px`;
canvas.style.height = `${rect.height}px`;
```

MapLibre GL JS follows the same rule for its map canvas. Its `pixelRatio` option
is documented as: "The canvas' `width` attribute will be `container.clientWidth *
pixelRatio` and its `height` attribute will be `container.clientHeight *
pixelRatio`. Defaults to `devicePixelRatio` if not specified"
([map.ts](https://github.com/maplibre/maplibre-gl-js/blob/main/src/ui/map.ts), lines 380-384).
Its `_resizeCanvas` carries the decisive comment: "Sizes the backing store to
whole device pixels and the CSS box to cover exactly that many, so the compositor
never rescales the canvas" (lines 4217-4231). `getPixelRatio()` returns
`_overridePixelRatio ?? devicePixelRatio` (lines 1710-1712), and the fragment
shader divides `EDGE_GAMMA` by the same ratio.

Our page does the opposite: backing store = CSS pixels, CSS box = the same CSS
sizes, so on a DPR-2 display the compositor rescales 2x. Every label edge is
therefore filtered twice: once by our shader's 0.4-device-pixel band, and again
by the compositor's 2x bilinear upscale. The @2x tiles are also round-tripped
through the 1x canvas, so the whole demo is soft, but text suffers most because
it is the highest-frequency content and is drawn at half its device resolution.

Note the two distinct notions the fix must keep apart:

- **layout space** (camera, label text sizes, halo widths, collision padding,
  gesture deltas, line widths) is in CSS pixels;
- **render target extent** (the WebGPU surface texture) is in device pixels.

Clip space is normalised, so a quad laid out with a CSS-pixel viewport maps onto a
device-pixel target automatically: 1 CSS px becomes DPR device px. That is
MapLibre's model (its transform is sized from container dimensions, its canvas
backing store from width * pixelRatio). Our renderer instead derives the layout
viewport from `canvas.width()`, which currently equals the CSS size, so both
notions coincide by accident.

## 5. Ranked probable causes of the fog

Impact estimates assume the demo labels: 10-18 CSS px, halo 1.3-1.5 px, dark grey
fill on a white halo.

| Rank | Cause | Mechanism | Evidence | Impact | Confidence |
|---|---|---|---|---|---|
| 1 | Canvas backing store stays at CSS resolution on Retina | Whole frame is bilinearly upscaled by the compositor; text drawn at 10-18 backing px becomes 20-36 device px of smooth blur | `playground.mjs:3386-3389`, `playground.css:116`, `canvas.rs:1554-1557`; MDN pattern; GL JS `_resizeCanvas` | Universal 2x smear on every DPR>1 display; dominates all shader issues | High |
| 2 | Halo threshold 0.32 is below the SDF's stored border values, and the quad is inflated with ClampToEdge | The border (values 0.37-0.40 on a straight edge) is fully covered; the inflated ring repeats the border texel; paint reaches `T/8 + halo_width` (2.7-3.8 px) with near-full alpha | fontnik encoding (`glyph_foundry_impl.hpp`); fixture border 95-101; `labels.rs:499-509`, `:568-583`; Navara's repeated-texel warning | Thick white bloom merges glyphs; reads as low contrast | High |
| 3 | Text threshold 0.5 instead of the protocol edge 0.75 | Dilates every glyph by 2 atlas px = `T/12` CSS px per side (1.0 px at 12 px, 1.5 px at 18 px); counters close, strokes fatten into the halo | fontnik encoding; MapLibre `(256-64)/256`; fixture `H` scanline | Bold, blobby small text; contributes to merging and apparent softness | High |
| 4 | Fixed ±0.05 smoothing band, not DPR- or size-aware | At the current 1x backing store the whole band is 0.4 canvas px and is destroyed by the upscale; even after the DPR fix it is 0.8 device px total versus MapLibre's 1.68, so edges are harder/aliased at DPR 1 and not consistent across sizes | `headless.rs:185`, `canvas.rs:557`; MapLibre `EDGE_GAMMA` formula | Secondary now; must be fixed so the corrected text looks right at both DPR 1 and 2 | Medium |
| 5 | 24 px em atlas minified to 0.42-0.75x with bilinear and no mips | At 10 px (2.4:1) and on rotated line labels the bilinear footprint undersamples; at DPR 2 the ratio becomes 0.83-1.5 (magnification for large labels), which is the intended regime | `labels.rs:73`, `:265`; atlas 1 px padding; MapLibre has the same regime | Minor after the DPR fix; a residual slight softening of 18 px text at DPR 2 | Low |
| 6 | Text color alpha / color space | Ruled out: style colors are alpha 1.0; both render targets are non-sRGB (`surface.rs:159-166`), so blending is in the same space as WebGL's default | Bright style fixture; `surface.rs:163-166` | None | Ruled out |
| 7 | Font coverage / atlas capacity | Ruled out: 223 Latin glyphs in 1024x1024, all requested names served | fixture README; `atlas.rs` | None | Ruled out |

One more contributing detail for rank 3: the interior of thin stems only reaches
`0.89` in the fixture (fontnik saturates 2 px inside the edge). With MapLibre's
correct edge and a DPR-1 gamma of 0.21 at 12 px, a stem center reaches about 0.92
coverage, so 12 px text at DPR 1 is legitimately a little lighter than at DPR 2,
where it reaches 1.0. That is MapLibre's behavior too and should not be "fixed" by
lowering the threshold; if it matters, use a small-text stem-darkening term like
Navara's.

## 6. Spec proposal

### 6.1 Protocol constants (single source of truth)

Move the encoding into documented constants in `map-glyphs` (or `map-rendering`,
which already depends on it) and import them everywhere:

```rust
/// fontnik's `radius` and the shaders' `SDF_PX`: one field unit spans 8 px.
pub const GLYPH_SIGNED_DISTANCE_FIELD_PIXELS_PER_UNIT: f32 = 8.0;

/// The zero-distance contour of a Mapbox glyph bitmap: fontnik writes
/// `byte = 255 - (64 + 32 * distance_px)`, so the outline is at 191/255.
/// MapLibre uses the rounded `(256 - 64) / 256 = 0.75`.
pub const GLYPH_SIGNED_DISTANCE_FIELD_EDGE: f32 = 0.75;

/// The 3 px border is the maximum exterior distance the protocol stores.
pub const GLYPH_SIGNED_DISTANCE_FIELD_MAXIMUM_OUTWARD_PIXELS: f32 = 3.0;

/// MapLibre's EDGE_GAMMA: an ~0.84-device-pixel half-band, independent of DPR.
pub const GLYPH_EDGE_GAMMA_DEVICE_PIXELS: f32 = 0.105;
```

Justification: 8 comes from `radius = 8` in fontnik and `SDF_PX 8.0` in every
MapLibre shader; 0.75 from the cutoff shift; 3 from the buffer; 0.105 from
MapLibre's `EDGE_GAMMA`, whose DPR division makes the antialias band one device
pixel (0.84 half-band) at any display density.

### 6.2 The WGSL port

Keep the current vertex layout and add one `f32` attribute, the smoothing
half-band. Delete the shader's fixed `GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING`.

```wgsl
struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) texture_coordinates: vec2<f32>,
    @location(1) rgba_color: vec4<f32>,
    @location(2) signed_distance_threshold: f32,
    @location(3) signed_distance_gamma: f32,
};

@group(0) @binding(0) var glyph_atlas: texture_2d<f32>;
@group(0) @binding(1) var glyph_sampler: sampler;

@vertex
fn vertex_main(
    @location(0) clip_position: vec4<f32>,
    @location(1) texture_coordinates: vec2<f32>,
    @location(2) rgba_color: vec4<f32>,
    @location(3) signed_distance_threshold: f32,
    @location(4) signed_distance_gamma: f32,
) -> VertexOutput {
    var output: VertexOutput;
    output.clip_position = clip_position;
    output.texture_coordinates = texture_coordinates;
    output.rgba_color = rgba_color;
    output.signed_distance_threshold = signed_distance_threshold;
    output.signed_distance_gamma = signed_distance_gamma;
    return output;
}

@fragment
fn fragment_main(vertex: VertexOutput) -> @location(0) vec4<f32> {
    let distance = textureSample(glyph_atlas, glyph_sampler, vertex.texture_coordinates).r;
    let coverage = smoothstep(
        vertex.signed_distance_threshold - vertex.signed_distance_gamma,
        vertex.signed_distance_threshold + vertex.signed_distance_gamma,
        distance);
    return vec4<f32>(vertex.rgba_color.rgb, vertex.rgba_color.a * coverage);
}
```

Per-vertex values, computed in `labels.rs` where `text_size_pixels`,
`halo_width_pixels` and the pixel ratio are known:

```rust
let font_scale = text_size_pixels / GLYPH_FONT_EM_PIXELS;              // f64
let gamma = GLYPH_EDGE_GAMMA_DEVICE_PIXELS / device_pixel_ratio / font_scale; // f32

// Text pass
let text_threshold = GLYPH_SIGNED_DISTANCE_FIELD_EDGE;                  // 0.75
let text_gamma = gamma;

// Halo pass: same quad geometry as the text pass, no inflation.
let halo_width_atlas_pixels =
    (halo_width_pixels / font_scale).min(GLYPH_SIGNED_DISTANCE_FIELD_MAXIMUM_OUTWARD_PIXELS);
let halo_threshold =
    GLYPH_SIGNED_DISTANCE_FIELD_EDGE - (halo_width_atlas_pixels / 8.0) as f32;
let halo_gamma = gamma;  // halo_blur is zero in our styles
```

This is MapLibre's math with `halo_blur = 0`:

```
text: smoothstep(0.75 - g, 0.75 + g, d)
halo: smoothstep(0.75 - w_atlas/8 - g, 0.75 - w_atlas/8 + g, d)
g = (0.105 / DPR) / (T / 24)
```

Why `halo_gamma = gamma` is correct: MapLibre's halo gamma is
`(halo_blur * 1.19 / 8 + EDGE_GAMMA) / fontScale`; with `halo_blur = 0` it equals
the text gamma. If `halo_blur` is introduced later, use the full expression.

### 6.3 Halo width in SDF units, and the protocol's hard ceiling

```
w_atlas_px = halo_width_css_px / font_scale
halo_edge  = 0.75 - w_atlas_px / 8
distance_at_edge_css_px = halo_width_css_px          (exactly, by construction)
```

| T (CSS px) | f | style halo (px) | w_atlas (px) | correct reach (px) | buffer ceiling T/8 (px) | fully-faded ceiling (T/8 - 0.84/DPR) at DPR 2 (px) |
|---|---|---|---|---|---|---|
| 10 | 0.417 | 1.5 | 3.60 | 1.5 | 1.25 | 0.83 |
| 12 | 0.500 | 1.3 | 2.60 | 1.3 | 1.50 | 1.08 |
| 13 | 0.542 | 1.5 | 2.77 | 1.5 | 1.63 | 1.21 |
| 14 | 0.583 | 1.3 | 2.23 | 1.3 | 1.75 | 1.33 |
| 18 | 0.750 | 1.5 | 2.00 | 1.5 | 2.25 | 1.83 |

Two consequences:

- The style's 1.3-1.5 px halos are near or beyond the protocol's 3 px buffer at
  the demo's small sizes. Clamp `w_atlas` to 3.0 (the representable range) and
  document that a *fully faded* halo needs
  `w_atlas <= 3 - 0.84 / (DPR * font_scale)`, which is about 2.2 atlas px at
  DPR 2 and 12 px text (1.08 CSS px) and only 1.3 atlas px at DPR 1 (0.66 CSS px).
  MapLibre accepts the partial cap at the bitmap boundary; at 1.3 px halo width
  that cap is around 30% alpha. The current 2.8 px solid bloom is a different
  magnitude entirely.
- Do not inflate the quad to fake a wider halo: the inflated ring repeats the
  border texel and produces exactly the bloom we are removing. If the design
  wants a visibly thicker halo at 10-12 px, the only correct route is a glyph
  source with a larger buffer (not the public 3 px protocol), or an outline
  rendered from the SDF by a second, deliberately blurred pass. That is a later
  decision, not part of this fix.

### 6.4 Geometry

- The halo quad must use exactly the text quad's rectangle and UVs. Remove the
  `- halo_width`/`+ 2 * halo_width` expansion in both the axis-aligned and the
  rotated emitters (`labels.rs:568-583`, `:633-650`).
- Optionally clamp the sampled UV to the glyph's own `uv_rectangle` (Navara's
  lesson). With 3 px of SDF border plus 1 px of packing padding, bilinear at the
  quad edge cannot reach a neighbouring glyph, so this is defensive, not urgent.
- Keep `ClampToEdge`; it is only visible when a quad reads outside its glyph
  rect, which the two changes above prevent.

### 6.5 Filtering and mipmaps

Keep `Linear`/`Linear`, `ClampToEdge`, one mip level. This matches MapLibre GL JS
and MapLibre Native. After the DPR fix the atlas-to-device ratio for the demo is
`T * DPR / 24` = 0.83-1.5, which is bilinear's good range. Do not add a mip chain:

- Signed-distance fields average poorly away from the contour, and mip levels of
  the atlas would mix unrelated glyphs at low levels.
- The failure mode mips would address (minification below ~0.5x) disappears once
  the canvas is device-sized; at 10 CSS px on DPR 2 the ratio is 0.83.
- If a future style renders 8 CSS px labels on DPR 1 (0.33x), revisit with a
  second atlas rasterized at a smaller em, not with mips.

### 6.6 Device-pixel-ratio requirements for the canvas

Required:

1. `resize_canvases` sizes the backing store in device pixels and pins the CSS
   box to the same logical size, following GL JS's `_resizeCanvas`
   ("so the compositor never rescales the canvas"):

```js
function resize_canvases() {
  const dpr = window.devicePixelRatio || 1;
  const css_width = window.innerWidth;
  const css_height = window.innerHeight;
  const backing_width = Math.round(css_width * dpr);
  const backing_height = Math.round(css_height * dpr);
  map_canvas.width = backing_width;
  map_canvas.height = backing_height;
  map_canvas.style.width = `${backing_width / dpr}px`;
  map_canvas.style.height = `${backing_height / dpr}px`;
  // The overlay draws only 2D guides and feeds gesture math in CSS pixels;
  // leave it at CSS size unless/until it needs retina strokes too.
  overlay_canvas.width = css_width;
  overlay_canvas.height = css_height;
}
```

2. Keep layout in CSS pixels. In `renderFrame`
   (`crates/map-web-bindings/src/canvas.rs:1554-1557`), derive the layout
   viewport from the canvas' CSS size (`client_width()`/`client_height()`, falling
   back to the backing extent when the element is not rendered) and keep the
   surface extent from `canvas.width()`/`height()`. Pass the ratio
   `canvas.width() / client_width()` (not `window.devicePixelRatio` directly) into
   the label layout as `device_pixel_ratio`, so browser zoom and fractional DPRs
   stay consistent with the actual surface.
3. Native surfaces must pass the same ratio: `surface_extent / logical_viewport`.
   Headless rendering passes 1.0.
4. The `@2x` tile-resolution seam stays as it is; with a device-sized canvas the
   retina fixtures become a true 1:1 draw instead of a downscale-then-upscale.

Trade-off to state clearly: if the overlay canvas remains CSS-sized, its guide
strokes stay at CSS resolution while the map is retina. That is acceptable for
the current overlay content; scaling it later requires switching the gesture code
from `overlay_canvas.width` to `clientWidth` (the page already uses CSS pixels for
camera fits, e.g. `playground.mjs:987-992`).

### 6.7 Minimal changes and constant list

| File | Change |
|---|---|
| `crates/map-glyphs/src/glyph.rs` | Add the protocol constants (`SDF` spread 8, edge 0.75 / 191, 3 px maximum outward) with docs citing fontnik. Keep the border at 3. |
| `crates/map-rendering/src/labels.rs` | `GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD: 0.5 -> 0.75`; delete `GLYPH_HALO_SIGNED_DISTANCE_THRESHOLD`; add `GLYPH_EDGE_GAMMA_DEVICE_PIXELS`, `GLYPH_MAXIMUM_HALO_WIDTH_ATLAS_PIXELS`; compute per-label threshold and gamma; add `signed_distance_gamma` to `ClipSpaceGlyphVertex`; stop inflating halo quads. |
| `crates/map-rendering/src/headless.rs` | Shader: add `@location(3) signed_distance_gamma`, use it in the smoothstep; delete `GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING`; make the shader `pub` for reuse. |
| `crates/map-rendering/src/surface.rs` | Vertex layout adds the gamma attribute; pass the surface/logical pixel ratio. |
| `crates/map-web-bindings/src/canvas.rs` | Delete the duplicated shader string and import `map_rendering::GLYPH_ATLAS_SHADER_SOURCE`; add the gamma attribute; layout viewport from CSS size; pass the ratio. |
| `platform/web/playground.mjs` | Device-pixel backing store with an explicit CSS size. |
| `platform/web/styles/playground.css` | No change needed (`100vw/100vh` stays the layout size); inline sizes from the script win. |
| `crates/map-rendering/fixtures/render/golden/*.png` | Regenerate the two label goldens. |
| `platform/web/playwright.config.mjs` | No change; retina tests create their own context. |

Constants to remove or replace:

- `GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD = 0.5` -> `0.75`
- `GLYPH_HALO_SIGNED_DISTANCE_THRESHOLD = 0.32` -> derived from halo width
- `GLYPH_SIGNED_DISTANCE_EDGE_SMOOTHING = 0.05` -> derived from DPR and font scale

Constants to add:

- `GLYPH_SIGNED_DISTANCE_FIELD_PIXELS_PER_UNIT = 8.0`
- `GLYPH_SIGNED_DISTANCE_FIELD_EDGE = 0.75` (true byte value 191/255 documented)
- `GLYPH_SIGNED_DISTANCE_FIELD_MAXIMUM_OUTWARD_PIXELS = 3.0`
- `GLYPH_EDGE_GAMMA_DEVICE_PIXELS = 0.105`

Do not change `GLYPH_FONT_EM_PIXELS = 24`, the 3-pixel border, the 1-pixel packing
padding, the `R8Unorm` format, or the linear/clamp sampler.

### 6.8 Optional alternative: derivative-derived coverage

If threading a pixel ratio into both shader copies is undesirable, the same
one-device-pixel antialias can be computed in the fragment shader from UV
derivatives (Navara's approach, adapted to our encoding):

```wgsl
let atlas_size = vec2<f32>(textureDimensions(glyph_atlas, 0));
let uv_dx = dpdx(vertex.texture_coordinates);
let uv_dy = dpdy(vertex.texture_coordinates);
let texels_per_device_pixel = max(length(uv_dx * atlas_size), length(uv_dy * atlas_size));
let screen_pixel_range = 8.0 * max(texels_per_device_pixel, 0.5);
let coverage = clamp(screen_pixel_range * (distance - edge) + 0.5, 0.0, 1.0);
```

This removes the DPR uniform and adapts to rotation and perspective for free, but
it gives a 1-device-pixel transition rather than MapLibre's 1.68-device-pixel one.
Adopt it only with the same edge-profile tests; the primary proposal above is the
faithful MapLibre port.

## 7. Test strategy

### 7.1 Protocol and layout tests (CPU, always run)

- `crates/map-rendering/tests/glyph_protocol.rs` (new): decode
  `DEFAULT_LATIN_GLYPH_RANGE_PBF_BYTES`, glyph `H`, and assert the encoding
  invariants: a 32-per-pixel ramp; the 191 crossing between the 165 and 197
  border/ink pixels; the interior maximum at 227; the straight-edge border at
  95-101. This is the test that stops anyone from "fixing" the threshold back to
  0.5.
- `crates/map-rendering/src/labels.rs` tests (extend the existing modules):
  - for a 12 px label the emitted text threshold is 0.75 and the gamma is
    `(0.105 / DPR) / 0.5`;
  - the emitted halo threshold for halo width 1.3 is
    `0.75 - 1.3 / 0.5 / 8 = 0.425`;
  - the halo quad rectangle and UVs equal the text quad's, for both axis-aligned
    and rotated labels;
  - a halo width beyond `3 * font_scale` is clamped to the protocol ceiling.
- `crates/map-web-bindings/src/canvas.rs` unit tests: a pure
  `backing_store_extent(css_width, css_height, dpr)` helper rounds to whole device
  pixels and validates zero/negative inputs, and `layout_viewport` prefers the CSS
  size with a documented fallback.

### 7.2 Headless coverage-profile test (GPU; skips without an adapter)

`crates/map-rendering/tests/glyph_coverage_profile.rs` (new), following
`golden_image.rs`'s graceful-skip pattern:

- Render one label (for example `H` at 24 px, so the atlas-to-screen scale is 1)
  on a known background, with and without a halo, at `device_pixel_ratio` 1 and 2.
- Read back the RGBA frame and take a horizontal profile across a vertical stem.
- Assert:
  - the coverage ramp is monotone and crosses 0.5 within one pixel of the
    geometric stem boundary (the position where the atlas scanline crosses 191);
  - the full 0%-100% transition width is `1.68` device pixels within a tolerance,
    independent of DPR (a 10%-90% distance of roughly 1 device px);
  - the stem interior reaches at least 0.99 of the fill alpha at 24 px;
  - for the halo, coverage falls to the background at exactly `halo_width` CSS px
    beyond the stem edge and never paints a rectangular cap at the bitmap border;
  - the composited glyph body is fill-colored, not halo-colored, and no white
    fringe survives on the stem edges.

### 7.3 Browser screenshot / pixel test (catches the compositor)

`platform/web/tests/text_quality.spec.mjs` (new), using the established in-page
probe pattern (draw the fresh surface into a 2D canvas, then `getImageData`; see
`platform/web/golden.mjs:218-252` and `sdk_core.spec.mjs:375-392`; `drawImage` on a
WebGPU canvas requires a freshly presented frame, so force a re-present first):

- Create a DPR-2 context (`browser.newContext({ deviceScaleFactor: 2, viewport })`,
  the pattern at `sdk_core.spec.mjs:579-584`).
- Assert `map_canvas.width === Math.round(innerWidth * 2)`, the same for height,
  and that the CSS box is unchanged (`getBoundingClientRect().width === innerWidth`).
- Switch to the Bright vector base, wait for labels, then probe around a known
  place label:
  - **Interior opacity:** the darkest stem pixel versus the local background
    reaches at least 0.95 of the style's text alpha.
  - **Edge transition width:** across a scanline through a stem, the 10%-90%
    luminance distance is at most 1.5 device px (MapLibre's full transition is
    1.68 device px, so its 10%-90% distance is about 1 device px).
  - **Halo reach:** the white halo falls back to the map color within
    `halo_width + 1` CSS px of the stem edge, not `T/8 + halo_width`.
  - **No quad cap:** the four corners just outside a glyph's bitmap rectangle are
    background-colored, not halo-colored.
- Add a DPR-1 control context with the same assertions. The transition is defined
  in device pixels, so the same device-pixel distances apply; only the CSS
  distances differ.

### 7.4 DPR assertions on the existing seams

- `platform/web/tests/sdk_core.spec.mjs` retina test (lines 571-624): keep the
  `@2x` tile URL assertions, and add the canvas backing-store assertion. This is
  the cheapest regression guard for cause 1.
- `platform/web/tests/vector_labels.spec.mjs` (lines 1-160): keep the placement
  and label-count assertions; the new pixel test covers quality so this suite
  stays a behavior test.

### 7.5 Goldens

- Regenerate `crates/map-rendering/fixtures/render/golden/sacramento_zoom14_place_labels.png`
  and `sacramento_zoom14_road_names.png` after the shader change. The harness
  writes a missing fixture on first run (`golden_image.rs:1-30`), so delete the two
  files, run the two tests, inspect the new images, and commit them with the
  change.
- The golden tolerances (`MEAN_ABSOLUTE_ERROR_TOLERANCE = 2.0`,
  `OUTLIER_CHANNEL_ERROR = 24.0`, `OUTLIER_PIXEL_FRACTION_LIMIT = 0.02` in
  `golden_image.rs`, mirrored in `platform/web/tests/golden_compare.spec.mjs`)
  should hold; widen them only if the new rendering's GPU variance proves
  otherwise, and mirror any change on both sides.
- The headless goldens run at DPR 1 by design, so they catch threshold and halo
  regressions but not the browser upscale; the browser test in 7.3 is what catches
  cause 1.

### 7.6 Shader duplication guard

`map-web-bindings` copies the shader string today ("copied verbatim from the
native `map-rendering`", `canvas.rs:551-555`) with no equality test. Either delete
the copy by making `map-rendering`'s constant public and importing it, or add a
unit test that asserts the two strings are byte-identical. The proposed change
touches the shader in both places; drift here is a silent quality regression.

## 8. Open questions

1. Should the overlay canvas also be device-sized? Its strokes are currently CSS
   resolution; scaling it requires moving gesture math from
   `overlay_canvas.width` to `clientWidth` consistently (the camera-fit code
   already uses CSS pixels).
2. Do the native refapps lay out labels in logical or physical pixels? The
   `device_pixel_ratio` seam must be sourced from `surface_extent /
   logical_viewport` in whichever convention each platform uses; this study did
   not audit the Android/iOS surface setup.
3. The style's 1.3-1.5 px halos exceed the fully-faded limit at 10-12 px on DPR 2.
   After the fix, is the clipped halo acceptable, or should the style widths be
   lowered for small sizes? That is a design decision, not a shader one.

## 9. References

External sources (all fetched from the live repositories on 2026-10-31):

- MapLibre Native, `shaders/symbol_sdf.fragment.glsl`:
  https://github.com/maplibre/maplibre-native/blob/main/shaders/symbol_sdf.fragment.glsl
- MapLibre Native, `shaders/symbol_sdf.vertex.glsl`:
  https://github.com/maplibre/maplibre-native/blob/main/shaders/symbol_sdf.vertex.glsl
- MapLibre Native, WebGPU WGSL symbol shader:
  https://github.com/maplibre/maplibre-native/blob/main/include/mln/shaders/webgpu/symbol.hpp
- MapLibre Native, WebGPU common constants:
  https://github.com/maplibre/maplibre-native/blob/main/include/mln/shaders/webgpu/common.hpp
- MapLibre Native, `DEVICE_PIXEL_RATIO` program define:
  https://github.com/maplibre/maplibre-native/blob/main/src/mln/shaders/program_parameters.cpp
- MapLibre Native, glyph atlas sampler:
  https://github.com/maplibre/maplibre-native/blob/main/src/mln/gfx/drawable_atlases_tweaker.cpp
- MapLibre GL JS, `symbol_text_and_icon.fragment.glsl`:
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/shaders/glsl/symbol_text_and_icon.fragment.glsl
- MapLibre GL JS, `symbol_text_and_icon.vertex.glsl`:
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/shaders/glsl/symbol_text_and_icon.vertex.glsl
- MapLibre GL JS, `src/ui/map.ts` (pixel ratio and `_resizeCanvas`):
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/ui/map.ts
- MapLibre GL JS, `src/render/glyph_atlas.ts`:
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/render/glyph_atlas.ts
- MapLibre GL JS, `src/webgl/draw/draw_symbol.ts`:
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/webgl/draw/draw_symbol.ts
- MapLibre GL JS, `src/webgl/texture.ts`:
  https://github.com/maplibre/maplibre-gl-js/blob/main/src/webgl/texture.ts
- Mapbox GL JS, `src/shaders/symbol.fragment.glsl`:
  https://github.com/mapbox/mapbox-gl-js/blob/main/src/shaders/symbol.fragment.glsl
- Mapbox GL JS, `src/shaders/symbol.vertex.glsl`:
  https://github.com/mapbox/mapbox-gl-js/blob/main/src/shaders/symbol.vertex.glsl
- Mapbox GL JS v0.30.0, `js/render/draw_symbol.js` (the explicit `sdfPx`,
  `gamma`, `u_buffer` setup):
  https://github.com/mapbox/mapbox-gl-js/blob/v0.30.0/js/render/draw_symbol.js
- Mapbox GL JS v0.30.0, `shaders/symbol_sdf.fragment.glsl`:
  https://github.com/mapbox/mapbox-gl-js/blob/v0.30.0/shaders/symbol_sdf.fragment.glsl
- Mapbox GL JS v0.30.0, `shaders/symbol_sdf.vertex.glsl`:
  https://github.com/mapbox/mapbox-gl-js/blob/v0.30.0/shaders/symbol_sdf.vertex.glsl
- Mapbox GL JS, `src/render/glyph_atlas.ts`:
  https://github.com/mapbox/mapbox-gl-js/blob/main/src/render/glyph_atlas.ts
- node-fontnik, `src/glyphs.cpp` (`RenderSDF(glyph, 24, 3, 0.25, face)`):
  https://github.com/mapbox/node-fontnik/blob/master/src/glyphs.cpp
- node-fontnik, `include/mapbox/glyph_foundry_impl.hpp` (radius 8, cutoff 0.25,
  byte encoding):
  https://github.com/mapbox/node-fontnik/blob/master/include/mapbox/glyph_foundry_impl.hpp
- node-fontnik, `include/mapbox/glyph_foundry.hpp`:
  https://github.com/mapbox/node-fontnik/blob/master/include/mapbox/glyph_foundry.hpp
- Mapbox glyph protocol (`proto/glyphs.proto`, "border of 3 pixels"):
  https://github.com/mapbox/fontnik/blob/master/proto/glyphs.proto
- fontnik (pure JS sprite SDF, same encoding):
  https://github.com/mapbox/fontnik/blob/master/lib/sdf.js
- Navara, font atlas (`SDF_PX_SIZE 64`, 12 px buffer, 1 px padding):
  https://github.com/maplibre/navara/blob/main/crates/navara_wasm_font_worker/src/atlas.rs
- Navara, MTSDF generation (`MSDF_PADDING_PX 8`, `MSDF_RANGE_PX 16`):
  https://github.com/maplibre/navara/blob/main/crates/navara_wasm_font_worker/src/msdf.rs
- Navara, `shaders/glsl/sdfText.frag.glsl` (screen-pixel range, UV clamp,
  stem darkening, supersampling):
  https://github.com/maplibre/navara/blob/main/shaders/glsl/sdfText.frag.glsl
- maplibre-rs, SDF fragment shader (0.55 edge, the same class of error):
  https://github.com/maplibre/maplibre-rs/blob/main/maplibre/src/render/shaders/sdf.fragment.wgsl
- maplibre-rs, glyph decoding and atlas packing:
  https://github.com/maplibre/maplibre-rs/blob/main/maplibre/src/sdf/text.rs
- MDN, Canvas "Optimizing canvas" (DPR scaling pattern and the blur symptom):
  https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Optimizing_canvas

Internal sources:

- `crates/map-glyphs/src/glyph.rs`, `crates/map-glyphs/src/atlas.rs`
- `crates/map-rendering/src/labels.rs`, `headless.rs`, `surface.rs`
- `crates/map-web-bindings/src/canvas.rs`
- `platform/web/playground.mjs`, `platform/web/styles/playground.css`,
  `platform/web/golden.mjs`, `platform/web/playwright.config.mjs`
- `platform/web/tests/sdk_core.spec.mjs`, `vector_labels.spec.mjs`,
  `golden_compare.spec.mjs`
- `crates/map-rendering/tests/golden_image.rs`
- `crates/map-rendering/fixtures/render/vector-style-bright-light.json`,
  `fixtures/render/glyphs/README.md`

## Measured coverage profile (M30 Slice D, 2026-10-31)

The shader's edge is now pinned by a headless measurement, not only by the
golden comparison. `crates/map-rendering/tests/golden_image.rs` renders one
white `I` on the clear colour with no tiles and no halo at 36 and 48 device
pixels, derives each pixel's coverage from the frame's own background and text
luminance, and asserts:

- a stroke interior reaches **≥ 0.98** coverage, and
- the transition immediately beside the widest interior run spans **at most
  2 sampled pixels** (the 0.84-device-pixel half-band rounded to pixel
  centres).

On Metal (`Apple M5 Pro`) the measured profile is:

| Text size | Full-interior pixels | Left/right edge runs |
|---|---|---|
| 36 px | 50 | 0 / 0 px |
| 48 px | 123 | 2 / 1 px |

The measurement crosses a vertical stroke's cross-section, so a horizontal
cap edge (where a scanline runs along the edge rather than across it) cannot
masquerade as a wide ramp. The test skips when no graphics adapter is
available, exactly like the golden fixtures. The browser-side pixel assertion
at DPR 1 and 2 remains the open half of Slice D.
