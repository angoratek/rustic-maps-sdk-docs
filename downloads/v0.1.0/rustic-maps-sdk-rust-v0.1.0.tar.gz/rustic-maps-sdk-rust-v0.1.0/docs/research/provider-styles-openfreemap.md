# Adopting openfreemap-styles: decision-ready research
Scope: pick 2–3 real styles from <https://github.com/hyperknot/openfreemap-styles> for the vector
demo (light + dark + optional), map them onto the data-only schema in
`crates/map-rendering/fixtures/render/vector-style*.json`, and state the required engine work,
licensing and serving facts. Colors/widths were read from the style JSONs at
`raw.githubusercontent.com/hyperknot/openfreemap-styles/main/styles/<name>/style.json`; widths
marked "z14" were computed by evaluating the `interpolate` stops at zoom 14 (the demo camera's
zoom, `platform/reference-scenes.json:13`) with the MapLibre formula
`v0 + (v1-v0)·(base^t-1)/(base-1)`. No color is guessed.

## Recommendation

| Theme | Adopt | Style file | Reason |
|---|---|---|---|
| Light | **Bright** | `styles/bright/style.json` | Only candidate combining a colored road hierarchy (white minor → `#fea` secondary → `#fc8` motorway, `#e9ac77` casing) with green parks, blue water and warm buildings; everything maps to fill/line with per-class duplication. |
| Dark | **Fiord** | `styles/fiord/style.json` | A dark-but-not-black palette (`#45516E` ground, `#38435C` water, `#59658C` casings over `#3C4357` fills) where road classes stay legible; Dark Matter is near-black-on-black. |
| Optional 3rd | Positron — **defer** | `styles/positron/style.json` | Deliberately monochrome (water `rgb(194,200,202)`, parks `rgb(230,233,229)` on `rgb(242,243,240)`); *less* rich than what we ship. Add only if a style picker lands. |

Engine verdict: **no engine feature is required for a respectable v1.** Casing is already
expressible as stacked style layers (our committed styles do it), opacity is the alpha channel,
ordering is array order, and the demo is fixed at z14 so zoom stops can be evaluated once. Missing
for a finished look: dashes (cosmetic, skippable) and labels (out of scope). Two additive schema
fields — width/radius zoom stops and numeric/multi-value filters — are worth doing next, not first.

"Auto": do **not** default to the OS preference. `docs/ReferenceAppUX.md` §3 (lines 208–220) locks
two themes, dark default, "never read the browser/OS preference at runtime"; auto can only be an
explicit third toggle state after a PRD §6 ruling (see §4.5). Reachability: the vector base
defaults to the first descriptor with a `url_template`, **osmus / carto**
(`platform/web/playground.mjs:1056-1062`, `platform/providers.json:48-69`), so a default-provider
change is needed for the demo to open on OpenMapTiles-schema cartography.

## 1. What the repo ships, and under what license

| Style | Layers (total / fill / line / symbol) | Forked from | Served at |
|---|---|---|---|
| Bright | 119 / 22 / 71 / 25 (+1 background) | `openmaptiles/osm-bright-gl-style` | `.../styles/bright` |
| Liberty | 111 / 16 fill, 67 line, 25 symbol, 1 raster, 1 fill-extrusion | `maputnik/osm-liberty` (fork of OSM Bright) | `.../styles/liberty` |
| Positron | 55 / 9 / 26 / 19 | `openmaptiles/positron-gl-style` | `.../styles/positron` |
| Dark | 47 / 9 / 22 / 15 | `openmaptiles/dark-matter-gl-style` | `.../styles/dark` |
| Fiord | 48 / 8 / 25 / 14 | `openmaptiles/fiord-color-gl-style` | `.../styles/fiord` |

(`...` = `https://tiles.openfreemap.org`.) README: `.../hyperknot/openfreemap-styles/blob/main/README.md`.
Positron/Bright/Liberty are being unified; **Dark and Fiord are "not yet complete… unmodified"**
apart from a Noto Sans font swap. Fiord carries a bug: its `landuse_residential` filters on
`subclass == "residential"` while OpenMapTiles emits `class`, so residential landuse never paints.
Transcribe with `class`.

**License** (`LICENSE.md`): repository code **MIT**, © 2023 Zsolt Ero; style code **BSD 3-Clause**;
design **CC BY 4.0**, except the CartoDB lineage (Positron, Dark, Fiord), also **CC BY 3.0**
(CartoDB Basemaps, "designed by Stamen and Paul Norman for CartoDB Inc."). Notices to retain:
`© 2024, MapTiler.com & OpenMapTiles contributors` and `© 2015, CartoDB Inc.` (in the
`dark-matter-gl-style` and `fiord-color-gl-style` `LICENSE.md`). Fonts Noto Sans (SIL OFL 1.1),
sprites Maki (CC0), Natural Earth public domain, map data OSM ODbL (credited in
`platform/providers.json:62-63`). **Redistribution: yes** — MIT/BSD-3/CC BY all permit it; CC BY
4.0 requires attribution and indication of changes. Our transcription is a change (subset,
symbols dropped, Fiord filter fixed), so notices must ship. The JSONs embed no attribution
(top-level keys are only `version, sources, sprite, glyphs, layers`), so it must live in the repo
and the map's attribution surface.

## 2. Candidate character and the inventory that matters at z14
The demo tile (`fixtures/openfreemap/openmaptiles_tile_z14_x2661_y6286.pbf`) contains: landcover
grass/wood; landuse commercial/industrial/pitch/stadium/school/college/library; 23 buildings;
water river + pools; 1 waterway; 327 transportation lines (motorway incl. 49 ramps, primary,
secondary, tertiary, minor, service, track, path, rail, pier); boundary admin_level **6 and 10
(numeric)**; 14 place points.

| | Bright | Positron | Dark (Matter) | Fiord |
|---|---|---|---|---|
| Background | `#f8f4f0` | `rgb(242,243,240)` | `rgb(12,12,12)` | `#45516E` |
| Water | `#AECFE2` | `rgb(194,200,202)` | `rgb(27,27,29)` | `#38435C` |
| Park fill | `#d8e8c8` @0.2 (z14) | `rgb(230,233,229)` | `rgb(32,32,32)` | `hsl(204,17%,35%)` @0.3 |
| Building | `#f2eae2` | `rgb(234,234,229)` | `rgb(10,10,10)` | `hsla(232,47%,18%,0.65)` @0.25 |
| Minor road | `#fff` 2.50 over `#cfcdca` 4.0 | `hsl(0,0%,88%)` 3.94 | `#181818` 3.94 | `hsl(224,22%,45%)` 3.94 |
| Major inner | `#fea` 6.47–8.06 | `#fff` 8.64 | `hsl(0,0%,7%)` 8.64 | `#3C4357` 8.64 |
| Motorway inner | `#fc8` 9.53 | `#fff` 16.51 | `#000` 16.51 | `hsl(224,20%,29%)` 16.51 |
| Casing | `#e9ac77` 8.9–12.07 | `rgb(213,213,213)` 10.38–22.61 | `rgba(60,60,60,0.8)` | `hsl(224,22%,45%)` 10.38–22.61 |
| Boundary | `hsl(248,7%,66%)` 3 / `hsl(0,0%,70%)` 2 dashed | `hsl(0,0%,70%)` 2–3 | `hsl(0,0%,23%)` 8.66–11.78 | `hsl(214,63%,76%)`@0.56 11.78 / `hsla(195,47%,62%,0.26)` 8.66 |

Inventory after dropping symbol layers and bridge/tunnel variants: **Bright** ~15 usable fills
plus ~17 line entries (5 road classes × casing+fill, path, river/stream, rail, 2 boundaries,
2 aeroway); **Positron** 7 fills, ~11 lines (same road skeleton, no hue separation); **Dark**
7 fills, ~12 lines, with under 3 % luminance separation between ground (12), water (27), roads
(0–24) and buildings (10) — the demo would read almost blank; **Fiord** 5 usable fills (water,
wood, park, building; residential is broken), ~15 lines. Verdict: **Bright for light** (max hue
and class differentiation; Liberty is a close second with more saturated water
`rgb(158,189,255)`), **Fiord for dark** (enough contrast to see the hierarchy; keep Dark only if
the canvas must stay near-black).

## 3. Missing style-engine features, ranked by visual payoff
Current model (`crates/map-rendering/src/vector_style.rs:73-91, 617-641`): `source_layer`,
`geometry_kind` ∈ fill/line/circle, optional `filter {attribute_name, expected_text}` (text
equality only), `rgba`, `width_pixels`, `radius_pixels`. Layers apply in array order and are
flattened; nothing reads the camera zoom.

| Rank | Feature | Missing? | Payoff on the demo | Minimal additive schema |
|---|---|---|---|---|
| 1 | Road-class coverage, landuse/landcover expansion | No — data entry | **Highest**: colored road tiers, paths, more landuse, park/wood/grass | none; more layer entries |
| 2 | Casing | **No** — a data pattern; committed styles already stack wide under narrow | High (roads read as ribbons) | none (2 entries per class) |
| 3 | Opacity | No — alpha in `rgba` | Medium (park @0.2, industrial @0.34) | none; pre-multiply `fill-opacity` into alpha (Fiord building: 0.65 × 0.25 = 0.1625) |
| 4 | Zoom-dependent width/color | Yes | Low at fixed z14; high once the user zooms | `"width_pixels": {"stops": [[6, 0.6], [14, 12.07], [20, 18]]}`; keep the number form as shorthand |
| 5 | min/max zoom | Yes | Low at z14; high when zoomed out (otherwise every service road shows at z10) | `"min_zoom": 12, "max_zoom": 16` |
| 6 | Attribute matching beyond one exact string | Yes, mostly ergonomics | Low at z14; numeric filters only fix boundary classes and tunnels | extend `filter` with `matches_any: [...]` and `number_equals: 2`; keep `expected_text` |
| 7 | Line dashes | Yes | Low (1 path line, 1 railway, boundaries) | `"dash_pixels": [2, 2]` + a dash stage in the polyline pipeline |
| 8 | Layer ordering | No | — | none |
| 9 | Text / symbols / sprites | Yes, by design | Largest gap vs. the real styles, explicitly out of scope | later symbol slice |

Row 6 landed round 44: `VectorAttributeFilter` carries `matches_any` (several accepted text
spellings) and `number_equals` (a numeric value matched through every numeric wire variant),
with the artifact parser accepting either beside `expected_text`. The three committed styles
still keep their curated single-entry boundary layers, because the upstream numeric admin-level
filters match nothing in the demo tile (see the Fiord note below); the capability is there for
a provider whose tiles carry the values (`admin_level: 2`, tunneled road classes).

Per style: Bright needs ranks 1–2 (data only) for v1 and rank 5 to stay sane when zoomed out;
Fiord needs the same, plus rank 6 if its per-admin-level boundary colors are to survive — its
filters test `admin_level` numerically, the fixture has 6 and 10, and Fiord only matches 2 and 4,
so **faithful Fiord paints no boundary on the demo tile**; collapse to one curated entry instead.
Neither needs dashes for a respectable first cut; both need labels to look finished (separate
milestone). For rank 4–5, `vector_tile_overlays()` currently knows only the tile address
(`zoom_level` available); style application would take the camera zoom as an extra parameter.

## 4. Concrete proposal
### 4.1 Where the styles live
Transcribe into the two existing OpenMapTiles-schema artifacts, keeping the id model
`${schema}-${theme}` unchanged (`vector_style.rs:203-211`, `platform/web/tile_switch.mjs:261-267`):

- `crates/map-rendering/fixtures/render/vector-style-openmaptiles-light.json` ← Bright @ z14
- `crates/map-rendering/fixtures/render/vector-style-openmaptiles-dark.json` ← Fiord @ z14

A third named style (Positron) needs a style-family dimension (`schema-family-theme`), a
registry/contract change; defer until a style picker exists.

### 4.2 Light layer list (Bright, evaluated at z14)
Order = draw order; cite layer ids in `styles/bright/style.json`.

| # | source layer | kind | filter | color (RGBA) | width/radius | source layer id |
|---|---|---|---|---|---|---|
| 1 | landuse | fill | class=commercial | 0.948,0.792,0.792,0.23 | — | `landuse-commercial` |
| 2 | landuse | fill | class=industrial | 1.0,0.956,0.76,0.34 | — | `landuse-industrial` |
| 3 | landuse | fill | class=residential | 0.919,0.900,0.881,0.30 | — | `landuse-residential` (alpha 0.4→0.2 z12–16) |
| 4 | landuse | fill | class=school | 0.941,0.910,0.973,1 | — | `landuse-school` |
| 5 | landuse | fill | class=hospital | 1.0,0.867,0.933,1 | — | `landuse-hospital` |
| 6 | landuse | fill | class=cemetery | 0.878,0.894,0.867,1 | — | `landuse-cemetery` |
| 7 | landuse | fill | class=pitch | 0.812,0.902,0.757,1 | — | *retained from current artifact* (Bright has none) |
| 8 | landuse | fill | class=stadium | 0.882,0.894,0.910,1 | — | *retained from current artifact* |
| 9 | landcover | fill | class=grass | 0.847,0.910,0.784,1 | — | `landcover-grass` |
| 10 | landcover | fill | class=wood | 0.400,0.667,0.267,0.10 | — | `landcover-wood` |
| 11 | park | fill | — | 0.847,0.910,0.784,0.20 | — | `park` (opacity 0.2 at z14) |
| 12 | water | fill | — | 0.682,0.812,0.886,1 | — | `water` (#AECFE2) |
| 13 | building | fill | — | 0.949,0.918,0.886,1 | — | `building` (#f2eae2) |
| 14 | transportation | fill | class=pier | 0.973,0.957,0.941,1 | — | `road_area_pier` |
| 15 | waterway | line | — | 0.627,0.784,0.941,1 | 2.0 (river 2.53; streams 0.62–0.94) | `waterway-river`, `waterway-other` |
| 16–17 | transportation | line | class=motorway | casing 0.914,0.675,0.467,1 / fill 1.0,0.800,0.533,1 | 12.07 / 9.53 | `highway-motorway-casing`, `highway-motorway` |
| 18–19 | transportation | line | class=primary | `#e9ac77` / `#fea` | 10.36 / 8.06 | `highway-primary-casing`, `highway-primary` |
| 20–23 | transportation | line | class=secondary, tertiary | `#e9ac77` / `#fea` | 8.90 / 6.47 each | `highway-secondary-tertiary-casing`, `highway-secondary-tertiary` |
| 24–29 | transportation | line | class=minor, service, track | `#cfcdca` / `#fff` | 4.00 / 2.50 each | `highway-minor-casing`, `highway-minor` |
| 30 | transportation | line | class=path | 0.800,0.733,0.667,1 | 1.2 (dashed [1.5,0.75] in source → solid) | `highway-path` |
| 31 | transportation | line | class=rail | 0.733,0.733,0.733,1 | 1.2 (source 0.4 is invisible; deviation) | `railway` |
| 32 | boundary | line | — | 0.643,0.636,0.684,1 | 2.0 (source country 3, state 2 dashed) | `boundary_2`, `boundary_3` |
| 33 | place | circle | — | 0.49,0.51,0.55,0.60 | r 2.0 | stand-in for Bright's `place` symbols |

~33 entries (vs. 35 today). Deliberate deviations: no brunnel/ramp splits (tunnels render as
surface roads), no `building-top` fade, dashed paths/rail/boundaries drawn solid, pitch/stadium
kept from our artifact because Bright dropped them.

### 4.3 Dark layer list (Fiord, evaluated at z14)

| # | source layer | kind | filter | color (RGBA) | width/radius | source layer id |
|---|---|---|---|---|---|---|
| 1–3 | landuse | fill | class=commercial / industrial / residential | 0.110,0.106,0.118,1 / 0.102,0.110,0.118,1 / 0.098,0.106,0.122,1 | — | *retained from current dark artifact* (Fiord's residential filter is broken) |
| 4 | landcover | fill | class=wood | 0.246,0.260,0.354,0.57 | — | `landcover_wood` |
| 5 | park | fill | — | 0.291,0.362,0.410,0.30 | — | `park` |
| 6 | water | fill | — | 0.220,0.263,0.361,1 | — | `water` (#38435C) |
| 7 | building | fill | — | 0.095,0.118,0.265,0.1625 | — | `building` (0.65 × 0.25 opacity) |
| 8 | waterway | line | — | 0.220,0.263,0.361,0.60 | 1.8 | `waterway` |
| 9–11 | transportation | line | class=minor, service, track | 0.351,0.404,0.549,0.90 | 3.94 each | `highway_minor` |
| 12–17 | transportation | line | class=primary, secondary, tertiary | casing 0.351,0.404,0.549,1 / fill 0.235,0.263,0.341,1 | 10.38 / 8.64 each | `highway_major_casing`, `highway_major_inner` |
| 18–19 | transportation | line | class=motorway | casing 0.351,0.404,0.549,1 / fill 0.232,0.263,0.348,1 | 22.61 / 16.51 | `highway_motorway_casing`, `highway_motorway_inner` |
| 20 | transportation | line | class=path | 0.271,0.345,0.478,1 | 1.16 (dashed → solid) | `highway_path` |
| 21 | transportation | line | class=rail | 0.351,0.404,0.549,0.90 | 1.5 (source `hsl(200,10%,18%)` 3.0 is near-invisible; deviation) | `railway_dashline` |
| 22 | boundary | line | — | 0.609,0.740,0.911,0.56 | 2.0 (source 11.78; reduced for a solid hairline) | `boundary_country_z5-` |
| 23 | place | circle | — | 0.61,0.74,0.91,0.60 | r 2.0 | stand-in |

~23 entries (vs. 35 today). Fiord's boundary filters (numeric admin_level 2/4) match nothing in
the demo tile, so the curated single entry replaces them; its near-black rail and broken
residential landuse are replaced/retained as noted.

### 4.4 Theme clear colors
There is no background layer; the app clears the vector canvas per theme
(`platform/web/playground.mjs:1040-1043`). Set them to the style backgrounds:

- light: `{0.973, 0.957, 0.941}` (Bright `#f8f4f0`, was `0.94,0.93,0.90`)
- dark: `{0.271, 0.318, 0.431}` (Fiord `#45516E`, was `0.063,0.078,0.098`)

The dark change makes the canvas mid-blue instead of near-black, touching the "glass on glass"
panel assumption in `docs/ReferenceAppUX.md` §2 (line 135); design-review it, with Dark Matter
(`rgb(12,12,12)`) as the keep-the-canvas fallback.

### 4.5 "auto" policy
Locked today: two themes, dark default, never read the OS preference, not persisted
(`docs/ReferenceAppUX.md` §3; the web cycle is `dark → light` only, `playground.mjs:97`).

1. Ship Bright/Fiord behind the existing two-state toggle now. No auto.
2. If desired, file a PRD §6 ruling and add a **third explicit state**
   `dark → light → auto → dark`, session-scoped like the others (no persistence).
3. While auto is active, resolve `window.matchMedia('(prefers-color-scheme: dark)')` on selection,
   apply the matching style id and clear color, subscribe to the query's `change` event and
   unsubscribe on leaving auto. First paint stays dark until the user chooses auto, preserving the
   deterministic first-paint contract.
4. On a change, repaint panels (`data-theme`) and the vector base: `apply_theme()` and
   `refresh_vector_base_for_theme()` already exist (`playground.mjs:840-846, 1284`). Add a
   Playwright case with `page.emulateMedia({ colorScheme })` proving the change switches style id.

Native refapps (parked) mirror the tri-state with Compose `isSystemInDarkTheme()` in a
`LaunchedEffect` and iOS `traitCollectionDidChange`; no key or contract change.

### 4.6 Default provider / demo reachability
`VECTOR_BASE_MAP_DESCRIPTORS[0]` is `osmus` (Sourdough/carto), so the vector demo opens on the
carto family (`playground.mjs:1056-1062`). To show the new styles without a manual provider
switch, either prefer the `openmaptiles` descriptor as the initial vector provider (one
constant/selection change) or transcribe Bright into the carto artifact too (different source
vocabulary: `highways`, `buildings`, `places`). Recommend the former; the latter doubles the work
for no extra demo value.

## 5. Serving and redistribution
- Styles are normally served as **style JSON URLs**, not bundled:
  `https://tiles.openfreemap.org/styles/{bright,liberty,positron,dark,fiord}` (README + Quick
  Start). The JSONs are not standalone: `sources`, `glyphs` and `sprite` carry
  `__TILEJSON_DOMAIN__` placeholders that OpenFreeMap's server rewrites, and point at a remote
  `planet` TileJSON, fonts and sprites.
- **May we redistribute a derived copy? Yes.** MIT + BSD-3-Clause (code) + CC BY 4.0 (design) all
  allow it. Obligations: keep the copyright/license texts (MIT, BSD-3, CC BY 4.0, and the CartoDB
  CC BY 3.0 attribution for the lineage); credit OpenFreeMap, MapTiler/OpenMapTiles and
  CartoDB/Stamen/Paul Norman in docs/NOTICE and the map attribution surface; indicate that we
  changed the styles (subset, no symbols, filter fixes).
- Our artifacts stay data-only JSON (the test `the_style_artifact_is_provider_neutral_data`
  forbids `http`, `url`, `openstreetmap` in the default artifact). Put provenance/attribution in
  `docs/` + a NOTICE file, and add a `style_attribution` string to the provider descriptor when
  the style-family dimension lands. Tile data remains OSM ODbL, already attributed in
  `platform/providers.json:62-63`.

## 6. Integration risks and test impact
- The committed files are the demo's only style source; changing them changes overlay counts and
  colors. Tests assert the four ids parse, differ per theme, and that the OpenMapTiles fixture
  paints fill/line/point (`vector_style.rs:1150-1215`); they do not pin layer counts, and the
  Playwright vector tests assert finiteness/kind, not pixels
  (`platform/web/tests/vector_layer.spec.mjs:152-193`). No golden PNG covers the vector base;
  `fixtures/render/golden/*.png` are raster/marker goldens and are unaffected.
- The in-code fallback (`in_code_default_vector_tile_style`) mirrors only the carto default, so
  no fallback change is needed for the OpenFreeMap artifacts.
- Widths transcribe 1:1: the camera world is `MERCATOR_TILE_SIZE_PIXELS = 512`
  (`crates/map-rendering/src/projection.rs:15`), the convention the MapLibre styles assume. Verify
  once against the golden camera: Bright's motorway casing is 12.07 px vs. our 7.2 px and will
  read noticeably bolder. Fiord is upstream-unfinished; treat transcription as curation, not a
  port, and note each deviation in the commit/CHANGELOG.

## 7. Open questions for the owner
1. Accept Fiord's `#45516E` canvas (changes the dark "glass on glass" look) or stay near-black
   with Dark Matter?
2. Is a style picker in scope (needs a `schema-family-theme` id dimension + registry field), or
   do Bright/Fiord simply replace the two OpenMapTiles palettes?
3. Does "auto" overturn the §3 no-OS-preference ruling? If yes, is the tri-state above the right
   shape (dark default, auto session-scoped, live `matchMedia` updates)?
