# Vector-tile latency and label quality

Date: 2026-11-01. Status: the vector payload cache, prefetch, progressive draw
and diagnostics landed; motion grading remains open. Repeated line labels
landed; collision padding and priority, regional thinning and the typography
audit remain open. Research for the owner's reports that the
Android reference app feels slow when switching to the OpenStreetMap US vector
tiles, and that iOS label rendering is not yet as smooth as the reference maps
(Google Maps, HERE, Mapbox, MapLibre).

## Landed and open

| Measure | Status |
|---|---|
| Persistent vector payload cache | Landed: native payloads share the installed SQLite tile cache at the 30-day vector TTL, plus a TTL'd in-memory LRU. Native caching needs the tile cache installed before the source. |
| Prefetch | Landed: same-zoom neighbours plus coarse parents, parents first, budget 32 tiles, at most one plan per 500 ms, detached and cancellable. Next-zoom-step children remain a follow-up. |
| Progressive draw | Landed: the wasm canvas resolves decoded tiles and detached prefetches, and a missing child is covered by its nearest cached ancestor. |
| Motion grading | Open. |
| Diagnostics | Landed in the renderer and wasm status; native `FrameStatistics` is a frozen record, so surfacing the counters there needs an addition-only contract wave. |
| Repeat line labels | Landed: names repeat along a long run, spaced at least 90 px, each rotated to its segment. |
| Collision padding, per-glyph boxes, priority | Open. |
| Regional label thinning | Open. |
| Typography audit | Open. |

The analysis below records the state the report found.

## Why the vector base feels slow

The vector path fetches tiles only when the camera asks for them and only for
the tiles inside the viewport:

- `VectorBaseScheduler::resolve_frame` lists the visible tiles at the served
  zoom, fetches the missing ones through the provider, decodes and styles them,
  and builds the frame. There is no prefetch of the next zoom level or the ring
  around the viewport, and no per-tile cache shared between frames beyond the
  scheduler's styled-tile cache (keyed by style revision, bounded in memory).
- On the native platforms the vector provider goes straight to the network
  through the portable transport. The `rustic-maps-cache` store (SQLite,
  TTL/LRU/quota) is wired to the response categories but not to the vector-base
  scheduler, so a reload of the same region fetches it again.
- The tile service itself may be slow from the device's network, and the
  OpenStreetMap US tileservice's terms are low-volume and non-commercial: a
  client that hammers it will also be throttled. Both reasons point the same
  way — cache and prefetch locally, and render progressively rather than
  blocking on the network.

The raster path already has the countermeasures the vector path lacks: a tile
texture pool, parent-tile fallback while children load, a fetch budget per
frame, and (on the browser) a detached prefetch of the next ring. The vector
scheduler should reach parity.

## The measures, in value order

1. **Persist vector tiles.** Put vector payloads through the same cache the
   raster path uses (per-provider TTL ceiling, LRU, quota) plus the bounded
   in-memory payload cache. A region browsed once is then instant on the next
   session, and the service sees one fetch per tile per TTL window. The
   provider descriptor already declares the tile-imagery policy (30 days).
2. **Prefetch deliberately.** After a frame settles, prefetch the ring around
   the viewport at the served zoom and the parent/child of the next zoom step,
   with a small budget (a few tiles per frame) and a cancellable queue.
   MapLibre and Mapbox call this the tile pyramid's idle prefetch; it turns the
   first pan into a cache hit.
3. **Render progressively.** Draw a parent tile scaled up while the child is in
   flight (the raster path's `FallsBackTo` semantics), and never block the
   frame on a fetch. A vector frame with some missing tiles should draw the
   ones it has and report the rest, exactly as the raster scheduler does.
4. **Grade the work by camera motion.** During a gesture, draw from the cache
   at the current zoom and defer style/label assembly of new tiles to the
   settle; after a short idle, resolve the full frame. MapLibre's render modes
   (`Continuous`, `Still`, `Off`) are the reference shape; our equivalent is a
   scheduler mode with a motion heuristic.
5. **Reduce per-tile cost.** The styled-tile cache keyed by style revision
   already avoids restyling; measure decode and style time per tile and add a
   decoded-geometry LRU if decode dominates. Compression (gzip) and persistent
   connections are transport concerns; the browser `fetch` transport gets them
   for free, `reqwest` needs the rustls/http2 features verified.
6. **Report it.** The frame statistics should carry vector cache hits, in-flight
   fetches and the time to first drawn tile, so a device measurement answers
   "is it the server?" with data instead of a guess.

## Label quality

Today the label pipeline places point and line candidates with greedy collision
rejection and a per-frame cap, drawing SDF glyphs from a packed atlas. The
gaps against the reference maps are placement and typography, not the atlas:

- **Road names repeat along the line.** MapLibre places a name every N pixels
  along a long road rather than once at its midpoint, with the glyphs following
  the line's curve. Our line placement currently draws one label per feature.
- **Collision padding and spacing.** The greedy test uses a padded rectangle;
  the reference engines use per-glyph boxes, a spacing between repeated labels
  and a priority-ordered retry. A slightly larger padding and a repeat distance
  are the visible fixes.
- **Priority.** Style priority should order by road class first (motorways over
  residential), then by feature rank; shields draw before names.
- **Point labels at regional zooms.** City labels should thin by rank as the
  camera widens and grow with zoom (the size stops exist; the rank filter needs
  to use them consistently).
- **Typography.** The halo width, text size stops and the SDF threshold curve
  are style data; the iOS report of "labels not there yet" is most likely the
  point-label density and the line-name repetition rather than glyph quality.
  A side-by-side capture against the Bright style at the same camera is the
  first diagnostic.

## Plan

`PLAN.md` M38 carries the vector latency slices (persistent cache, prefetch,
progressive draw, motion grading, diagnostics) and M39 carries the label
slices (repeat along lines, collision padding and priority, regional thinning,
typography audit), each with a measured or golden proof. The browser's frame
statistics and the native headless harness are the measuring instruments; the
committed z9 Carto golden is the label regression fixture.
