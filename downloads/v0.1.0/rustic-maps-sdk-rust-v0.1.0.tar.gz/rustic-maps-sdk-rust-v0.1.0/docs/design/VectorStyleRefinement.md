# Vector style refinement: road hierarchy, widths and labels

Date: 2026-11-01. Status: slices 1–3 landed, and slice 4's native half landed.
The browser regional golden, the before/after numbers and place-label thinning
at z9–11 remain open. Research for the owner's report that the
OpenStreetMap US Carto styles look "messy at 3 km — all roads overlap and look
very thick" compared with Google Maps, HERE, Mapbox and MapLibre.

## What the screenshots show

The live demo's 3 km scale bar puts the camera around zoom 9 over California's
Central Valley. The frame draws every road class at the same weight and with
the same paint at every zoom: motorways, trunk routes, primaries, secondaries,
tertiaries, residential streets, service roads and pedestrian ways all render,
each with a fixed pixel width (motorway 7.2 px, primary 4.2 px, residential
2.1 px). At that scale the network is a dense orange mesh rather than a
hierarchy, and the thick casings on motorways and trunks dominate the map.

## What the styles actually declare

Every committed style artifact was transcribed from an upstream style but lost
its zoom behaviour in the process:

| Artifact | Road line layers | With width zoom stops | With per-class min zoom |
|---|---|---|---|
| `vector-style.json` (Carto light) | 19 | 0 | 0 |
| `vector-style-dark.json` (Carto dark) | 19 | 0 | 0 |
| `vector-style-bright-light.json` | 16 | 2 | 0 |
| `vector-style-fiord-dark.json` | 13 | 2 | 0 |
| `vector-style-positron-light.json` | 13 | 1 | 0 |
| `vector-style-openmaptiles-light.json` | 10 | 0 | 0 |

The renderer already supports both mechanisms: `VectorLayerStyle` carries
`width_zoom_stops` with linear interpolation (`width_pixels_at_zoom`) and a
per-layer `min_zoom_level` (`is_visible_at_zoom`). The Carto styles simply never
use them, and the named styles use stops on only a couple of layers. Upstream
Mapbox/MapLibre styles express road paint as
`interpolate` expressions over zoom with an exponential base (commonly 1.5)
plus `minzoom` per class; a transcription that takes only the base value keeps
the colour and loses the hierarchy.

## What the reference engines do

- **MapLibre / Mapbox styles (Bright, Fiord, Positron, Carto).** Road width is
  a zoom interpolation per class; class `minzoom` hides residential streets
  until the mid-teens and service roads later still; casings are drawn only for
  the motorway/trunk tiers and disappear at low zoom.
- **Google Maps.** At a 3 km bar only motorways, trunk routes, primaries and
  some secondaries draw; widths are a fraction of a pixel to about two pixels;
  route shields carry the hierarchy instead of line weight. Minor roads appear
  as the camera crosses roughly z12–13.
- **HERE.** Same class-gated hierarchy with an emphasis on legibility of
  route numbers at regional zooms; line widths are capped until the street
  grid is meaningful.
- **MapLibre Native's renderer.** Width comes from the style, not from the
  renderer; its default styles use the same interpolation tables as GL JS.
  There is no renderer-side "thin the roads" heuristic to borrow: the fix is
  data.

## The plan

### Slice 1 — Carto light and dark (the reported styles) — **landed 2026-11-01**

Every road layer in `vector-style.json` and `vector-style-dark.json` now carries
a per-class `min_zoom` and a width-stop curve, and the in-code fallback mirrors
the same table (the artifact/fallback equality test still holds). A unit test
asserts both themes: at zoom 9 only motorway, trunk, primary and secondary
paint, none wider than 3.5 px; the motorway fill interpolates to 2.45 px; the
street grid is absent until its class zoom and paints 1.2 px at z16. The
renderer suite, the wasm build and the 125-test browser suite pass.

Give every road layer a per-class `min_zoom` and a width-stop curve, and mirror
the same table in the in-code fallback so the artifact/fallback equality test
keeps its meaning. Target behaviour, in screen pixels:

| Class | Min zoom | Width at its first zoom | Width at z16 | Casing |
|---|---|---|---|---|
| motorway, trunk (and links) | 4 | 0.9 | 6.3 | yes, ~1.4 px over the fill, same stops |
| primary (and links) | 7 | 0.7 | 3.5 | no |
| secondary (and links) | 9 | 0.6 | 2.2 | no |
| tertiary (and links) | 11 | 0.5 | 1.5 | no |
| residential, unclassified, living street | 12 | 0.4 | 1.2 | no |
| service | 15 | 0.4 | 0.9 | no |
| pedestrian | 14 | 0.5 | 1.2 | no |

Links paint 0.8 of their parent class. Stops run at the class's first zoom and
then at 8, 10, 12, 14, 16 and 18, so interpolation is smooth rather than a
one-step jump. The result at zoom 9: motorway/trunk ribbons of about 2 px with
a thin casing, primaries around 1 px, secondaries barely visible, and no street
grid at all.

### Slice 2 — the other schema styles — **landed 2026-11-01**

Bright, Fiord, Positron and both OpenMapTiles artifacts now carry per-class
minimum zooms and width curves anchored on each layer's existing city-zoom
width, so the committed z14 goldens render unchanged while regional frames
thin out. A unit test asserts every style: at zoom 9 each visible road is at
most 60% of its city weight and no minor, residential, service, track, path or
pedestrian class paints. The native styled-base goldens (Bright and
OpenMapTiles light) and the 125-test browser suite pass unchanged.

Apply the same class table, adapted to each schema's class names and palettes,
to Bright, Fiord, Positron and both OpenMapTiles artifacts. Bright and Fiord
also carry a handful of width stops today; they become the full curve.

### Slice 3 — labels at regional zooms — **shields landed 2026-11-01**

A route-shield symbol layer on the `highways` source layer now reads its text
from `ref`, draws from z5 to z12 with size stops, and sits at priority 0 ahead
of place labels; the recorded z9 OpenStreetMap US tile confirms the attributes
(I 5, I 80, CA 99, US 50) and a unit test pins the shields on both Carto
themes. Place-label thinning at z9–11 remains.


- Keep the road-name layers' per-class `min_zoom` (motorway from 10 and the
  minor classes from 15) so names appear with the roads they name.
- Add **route shields**: a symbol layer on the `highways` source layer whose
  text falls back to `ref` before `name`, drawn from z5 to about z11 on the
  motorway/trunk features. Google and HERE carry the hierarchy with numbers at
  exactly the zoom the screenshots show. The feature attribute must be verified
  against a recorded OpenStreetMap US tile first (the committed Sourdough
  fixture is a z6 tile with no highway names or refs).
- Re-check place-label density at z9–11: city and town ranks should thin the
  list so regional labels do not collide with the road network.

### Slice 4 — proof — **native half landed 2026-11-01**

The z9 tile over the demo's California region is a committed fixture with a
registry route (`fixtures/openstreetmap-us/osmus_tile_z9_x83_y196.mvt`), and
`sacramento_region_zoom9_carto_light.png` pins the regional Carto frame: thin
motorway ribbons with casings, hairline primaries and secondaries, route
shields and city labels, on the style's own paper background. The surfaces now
clear to the style background (the headless capture gained
`set_clear_color_rgba`, which also fixed the black-backed Bright and
OpenMapTiles goldens). Remaining: a browser golden beside the per-style set and
the before/after numbers below.


- Unit tests: `width_pixels_at_zoom` and `is_visible_at_zoom` assertions per
  class for every artifact (the table above is the expectation).
- A recorded **z9 OpenStreetMap US tile fixture** (one tile over the demo's
  California area) and a golden rendered from it, so the reported frame's
  look is pinned the way the Sacramento z14 goldens pin the city zoom. The
  recording tool is a dev-time seam; the test itself uses the committed
  fixture served same-origin.
- Browser golden for Carto light at the regional zoom, alongside the existing
  per-style goldens.

### Renderer follow-ups (only if the data is not enough)

- The width interpolation is linear between stops. Mapbox styles often use an
  exponential base (1.5); a few well-placed stops approximate it closely. If a
  future style needs the exponent, add an optional
  `width_zoom_stops[i].interpolation` field to the artifact schema (additive)
  rather than a renderer special case.
- Line caps and joins are the WGSL shader's; the thick-overlap look is a width
  problem first. Revisit joins only after the widths are correct.

## Why not a renderer heuristic

A renderer that thinned roads by zoom would override the style's intent and
make every schema behave the same. The reference engines keep the policy in
the style data; so does this plan.
