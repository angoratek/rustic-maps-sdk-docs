# Choosing a provider per capability

Date: 2026-11-01. Status: design and landed. The contract wave, the native
catalog, both routing crates, the registry descriptors and the
foreign-implementation surface for all eight provider contracts landed the
same day; the per-capability settings rows and the on-map layer control remain
open in `PLAN.md` M40 and M41. This document answers the owner's questions —
can a platform add any kind of provider, not only geocoding and tiles; how
does a Rust provider crate reach an Android or iOS app; and can one map
already mix MapQuest geocoding, OpenStreetMap US vector tiles and a
third-party routing engine at the same time.

## What already works

The core selects per capability and always has. `ProviderRegistry` holds one
slot per contract — geocoding, routing, distance matrix, place search, traffic
incidents, traffic flow, elevation, raster tiles, vector tiles, offline routing
— and registering one replaces only that slot. A call into an empty slot
returns `ProviderNotConfigured` naming the contract, never a wrong-provider
answer.

The application surfaces carry that model for the capabilities that grew a
registration of their own:

| Capability | How an app sets it today | Replaces only its slot |
|---|---|---|
| Geocoding | `MapSdk.set_provider_credential` (whole MapQuest set) or `register_geocoding_provider_from_foreign` | Foreign yes; credential no |
| Raster tiles | `register_url_template_raster_tile_source` or `register_raster_tile_provider_from_foreign` | yes |
| Vector tiles | `MapView.set_vector_tile_source` | yes |
| Routing, matrix, search, traffic, elevation | `set_provider_credential` only | no |

So a reference app already mixes providers for the base map: a MapQuest
credential serves the seven vendor capabilities while a URL-template or styled
vector source serves the imagery. What it cannot do is choose a *routing*
provider that differs from the credential's vendor, because no contract call
installs one — and `set_provider_credential` is vendor-named, so the only
whole-set installer is one company's.

## The gap, stated precisely

1. **No per-capability registration on the contract.** There is no call that
   says "routing comes from this provider key with this credential".
2. **No readback.** An app cannot ask which provider serves a capability, so
   it cannot render the serving provider in settings or restore a choice.
3. **No compiled-in catalog.** The native binding knows how to construct one
   vendor's set. A second routing crate would compile into the binary and be
   unreachable.
4. **Only two contracts were host-implementable** at the time of this design:
   Kotlin and Swift could implement geocoding and raster tiles, so a
   developer could not supply a routing implementation from app code either.
   Landed: every contract now has a `[Trait, WithForeign]` interface and a
   `register_*_from_foreign` call, and elevation gained the
   `fetch_elevation_points` call that consumes its slot.

## The contract addition

One addition-only wave (no existing member changes meaning):

```
enum ProviderContract {
    "Geocoding", "Routing", "DistanceMatrix", "PlaceSearch",
    "TrafficIncidents", "TrafficFlow", "Elevation",
    "RasterTiles", "VectorTiles", "OfflineRouting",
};

dictionary ProviderRegistration {
    ProviderContract contract;
    string provider_key;
    string display_name;
    boolean registered;
};

[Throws=SdkError]
void configure_provider(ProviderContract contract, string provider_key, string credential);

sequence<ProviderRegistration> provider_registrations();
```

Semantics:

- `configure_provider` replaces exactly one slot. Every other slot keeps
  serving. Succeeding is the only way the slot changes; a refused key or
  credential leaves the previous provider in place and throws with the reason.
- An empty `credential` is legal for a keyless provider (a URL-template source,
  a self-hosted OSRM server) and refused for a provider whose descriptor
  declares a credential label.
- `provider_registrations` reports every capability in a stable order with the
  serving key, the descriptor's display name, and whether a provider is
  installed. An app renders its settings rows from this list plus the shared
  descriptor registry, so no capability name is hardcoded in a shell.
- `set_provider_credential` keeps working exactly as today as the one-call
  convenience. It becomes a wrapper that calls `configure_provider` for each
  capability its vendor serves, which is what makes it provider-neutral code
  rather than a vendor branch.

Foreign implementations stay as they are for the two contracts that allow
them. `configure_provider` and a foreign registration write the same slot;
last write wins, and the readback reports it.

## The native catalog

`rustic-maps-native-core` gains one table mapping a provider key to a
constructor that returns the set of contracts that key serves:

| Key | Capabilities | Credential |
|---|---|---|
| `mapquest` | geocoding, routing, distance matrix, place search, traffic incidents, traffic flow, raster tiles | required |
| `osrm` | routing | optional base URL, no key |
| `valhalla` | routing | optional base URL, no key |
| `openstreetmap` | raster tiles | none |
| `osmus`, `openfreemap` | vector tiles | none |

The table is the only place a provider name reaches the binding, next to the
descriptors and the dispatch arms the guard already allows. Adding a provider
is a crate, a descriptor, a table row, and nothing else — the same "would this
work unchanged for a second provider?" question, answered yes by construction.

## Why OSRM and Valhalla first

Both are ordinary HTTP routing APIs, so each becomes a `RoutingProvider` crate
with committed fixture responses and no network in tests. OSRM is the
keyless/self-hosted demo path; Valhalla carries richer maneuver text and was
already recorded in `PRD.md` §6 item 6 as the future routing option. Together
they make "different provider per capability" demonstrable end to end: the
demo plans the same route through MapQuest and through OSRM from committed
payloads and shows which one served.

## What the applications show

The settings surface gains one row per capability from
`provider_registrations()`, ordered Geocoding, Routing, Place search, Distance
matrix, Traffic incidents, Traffic flow, Elevation, Raster tiles, Vector
tiles, Offline routing. Each row shows the serving provider's display name and
a picker limited to descriptors that declare that capability for the platform.
The choice joins the existing versioned preferences record in every app, so a
relaunch restores it; a capability with no installed provider reads
"Not configured" rather than an empty control.

## Documentation

`adding-a-provider.md` gains the missing half of Route 1: after registering the
crate in the core, the page shows the exact Kotlin, Swift and TypeScript calls
that make the key selectable, the descriptor entry the settings surface reads,
and the two-call sequence a developer writes — register the key once at
startup, then `configureProvider` when the user picks it. The page states
plainly that compiling a crate into the binding does not make it selectable by
itself; the catalog row is what does.

A new page, *Mix providers per capability*, walks the MapQuest-geocoding +
OpenStreetMap-US-tiles + OSRM-routing combination end to end and shows the
settings rows it produces.

## Tests

- Rust: the catalog constructs each key and reports its contracts; an unknown
  key throws `ProviderNotConfigured` naming it; a refused credential leaves the
  previous provider serving; `set_provider_credential` still installs the whole
  vendor set.
- OSRM and Valhalla: wiremock tests over committed fixtures for success, a
  documented refusal, a transport failure, and an unparseable payload.
- Browser: a case configures routing to a second provider, plans from the
  fixture, reloads, and sees the choice restored and the route served.
- Android and iOS: the same case through the settings surface on the standing
  devices.
- The provider-name guard keeps passing: the new names appear only in their
  crate, their sample-data directory, the descriptor and the catalog row.
