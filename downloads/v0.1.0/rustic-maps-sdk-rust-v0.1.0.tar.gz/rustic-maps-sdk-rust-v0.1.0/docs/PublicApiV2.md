# Public API v2 — naming, `MapView` and the one-contract goal

**Status:** specification input for M17 (`PLAN.md`), owner-directed 2026-10-29.
**Scope:** every developer-facing surface — the UDL contract, the Kotlin, Swift,
React Native and WebAssembly bindings, and the reference applications.

This document records the vendor survey, the naming rules we adopt, the exact
`MapView` surface, and the WebAssembly decision. It is the reference the M17
work items are checked against; the site's tutorials are rewritten from it once
each slice lands (M18).

## Owner rulings behind this document (2026-10-29)

- The SDK API redesign and the documentation restructure run **in parallel**.
- The breaking rename reaches the public surfaces, the UDL contract, the
  bindings namespace and the Rust crate names.
- WebAssembly keeps `wasm-bindgen` underneath and gains a **contract-identical
  façade** (`MapView`, camelCase, the same records); ubrn's web target stays
  deferred behind its uniffi 0.31 pin.
- `MapView` is a **full map widget**: it owns the surface, the frame pump, the
  lifecycle, gestures, camera control, overlays and listeners.
- The contract may break until 1.0; every break ships with its regenerated
  bindings, reference apps and docs in the same commit.

## 1. What the industry converges on

Read from the live references (URLs in §8), five patterns are unanimous:

1. **`MapView` is the noun everywhere.** HERE, Mapbox, Google, MapLibre Native and
   flutter_map all name the embeddable surface `MapView`. HERE and Mapbox also expose a
   lower-level `MapSurface`, but that is the *external-surface* variant (Android Auto,
   CarPlay), never the developer's entry point.
2. **Lifecycle is forwarded verbatim.** HERE, Google and MapLibre require
   `onCreate / onStart / onResume / onPause / onStop / onDestroy` on Android; Mapbox v11
   requires `onStart / onStop / onDestroy / onLowMemory`. iOS needs nothing (a `UIView`).
3. **Readiness is a named callback, never an implied side effect of construction.**
   HERE `MapView.OnReadyListener.onMapViewReady()`, Google/MapLibre
   `OnMapReadyCallback.onMapReady(...)`, Mapbox `subscribeMapLoaded`. It gates picking,
   projection and camera reads.
4. **Capabilities are separate engine objects.** HERE `SDKNativeEngine` +
   `SearchEngine`/`RoutingEngine`/`Navigator`/`MapDownloader`; Mapbox `MapView.mapboxMap`
   + `MapboxNavigation`; Google `GoogleMap` + separate Places/Directions SDKs. **No
   vendor hangs search, routing, navigation and offline on one god object.**
5. **The camera is an immutable value plus a small verb set on the view.** `CameraOptions`
   (Mapbox), `CameraPosition` (Google), `MapCamera` + `MapCameraUpdateFactory` (HERE),
   `CameraUpdate` (MapLibre); verbs are `setCamera` / `moveCamera` / `animateCamera` /
   `easeCamera` / `fitBounds`.

Two anti-patterns to avoid: Google's `CameraUpdateFactory` (a static factory whose only
job is wrapping a builder), and MapLibre's three parallel camera verbs for one operation.

---

## 2. Master mapping table

Spelling shown is as a developer types it in Kotlin / Swift / TypeScript. UniFFI
camelCases UDL `snake_case` automatically, so the UDL keeps snake_case; the column is
the *consumer-facing* name.

| Concept | HERE | Mapbox v11 | Google | OSM / MapLibre | Ours today | Proposed |
|---|---|---|---|---|---|---|
| SDK root object | `SDKNativeEngine` (shared instance) | `MapboxMapsOptions` + `MapView` | `MapsInitializer` | `MapLibre.getInstance` | `MapSdk` | **`MapsSdk`** (Rust type stays `MapSdk`) |
| Embeddable map surface | `MapView` (`FrameLayout`) | `MapView` | `MapView` / `GMSMapView` | `MapView` / `FlutterMap` | `MapSurfaceView` (UDL), `GpuMapCanvas` (wasm) | **`MapView`** |
| Platform surface handle | — (internal) | `MapSurface` (`TextureView`/`SurfaceView`) | — | `NativeMapView` | `MapSurfaceTargetHandle` | **`SurfaceHandle`** (internal, hidden) |
| Lifecycle | `onCreate/onResume/onPause/onDestroy` | `onStart/onStop/onLowMemory/onDestroy` | `onCreate…onDestroy` + `onSaveInstanceState` | `onCreate…onDestroy` + `onSaveInstanceState` | `attach` / `resize` / `detach` / `draw` | **`onStart/onStop/onDestroy`**; `attach/detach` stay internal |
| Readiness | `MapView.OnReadyListener.onMapViewReady()` | `MapLoadedCallback` | `OnMapReadyCallback.onMapReady` | `OnMapReadyCallback.onMapReady` | none (only `frame_settled`) | **`MapView.OnReadyListener.onMapReady(mapView)`** |
| Camera value | `MapCamera` | `CameraOptions` / `CameraState` | `CameraPosition` | `CameraPosition` | `MapCamera` | **`MapCamera`** (keep) |
| Apply camera | `mapView.camera.lookAt(...)` | `mapboxMap.setCamera(CameraOptions)` | `moveCamera(CameraUpdate)` | `map.animateCamera(CameraUpdate)` | `new MapCamera(...)` then `draw(camera)` | **`mapView.setCamera(camera)` / `animateCamera(camera, durationMs)`** |
| Fit bounds | `MapCameraUpdateFactory.newLookAt(GeoBoundingBox)` | `cameraForCoordinateBounds(...)` | `CameraUpdateFactory.newLatLngBounds` | `getCameraForLatLngBounds` | `MapCamera(bounds, viewport, insets, maxZoom)` constructor | **`mapView.fitBounds(bounds, edgeInsets, maximumZoom)`** |
| Camera getters | `mapView.camera` | `mapboxMap.cameraState` | `map.getCameraPosition()` | `map.getCameraPosition()` | `MapCamera.center()/zoomLevel()/bearingDegrees()/pitchDegrees()` | **`mapView.camera` (value) with those getters** |
| Marker | `MapMarker` | `PointAnnotationManager` | `Marker` (`GMSMarker`) | `PointAnnotationManager` | `MapOverlayDescriptor(kind = PointMarkers)` | **`Marker`** |
| Polyline | `MapPolyline` | `PolylineAnnotationManager` | `Polyline` | `LineAnnotationManager` | `MapOverlayDescriptor(kind = RoutePolyline)` | **`Polyline`** |
| Polygon | `MapPolygon` | `PolygonAnnotationManager` | `Polygon` | `FillAnnotationManager` | `MapOverlayDescriptor(kind = FilledPolygon)` | **`Polygon`** |
| Overlay collection | `mapView.mapScene.addMapPolyline(...)` | `mapboxMap.annotations` | `googleMap.addMarker(...)` | `map.addMarkers(...)` | `setOverlays(list)` / `clearOverlays()` | **`mapView.addOverlay(...)`, `removeOverlay(handle)`, `clearOverlays()`** |
| Location puck | `LocationIndicator` | `LocationPuck2D/3D` | `MyLocation` layer | `LocationComponent` | `set_location_indicator` / `clear_location_indicator` | **`mapView.locationIndicator.show(...)` / `.hide()`** |
| Search | `SearchEngine` | `SearchEngine` (`mapbox-search-android`) | Places SDK (`PlacesClient`) | Places plugin | `MapSdk.forwardGeocode` / `searchPlaces` / `searchAutocomplete` | **`SearchEngine.search(query, boundary)` / `suggest(query)` / `reverseGeocode(coordinate)`** |
| Routing | `RoutingEngine.calculateRoute(with:options:)` | `MapboxDirections` | Directions API | — (none on-device) | `MapSdk.calculateRoute(waypoints, options)` | **`RoutingEngine.calculateRoute(waypoints, options)`** |
| Distance matrix | `RoutingEngine.calculateRoute` overload | Matrix API | Distance Matrix API | — | `MapSdk.calculateDistanceMatrix` | **`RoutingEngine.calculateDistanceMatrix(origins, destinations, mode)`** |
| Traffic | `TrafficEngine` | — | — | — | `MapSdk.fetchTrafficIncidents` / `fetchTrafficFlow` | **`TrafficEngine.incidents(bounds)` / `.flow(bounds)`** |
| Navigation | `Navigator` / `VisualNavigator` | `MapboxNavigation` / `NavigationMapView` | Navigation SDK (`NavigationView`) | — | `MapNavigationController` | **`Navigator`** |
| Start navigation | `navigator.startRoute(...)` | `navigation.startTrip(...)` | `NavigationLauncher` | — | `start_trip(route, ...)` | **`navigator.startNavigation(route, options)`** |
| Stop navigation | `navigator.stop()` | `navigation.stop()` | — | — | (none) | **`navigator.stopNavigation()`** |
| Location feed | `LocationEngine` → updates | `location` provider | — | `LocationComponent` | `provide_location_update(update)` | **`navigator.updateLocation(update)`** |
| Reroute | `RoutingEngine` + `Navigator` callbacks | `NavigationRoute` refresh | — | — | `provide_reroute` / `begin_reroute_calculation` | **`navigator.applyReroute(route)`**; gate stays internal |
| Navigation events | `NavigatorListener` | `NavigationListener` | `NavigationListener` | — | `NavigationStateEventListener` + 4 `subscribe_to_*` | **`NavigationListener` + `navigator.addNavigationListener { }`** |
| Subscription handle | `NavigatorListener` remove | `Cancelable` | `ListenerRegistration` | `Cancelable` | `NavigationTopicSubscription.cancel()` | **`Subscription.cancel()`** (keep shape) |
| Offline downloads | `MapDownloader` / `MapUpdater` / `OfflineSearchEngine` | `OfflineManager` / `OfflineRegion` | — | `OfflineManager.createOfflineRegion` | `register_mapquest_providers_with_tile_cache` + `set_raster_tile_cache_time_to_live` | **`OfflineManager.downloadRegion(region)`, `.tileCacheSettings`, `.setTileTimeToLive(seconds)`** |
| Offline progress | `MapDownloader` progress | `OfflineRegionObserver.onStatus` | — | `OfflineRegionObserver` | `TileFrameStatistics` only | **`RegionDownload.task.addProgressListener`** (`completedTileCount` / `requiredTileCount` / bytes) |
| Provider credential | `SDKOptions(AuthenticationMode.withKeySecret)` | `MapboxOptions.accessToken` | manifest API key | style URL | `register_mapquest_providers(key)` | **`maps.setProviderCredential(credential)`** (all-in-one) or **`maps.configureProvider(contract, providerKey, credential)`** (one capability) |
| Provider instance | engine constructor injection | `MapboxOptions` | `MapsInitializer` | `MapLibre.setHttpClient` | `register_*_provider_from_foreign(...)` | **`maps.configureProvider(contract, providerKey, credential)`** for a built-in key; a foreign object uses the matching `register_*_from_foreign` call. The `maps.providers.register(provider)` façade is **not landed** |
| Base-map / style | `mapScene.loadScene(MapScheme)` | `loadStyle(StyleURI)` | `GoogleMap.setMapType` | `setStyle(url)` | (raster/vector tile source on the canvas) | **`mapView.setStyle(MapStyle)` + `maps.tileProviders.setRasterSource(source)`** |
| Diagnostics | — | `MapboxMaps` logging | — | — | `subscribe_to_diagnostic_events` / `flush_recent_diagnostic_events` | **`maps.diagnostics.addListener(listener, minimumSeverity)` / `.flushRecent(maximumCount)`** |
| Errors | typed `SDKError` | `MapboxMap` throws | logs + callbacks | throws | `SdkError` | **`SdkException`** (keep the UDL type name `SdkError`) |

**Verdict on our vocabulary:** coordinates, tiles, camera value and progress records are
already better named than most vendors' (`GeographicCoordinate` beats `LatLng`, `Point`,
`CLLocationCoordinate2D`). Everything *above* the record layer — the root object, the
view, the navigation controller and the wasm names — is where the drift is.

---

## 3. Naming rules (adopt these as review criteria)

- **R1 — Noun-first types.** `MapView`, `MapCamera`, `MapStyle`, `SearchEngine`,
  `RoutingEngine`, `Navigator`, `OfflineManager`. Never `MapViewHost`, `MapSurfaceHost`,
  `CanvasManager`.
- **R2 — One concept, one word, everywhere.** Pick *view*, *camera*, *marker*,
  *polyline*, *polygon*, *route*, *navigation*, *navigator*, *region*, *provider*,
  *credential*, *listener*, and never alternate with *surface*, *scene*, *puck*, *trip*,
  *subscription* (as a noun for the thing you listen to).
- **R3 — Engine = noun + verb methods.** `SearchEngine.search`, `RoutingEngine.calculateRoute`,
  `Navigator.startNavigation`, `OfflineManager.downloadRegion`.
- **R4 — Approved verbs.** `search`, `suggest`, `reverseGeocode`, `calculateRoute`,
  `calculateDistanceMatrix`, `startNavigation`, `stopNavigation`, `updateLocation`,
  `setCamera`, `animateCamera`, `fitBounds`, `addOverlay`, `removeOverlay`,
  `clearOverlays`, `setProviderCredential`, `configureProvider`,
  `providerRegistrations`, `register`, `downloadRegion`,
  `deleteRegion`, `addListener`, `removeListener`, `cancel`.
- **R5 — Booleans read as questions.** `isFrameSettled`, `isNavigationActive`,
  `isOffline`. Never `frame_settled` on a foreign surface.
- **R6 — Events are `on<PastParticiple>` on a listener interface.** `onMapReady`,
  `onCameraChanged`, `onInstruction`, `onSpeechInstruction`, `onDeviationChanged`,
  `onPhaseChanged`, `onArrival`, `onError`.
- **R7 — Units live in the name, spelled out.** `_meters`, `_seconds`, `_pixels`,
  `_degrees`, `_bytes`. Keep the current discipline (`distanceRemainingMeters`,
  `durationRemainingSeconds`); it is a strength most vendors lack. Never `ms`, `px`,
  `deg` in identifiers (prose may abbreviate).
- **R8 — No vendor in a public name.** `registerMapquestProviders` is the single
  worst name in the contract: it bakes MapQuest into every integrator's call site and
  contradicts the provider-genericity north star. Vendor names belong in provider
  crates and the registry descriptor only.
- **R9 — No platform/internal leakage.** `Surface`, `Gpu`, `Canvas`, `NativeWindow`,
  `Pointer`, `Descriptor` never appear in a name a developer types. `MapSurfaceTargetHandle`
  exists to carry `ANativeWindow*` / `UIView*`; it should be internal to the wrapper.
- **R10 — No transport-mode suffixes.** `_live` (`forwardGeocodeLive`,
  `calculateRouteLive`, `fetchRasterTileLive`) describes the harness's transport choice,
  not the SDK operation. Live/recorded is a *provider registration*, never a method name.
- **R11 — snake_case only inside Rust/UDL.** UniFFI camelCases UDL members for Kotlin,
  Swift and RN for free. The wasm surface does **not**: wasm-bindgen preserves Rust
  names unless each export carries `#[wasm_bindgen(js_name = ...)]`. Every wasm export
  must set `js_name`.
- **R12 — Abbreviations.** `SDK`, `URL`, `HTTP`, `GPS`, `MVT` allowed in prose, never as
  identifier shorthand (`docs/DocsStyleGuide.md` §11 already rules this). `Gpu` is an
  implementation word, not an abbreviation we need — drop it.
- **R13 — Values are immutable, verbs live on the owner.** `MapCamera` is a value
  (matches Mapbox `CameraOptions`); you change the camera by *telling the view*
  (`setCamera`), not by mutating the camera. This is already our UDL shape — keep it.
- **R14 — Prefix scope by plane, not by vendor.** `Map*` for things drawn on the map
  (`MapView`, `MapCamera`, `MapStyle`, `Marker`, `Polyline`, `Polygon`),
  `Navigation*` for trip/session data (`NavigationState`, `NavigationListener`,
  `NavigationPhase`). Do not mix (`MapNavigationController` is both).

---

## 4. Proposed public `MapView` surface (exact signatures)

The intent: one object a developer holds per screen; engines hold the SDK root; the
wasm harness gets the same names.

### (a) Create + lifecycle

```kotlin
// Kotlin (Android)
val maps = MapsSdk()
// The all-in-one convenience registers the built-in MapQuest provider set from
// the one credential it issued. To choose one capability independently, call
// `configureProvider(contract, providerKey, credential)` instead.
maps.setProviderCredential(credential)  // throws SdkException verbatim
val mapView = MapView(context, maps)                  // FrameLayout
mapView.onStart(); mapView.onStop(); mapView.onDestroy()
mapView.setOnReadyListener(object : MapView.OnReadyListener {
    override fun onMapReady(mapView: MapView) { mapView.setCamera(initialCamera) }
})
```
```swift
// Swift (iOS) — no lifecycle forwarding; readiness is the only gate
let maps = MapsSdk()
try maps.setProviderCredential(credential)
let mapView = MapView(frame: .zero, maps: maps)
mapView.onReadyListener = { mapView in mapView.setCamera(initialCamera) }
```
```ts
// React Native (generated from the UDL, camelCase)
const maps = new MapsSdk();
maps.setProviderCredential(credential);
const mapView = new MapView(maps);   // native host view binds to this object
mapView.onReadyListener = { onMapReady: (view) => view.setCamera(initialCamera) };
```
```ts
// wasm mirror (hand-written; needs js_name on every export)
await init();
const maps = await MapsSdk.create();                 // was today's `start_sdk()`
const mapView = new MapView(canvas, maps);           // async init inside; was `GpuMapCanvas`
await mapView.ready;
mapView.setCamera(initialCamera);
```

The wasm entry keeps the product name with an async factory (`MapsSdk.create()`),
while the contract interface is the direct constructor `MapSdk()` that Kotlin and
Swift bind. The shapes differ on purpose — a browser page awaits its module and
then a factory; native hosts construct the interface — and `contract_sync.mjs`
records that one-name tolerance rather than mirroring an async factory the UDL
does not carry.

#### Choosing a provider

`configureProvider(contract, providerKey, credential)` is provider-neutral by
design: the contract name selects the capability slot, the key names a provider
the registry knows, and the credential is whatever that provider issued.
`setProviderCredential(credential)` is the all-in-one convenience that fills
every capability one vendor serves from a single credential. What ships today:

| `providerKey` | Serves | Credential |
|---|---|---|
| `mapquest` | geocoding, routing, distance matrix, place search, traffic, raster tiles | a MapQuest API key |
| `osrm` | routing | none; the deployment's base URL (empty for a local server) |
| `valhalla` | routing | none; the deployment's base URL (empty for a local server) |
| `openstreetmap` | raster tiles | none (some sources want a User-Agent) |
| `osmus`, `openfreemap` | a styled vector base with labels | none |

A keyless base map draws; search, routing and traffic answer once a provider
serving those contracts has a credential. Adding a second provider is a
provider crate plus a registry descriptor plus a dispatch arm — the calls above
do not change. `providerRegistrations()` reports, in a stable order, which key
serves each capability. The settings surface of every reference app renders its
rows from the same registry, so a new provider appears there without a UI
change.

**Landed (2026-10-30).** The wasm seam now serves the construction half of
this shape: `await MapsSdk.create()` resolves to the SDK root
(`maps.compiledVersion`), `new MapView(canvas, maps)` binds the canvas to
that root (`mapView.sdkCompiledVersion`), and the optional third argument
(`new MapView(canvas, maps, TileResolution.Retina)`) pins the tile
resolution for capture harnesses — omitted, it follows the same device
pixel-ratio rule as `devicePixelRatioThreshold()`. `initializeSdk()` stays
as the readiness alias for existing harness code. The camera verbs and
`ready` promise on this class remain open.

### (b) Camera control / animation / fit-bounds

```kotlin
val camera: MapCamera = mapView.camera
mapView.setCamera(MapCamera(center, zoomLevel = 14.0, bearingDegrees = 0.0, pitchDegrees = 0.0))
mapView.animateCamera(target, durationMilliseconds = 500)          // cancelable
mapView.fitBounds(bounds, edgeInsets = EdgeInsets(top = 64.0, left = 16.0, bottom = 300.0, right = 16.0), maximumZoom = 17.0)
mapView.addCameraChangeListener { camera, isAnimating -> }           // returns Subscription
```
```swift
mapView.setCamera(camera, animated: true)
mapView.fitBounds(bounds, edgeInsets: EdgeInsets(...), maximumZoom: 17.0)
let subscription = mapView.addCameraChangeListener { camera, isAnimating in }
// TS / wasm: mapView.setCamera(camera); mapView.animateCamera(camera, { durationMilliseconds: 500 });
//            mapView.fitBounds(bounds, { edgeInsets, maximumZoom: 17 });
```

### (c) Overlays

```kotlin
val marker = mapView.addMarker(Marker(coordinate, anchor = MarkerAnchor.BottomCenter))
val polyline = mapView.addPolyline(Polyline(coordinates, widthPixels = 6.0, color = RouteColor))
val polygon = mapView.addPolygon(Polygon(ringCoordinates, fillColor = ParkColor))
mapView.removeOverlay(marker); mapView.clearOverlays()
```
`Marker` / `Polyline` / `Polygon` are binding-layer types converting to the existing
`MapOverlayDescriptor` list in one `setOverlays` call — the single-descriptor-with-
nullable-payload record stays inside the FFI, never in a developer's hands.

**Contract status (M17 contract slice, 2026-10-30):** the id-addressed members are
on the UDL contract as `MapView.add_overlay` / `update_overlay` / `remove_overlay`
(Kotlin `addOverlay` / `updateOverlay` / `removeOverlay`). `add_overlay(overlay)`
answers a generated opaque identifier (`overlay-1`, a monotonic per-view sequence
that is never reused, even across `clear_overlays`/`set_overlays`); validation is
`set_overlays`' all-or-nothing validation for the single descriptor, so a refused
descriptor throws and adds nothing. `update_overlay(id, overlay)` replaces the
addressed overlay in its draw position; an invalid descriptor throws and keeps the
previous overlay in force, and an unknown id throws a typed `SdkError` with a
precise detail. `remove_overlay(id)` answers whether the id was present (an
unknown id is not an error), and `clear_overlays()` clears both the bulk list and
every addressed overlay. `set_overlays` stays the documented bulk call: it
replaces the whole drawn list — including addressed overlays — and drops the
addressed bookkeeping, so an id returned before a `set_overlays` call no longer
addresses anything. Overlay state, the addressed set and the identifier sequence
all outlive attach/detach.

### (d) Gestures

```kotlin
mapView.gestures.isPanEnabled = true
mapView.gestures.isZoomEnabled = true
mapView.gestures.isRotateEnabled = true
mapView.gestures.isTiltEnabled = false
mapView.addInteractionListener(object : MapView.InteractionListener {
    override fun onPanBegin() {}; override fun onPan() {}; override fun onPanEnd() {}
})
```
The three `MapCamera` gesture members (`pan_by_screen_pixels`,
`zoom_by_levels_around_screen_point`, `rotate_by_degrees_around_screen_point`) carry
this algebra in the contract, so all four shells compute identical results; the
reference apps route their pan/pinch/rotate math through them.

### (e) Search

```kotlin
val search = SearchEngine(maps)
suspend fun places(q: String) = search.search(q, boundary = null)      // was searchPlaces
suspend fun suggestions(q: String) = search.suggest(q, boundary = null) // was searchAutocomplete
suspend fun at(c: GeographicCoordinate) = search.reverseGeocode(c)
```

### (f) Route

```kotlin
val routing = RoutingEngine(maps)
val route: Route = routing.calculateRoute(waypoints, RouteOptions(...))
val matrix = routing.calculateDistanceMatrix(origins, destinations, TransportationMode.DRIVING)
```

### (g) Navigation with listeners

```kotlin
val navigator = Navigator(maps)
val subscription = navigator.addNavigationListener(object : NavigationListener {
    override fun onInstruction(instruction: NavigationInstruction) {}
    override fun onSpeechInstruction(speech: SpeechInstruction) {}
    override fun onDeviationChanged(change: DeviationStatusChange) {}
    override fun onPhaseChanged(change: NavigationPhaseChange) {}
})
navigator.startNavigation(route, NavigationOptions(unitSystem = UnitSystem.METRIC))
navigator.updateLocation(locationUpdate)
navigator.applyReroute(replacementRoute)
navigator.stopNavigation()
subscription.cancel()
```
One listener with four methods replaces the four `subscribe_to_*` calls (and matches
HERE's `NavigatorListener` / Mapbox's `NavigationListener`). The four topics remain
inside the implementation for honesty — a `NavigationListener` that implements only
`onInstruction` still must not receive speech on that method.

**Contract status (M17 contract slice, 2026-10-30):** `Navigator.add_navigation_listener`
and `Navigator.stop_navigation` are on the UDL contract. The listener is subscribed
to all four existing topics in one call, and the returned composite `Subscription`'s
`cancel()` removes all four registrations (idempotent). `stop_navigation()` ends the
active trip and clears trip state — `current_trip_state`/`current_instructions` answer
null, and later fixes, reroutes and reroute-request signals are dropped until
`start_navigation` begins a new trip. It resets the speech-trigger band memory and
the reroute-recalculation gate with the trip (utterance ids stay monotonic; the
configured reroute policy persists) and leaves listener subscriptions untouched.
No stop event is dispatched: the native reducer and the frozen phase channel have no
stop transition, so inventing one would be a semantics the reducer does not own.

### (h) Offline downloads

```kotlin
val offline = OfflineManager(maps)
offline.setTileTimeToLive(seconds = 2_592_000)          // ceiling still clamps; readback is the truth
val terms: TileCacheTerms = offline.tileCacheTerms
if (terms.effectiveTimeToLiveSeconds != requestedSeconds) { /* show clamped value */ }
val download: RegionDownload = offline.downloadRegion(
    RegionDefinition(boundingBox = bounds, minimumZoom = 10, maximumZoom = 16),
)
download.addProgressListener { status -> /* completedTileCount / requiredTileCount / bytes */ }
```
Region downloads are the M7 pack-manager surface; until it lands, `OfflineManager` still
carries `configureTileCache(path, budgetBytes)` as the honest name for what exists.

Routing from a compiled archive is a contract function on every native surface today —
archive bytes in, a `Route` out — sharing one `rustic-maps-core` implementation with the wasm
`offlineRouteFromArchiveBytes` export:

```kotlin
val plannedRoute: Route = offlineRouteFromArchiveBytes(
    archiveBytes = compiledArchiveBytes,          // ByteArray from the RMOG file
    start = GeographicCoordinate(latitude = 0.001, longitude = 0.0),
    end = GeographicCoordinate(latitude = 0.001, longitude = 0.002),
)
```
The request uses the archive profile's default options (automobile, fastest, metric);
a corrupt archive throws `OfflineRoutingFailure`. The engine-shaped façade
(`OfflineRoutingEngine.fromArchiveBytes`) remains the v2 target, not a requirement for
the capability.

### (i) Tile / base-map provider registration

```kotlin
maps.configureProvider(ProviderContract.RasterTiles, "openstreetmap", "")  // one capability
maps.registerUrlTemplateRasterTileSource(rasterSource)   // or declare the source here
mapView.setVectorTileSource(vectorSource)                // styled vector base with labels
mapView.setStyle(MapStyle.VECTOR_LIGHT)                  // base-map switch
```
`setProviderCredential(credential)` registers the MapQuest set in one call;
`configureProvider(contract, providerKey, credential)` replaces exactly one
slot, and `providerRegistrations()` reads back what serves each one. The
browser target serves the same per-capability registry through
`configureProvider`, `providerRegistrations`, `setProviderCredential(credential)`
and `clearProviderRegistrations`; the older `registerProvider` / `clearProvider`
names are gone.

### (j) Readiness and errors

```kotlin
mapView.setOnReadyListener(...)                                    // map can now draw & project
maps.diagnostics.addListener(listener, SdkLogSeverity.WARNING)     // replaces subscribe_to_diagnostic_events
maps.diagnostics.flushRecent(listener, SdkLogSeverity.WARNING, maximumCount = 100)
try { search.search(q) } catch (error: SdkException) { /* typed, verbatim detail */ }
```
Keep the typed-exception model (Mapbox does the same); do not invent string-based error
callbacks (Google's model). Readiness is the only callback.

---

## 5. Abbreviations and snake_case leakage — verdict

**Verdict: the wasm surface is the largest DX defect in the product.** A browser
developer writes `gpu_map_canvas.render_frame(camera, width, height, field_of_view, ...)`
and `await forward_geocode_live(query)` against a public npm package. No surveyed vendor
exposes snake_case, and none exposes an implementation adjective (`Gpu`) in the type name.

| Current (wasm export / type) | Proposed | Note |
|---|---|---|
| `GpuMapCanvas` | `MapView` | match native; `Gpu` is an implementation detail |
| `render_frame` | `renderFrame` (`js_name`) | render pump stays public but is documented as harness-owned |
| `stage_tile_parent_fallback` | `stageParentTile` | "tile parent fallback" is scheduler jargon |
| `start_sdk` | `MapsSdk.create()` / `initializeSdk()` | async factory, not a global side effect |
| `set_live_raster_tile_source` | retired: `registerUrlTemplateRasterTileSource(source)` | one contract-shaped source record, not a canvas-only template |
| `set_tile_layer_visible` | `setBaseMapVisible` | "tile layer" leaks the raster path |
| `set_clear_color` | `setBackgroundColor` | "clear color" is GPU vocabulary |
| `forward_geocode_live` | `SearchEngine.search` | move `live` transport into the harness |
| `calculate_route_live` / `fetch_raster_tile_live` | `RoutingEngine.calculateRoute` / `fetchRasterTile` | ditto |
| `register_provider` / `clear_provider` | retired: `configureProvider` / `clearProviderRegistrations` | the registration is per capability, through the registry |
| `register_mapquest_providers` | retired (never shipped as a wasm export) | vendor leak (R8) |
| `clear_mapquest_providers` | retired: `clearProviderRegistrations` | vendor leak (R8) |
| `offline_route_from_archive_bytes` | `OfflineRoutingEngine.fromArchiveBytes` | landed on the contract as a namespace function (native and wasm share one implementation); the engine façade stays the v2 shape |
| `vector_tile_overlay_descriptors[_for_style]` | `VectorTile.overlayDescriptors(style:)` | |
| `vector_tile_geographic_bounds` | `VectorTile.geographicBounds` | |
| `camera_pan_by_screen_pixels` | `MapCamera.panByScreenPixels(…)` | method, not free function |
| `camera_zoom_by_levels_around_screen_point` | `MapCamera.zoomByLevels(levels, aroundScreenPoint)` | |
| `camera_rotate_by_degrees_around_screen_point` | `MapCamera.rotateByDegrees(degrees, aroundScreenPoint)` | |
| `subscribe_to_diagnostic_events` | `maps.diagnostics.addListener` | |
| `flush_recent_diagnostic_events` | `maps.diagnostics.flushRecent` | |
| `get_sdk_compiled_version` | `sdkVersion` | constant, not a call |
| `retina_device_pixel_ratio_threshold` | `devicePixelRatioThreshold` | "retina" is Apple marketing |
| `CanvasTileResolution` | `TileResolution` | |
| `CanvasTrafficFlowCongestionLevel` | `TrafficFlowCongestionLevel` | reuse the UDL enum name |
| `CanvasSdkLogSeverity` | `SdkLogSeverity` | reuse the UDL enum name |

Kotlin/Swift/RN generated names are mostly fine (UniFFI camelCases), but these UDL
spellings should change:

| Current UDL | Generated today | Proposed | Why |
|---|---|---|---|
| `MapSurfaceView` | `MapSurfaceView` | `MapView` | §2 |
| `MapSurfaceTargetHandle` | `MapSurfaceTargetHandle` | `SurfaceHandle` (internal) | R9 |
| `MapNavigationController` | `MapNavigationController` | `Navigator` | R2/R14 |
| `NavigationStateEventListener` | `NavigationStateEventListener` | `NavigationListener` | vendor consensus |
| `NavigationTopicSubscription` | `NavigationTopicSubscription` | `Subscription` | it is not a topic |
| `start_trip` | `startTrip` | `startNavigation` | vendor consensus |
| `provide_location_update` | `provideLocationUpdate` | `updateLocation` | provider voice → consumer voice |
| `provide_reroute` | `provideReroute` | `applyReroute` | |
| `current_trip_state` | `currentTripState` | `navigationState` | |
| `current_instructions` | `currentInstructions` | `currentInstruction` | singular payload |
| `frame_settled` | `frameSettled` | `isFrameSettled` | R5 |
| `search_places` | `searchPlaces` | `search` | |
| `search_autocomplete` | `searchAutocomplete` | `suggest` | what it actually does |
| `forward_geocode` | `forwardGeocode` | `search` / `geocode` | keep `reverseGeocode`; drop `forward` |
| `register_mapquest_providers` | `registerMapquestProviders` | `setProviderCredential(credential)` | R8 |
| `set_raster_tile_cache_time_to_live` | `setRasterTileCacheTimeToLive` | `setTileTimeToLive` | `raster` is a path, not the feature |
| `raster_tile_cache_terms` | `rasterTileCacheTerms` | `tileCacheTerms` | |
| `set_overlays` / `clear_overlays` | `setOverlays` / `clearOverlays` | `addOverlay`/`removeOverlay`/`clearOverlays` | Mapbox/Google/HERE all use add/remove |
| `MapOverlayDescriptor` | `MapOverlayDescriptor` | `MapOverlay` (sealed wrapper) | `Descriptor` is FFI vocabulary |
| `MapOverlayKind` | `MapOverlayKind` | `MapOverlay.Kind` | |
| `TileFrameStatistics` | `TileFrameStatistics` | `FrameStatistics` | |
| `ViewportPixels` / `EdgeInsetsPixels` | same | `ViewportSize` / `EdgeInsets` | the type *is* a size, not a unit |
| `TileKeyRecord` / `DiagnosticLogEvent` | same | `TileKey` / `LogEvent` | `Record`/`Event` is FFI vocabulary |
| `PlaceResult` / `RouteData` | same | `Place` / `Route` | HERE/Google/Mapbox all say `Place`; `Data` is FFI vocabulary |

**Never rename:** `GeographicCoordinate`, `BoundingBox`, `RouteStep`, `RouteLeg`,
`RouteOptions`, `AvoidOptions`, `NavigationPhase`, `SdkError`, `MapCamera`.

---

## 6. Change classification — what costs what

### A. Pure binding (no UDL change; ship first, zero risk)

- Every wasm `js_name` in §5, plus the TS mirror types in
  `platform/web/types/rustic_maps.d.ts`.
- Kotlin wrapper classes `MapView` (over `MapSurfaceView` + `MapSurfaceHostState`),
  `SearchEngine`, `RoutingEngine`, `Navigator`, `OfflineManager`, `Diagnostics` — thin
  delegating facades over today's `MapSdk` / `MapNavigationController`.
- Swift equivalents in `MapNativeCoreUI` / a new `RusticMapsSDK` view layer.
- `Marker` / `Polyline` / `Polygon` value types converting to `MapOverlayDescriptor`.
- `MapsSdkFacade` → `MapsSdk` (Kotlin) rename; it currently reads as an internal helper.

**Cost:** Kotlin + Swift + TypeScript only. RN and the UDL are untouched, so the
generated `rustic_maps` module keeps working — but RN developers would still see
`mapSdk.searchPlaces(...)`, i.e. an RN surface that does not match Kotlin's. That is
worse than either consistent extreme.

### B. UDL addition (legal under the addition-only rule)

Add engine interfaces and `MapView` delegating to the existing members; keep the old
members in place, marked deprecated in `///` docs:

```
interface MapView { constructor(MapSdk); MapCamera camera(); void set_camera(MapCamera); ... }
interface SearchEngine { constructor(MapSdk); [Async, Throws=SdkError] sequence<Place> search(string, BoundingBox?); }
interface Navigator { constructor(MapSdk); NavigationSubscription add_navigation_listener(NavigationListener); ... }
interface OfflineManager { constructor(MapSdk); TileCacheTerms tile_cache_terms(); ... }
```
This is the only path that gives **RN the same names as Kotlin and Swift for free**,
because ubrn regenerates from the UDL. It is also the largest change: ~5 new interfaces,
~20 members, plus `contract_sync.mjs` additions and wasm mirrors.

**Status (2026-10-30):** landed as the M17 contract slice. The UDL now carries
`SearchEngine`, `RoutingEngine`, `OfflineManager` and `Diagnostics` (each a
`constructor(MapSdk)` delegating verbatim — same validation, typed failures and
detail messages as the matching `MapSdk` member), the `MapView` id-addressed
overlay members beside `set_overlays`, and `Navigator.add_navigation_listener` /
`stop_navigation`. The old members stay (the contract is addition-only). The
wasm `MapView` adopts the overlay members in the same round
(`addOverlay`/`updateOverlay`/`removeOverlay`, identifiers `overlay-1`, …); the
engine interfaces remain native-only until a wasm engine surface exists, while
the `Navigator`'s driving and readback core (`startNavigation`,
`updateLocation`, `applyReroute`, `stopNavigation`, `currentTripState`) is on
the wasm seam since round 43 — the listener, speech and reroute-recalculation
members stay native until the seam has a foreign-listener contract. The
per-platform wrapper facades (§6 A) are the surfaces that adopt these names
next.

### C. Breaking UDL (requires an explicit owner ruling — the contract is addition-only today)

Renaming or removing any existing member: `MapSurfaceView`→`MapView`,
`start_trip`→`startNavigation`, `register_mapquest_providers` removal, etc.

Blast radius if taken:
- **RN:** `platform/rn/src/generated/rustic_maps.ts` regenerates; every RN app call
  site and the 50 jest tests change; `MapsSdkRn` identifiers are unaffected.
- **wasm:** `pkg/*.d.ts`, the hand-written TS mirror, `contract_sync.mjs`'s name lists,
  every `platform/web/*.mjs` call site, all 63 Playwright specs, `index.html`.
- **Kotlin/Swift:** regenerate + update the wrapper facades, Espresso and XCUITest
  launch demos, and the four reference apps.
- **Docs:** `site/book-src/{first-map,search-and-routing,navigation-simulation,offline-maps}.md`
  and the earlier contract draft (removed from the tree; the frozen UDL is the
  source of truth); the site's byte-equality publish gates will fail
  until regenerated renders land in the same commit.
- **M10 packaging:** none of the package identities move (`com.angoratek:rustic-maps-sdk`,
  `RusticMapsSDK`, `@angoratek/rustic-maps-sdk`), so the rename does not reopen round 24.

### Recommended sequencing

1. **Phase 1 (binding):** wasm `js_name` renames + TS mirror + Kotlin/Swift facades.
   Gates: `contract_sync.mjs` green (it reads names from the export sources, so the
   lists need updating in the same commit), Playwright 63/63, Kotlin/Swift builds.
2. **Phase 2 (UDL additions):** engines + `MapView` + `NavigationListener`; old members
   deprecated and kept until the next major.
3. **Phase 3 (breaking removal), only with the owner's ruling:** delete the deprecated
   members in the release that also flips the major version, so integrators get one
   clean break with a migration table generated from §5.

---

## 7. Decisions for the owner (recorded 2026-10-29)

Rulings: the contract **may break** until 1.0 (ruling 1); `MapView` is a **UDL
interface**, so the render pump exists once (ruling 2); the root object is
**`MapsSdk`** (ruling 5). The two remaining questions (`FrameStatistics` naming
and `PlaceResult` → `Place`) are folded into the M17 contract slice.

1. **May the frozen contract take a breaking rename at all?** CLAUDE.md says
   addition-only. Phase 3 is otherwise impossible, and Phases 1–2 alone leave RN with
   the old names unless Phase 2 ships.
2. **`MapView` as a UDL interface vs a per-platform wrapper.** UDL = one implementation
   of the render pump for all four shells; wrapper = three hand-written pumps over
   `MapSurfaceView` (the audit-C2 duplication the plan already flags). Recommendation:
   UDL, because it also fixes audit C2.
3. **`FrameStatistics` vs `TileFrameStatistics`.** Rename only if Phase 3 is approved;
   it appears in the wasm harness's perf readout.
4. **`PlaceResult` → `Place`.** Safe but touches every fixture and doc snippet; confirm
   before scheduling.
5. **`MapsSdk` vs `RusticMaps`** as the root object's consumer-facing name. Vendors all
   use a product-shaped root (`SDKNativeEngine`, `MapboxMapsOptions`, `MapLibre`).
   Recommendation: `MapsSdk` (the Rust type already is `MapSdk`; the Kotlin facade
   already is `MapsSdkFacade`).

---

## 8. Sources

- HERE: [API references](https://docs.here.com/here-sdk/page/here-sdk-api-references) · [Android maps](https://docs.here.com/here-sdk/docs/android-maps) · [`MapView` Android](https://here-dni.github.io/HERESDKforAndroidAPIReferenceNavigate/com/here/sdk/mapview/MapView.html) · [`MapSurface`](https://here-dni.github.io/HERESDKforAndroidAPIReferenceNavigate/com/here/sdk/mapview/MapSurface.html) · [engines](https://docs.here.com/here-sdk/docs/android-tips-engines) · [`MapView` iOS](https://here-dni.github.io/HERESDKforiOSAPIReferenceNavigate/Classes/MapView.html) · [`RoutingEngine` iOS](https://here-dni.github.io/HERESDKforiOSAPIReferenceNavigate/Classes/RoutingEngine.html) · [Flutter](https://docs.here.com/here-sdk/docs/flutter-maps)
- Mapbox: [Android migrate to v11](https://docs.mapbox.com/android/maps/guides/migrate-to-v11/) · [Android camera](https://docs.mapbox.com/android/maps/guides/camera-and-animation/camera/) · [`MapboxMap.kt`](https://github.com/mapbox/mapbox-maps-android/blob/879a1fe3/maps-sdk/src/main/java/com/mapbox/maps/MapboxMap.kt) · [iOS `MapView`](https://docs.mapbox.com/ios/maps/api/latest/documentation/mapboxmaps/mapview/) · [iOS migrate to v11](https://docs.mapbox.com/ios/maps/guides/migrate-to-v11/) · [Flutter `MapWidget`](https://docs.mapbox.com/flutter/maps/api/latest/mapbox_maps_flutter/MapWidget-class.html)
- Google: [Android `MapView`](https://developers.google.com/maps/documentation/android-sdk/reference/com/google/android/libraries/maps/MapView) · [camera and view](https://developers.google.com/maps/documentation/android-sdk/views) · [`CameraUpdateFactory`](https://developers.google.com/maps/documentation/android-sdk/reference/com/google/android/libraries/maps/CameraUpdateFactory) · [iOS `GMSMapView`](https://developers.google.com/maps/documentation/ios-sdk/reference/interface_g_m_s_map_view)
- MapLibre: [`MapLibreMap`](https://maplibre.org/maplibre-native/android/api/-map-libre%20-native%20-android/org.maplibre.android.maps/-map-libre-map/index.html) · [`MapView.java`](https://github.com/maplibre/maplibre-native/blob/main/platform/android/MapLibreAndroid/src/main/java/org/maplibre/android/maps/MapView.java) · [annotation plugin](https://github.com/maplibre/maplibre-plugins-android/tree/main/plugin-annotation)
- flutter_map: [`MapController`](https://pub.dev/documentation/flutter_map/latest/flutter_map/MapController-class.html) · [`MapOptions`](https://pub.dev/documentation/flutter_map/latest/flutter_map/MapOptions-class.html) · [layers](https://docs.fleaflet.dev/usage/layers)

---

## 9. WebAssembly: one contract, four surfaces

### Verdict

- The browser cannot get its view class from the UDL, from any generator, ever:
  a DOM `HTMLCanvasElement` / `GPUDevice` is not expressible in UniFFI types. A
  thin **wasm-bindgen** layer for the canvas stays, in every option.
- What *can* be shared is everything else: record shapes, enum spellings,
  method names, class names, error variants. Today the wasm surface shares the
  record shapes (asserted) but not the **callable names** (`forward_geocode_live`,
  `GpuMapCanvas.render_frame`, flattened scalar parameters, string errors).
- `uniffi-bindgen-react-native` **does** have a web target since 2026 (`web`
  wasm-bindgen-shim flavor and the newer `wasm2` player). The workspace aligned
  on uniffi **0.31.2** on 2026-11-01 (PRD §6 item 27), so the generator's line
  now matches; the migration to a generated web surface is planned as PLAN.md
  M35. `rustic-maps-native-core` has built for wasm32 since round 117 (the
  single-threaded UniFFI runtime path, the native surface view, JNI and the disk
  cache are gated), so the wasm-buildable contract surface exists; the canvas
  adapter beside it is the remaining piece.
- Recommendation: **Option A/C** — keep wasm-bindgen plumbing, add a
  UDL-generated (and byte-equality-asserted, both directions) TypeScript facade
  that is the npm package's entry point. This completes the design that
  `PRD.md` §4.7 already locks ("a contract test suite asserts the TS types stay
  in sync with the UDL (same records, same names)") — the missing half is the
  callable surface. B is now the owner-directed path (PRD §6 item 27): its
  prerequisite — the aligned toolchain and a wasm32 build of
  `rustic-maps-native-core` (landed round 117) — has landed.

### Recommended work items

| # | Item | Effort | Gate |
|---|---|---|---|
| 1 | Write `platform/web/sdk.mjs` facade: `MapView`, `MapCamera`, `MapSdk`-shaped free-function surface (`createSdk()` until `MapSdk` exists on wasm), records re-exported from `types/rustic_maps.d.ts` | M | `node --test` smoke + Playwright demo unchanged |
| 2 | Generate, don't hand-write: `scripts/generate-web-facade.mjs` (zero deps, reuse `parse_uniffi_contract`; `--check` mode fails on drift) emitting `sdk.d.ts` (and later `sdk.mjs`) | M | byte-equality `--check` in CI |
| 3 | Add the missing wasm exports the contract already has: `MapCamera` getters (`center`, `zoomLevel`, `bearingDegrees`, `pitchDegrees`) and a `fitBounds(box, viewport, insets, maxZoom)` free helper on the wasm side | S | `contract_sync` member list grows; new unit tests |
| 4 | Align the frame-statistics return of `render_frame` with the UDL `TileFrameStatistics` field names (today it returns `requestedTiles/drawnTiles/drawnFragments/missingTiles/tileZoomLevel/tileResolution/overlayTriangles`; contract is `requested_tile_count/present_tile_count/fallback_tile_count/deferred_tile_count/unavailable_tile_count/overlay_triangle_count`) — facade maps for now, Rust renames when the seam is next touched | S | facade type test |
| 5 | Extend `contract_sync.mjs` to assert the facade both ways (C's core) and add `tsc --noEmit` for the facade `.d.ts` | S | existing `node --test platform/web/tests/contract_sync.mjs` |
| 6 | Make the facade the npm entry (`platform/web/npm/package.json`: `.` → `sdk.js`, keep glue at `./wasm/rustic_maps_web_bindings.js`) and update `scripts/package-web-npm.sh`'s exact-member assertion | S | package script's fail-closed member set |
| 7 | Docs: one quickstart snippet that is verbatim-identical across Kotlin/Swift/TS/wasm (M11's tutorial gate wants this anyway) | S | doc build |
| 8 | Option B is planned (PLAN.md M35): the toolchain alignment has landed; the next gate is a wasm-buildable `rustic-maps-native-core`, and the canvas shim stays even then | L | M35's wasm-safe contract surface, then the `wasm2` spike |

---

## 10. `MapView` ownership and the frame pump

### Ownership split (extends `docs/ReferenceAppUX.md` §5.1, which currently stops at "platform owns gestures")

SDK owns: surface acquisition & lifetime, the frame pump, resize, camera value store + animation,
gesture→camera deltas, overlay bookkeeping by id, readiness/error derivation, pointer→coordinate for
taps. Platform app owns: widgets, sheets, navigation UI, TTS, provider credentials UI.

### Frame pump ownership

**Lives in the platform wrapper (Kotlin/Swift), never in Rust.** The contract is explicit that there is
no SDK render loop (`rustic_maps.udl:1257-1268`, "never an SDK-internal loop"); moving it into Rust
would require a platform callback into FFI, i.e. a new foreign-callback interface and a threading story
for UIKit/Choreographer — the opposite of a simplification. The wrapper is also the only place that can
observe window attachment and pause.

**Android** — `Choreographer.postFrameCallback` + a `Channel<Long>(CONFLATED)` + one consumer coroutine;
copy the proven RN shape (`ReferenceMapController.kt:744-778`) rather than the Compose
`withFrameNanos` one, so the same code serves XML and Compose hosts. Post from
`onAttachedToWindow`, stop on `onDetachedFromWindow` / `onWindowVisibilityChanged != VISIBLE` /
`setRenderingPaused(true)`.

**iOS** — `CADisplayLink` on `.main`/`.common`, started in `didMoveToWindow` when `window != nil`,
invalidated when `nil`, plus `setRenderingPaused`.

**Per tick, in order** (all already validated in-tree):
1. extent check → `resize` when the *capped* pixel extent changed (never every frame);
2. `frame_settled(camera)` — pure query; throws only when detached (`udl:1468-1477`);
3. if settled → **pause the pump** (see below); else `draw` with at most one in flight
   (`SdkException.RenderingSurfaceUnavailable` → retry next tick);
4. report statistics / ready / error.

**Not burning a core when idle.** Because `draw` performs its fetch phase inside the call (the await
spans network), a `frame_settled == true` answer means nothing is pending — so the pump may stop
entirely rather than keep ticking. On settle: `Choreographer.removeFrameCallback` /
`displayLink.isPaused = true`. Resume on: camera set/animate, gesture delta, overlay mutation,
location-indicator change, surface created/changed, window attach / visibility / `setRenderingPaused(false)`,
`retryAttach`, and a ~1 s watchdog tick (cheap insurance for anything not observable). Keep ticking
while `frame_settled == false`; if statistics report `deferred == 0` and `unavailable > 0` with an
unchanged pose for N consecutive frames, drop to a 1 s retry cadence — otherwise a permanently failing
provider turns into a 60 fps spin against the network (the scheduler retries `Unavailable` tiles every
frame: `rustic-maps-rendering/src/tile_scheduler.rs:11-12, :34-35`).

**What the app must still do: nothing.** Optional only: `setRenderingPaused(true)` in
`onStop`/`scenePhase == .background` if it wants to release the GPU surface early; `retryAttach()` after
an error surfaced by `onError`.

### Device pixel ratio

The committed styles declare point/CSS sizes while the surface draws device pixels. The wrapper reports
the drawing buffer's device pixels per point with the contract's `set_device_pixel_ratio`
(`MapView.set_device_pixel_ratio`, M30) whenever it applies the drawable scale — at attach, after a
resize and on a rebuilt native view. The SDK multiplies the placed glyph sizes and the overlay line
widths and marker/pin radii by that ratio exactly once, so labels and overlays keep their declared point
size on a 1×, 2× or 3× surface. Android reports `resources.displayMetrics.density` (falling back to 1.0
until the display resolves); iOS reports its capped drawable scale (`drawable pixels / point`). The wasm
canvas derives its own ratio from `canvas.width / clientWidth` and deliberately carries no setter, so the
member stays native-only.

---

## 11. Native view construction — implementation notes

These are the measured facts behind the M17 native slices; they keep the
work from re-discovering the same constraints.

### Android: the surface pointer shim ships inside the AAR

Android exposes no public Kotlin API for a `Surface`'s `ANativeWindow*`, so
today every integrator hand-writes a three-line C shim and a JNI declaration.
The SDK can ship it: the crate already builds the Android `cdylib`
(`librustic_maps.so`), so a `cfg(target_os = "android")` module with
`jni` and `ndk-sys` dependencies exports

```rust
#[no_mangle]
pub extern "system" fn Java_com_angoratek_rusticmaps_map_NativeWindowShim_acquireNativeWindow(
    environment: JNIEnv,
    _shim_class: JClass,
    surface: JObject,
) -> jlong
```

and the AAR's Kotlin object loads it with `System.loadLibrary("rustic_maps")`
(the same library the UniFFI JNA bindings load). A fixed class/package name
makes the mangled symbol a compile-time constant; `RegisterNatives`/
`JNI_OnLoad` buys nothing here, and a consumer ProGuard keep rule covers
obfuscation. Releasing the window on every failure path matters: both current
app-side hosts leak one `ANativeWindow*` reference per failed attach.

### iOS: the view owns its own layer pointer

`MapView: UIView` with `layerClass == CAMetalLayer` hands Rust
`Unmanaged.passUnretained(self).toOpaque()` from inside the view, so user code
never does pointer math. It must also:
- implement `init?(coder:)` (the current app-side view `fatalError`s, so it
  cannot be used from a Storyboard or XIB);
- cap the drawable at the platform's texture limit (`max_texture_dimension_2d`
  is 2048 on downlevel adapters — an unguarded full-screen buffer on a tall
  phone is rejected);
- detach in `dismantleUIView` / `didMoveToWindow(nil)`, never in `deinit`
  (the Rust side must release its surface while the layer still exists).

### React Native: one SDK object, owned by the package

The generated JSI bindings construct their own `MapSdk`, and there is no way
to import a foreign handle into them. A native `<MapView>` therefore has to
use the SDK object the package owns and proxy the map calls through its
module — otherwise two registries (and two SQLite tile caches) exist in one
process. The app shell already works this way; the M17 slice moves that
pattern into the shipped package.

Navigation does not need that package-owned handle: the generated `Navigator`
creates its own native navigation object and exposes the contract's
`NavigationListener` callback surface, so JavaScript can drive a trip and
receive the instruction/phase/deviation/speech topics directly:

```ts
import { Navigator } from '@angoratek/rustic-maps-sdk';

const navigator = new Navigator();
navigator.addNavigationListener({
  onNavigationInstruction: instruction => renderBanner(instruction),
  onNavigationPhaseChange: change => renderPhase(change),
});
navigator.startNavigation(route, 'metric');
navigator.updateLocation(fix);
```

The curated `MapsSdk` proxy deliberately does not duplicate this surface; its
provider-scoped members (distance matrix, traffic, credentials) stay on the
proxy because they need the shared provider registry. The owner recorded the
split in `PRD.md` §6 item 22.

### Slice order and effort

| Slice | Effort | Notes |
|---|---|---|
| UDL gesture members (`pan_by_screen_pixels`, `zoom_by_levels…`, `rotate_by_degrees…`) | S | Unblocks identical gesture algebra on all shells |
| JNI shim inside the AAR | S–M | Needs `jni`/`ndk-sys` and one Android cross-build check |
| Android `MapView` + Compose entry + refapp migration | M | Deletes `MapSurfaceHost.kt` (≈375 lines) |
| Android gestures and animated camera moves | M | Easing is wrapper-side by design |
| iOS `MapView` + SwiftUI entry + refapp migration | M | Deletes `MapSurfaceDisplayView.swift` (≈282 lines) |
| Listener/overlay parity pass | S | Ready/camera/tap/error/statistics on both |
| RN package view and shell deletions | L | Third controller copy leaves the tree |
| Docs + PLAN/CHANGELOG | S | M18 rewrites the tutorials on the final names |

## 12. Device positioning

The contract carries one positioning controller and its records (added in
0.1.0; see `docs/history/PositioningResearch.md` for the platform research):

```text
dictionary PositionFix {
    GeographicCoordinate coordinate;
    double? horizontal_accuracy_meters;
    double? course_heading_degrees;
    double? timestamp_seconds;
};

enum PositionSourceError { "PermissionDenied", "ServiceDisabled", "Unavailable", "Timeout" };

interface PositionController {
    constructor();
    [Throws=SdkError] void feed_fix(PositionFix fix);
    void source_failed(PositionSourceError error);
    PositionFix? latest_fix();
    double? smoothed_course_degrees();
    boolean is_stale(double now_seconds);
    PositionSourceError? source_status();
};
```

The host owns the operating system's location API and its permission prompt,
and pushes fixes and failures into the controller. The controller validates
each fix, ignores stationary repeats when averaging course, smooths the course
around the circle, tracks staleness and records source failures, so the
renderer's location indicator, a follow camera and the `Navigator` read one
consistent stream. A controller built before any fix answers `latest_fix` as
null; an invalid fix throws `SdkError::InvalidCoordinateInput` with the
validator's detail and leaves the previous state in force.

The wasm seam exposes the same class (`feedFix`, `sourceFailed`, `latestFix`,
`smoothedCourseDegrees`, `isStale`, `sourceStatus`); the browser demo's
Location settings use it with `navigator.geolocation`.
