# Documentation style guide

**Status:** owner-directed 2026-10-31 (M32). This is the standard every
published page, API reference, screenshot caption and public documentation
comment is checked against. The reference sites for tone and structure are
Stripe's documentation and HERE's SDK guides: direct, concrete, outcome-first,
and free of storytelling about the team that built the product.

## 1. The reader and the promise

Write for an application developer who has a map, a route or a position to
ship and is evaluating or using the SDK. Assume competence, not context: the
reader has not read the plan, does not know the internal vocabulary and should
never need to.

Every page answers, in this order:

1. **What you get** — the outcome in one or two sentences.
2. **What you need** — SDK artifact, minimum OS, permissions, provider key.
3. **How to do it** — numbered, complete steps with runnable code.
4. **What you should see** — the expected result, including failure states.
5. **Where to go next** — one or two links, not a wall of related reading.

## 2. Voice

- Second person, present tense, imperative for steps: "Create a `MapView`",
  not "The developer can create a `MapView`".
- Short sentences. One idea per sentence. Prefer the concrete noun to the
  abstract one.
- State facts plainly. No "simply", "just", "of course", "it should be noted",
  "as you may know", "in order to", "we are excited to".
- No hedging or self-praise: not "powerful", "seamless", "state-of-the-art",
  "robust", "blazing fast". Show the number or drop the adjective.
- No narrative about the project's process: no milestones, rounds, plan
  numbers, owner names, internal tickets, "this slice", "for now", "future
  work", "we plan to". Describe what exists and how to use it.
- Parentheses carry data or a short clarification only. Never put an insider
  aside in parentheses (for example a note about hostnames, repository paths
  or how the site is hosted). If the reader does not need it, delete it.
- American English, serial comma, sentence case headings. Product names keep
  their exact spelling (`MapView`, `MapCamera`, `MapQuest`, `OpenFreeMap`).

## 3. Page structure

- One `#` title per page, then short sections with `##`. A page longer than a
  screen needs a one-paragraph summary at the top.
- Steps are numbered; reference material is bulleted or tabulated.
- Every code block states its language, is complete enough to run, and is
  checked by `scripts/check-doc-snippets.mjs`. No `...` placeholders in a
  quickstart.
- Every platform-specific page shows the same scenario with the same values,
  so a reader can compare platforms line by line.
- Link text names the destination ("Install the Android artifact"), never
  "here".

## 4. Platform order and names

The order is **Rust, Android, iOS, React Native, WebAssembly** on every
matrix, download table, tab set and screenshot gallery. Rust is first once
its libraries ship.

One concept keeps one name across platforms: `MapView`, `MapCamera`,
`search`, `calculateRoute`, `startNavigation`, `PositionController`. State a
platform spelling rule once (Kotlin `UPPER_SNAKE` enum constants, Swift
lowerCamel cases, TypeScript string unions) instead of repeating it per tab.

## 5. Screenshots

- One capture per platform, in the platform order, from one revision, with
  the same camera, the same route and the same trip state.
- The reference scenario is **simulated navigation**: the turn-by-turn
  banner, the planned route polyline, the ETA line and the playback-speed
  controls are visible. A screenshot that shows a different mode teaches a
  different app.
- Captions name what the reader sees (readiness chip, banner, polyline,
  scale bar, attribution) with the shared vocabulary.
- A capture must be verifiably from the platform it claims: record the
  revision and the scenario in the page, and keep the evidence file names in
  the round record.
- Recapture the whole set whenever a UI change reaches any platform; never
  update one platform alone.

## 6. API reference pages

- One page per surface: Rust, Android/Kotlin, iOS/Swift, React Native and
  WebAssembly.
- For each public type: purpose, construction, members with parameters,
  return values, errors, threading/async rules and one minimal example.
- Generated material (types, signatures, error variants) is generated, not
  hand-copied; hand-written prose is linted against the generated surface.
- Link every platform page from the API reference landing page and from the
  matching guide.

## 7. Documentation comments

Public Rust documentation comments are the source of the HTML and the
generated reference. They describe the problem the item solves, its
parameters, its return value and its failure modes. They never mention
milestones, rounds, plan identifiers, owner names, internal teams, review
history or "this slice".

```rust
/// Projects a geographic coordinate into the normalized world square.
///
/// # Parameters
/// - `coordinate` — a WGS 84 coordinate inside the valid latitude range.
///
/// # Returns
/// The coordinate's position in the `[0, 1]` world square, with the origin at
/// the north-west corner.
///
/// # Errors
/// Returns [`SDKError::InvalidCoordinateInput`] when the latitude is outside
/// `-90..=90` or any component is not finite.
```

## 8. Banned vocabulary in published material

| Do not write | Write instead |
| --- | --- |
| slice, round, milestone, plan item, M-number | (delete; describe the feature) |
| owner, owner ruling, PRD §, audit round | (delete) |
| refapp, harness, playground (as product words) | reference application, test suite, demo |
| fixture (for a reader-facing artifact) | recorded sample data |
| "for now", "to come", "not yet wired", "pending seam" | what ships today, or omit |
| parenthetical hosting/path/internal notes | (delete) |

## 9. Review checklist

A page is ready when each answer is yes:

- Does the first paragraph say what the reader gets?
- Can every code block run as written, and is it compile-checked?
- Are the platform tabs complete, in order, and showing the same scenario?
- Does the page avoid every banned word and every internal identifier?
- Are all figures, counts and version numbers derived from the artifact or a
  run, rather than remembered?
- Do the links name their destinations and resolve?
- Are screenshots current, from one revision, and in the reference scenario?
