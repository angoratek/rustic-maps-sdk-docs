# Documentation Style Guide

The rules below govern every document this repository publishes externally:
the site chapters, README files, and generated reference intros. Apply them
when you add or revise a chapter. They are our own rules; four public
guides shaped them and are cited here once, not copied: the Google
developer documentation style guide, the Apple Style Guide, Stripe's
internal writing rules, and the plain-language conventions of the
Mapbox/MapLibre docs families.

For the project-specific code conventions the site publishes, see
`docs/CodingConventions.md`. This guide covers prose only.

## Voice, tense, and person

1. **Address the reader as "you".** Never "we" for the reader's actions and
   never "the user" in how-to prose. Reserve "we" for statements about this
   project's own choices, and prefer them sparingly.
2. **Use the active voice by default.** Name the actor. Passive voice is
   acceptable only when the actor genuinely does not matter ("The fixture
   is committed" when the committing party is irrelevant).
3. **Use the present tense for general behavior.** Write "The scheduler
   requests parent tiles", not "will request". Future tense appears only
   for something that happens genuinely later in time.
4. **Use past tense only for recorded facts.** Verification history
   ("was verified on X") states a past event; behavior of the code is
   present tense regardless of when you wrote the section.

## Sentence rules

1. **One idea per sentence.** If a sentence needs a second dash-separated
   clause to carry a second idea, split it.
2. **Lead with the answer.** The first sentence of a paragraph answers the
   reader's question or states the rule; the rest of the paragraph
   supports it. Never open with history, meta-commentary, or a rhetorical
   question.
3. **Complete sentences, not headline fragments.** A claim like
   "Contract-sync test: parses, compares, rejects" is a note to self, not
   documentation. Write "The contract-sync test parses the UDL file and
   compares it with the TypeScript mirror."
4. **Explain, then reference.** A file path or API name appears in the
   sentence only after the reader knows why it matters. Never write a
   sentence that is only a path.
5. **Give examples before abstractions.** A short concrete example
   (command, code block, or concrete value) precedes the general rule or
   the configuration surface.
6. **Keep link text descriptive.** Link text names the destination
   ("the UniFFI contract"), never "here" or "see below".

## Banned patterns

| Banned | Reason | Rewrite |
| --- | --- | --- |
| "seamlessly", "leverage", "utilize", "robust", "powerful" | Marketing filler; no information | Name what the thing actually does |
| "simply", "just", "obviously", "easy to use" | Judges the reader; unsupported claims | Delete, or show the short command |
| "ensure", "guarantee", "never fails" | Promises we cannot verify | State the mechanism and its limits |
| "blazing fast", "state-of-the-art" (any unmeasured speed/size claim) | Unverifiable | State the measured fact and its source |
| Dashes as connective padding: "X — and Y — while Z" | One idea per sentence is lost | Split into two declarative sentences |
| Telegraphic summaries: "x does Y via Z" with no article or verb | Notes are not documentation | "X does Y. The Z is what makes the Y cheap: ..." (complete sentences) |
| "Note that ...", "It is worth mentioning..." | Throat-clearing | Delete the phrase; state the note |
| Rhetorical questions, exclamation marks | Performs interest instead of informing | Delete |
| "etc.", "i.e.", "e.g." | Abbreviated Latin the reader must expand | "and so on", "that is", "for example" |
| Over-bold emphasis of whole phrases | Emphasis stops meaning anything | Bold only defined names introduced to the reader, sparingly |
| "the following section will describe" | Pre-announcing | Delete; let the heading do the work |

When a whole passage reads like a list of claims compressed to fit a
slide, rewrite it at full sentence length. Compression is acceptable in
table cells and list items only; there the fragments are parallel and
scannable by design.

## Headings, lists, and structure

1. Use sentence case for every title and heading ("The browser e2e
   loop", not "The Browser E2E Loop"). Keep product names' own
   capitalization (UniFFI, WebGPU, OpenStreetMap).
2. One heading maps to one topic. If a section needs more than four
   short paragraphs, split it with a subsection.
3. Structure a guide page as what, then why, then how: state what the
   thing is, why it exists, then the procedure.
4. Numbered lists are for sequential steps only. Bulleted lists are for
   unordered items. Tables are for pairs of related data (term/meaning,
   file/role).
5. Every procedure starts with its precondition: what must exist or be
   installed before the first command.

## Code and links

1. Render file paths, commands, identifiers, and API names in code
   font inside prose.
2. Introduce a command block with a sentence that says what it does and
   under which precondition.
3. Relative links between site chapters stay relative and are verified
   by the mdBook build (`create-missing = false` catches renamed
   chapters).
4. Private paths (`PLAN.md`, `PRD.md`, `tmp/` research notes) never
   appear in site chapters. The publish scrub refuses the build when
   they do. The published package identities are the one allowed
   exception to the `com.angoratek` content denial: the scrub permits the
   Maven coordinate form (`com.angoratek:rustic-maps-sdk[:version]`), the
   artifact package form (`com.angoratek.rustic-maps-sdk…`) and the npm
   scopes in installation snippets, while a bare `com.angoratek` (a private
   bundle id) stays refused everywhere (scripts/build-docs-site.sh,
   self-checked).

## Domain vocabulary

Use these terms consistently; do not invent synonyms mid-document.

| Term | Meaning in this codebase | Do not write |
| --- | --- | --- |
| tile | One image tile keyed by `TileKey` (zoom, x, y; 256/512 px source) | map image, chunk, texture (when it is a texture, "texture" is the GPU term) |
| tile fixtures | The recorded committed tiles the render tests serve | sample imagery, test images |
| golden | A committed reference image rendered with a fixed camera | snapshot, baseline render |
| fix | One location result from the location source (position + accuracy + time) | GPS point, location update |
| pose | The camera's full state: center, zoom, bearing, pitch | camera position (incomplete), viewpoint |
| leg | A route segment between consecutive waypoints | route portion |
| step | One maneuver-bearing unit inside a leg | instruction |
| maneuver | The turn action derived from graph or provider geometry | turn instruction (reserve that for the display text) |
| banner instruction / spoken instruction | The two output channels of an instruction; speech is *triggered* by the SDK, voiced by the platform | TTS text, voice guidance |
| deviation | The graded state of leaving the active route or step | reroute (that is the remedy, not the condition) |
| reroute | The act of computing a replacement route after deviation | navigation reset |
| trip session | The active `NavigationSession` value | navigation, route |
| contract | The frozen UniFFI UDL file, the single source of truth for bindings | interface, API (too broad) |
| surface | The FFI face a binding layer sees (native, wasm) | boundary layer |
| fixture | A recorded external response (or tile) a parser or test replays | mock (a mock is a behavioral stand-in; a fixture is recorded data) |
| cache terms | A provider contract's declared cache time-to-live and budget | caching policy (vague) |
| readiness | The diagnostics readout a reference app shows on its home card | health check |

## Publication hygiene

1. Numbers, versions, file paths, and API names are facts: copy them
   from source files, never from memory.
2. Pages whose content is generated (the UDL contract chapter, the
   third-party notices) are never hand-edited; the build script's
   byte-equality assertions refuse a desynced stage.
3. When you change source code that a site chapter documents, update
   the chapter in the same commit so no published page lags its source.