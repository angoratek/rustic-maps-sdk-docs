# Reference-app settings, persistence and sheet sizing

Date: 2026-11-01. Status: research and plan for the owner's reports that the web
demo forgets its settings across reloads, that choices should persist on every
reference app (including the last search inputs), that the Android settings
surface is too tall for the screen, and that the web demo should link to the
mobile demos.

## What the apps persist today

| Preference | Web | Android | iOS | React Native |
|---|---|---|---|---|
| Theme (Light/Dark/Auto) | no | `ThemeChoiceStore` | `ThemeChoice` UserDefaults | state only (native store not wired to the shell) |
| Provider credential | localStorage, only when "remember" is chosen | `ProviderCredentialStore` (opt-in) | keychain/UserDefaults (opt-in) | curated SDK storage |
| Base map (raster source or vector style) | no | no | no | no |
| Demo plan / scene selection | no | no | no | no |
| Camera preset | no | no | no | no |
| Offline card selections | no | no | no | no |
| Last origin / destination text and search query | no | no | no | no |

The pattern is not a missing idea but an unshared one: each app persists only
what its own milestone needed, with its own key and format.

## The shared persistence contract

One small, versioned preferences record per app, written on every explicit user
choice and read at startup after the registry is ready:

- **Remembered choices**: theme, base map (provider key plus raster source or
  style id), selected demo plan and scene, camera preset, speed multiplier, the
  last origin and destination texts, and the last search query text.
- **Never remembered**: anything transient (current camera pose, open dialog,
  current route result), the provider credential unless the user turned on the
  existing "remember on this device" switch, and any cache-like state.
- **Shape**: a single JSON object namespaced by app version, for example
  `{"version":1,"theme":"auto","baseMap":{"providerKey":"openfreemap","styleId":"bright-light"},"plans":{...},"search":{"origin":"Capitol Park","destination":"Tower Bridge"}}`. Unknown keys are ignored and a version bump drops incompatible records instead of failing.
- **Reset**: a "Reset remembered choices" row clears the record; the credential
  store stays a separate, explicitly opt-in store.
- **Platform stores**: web `localStorage` (wrapped in try/catch so private
  windows keep working); Android `SharedPreferences` beside the existing stores;
  iOS `UserDefaults`; React Native through a small native preference call on the
  existing curated module (AsyncStorage is not currently a dependency).
- **Startup order**: preferences apply before the first frame or plan: the theme
  and base map restore silently; a remembered plan pair does not auto-plan a
  route (that would spend a provider call), it fills the fields so the user can
  press Plan route — the expedite the owner asked for.

## Sheet sizing and scrolling

- One rule for every platform: the settings surface is a scrollable content
  column inside a container capped at the panel maximum height fraction (0.72
  at phone width, the existing `phonePanelMaximumHeightFraction` token), with
  its title and Close action pinned. Content that overflows scrolls; the page
  never grows past the viewport and nothing is cut off under the system bars.
- Android today is a full-height dialog whose content can exceed the screen;
  the fix is a `Column` with a bounded height plus `verticalScroll`, the same
  shape Compose's `systemBarsPadding` uses elsewhere.
- iOS already presents a sheet that can scroll; verify every section is
  reachable and that the Close/Done action stays visible.
- React Native's settings sheet already scrolls its half content; audit the
  full-state height and the dialog variant.
- The browser dialog gets `max-height: min(72vh, ...)`, an internal scroll
  region and a pinned header/footer.

## Navigation between demos

The browser demo's header links to the documentation; it should also link to
the hosted mobile demo (`/demo/mobile/` on the published site, `../mobile-demo/`
locally) so a visitor can move between the browser demo and the device builds
without hunting through the book.

## Tests

- Web: a Playwright case changes theme, base map, demo plan and both search
  fields, reloads, and asserts each value is restored; a second case asserts the
  reset row clears them and that an un-remembered key is still not persisted.
- Android/iOS: one UI case each that changes the theme and the base map,
  relaunches the app and asserts the restored state; the search fields restore
  with the remembered pair.
- React Native: a jest case hydrating the preferences and one asserting the
  native write on change.
- Sizing: a small-viewport case per platform (web viewport and each native
  device) asserts the settings surface stays inside the viewport and its last
  section is reachable.
