# Docs hostname: `sdk.mapquest.live`

Owner request (2026-10-29): make `https://sdk.mapquest.live` serve the
published SDK documentation at
`https://angoratek.github.io/rustic-maps-sdk-docs/`, keeping
`sdk.mapquest.live` in the browser's address bar. (Owner amendment the same
day: the first deployment issued a 308, which replaced the URL — the owner
wants the hostname to stay visible.)

## Verified facts (2026-10-29, read-only checks)

- The Vercel CLI is installed (50.x) and authenticated as `angoratek`.
- `mapquest.live` is registered through Vercel (expires 2027-10-15) and uses
  Vercel's nameservers (`ns1.vercel-dns.com`, `ns2.vercel-dns.com`).
- Team `angorateks-projects` owns the domain. The project
  `mapquest-demo-studio` owns `www.mapquest.live` and the apex
  `mapquest.live`; the apex already 308-redirects to `www`.
- `sdk.mapquest.live` resolves to Vercel edge addresses but currently serves
  no site/certificate (it is not attached to a project).
- The documentation target is live: `https://angoratek.github.io/rustic-maps-sdk-docs/`
  returns HTTP 200.

## Recommended shape

An **isolated proxy project** keeps the change away from
`mapquest-demo-studio` and makes the behavior explicit in one file:

```json
{
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "https://angoratek.github.io/rustic-maps-sdk-docs/$1"
    }
  ]
}
```

- An external `rewrite` proxies the response server-side: the browser sees
  `200` and keeps `sdk.mapquest.live/…` in the address bar (a `redirect`
  would issue a 308 and replace the URL).
- `$1` preserves subpaths: `/first-map.html` is fetched from
  `…/rustic-maps-sdk-docs/first-map.html`. The bare `/` maps to the docs base
  with its trailing slash. If the owner prefers every path to land on the docs
  root instead, drop the `$1`.
- The published tree uses relative asset and nav URLs (only a `href="/"` home
  link is absolute), so every asset resolves back through the proxy.
- Vercel issues the certificate automatically once `sdk.mapquest.live` is
  attached, because the domain's DNS is Vercel-managed.

## Steps (outward-facing; owner approval required before running)

1. Add `site/hostname/vercel.json` (the file above) with a short README.
2. `vercel link`/deploy that directory as a new project (for example
   `rustic-maps-sdk-docs-redirect`) with no build step (`vercel --prod`).
3. Attach the hostname: `vercel domains add sdk.mapquest.live
   rustic-maps-sdk-docs-redirect` (or the dashboard's Domains view). DNS is
   automatic on Vercel nameservers.
4. Verify:
   - `curl -s -o /dev/null -w '%{http_code}' https://sdk.mapquest.live/` → `200`
     with no `location` header.
   - `curl -s https://sdk.mapquest.live/changelog.html` → the docs page's
     title; subpaths are proxied, not redirected.
   - Certificate valid; `www`/apex behavior unchanged.
5. Record the new canonical hostname in the docs site/README once verified.

## Deployed (2026-10-29)

- Project `rustic-maps-sdk-docs-redirect` created from `site/hostname` and deployed to
  production (`vercel deploy --prod`).
- `sdk.mapquest.live` attached with `vercel domains add sdk.mapquest.live` (Vercel-managed
  DNS; certificate issued automatically).
- First deployment used `redirects`/`permanent: true` and issued a 308; on the
  owner's amendment (`2026-10-29`) it was replaced by the external `rewrites`
  proxy above and redeployed, so the address bar keeps `sdk.mapquest.live`.
- Verified after the proxy deployment: `/` → `200` with the docs title and no
  `location` header; `/changelog.html`, `/api-reference.html`,
  `/udl-contract.html` and `/css/general-e96d0476.css` → `200` through the
  proxy; `www.mapquest.live` still returns `200`; the apex still `308`s to
  `www`. Paths that 404 on GitHub Pages (e.g. the not-yet-published
  `first-map.html`) 404 through the proxy too — publication fixes them.
- The project's deployment protection is `all_except_custom_domains`, so the custom
  domain is public while the `*.vercel.app` preview URL stays team-only.

## Alternatives considered

- **Domain-level redirect in the Vercel Domains API** (`redirect` /
  `redirectStatusCode` on the domain record): viable for apex-style redirects,
  but the subdomain still needs a project attachment in common setups; the
  project-level `vercel.json` is the documented, reproducible route.
- **Adding the redirect rules to `mapquest-demo-studio`**: rejected — it
  couples the docs hostname to the demo studio's configuration and risks its
  deploy.
- **Serving the docs from Vercel instead of redirecting**: not the request;
  GitHub Pages remains the publishing target, and a redirect keeps one source
  of truth.

## Risks

| Risk | Mitigation |
|---|---|
| Redirect loop or wrong base path | 308 destination is absolute and outside `mapquest.live`; verify root and a subpath |
| Domain attachment affects `www`/apex | Isolated project, separate hostname; check the existing apex behavior after |
| Certificate not issued immediately | Vercel-managed DNS; poll the domain status in the dashboard |
| Future docs path change | The redirect file lives in the repo; update it with the site |
