# Documentation platform parity

**Status:** working agreement for the docs site (M18), recorded 2026-10-29 from
the documentation audit. `PLAN.md` carries the milestone; this page carries the
rules a change is checked against.

## 1. What "parity" means

A reader picks a platform once and gets the same story on every page:

- **Order** is always Android, iOS, React Native, WebAssembly. WebAssembly is
  last everywhere (tutorials, screenshots, downloads).
- **One scenario per tutorial.** Every platform demonstrates the *same* task
  with the same inputs and the same expected output — one camera story, one
  route request, one set of place names — so a reader can compare tabs line by
  line. A difference is stated as a capability difference ("the browser has no
  disk cache"), never left implicit in a different example.
- **Same names.** A concept keeps one name across platforms (`MapView`,
  `MapCamera`, `search`, `calculateRoute`, `startNavigation`). Platform
  spelling rules are stated once (Kotlin `UPPER_SNAKE` enum constants, Swift
  lowerCamel cases, TypeScript string unions) instead of re-explained per tab.
- **Snippets compile.** Every snippet is checked against the generated bindings
  for its platform; "compiles" is a claim the site must be able to keep.

## 2. The tab and URL model

- One page per tutorial; four panels; the selected platform is a page-wide
  choice shared by every tab set on the chapter.
- The choice is in the URL (`first-map.html#android`), is written with
  `history.replaceState` on a tab click, and is remembered across chapters.
- A deep link wins over the remembered choice. A link to a heading inside a
  panel opens that panel.
- The on-page contents list (mdBook's heading navigation) repeats every
  panel's headings; each entry is relabelled `Android · Draw a map surface` and
  the labels are re-applied whenever mdBook rebuilds the list (it re-renders on
  scroll).
- Panel ids are the platform names; tab buttons carry `aria-controls` and the
  panels `aria-labelledby`.
- Without JavaScript every panel prints in full; the site must stay readable
  that way.

## 3. Scenario constants (the "one story" table)

These are the values the tutorials use; a change must touch all four tabs.

| Constant | Value | Why |
|---|---|---|
| Demo anchor | Capitol Park, Sacramento (38.5766, −121.4944) | The recorded demo region and every fixture |
| Launch zoom | 12 for a first map, 14 for the recorded scenes | Matches the recorded tiles |
| First-map camera | `MapCamera(38.5766, −121.4944, 12.0, 0.0, 0.0)` | Same call shape on all four |
| Search query | "Capitol Park" | One of the shared demo places, so it works keyless |
| Route | two waypoints, automobile, fastest, metric | The contract's `RouteOptions` default |
| Navigation demo | the recorded Capitol Park ⇔ Tower Bridge trip | The shared simulated trace |
| Offline region | the demo bounding box, zoom 10–16 | The recorded pack shape |

## 4. Per-platform capability matrix (what the docs must state)

| Capability | Android | iOS | React Native | WebAssembly |
|---|---|---|---|---|
| Live provider calls (search, route, tiles) | yes | yes | yes | yes (registration, forward/suggest/search geocoding, routing with options, tiles; reverse geocoding pending) |
| Distance matrix | yes | yes | yes (curated `MapsSdk`) | yes (`calculateDistanceMatrix`) |
| Traffic incidents and flow | yes | yes | yes (curated `MapsSdk`) | yes (`fetchTrafficIncidents`/`fetchTrafficFlow`) |
| Disk tile cache | yes | yes | yes | no |
| Offline routing archive | yes | yes | yes | yes (in-memory bytes; the planned offline route is startable and the card names its provenance) |
| Turn-by-turn controller | yes | yes | yes | yes (driving/readback plus instruction/phase/deviation/speech events, the on-map turn banner and the drawer's one ETA-distance line; reroute-recalculation members pending) |
| Map surface | `MapView` | `MapView` | `<MapView>` | `MapView(canvas)` |
| Gestures | yes | yes | yes | yes |
| Map labels | renderer-internal | renderer-internal | renderer-internal | renderer-internal (`MapView.setVectorTileSource` resolves styled tiles and their place names inside the canvas) |

When a row changes, the offline-maps and navigation tutorials change with it.

## 5. Downloads and artifacts

- Artifacts are published under the site's own versioned path
  (`/downloads/vX.Y.Z/…`) and mirrored to an immutable release record; a new
  version never rewrites an existing file.
- Every file carries a `.sha256` sidecar and a Sigstore bundle; the version
  page prints the exact verification identity for its tag.
- The development repository is never named on the site; the publish scrub
  fails on its URL, its host patterns, credentials and internal vocabulary.
- Artifacts are mirrored to the site itself while they stay under the host's
  per-file limit (100 MB per file, 1 GB site); the iOS XCFramework zip is
  about 94 MB and is published with the rest, and a file near the limit is
  moved to the release record if the limit tightens.

## 6. Screenshots

- One capture per platform, in the parity order, from one revision, with
  runtime-supplied credentials.
- Captions name what the reader can see (readiness chip, controls, scale bar,
  attribution control) and use one vocabulary for each control.
- A capture must be verifiably from the platform it claims; the gallery states
  the revision and the camera story rather than asserting sameness it cannot
  prove.

## 7. Vocabulary

Served chapters never use development vocabulary: no "frozen contract", no
"slice"/"milestone"/"round", no "fixture"/"harness"/"playground" as
product words, no internal paths. The publish scrub fails on the recorded
phrase list (it checks the hand-authored chapters only; the generated rustdoc,
the contract text and the demo's own sources keep their own wording).
