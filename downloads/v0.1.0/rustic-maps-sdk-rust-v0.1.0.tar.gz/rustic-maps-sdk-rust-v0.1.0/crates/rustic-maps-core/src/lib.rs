//! Orchestration core of the Maps SDK: the provider registry, the
//! cache-then-network policy and the typed value boundary between providers
//! and the rest of the SDK.
//!
//! Rendering, navigation and provider crates build on this crate. No concrete
//! provider is wired in directly; applications register providers at startup
//! through [`ProviderRegistry`].

pub mod cache_policy;
pub mod offline_routing;
// Benchmark support for the offline routing engine (M7 slice 6): the
// synthetic graphs, the Dijkstra baseline's harness and the coarse CI
// budget alarm. Test/bench seam, never production routing surface.
pub mod offline_routing_benchmark;
pub mod registry;
pub mod routing_fallback;

pub use cache_policy::{CacheThenNetworkOutcome, CachedResponseStore, execute_cache_then_network};
pub use offline_routing::{
    ArchiveOfflineRoutingProvider, calculate_offline_route_from_archive_bytes,
};
pub use registry::{ProviderContract, ProviderRegistry};
pub use routing_fallback::OfflineFallbackRoutingProvider;
