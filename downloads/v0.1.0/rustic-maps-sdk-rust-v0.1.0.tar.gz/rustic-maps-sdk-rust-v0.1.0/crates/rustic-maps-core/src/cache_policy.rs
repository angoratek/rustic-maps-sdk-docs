//! Cache-then-network orchestration around any provider call.
//!
//! The caller supplies a [`CachedResponseStore`] for persistence and a future
//! that performs the network call. Values travel as typed records end to end,
//! so the orchestration path never handles untyped JSON.

use std::future::Future;
use std::sync::Arc;

use geospatial_types::SDKError;

/// Where a cache-then-network execution took its value from.
///
/// Callers use this for freshness accounting, such as a staleness indicator in
/// a user interface.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CacheThenNetworkOutcome {
    /// The value came from the cache and no network call happened.
    CacheHit,
    /// The cache missed (or the entry was expired) and the network served.
    NetworkFetch,
}

/// Storage and retrieval of deserialized provider responses, keyed by request
/// fingerprint.
///
/// `D` is the typed record the provider returns, for example
/// `Vec<PlaceResult>`. Implementations must be safe to share across threads.
pub trait CachedResponseStore<D>: Send + Sync {
    /// Looks up a cached value for a request fingerprint.
    ///
    /// # Parameters
    /// - `request_fingerprint` — the stable key identifying the request.
    ///
    /// # Returns
    /// The stored value, or `None` when no entry exists or the entry has
    /// expired.
    ///
    /// # Errors
    /// Returns [`SDKError::CacheOperationFailure`] when the store cannot be
    /// read.
    fn lookup_response(&self, request_fingerprint: &str) -> Result<Option<Arc<D>>, SDKError>;

    /// Stores a value under a request fingerprint.
    ///
    /// # Parameters
    /// - `request_fingerprint` — the stable key identifying the request.
    /// - `response_value` — the value to store.
    /// - `time_to_live_seconds` — how long the entry stays valid.
    ///
    /// # Errors
    /// Returns [`SDKError::CacheOperationFailure`] when the store cannot be
    /// written.
    fn store_response(
        &self,
        request_fingerprint: &str,
        response_value: Arc<D>,
        time_to_live_seconds: u64,
    ) -> Result<(), SDKError>;
}

/// Executes the cache-then-network policy.
///
/// The store is consulted first. On a hit, the cached value is returned. On a
/// miss, `network_fetch` is awaited once, the result is stored for
/// `time_to_live_seconds`, and the fresh value is returned.
///
/// # Parameters
/// - `response_store` — the store consulted before and written after the
///   network call.
/// - `request_fingerprint` — the stable key identifying the request.
/// - `time_to_live_seconds` — how long the stored value stays valid.
/// - `network_fetch` — called once, and only on a cache miss.
///
/// # Returns
/// The value and [`CacheThenNetworkOutcome::CacheHit`] or
/// [`CacheThenNetworkOutcome::NetworkFetch`], saying where it came from.
///
/// # Errors
/// Returns the store's [`SDKError`] when the lookup fails, and the network
/// fetch's [`SDKError`] when the fetch fails. A failed cache write never fails
/// the call: the fresh value is still returned and storage degrades to
/// cache-less operation.
///
/// # Async
/// The returned future is safe to poll on any async runtime. The network
/// closure runs after the lookup and before the write.
pub async fn execute_cache_then_network<D, FetchFuture>(
    response_store: &dyn CachedResponseStore<D>,
    request_fingerprint: &str,
    time_to_live_seconds: u64,
    network_fetch: impl FnOnce() -> FetchFuture,
) -> Result<(Arc<D>, CacheThenNetworkOutcome), SDKError>
where
    FetchFuture: Future<Output = Result<D, SDKError>>,
{
    if let Some(cached_value) = response_store.lookup_response(request_fingerprint)? {
        return Ok((cached_value, CacheThenNetworkOutcome::CacheHit));
    }

    let fresh_value = network_fetch().await?;
    let shared_value = Arc::new(fresh_value);

    // Storage is best-effort: a failing store must not lose the network result.
    let _ = response_store.store_response(
        request_fingerprint,
        shared_value.clone(),
        time_to_live_seconds,
    );

    Ok((shared_value, CacheThenNetworkOutcome::NetworkFetch))
}
#[cfg(test)]
mod tests {
    use super::{CacheThenNetworkOutcome, CachedResponseStore, execute_cache_then_network};
    use geospatial_types::GeocodeQuality;
    use geospatial_types::GeographicCoordinate;
    use geospatial_types::PlaceResult;
    use geospatial_types::SDKError;
    use std::collections::HashMap;
    use std::sync::Arc;
    use std::sync::Mutex;

    /// Fixture store recording every network fetch through the closure.
    struct FixtureStore {
        lookups: Mutex<HashMap<String, Arc<Vec<PlaceResult>>>>,
        writes_rejected: bool,
    }

    impl FixtureStore {
        fn empty(writes_rejected: bool) -> Self {
            Self {
                lookups: Mutex::new(HashMap::new()),
                writes_rejected,
            }
        }
    }

    impl CachedResponseStore<Vec<PlaceResult>> for FixtureStore {
        fn lookup_response(
            &self,
            request_fingerprint: &str,
        ) -> Result<Option<Arc<Vec<PlaceResult>>>, SDKError> {
            Ok(self
                .lookups
                .lock()
                .unwrap()
                .get(request_fingerprint)
                .cloned())
        }

        fn store_response(
            &self,
            request_fingerprint: &str,
            response_value: Arc<Vec<PlaceResult>>,
            _time_to_live_seconds: u64,
        ) -> Result<(), SDKError> {
            if self.writes_rejected {
                return Err(SDKError::CacheOperationFailure(
                    geospatial_types::CacheOperationFailureReason::WriteRejected,
                ));
            }
            self.lookups
                .lock()
                .unwrap()
                .insert(request_fingerprint.to_string(), response_value);
            Ok(())
        }
    }

    fn canned_response() -> Vec<PlaceResult> {
        vec![PlaceResult {
            structured_address_text: "1301 L St, Sacramento".to_string(),
            coordinate: GeographicCoordinate::from_degrees(38.57, -121.49).unwrap(),
            geocode_quality: GeocodeQuality::StreetAddress,
        }]
    }

    #[tokio::test]
    async fn network_fetch_runs_once_then_cache_hits() {
        let store = FixtureStore::empty(false);
        let mut network_call_count = 0;

        let (first_value, first_outcome) =
            execute_cache_then_network(&store, "fingerprint-a", 3600, || async {
                network_call_count += 1;
                Ok::<_, SDKError>(canned_response())
            })
            .await
            .unwrap();
        assert_eq!(first_outcome, CacheThenNetworkOutcome::NetworkFetch);
        assert_eq!(first_value.len(), 1);

        let (second_value, second_outcome) =
            execute_cache_then_network(&store, "fingerprint-a", 3600, || async {
                network_call_count += 1;
                Ok::<_, SDKError>(canned_response())
            })
            .await
            .unwrap();
        assert_eq!(second_outcome, CacheThenNetworkOutcome::CacheHit);
        assert_eq!(second_value, first_value);
        assert_eq!(network_call_count, 1);
    }

    #[tokio::test]
    async fn failed_cache_write_still_returns_fresh_value() {
        let store = FixtureStore::empty(true);
        let (value, outcome) =
            execute_cache_then_network(&store, "fingerprint-b", 3600, || async {
                Ok::<_, SDKError>(canned_response())
            })
            .await
            .unwrap();
        assert_eq!(outcome, CacheThenNetworkOutcome::NetworkFetch);
        assert_eq!(value.len(), 1);
    }

    #[tokio::test]
    async fn network_failure_propagates() {
        let store = FixtureStore::empty(false);
        let failure = execute_cache_then_network(&store, "fingerprint-c", 3600, || async {
            Err::<Vec<PlaceResult>, SDKError>(SDKError::NetworkRequestFailed("offline".into()))
        })
        .await;
        assert!(matches!(failure, Err(SDKError::NetworkRequestFailed(_))));
    }
}
