# Style fixtures

## `demotiles-style.json`

- **Source:** <https://demotiles.maplibre.org/style.json>
- **Fetched:** 2026-11-02, byte-for-byte as served.
- **Repository:** <https://github.com/maplibre/demotiles>
- **License:** BSD 3-Clause, Copyright (c) 2021 MapLibre. The licence text is
  committed at `docs/THIRD_PARTY_LICENSES/maplibre-demotiles-LICENSE.txt`.
  The style's own metadata line is retained verbatim: "This style was
  generated on MapTiler Cloud. Usage is governed by the license terms in
  https://github.com/maplibre/demotiles/blob/gh-pages/LICENSE".
- **Data attribution:** vector tiles © OpenStreetMap contributors, licensed
  under the Open Database License (ODbL), served by the OSM US Tile Service.
  The country boundaries and country data derive from Natural Earth.

The fixture is test data, never a product default. Its source URLs name the
public upstream service only so the document parses as published; a test
binds those source ids to local fixtures and never requests the network.
