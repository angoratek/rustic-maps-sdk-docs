//! End-to-end tests of the foreign-callback provider injection (M4 slice 4):
//! a Rust-side implementation of the exported `[Trait, WithForeign]`
//! callback contracts — standing in for the foreign (Kotlin/Swift)
//! implementations the generated bindings would produce — registers through
//! `MapSdk::register_*_from_foreign`, and the awaited `MapSdk` calls resolve
//! future -> registry -> adapter -> callback contract -> binding record. A
//! failing callback contract must surface its `SdkError` variant after the
//! round trip through the core error model.

use std::sync::Arc;

use async_trait::async_trait;

use rustic_maps::{
    GeocodeQuality, GeocodingProvider, MapSdk, Place, RasterImageFormat, RasterTileData,
    RasterTileProvider, RasterTileResolution, SdkError,
};

/// Latitude of the forward-geocode response place, in decimal degrees.
const RESPONSE_LATITUDE_DEGREES: f64 = 38.57944;
/// Longitude of the forward-geocode response place, in decimal degrees.
const RESPONSE_LONGITUDE_DEGREES: f64 = -121.49085;
/// Latitude the reverse-geocode request sends and the echo rounds back, in
/// decimal degrees.
const REQUEST_LATITUDE_DEGREES: f64 = 38.5766;
/// Longitude the reverse-geocode request sends and the echo rounds back, in
/// decimal degrees.
const REQUEST_LONGITUDE_DEGREES: f64 = -121.4944;
/// Address text the forward-geocode callback answers with.
const RESPONSE_ADDRESS_TEXT: &str = "Tower Bridge, Sacramento";
/// Reverse-geocode response address text composed from the echoed
/// coordinate, matching the mock echo convention of the provider suite.
const RESPONSE_REVERSE_ADDRESS_TEXT: &str = "reverse geocode 38.5766, -121.4944";
/// Detail text the failing geocoding callback throws.
const FOREIGN_FAILURE_DETAIL: &str = "the foreign geocoder rejected the request";
/// Tile column the raster callback echoes.
const TEST_TILE_X: u32 = 8459;
/// Tile row the raster callback echoes.
const TEST_TILE_Y: u32 = 5721;
/// Zoom level the raster test fetches at.
const TEST_ZOOM_LEVEL: u8 = 12;
/// Distinct texel count of the echoed tile payload.
const TEST_IMAGE_BYTE_COUNT: usize = 2048;

fn coordinate(latitude: f64, longitude: f64) -> rustic_maps::GeographicCoordinate {
    rustic_maps::GeographicCoordinate {
        latitude,
        longitude,
    }
}

fn response_places() -> Vec<Place> {
    vec![Place {
        structured_address_text: RESPONSE_ADDRESS_TEXT.to_string(),
        coordinate: coordinate(RESPONSE_LATITUDE_DEGREES, RESPONSE_LONGITUDE_DEGREES),
        geocode_quality: GeocodeQuality::StreetAddress,
    }]
}

fn response_image_bytes() -> Vec<u8> {
    vec![7; TEST_IMAGE_BYTE_COUNT]
}

/// Geocoding callback implementation answering both contract calls with a
/// fixed success response, or throwing the configured failure.
struct FixedGeocodingCallback {
    success_places: Vec<Place>,
    failure: Option<SdkError>,
}

impl FixedGeocodingCallback {
    /// Builds the callback answering with the fixed places and an echo of
    /// every reverse-geocode coordinate.
    fn succeed_with(success_places: Vec<Place>) -> Self {
        Self {
            success_places,
            failure: None,
        }
    }

    /// Builds the callback throwing the fixed failure on every call.
    fn fail_with(failure: SdkError) -> Self {
        Self {
            success_places: Vec::new(),
            failure: Some(failure),
        }
    }
}

#[async_trait]
impl GeocodingProvider for FixedGeocodingCallback {
    async fn forward_geocode(&self, _address_text: String) -> Result<Vec<Place>, SdkError> {
        match &self.failure {
            Some(failure) => Err(failure.clone()),
            None => Ok(self.success_places.clone()),
        }
    }

    async fn reverse_geocode(
        &self,
        coordinate: rustic_maps::GeographicCoordinate,
    ) -> Result<Vec<Place>, SdkError> {
        match &self.failure {
            Some(failure) => Err(failure.clone()),
            None => Ok(vec![Place {
                structured_address_text: format!(
                    "reverse geocode {}, {}",
                    coordinate.latitude, coordinate.longitude
                ),
                coordinate,
                geocode_quality: GeocodeQuality::Street,
            }]),
        }
    }
}

/// Raster-tile callback implementation answering every fetch with the fixed
/// byte payload, or throwing the configured failure.
struct FixedRasterTileCallback {
    success_image_bytes: Vec<u8>,
    failure: Option<SdkError>,
}

impl FixedRasterTileCallback {
    /// Builds the callback answering with the fixed byte payload.
    fn succeed_with(success_image_bytes: Vec<u8>) -> Self {
        Self {
            success_image_bytes,
            failure: None,
        }
    }

    /// Builds the callback throwing the fixed failure on every fetch.
    fn fail_with(failure: SdkError) -> Self {
        Self {
            success_image_bytes: Vec::new(),
            failure: Some(failure),
        }
    }
}

#[async_trait]
impl RasterTileProvider for FixedRasterTileCallback {
    async fn fetch_raster_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
        image_format: RasterImageFormat,
        tile_resolution: RasterTileResolution,
    ) -> Result<RasterTileData, SdkError> {
        match &self.failure {
            Some(failure) => Err(failure.clone()),
            None => Ok(RasterTileData {
                tile_x,
                tile_y,
                zoom_level,
                image_format,
                tile_resolution,
                image_bytes: self.success_image_bytes.clone(),
            }),
        }
    }
}

#[tokio::test]
async fn foreign_geocoding_callback_serves_forward_geocode_end_to_end() {
    let map_sdk = MapSdk::new();
    map_sdk.register_geocoding_provider_from_foreign(Arc::new(
        FixedGeocodingCallback::succeed_with(response_places()),
    ));
    let places = map_sdk
        .forward_geocode("any address the callback ignores".to_string())
        .await
        .expect("the registered callback geocoder serves the address");
    assert_eq!(places, response_places());
}

#[tokio::test]
async fn foreign_geocoding_callback_serves_reverse_geocode_end_to_end() {
    let map_sdk = MapSdk::new();
    map_sdk.register_geocoding_provider_from_foreign(Arc::new(
        FixedGeocodingCallback::succeed_with(Vec::new()),
    ));
    let places = map_sdk
        .reverse_geocode(coordinate(
            REQUEST_LATITUDE_DEGREES,
            REQUEST_LONGITUDE_DEGREES,
        ))
        .await
        .expect("the registered callback geocoder serves the coordinate");
    assert_eq!(places.len(), 1);
    assert_eq!(
        places[0].structured_address_text,
        RESPONSE_REVERSE_ADDRESS_TEXT
    );
    assert_eq!(
        places[0].coordinate,
        coordinate(REQUEST_LATITUDE_DEGREES, REQUEST_LONGITUDE_DEGREES)
    );
    assert_eq!(places[0].geocode_quality, GeocodeQuality::Street);
}

#[tokio::test]
async fn foreign_raster_tile_callback_serves_the_fetch_end_to_end() {
    let map_sdk = MapSdk::new();
    map_sdk.register_raster_tile_provider_from_foreign(Arc::new(
        FixedRasterTileCallback::succeed_with(response_image_bytes()),
    ));
    let raster_tile = map_sdk
        .fetch_raster_tile(
            TEST_TILE_X,
            TEST_TILE_Y,
            TEST_ZOOM_LEVEL,
            RasterImageFormat::Png,
            RasterTileResolution::Retina,
        )
        .await
        .expect("the registered callback tile provider serves the address");
    assert_eq!(raster_tile.tile_x, TEST_TILE_X);
    assert_eq!(raster_tile.tile_y, TEST_TILE_Y);
    assert_eq!(raster_tile.zoom_level, TEST_ZOOM_LEVEL);
    assert_eq!(raster_tile.image_format, RasterImageFormat::Png);
    assert_eq!(raster_tile.tile_resolution, RasterTileResolution::Retina);
    assert_eq!(raster_tile.image_bytes, response_image_bytes());
}

#[tokio::test]
async fn foreign_geocoding_callback_error_surfaces_as_the_mapped_sdk_error_variant() {
    let map_sdk = MapSdk::new();
    map_sdk.register_geocoding_provider_from_foreign(Arc::new(FixedGeocodingCallback::fail_with(
        SdkError::ProviderRequestRejected {
            detail: FOREIGN_FAILURE_DETAIL.to_string(),
        },
    )));
    let failure = map_sdk
        .forward_geocode("any address the callback rejects".to_string())
        .await
        .expect_err("the failing callback must throw");
    assert_eq!(
        failure,
        SdkError::ProviderRequestRejected {
            detail: FOREIGN_FAILURE_DETAIL.to_string(),
        }
    );
}

#[tokio::test]
async fn foreign_raster_tile_callback_error_surfaces_as_the_mapped_sdk_error_variant() {
    let map_sdk = MapSdk::new();
    map_sdk.register_raster_tile_provider_from_foreign(Arc::new(
        FixedRasterTileCallback::fail_with(SdkError::RateLimitExhausted),
    ));
    let failure = map_sdk
        .fetch_raster_tile(
            TEST_TILE_X,
            TEST_TILE_Y,
            TEST_ZOOM_LEVEL,
            RasterImageFormat::Jpeg,
            RasterTileResolution::Standard,
        )
        .await
        .expect_err("the failing callback must throw");
    assert_eq!(failure, SdkError::RateLimitExhausted);
}

#[tokio::test]
async fn foreign_callback_mapped_failure_is_recorded_on_the_diagnostic_seam() {
    let map_sdk = MapSdk::new();
    map_sdk.register_geocoding_provider_from_foreign(Arc::new(FixedGeocodingCallback::fail_with(
        SdkError::NetworkRequestFailed {
            detail: FOREIGN_FAILURE_DETAIL.to_string(),
        },
    )));
    map_sdk
        .forward_geocode("any address the callback rejects".to_string())
        .await
        .expect_err("the failing callback must throw");
    let diagnostics = map_sdk.latest_provider_failure_diagnostics();
    assert_eq!(diagnostics.len(), 1, "exactly one recorded failure");
    let diagnostic = &diagnostics[0];
    assert_eq!(
        diagnostic.provider_contract_name, "GeocodingProvider",
        "the entry names the failing callback contract"
    );
    assert_eq!(
        diagnostic.provider_method_name, "forward_geocode",
        "the entry names the failing callback method"
    );
    assert_eq!(
        diagnostic.failure_classification,
        rustic_maps::ProviderFailureClassification::MappedContractError,
    );
    assert_eq!(
        diagnostic.failure_detail,
        "network request failed: the foreign geocoder rejected the request",
        "the mapped entry carries the thrown binding error's verbatim display form"
    );
    assert!(
        diagnostic.timestamp_milliseconds_since_epoch > 0,
        "the entry carries its recording timestamp"
    );
    // The readback is non-destructive: a second read (nothing failed between
    // the reads) returns the same single entry.
    assert_eq!(
        map_sdk.latest_provider_failure_diagnostics().len(),
        1,
        "the readback never clears the ring"
    );
}

#[tokio::test]
async fn foreign_callback_unclassified_failure_is_recorded_with_the_callback_reason() {
    let map_sdk = MapSdk::new();
    // A Rust-side callback cannot reproduce the uniffi unmapped-exception
    // path (which needs real foreign bindings), so the test stands in for it
    // the way the round-11 FFI-boundary pin tests do: the conversion of the
    // callback machinery's own error is driven directly, then handed to the
    // adapter as the callback's failure.
    let unclassified_failure: SdkError =
        uniffi::UnexpectedUniFFICallbackError::new(FOREIGN_FAILURE_DETAIL).into();
    map_sdk.register_geocoding_provider_from_foreign(Arc::new(FixedGeocodingCallback::fail_with(
        unclassified_failure,
    )));
    for _ in 0..2 {
        let failure = map_sdk
            .forward_geocode("any address the callback rejects".to_string())
            .await
            .expect_err("the failing callback must throw");
        assert!(
            failure
                .to_string()
                .contains("the provider implementation failed without a mapped error"),
            "the failure still surfaces typed as the round-11 conversion: {failure}"
        );
    }
    let diagnostics = map_sdk.latest_provider_failure_diagnostics();
    assert_eq!(diagnostics.len(), 2, "one entry per failed call");
    for diagnostic in &diagnostics {
        assert_eq!(
            diagnostic.provider_contract_name, "GeocodingProvider",
            "the entries name the failing contract"
        );
        assert_eq!(
            diagnostic.provider_method_name, "forward_geocode",
            "the entries name the failing callback method"
        );
        assert_eq!(
            diagnostic.failure_classification,
            rustic_maps::ProviderFailureClassification::UnclassifiedCallbackFailure,
            "the unclassified shape is recognized and reported as such"
        );
        assert_eq!(
            diagnostic.failure_detail, FOREIGN_FAILURE_DETAIL,
            "the unclassified entries carry the callback machinery's verbatim reason"
        );
    }
    assert!(
        diagnostics[0].timestamp_milliseconds_since_epoch
            <= diagnostics[1].timestamp_milliseconds_since_epoch,
        "the entries read back oldest first"
    );
}

#[tokio::test]
async fn foreign_callback_failures_accumulate_and_the_ring_is_per_map_sdk() {
    let map_sdk = MapSdk::new();
    map_sdk.register_raster_tile_provider_from_foreign(Arc::new(
        FixedRasterTileCallback::fail_with(SdkError::ProviderRequestRejected {
            detail: FOREIGN_FAILURE_DETAIL.to_string(),
        }),
    ));
    for _ in 0..3 {
        map_sdk
            .fetch_raster_tile(
                TEST_TILE_X,
                TEST_TILE_Y,
                TEST_ZOOM_LEVEL,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .expect_err("the failing callback must throw");
    }
    let diagnostics = map_sdk.latest_provider_failure_diagnostics();
    assert_eq!(
        diagnostics.len(),
        3,
        "one entry per failed call, oldest first"
    );
    assert_eq!(diagnostics[0].provider_contract_name, "RasterTileProvider");
    assert_eq!(diagnostics[0].provider_method_name, "fetch_raster_tile");
    for window in diagnostics.windows(2) {
        assert!(
            window[0].timestamp_milliseconds_since_epoch
                <= window[1].timestamp_milliseconds_since_epoch,
            "the entries read back in recording order"
        );
    }
    // A separately constructed object's ring starts empty: the seam is
    // per MapSdk, not process-wide.
    assert_eq!(
        MapSdk::new().latest_provider_failure_diagnostics().len(),
        0,
        "a fresh MapSdk serves an empty provider-failure ring"
    );
}
