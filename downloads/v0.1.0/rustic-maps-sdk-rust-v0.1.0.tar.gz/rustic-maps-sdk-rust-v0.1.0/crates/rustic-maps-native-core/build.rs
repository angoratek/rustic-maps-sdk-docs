//! Regenerates the Rust scaffolding from the frozen UDL contract.

fn main() {
    uniffi::generate_scaffolding("src/rustic_maps.udl").unwrap();
}
