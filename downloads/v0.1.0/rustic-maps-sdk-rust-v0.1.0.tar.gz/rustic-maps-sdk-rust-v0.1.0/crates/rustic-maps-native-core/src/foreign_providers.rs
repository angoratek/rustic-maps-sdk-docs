//! The foreign-callback provider injection surface: the exported callback
//! contracts that foreign code (Kotlin, Swift) implements to serve a
//! provider contract of the SDK, and the adapters that bridge those
//! implementations onto the native `geospatial-traits` traits behind the
//! `rustic-maps-core` [`ProviderRegistry`](rustic_maps_core::ProviderRegistry).
//!
//! The contract names here are the plain provider-contract names of the UDL
//! (`GeocodingProvider`, `RasterTileProvider`), so they resolve exactly as
//! the uniffi-generated scaffolding expects while staying the names a
//! foreign implementor reads (see the UDL provider-contract documentation).
//! The callback methods exchange binding records and throw
//! [`crate::SdkError`]; the adapters convert the mirror records back to the
//! native `geospatial-types` values through the [`crate::records`]
//! converters and re-raise the binding error as the core error, so the
//! provider registry sees an ordinary native provider implementation.
//!
//! The adapters are also the provider-failure diagnostic seam's write sites:
//! each holds the owning `MapSdk`'s [`ProviderFailureDiagnosticsRing`] and
//! records every failed foreign contract call with the contract and the
//! method it occurred on, its classification and the verbatim failure text
//! (see the inline `foreign_failure_with_diagnostic` helper).
//!
//! The traits are `#[async_trait]` desugared to match the generated
//! foreign-callback adapters, which uniffi emits implementing these same
//! traits over the foreign vtable.

use std::sync::Arc;

use geospatial_traits as native_traits;
use geospatial_types::SDKError;

use crate::provider_diagnostics::{
    ProviderFailureDiagnosticsRing, SharedProviderFailureDiagnostics,
};
use crate::records::{
    GeographicCoordinate, Place, ProviderFailureClassification, RasterImageFormat, RasterTileData,
    RasterTileResolution,
};

/// Contract name the provider-failure diagnostic seam reports for the
/// geocoding callback contract (the plain UDL contract name).
const GEOCODING_CONTRACT_NAME: &str = "GeocodingProvider";
/// Contract name the provider-failure diagnostic seam reports for the
/// raster-tile callback contract (the plain UDL contract name).
const RASTER_TILE_CONTRACT_NAME: &str = "RasterTileProvider";
/// Method name the provider-failure diagnostic seam reports for the
/// forward-geocode callback method.
const FORWARD_GEOCODE_METHOD_NAME: &str = "forward_geocode";
/// Method name the provider-failure diagnostic seam reports for the
/// reverse-geocode callback method.
const REVERSE_GEOCODE_METHOD_NAME: &str = "reverse_geocode";
/// Method name the provider-failure diagnostic seam reports for the
/// raster-tile-fetch callback method.
const FETCH_RASTER_TILE_METHOD_NAME: &str = "fetch_raster_tile";

/// Geocoding contract implemented by foreign code and registered on
/// `MapSdk` through `register_geocoding_provider_from_foreign`.
#[async_trait::async_trait]
pub trait GeocodingProvider: Send + Sync {
    /// Resolves a free-form address text into candidate places.
    async fn forward_geocode(&self, address_text: String) -> Result<Vec<Place>, crate::SdkError>;

    /// Resolves a coordinate into candidate places describing that position.
    async fn reverse_geocode(
        &self,
        coordinate: GeographicCoordinate,
    ) -> Result<Vec<Place>, crate::SdkError>;

    /// Internally required by the uniffi foreign-handle machinery (the
    /// foreign-handle probe of the uniffi 0.31 trait-object lowering);
    /// Rust-side implementations keep the default, which reports a
    /// Rust-implemented object.
    #[doc(hidden)]
    fn uniffi_foreign_handle(&self) -> Option<::uniffi::Handle> {
        Option::None
    }
}

/// Raster-tile contract implemented by foreign code and registered on
/// `MapSdk` through `register_raster_tile_provider_from_foreign`.
#[async_trait::async_trait]
pub trait RasterTileProvider: Send + Sync {
    /// Fetches one web-mercator XYZ raster tile at the requested resolution.
    async fn fetch_raster_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
        image_format: RasterImageFormat,
        tile_resolution: RasterTileResolution,
    ) -> Result<RasterTileData, crate::SdkError>;

    /// Internally required by the uniffi foreign-handle machinery (see
    /// [`GeocodingProvider::uniffi_foreign_handle`]).
    #[doc(hidden)]
    fn uniffi_foreign_handle(&self) -> Option<::uniffi::Handle> {
        Option::None
    }
}

/// Bridges a foreign implementation of the [`GeocodingProvider`] callback
/// contract onto the native `geospatial-traits` trait: an ordinary native
/// provider for the registry whose calls lower into the foreign
/// implementation, recording every failed call on the owning `MapSdk`'s
/// provider-failure diagnostic ring.
pub(crate) struct ForeignGeocodingProvider {
    /// The foreign implementation serving the contract calls.
    geocoding_implementation: Arc<dyn GeocodingProvider>,
    /// The owning `MapSdk`'s provider-failure diagnostics ring.
    provider_failure_diagnostics: SharedProviderFailureDiagnostics,
}

impl ForeignGeocodingProvider {
    /// Wraps the foreign geocoding implementation for native registration.
    pub(crate) fn new(
        geocoding_implementation: Arc<dyn GeocodingProvider>,
        provider_failure_diagnostics: SharedProviderFailureDiagnostics,
    ) -> Self {
        Self {
            geocoding_implementation,
            provider_failure_diagnostics,
        }
    }
}

#[async_trait::async_trait]
impl native_traits::GeocodingProvider for ForeignGeocodingProvider {
    async fn forward_geocode(
        &self,
        address_text: &str,
    ) -> Result<Vec<geospatial_types::PlaceResult>, SDKError> {
        let foreign_places = self
            .geocoding_implementation
            .forward_geocode(address_text.to_string())
            .await
            .map_err(|foreign_failure| {
                foreign_failure_with_diagnostic(
                    &self.provider_failure_diagnostics,
                    GEOCODING_CONTRACT_NAME,
                    FORWARD_GEOCODE_METHOD_NAME,
                    foreign_failure,
                )
            })?;
        Ok(foreign_places
            .into_iter()
            .map(Place::into_native_place_result)
            .collect())
    }

    async fn reverse_geocode(
        &self,
        coordinate: &geospatial_types::GeographicCoordinate,
    ) -> Result<Vec<geospatial_types::PlaceResult>, SDKError> {
        let foreign_places = self
            .geocoding_implementation
            .reverse_geocode(GeographicCoordinate::from_native_coordinate(coordinate))
            .await
            .map_err(|foreign_failure| {
                foreign_failure_with_diagnostic(
                    &self.provider_failure_diagnostics,
                    GEOCODING_CONTRACT_NAME,
                    REVERSE_GEOCODE_METHOD_NAME,
                    foreign_failure,
                )
            })?;
        Ok(foreign_places
            .into_iter()
            .map(Place::into_native_place_result)
            .collect())
    }
}

/// Bridges a foreign implementation of the [`RasterTileProvider`] callback
/// contract onto the native `geospatial-traits` trait: an ordinary native
/// provider for the registry whose calls lower into the foreign
/// implementation, recording every failed call on the owning `MapSdk`'s
/// provider-failure diagnostic ring.
pub(crate) struct ForeignRasterTileProvider {
    /// The foreign implementation serving the contract calls.
    raster_tile_implementation: Arc<dyn RasterTileProvider>,
    /// The owning `MapSdk`'s provider-failure diagnostics ring.
    provider_failure_diagnostics: SharedProviderFailureDiagnostics,
}

impl ForeignRasterTileProvider {
    /// Wraps the foreign raster-tile implementation for native registration.
    pub(crate) fn new(
        raster_tile_implementation: Arc<dyn RasterTileProvider>,
        provider_failure_diagnostics: SharedProviderFailureDiagnostics,
    ) -> Self {
        Self {
            raster_tile_implementation,
            provider_failure_diagnostics,
        }
    }
}

#[async_trait::async_trait]
impl native_traits::RasterTileProvider for ForeignRasterTileProvider {
    async fn fetch_raster_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
        image_format: geospatial_types::RasterImageFormat,
        tile_resolution: geospatial_types::RasterTileResolution,
    ) -> Result<geospatial_types::RasterTileData, SDKError> {
        let foreign_tile = self
            .raster_tile_implementation
            .fetch_raster_tile(
                tile_x,
                tile_y,
                zoom_level,
                RasterImageFormat::from_native_image_format(image_format),
                RasterTileResolution::from_native_tile_resolution(tile_resolution),
            )
            .await
            .map_err(|foreign_failure| {
                foreign_failure_with_diagnostic(
                    &self.provider_failure_diagnostics,
                    RASTER_TILE_CONTRACT_NAME,
                    FETCH_RASTER_TILE_METHOD_NAME,
                    foreign_failure,
                )
            })?;
        Ok(foreign_tile.into_native_raster_tile_data())
    }
}

/// The provider-failure diagnostic seam's conversion helper: records one
/// failed foreign-callback provider call on the owning `MapSdk`'s ring — the
/// contract and the callback method it occurred on, its classification, and
/// the verbatim failure text — and then converts the foreign
/// implementation's binding failure into the core error the registry path
/// carries.
///
/// The classification is mechanical: a failure carrying the
/// unclassified-callback conversion's verbatim detail prefix is that
/// conversion's subject and records the callback machinery's embedded reason
/// under `UnclassifiedCallbackFailure`; every other failure was a foreign
/// implementation's own typed `SdkError` throw and records its display form
/// under `MappedContractError`. A foreign implementation throwing the
/// conversion's exact phrasing is indistinguishable; the UDL documentation
/// states that limitation.
fn foreign_failure_with_diagnostic(
    provider_failure_diagnostics: &ProviderFailureDiagnosticsRing,
    provider_contract_name: &str,
    provider_method_name: &str,
    foreign_failure: crate::SdkError,
) -> SDKError {
    let (failure_classification, failure_detail) =
        match foreign_failure.unclassified_foreign_callback_reason() {
            Some(callback_failure_reason) => (
                ProviderFailureClassification::UnclassifiedCallbackFailure,
                callback_failure_reason.to_string(),
            ),
            Option::None => (
                ProviderFailureClassification::MappedContractError,
                foreign_failure.to_string(),
            ),
        };
    provider_failure_diagnostics.record(
        provider_contract_name,
        provider_method_name,
        failure_classification,
        failure_detail,
    );
    SDKError::from(foreign_failure)
}
