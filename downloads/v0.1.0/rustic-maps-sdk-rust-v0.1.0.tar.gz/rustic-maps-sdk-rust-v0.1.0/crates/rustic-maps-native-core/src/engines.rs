//! The engine facades: typed capability objects constructed over an existing
//! [`MapSdk`].
//!
//! Each engine holds the very same [`MapSdk`] the application already owns —
//! one provider registry, one tile-cache installation, one diagnostics ring
//! set — and delegates every member to the matching `MapSdk` method
//! verbatim. The engines add no validation, no mapping and no error
//! rewriting of their own: a typed failure is the SDK's typed failure with
//! the same variant and the same detail message, so an integrator moving
//! from `map_sdk.search(...)` to `search_engine.search(...)` observes no
//! behavioural change. Their point is vocabulary: the same engine names
//! reach Kotlin, Swift, React Native and the wasm mirror through one UDL
//! contract, and an application holds one `MapSdk` plus one engine per
//! capability instead of a single object with every call on it.
//!
//! The async members await the SDK's runtime-independent futures directly,
//! so the exported futures stay `Send` (the provider reactor work already
//! hands back through [`crate::runtime::drive`]).

use std::sync::Arc;

use crate::diagnostics::SdkDiagnosticEventListener;
use crate::error::SdkError;
use crate::provider::MapSdk;
use crate::records::{
    BoundingBox, DistanceMatrix, GeographicCoordinate, Place, Route, RouteOptions, SdkLogSeverity,
    TileCacheTerms, TransportationMode,
};

/// Search and geocoding facade over a [`MapSdk`]'s registered provider
/// contracts.
pub struct SearchEngine {
    /// The SDK whose provider registry serves this engine's calls.
    map_sdk: Arc<MapSdk>,
}

impl SearchEngine {
    /// Builds the engine over the SDK whose provider registry serves its
    /// calls.
    pub fn new(map_sdk: Arc<MapSdk>) -> Self {
        Self { map_sdk }
    }

    /// Returns full search results for a settled query; the boundary
    /// restricts the search when given. Delegates to [`MapSdk::search`].
    pub async fn search(
        &self,
        query_text: String,
        search_boundary: Option<BoundingBox>,
    ) -> Result<Vec<Place>, SdkError> {
        self.map_sdk.search(query_text, search_boundary).await
    }

    /// Returns fast completion candidates while the user types; the
    /// boundary restricts the search when given. Delegates to
    /// [`MapSdk::suggest`].
    pub async fn suggest(
        &self,
        query_text: String,
        search_boundary: Option<BoundingBox>,
    ) -> Result<Vec<Place>, SdkError> {
        self.map_sdk.suggest(query_text, search_boundary).await
    }

    /// Resolves a coordinate into candidate places describing that
    /// position. Delegates to [`MapSdk::reverse_geocode`].
    pub async fn reverse_geocode(
        &self,
        coordinate: GeographicCoordinate,
    ) -> Result<Vec<Place>, SdkError> {
        self.map_sdk.reverse_geocode(coordinate).await
    }
}

/// Routing facade over a [`MapSdk`]'s registered provider contracts.
pub struct RoutingEngine {
    /// The SDK whose provider registry serves this engine's calls.
    map_sdk: Arc<MapSdk>,
}

impl RoutingEngine {
    /// Builds the engine over the SDK whose provider registry serves its
    /// calls.
    pub fn new(map_sdk: Arc<MapSdk>) -> Self {
        Self { map_sdk }
    }

    /// Calculates a route through the ordered waypoints with the given
    /// options. Delegates to [`MapSdk::calculate_route`].
    pub async fn calculate_route(
        &self,
        waypoints: Vec<GeographicCoordinate>,
        route_options: RouteOptions,
    ) -> Result<Route, SdkError> {
        self.map_sdk.calculate_route(waypoints, route_options).await
    }

    /// Calculates durations and distances for every origin-destination
    /// pair. Delegates to [`MapSdk::calculate_distance_matrix`].
    pub async fn calculate_distance_matrix(
        &self,
        origins: Vec<GeographicCoordinate>,
        destinations: Vec<GeographicCoordinate>,
        transportation_mode: TransportationMode,
    ) -> Result<DistanceMatrix, SdkError> {
        self.map_sdk
            .calculate_distance_matrix(origins, destinations, transportation_mode)
            .await
    }
}

/// Offline tile-cache settings facade over a [`MapSdk`]'s installed tile
/// cache.
pub struct OfflineManager {
    /// The SDK whose installed tile cache this manager reads and tunes.
    map_sdk: Arc<MapSdk>,
}

impl OfflineManager {
    /// Builds the manager over the SDK whose installed tile cache it reads
    /// and tunes.
    pub fn new(map_sdk: Arc<MapSdk>) -> Self {
        Self { map_sdk }
    }

    /// Reads the effective raster-tile caching terms of the installed
    /// cache. Delegates to [`MapSdk::raster_tile_cache_terms`].
    pub fn tile_cache_terms(&self) -> Result<TileCacheTerms, SdkError> {
        self.map_sdk.raster_tile_cache_terms()
    }

    /// Overrides the installed raster-tile cache's time-to-live in seconds.
    /// Delegates to [`MapSdk::set_raster_tile_cache_time_to_live`].
    pub fn set_tile_time_to_live(&self, time_to_live_seconds: u64) -> Result<(), SdkError> {
        self.map_sdk
            .set_raster_tile_cache_time_to_live(time_to_live_seconds)
    }
}

/// Diagnostics facade over a [`MapSdk`]'s structured log-event stream and
/// bounded ring buffers.
pub struct Diagnostics {
    /// The SDK whose diagnostics this facade observes.
    map_sdk: Arc<MapSdk>,
}

impl Diagnostics {
    /// Builds the facade over the SDK whose diagnostics it observes.
    pub fn new(map_sdk: Arc<MapSdk>) -> Self {
        Self { map_sdk }
    }

    /// Subscribes the foreign listener to the SDK's structured internal log
    /// events at `minimum_severity` or above. Delegates to
    /// [`MapSdk::subscribe_to_diagnostic_events`].
    pub fn add_listener(
        &self,
        listener: Arc<dyn SdkDiagnosticEventListener>,
        minimum_severity: SdkLogSeverity,
    ) {
        self.map_sdk
            .subscribe_to_diagnostic_events(listener, minimum_severity);
    }

    /// Drains up to `maximum_count` of the most recent ring events at
    /// `minimum_severity` or above through the listener, oldest first, and
    /// answers how many were delivered. Delegates to
    /// [`MapSdk::flush_recent_diagnostic_events`].
    pub fn flush_recent(
        &self,
        listener: Arc<dyn SdkDiagnosticEventListener>,
        minimum_severity: SdkLogSeverity,
        maximum_count: u32,
    ) -> u32 {
        self.map_sdk
            .flush_recent_diagnostic_events(listener, minimum_severity, maximum_count)
    }
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicU32, Ordering};
    use std::sync::{Arc, Mutex};

    use geospatial_traits::mock::{
        MockDistanceMatrixProvider, MockGeocodingProvider, MockRoutingProvider,
        MockSearchPlaceProvider,
    };

    use super::{Diagnostics, OfflineManager, RoutingEngine, SearchEngine};
    use crate::diagnostics::SdkDiagnosticEventListener;
    use crate::error::SdkError;
    use crate::provider::MapSdk;
    use crate::records::{
        AvoidOptions, GeographicCoordinate, LogEvent, RouteOptions, RouteStrategy, SdkLogSeverity,
        TransportationMode, UnitSystem,
    };

    /// Latitude of the test coordinates, in decimal degrees (the coordinate
    /// the geocoding mock answers with): downtown Sacramento.
    const TEST_LATITUDE_DEGREES: f64 = 38.5766;
    /// Longitude of the test coordinates, in decimal degrees.
    const TEST_LONGITUDE_DEGREES: f64 = -121.4944;
    /// Latitude of the second mock coordinate, north-east of the anchor.
    const OTHER_LATITUDE_DEGREES: f64 = 39.5296;
    /// Longitude of the second mock coordinate, north-east of the anchor.
    const OTHER_LONGITUDE_DEGREES: f64 = -119.8138;
    /// Query text the search mocks echo.
    const TEST_QUERY_TEXT: &str = "Capito";
    /// Consumer key the tile-cache tests install; construction needs no live
    /// endpoint.
    const MAPQUEST_TEST_CONSUMER_KEY: &str = "test-consumer-key";
    /// Tile-cache byte budget the settings tests install.
    const TEST_TILE_CACHE_BUDGET_BYTES: u64 = 16 * 1024 * 1024;
    /// Time-to-live override the offline-manager delegation test applies, in
    /// seconds.
    const TEST_TILE_TIME_TO_LIVE_SECONDS: u64 = 60;

    fn coordinate(latitude: f64, longitude: f64) -> GeographicCoordinate {
        GeographicCoordinate {
            latitude,
            longitude,
        }
    }

    fn sdk_with_mock_providers() -> Arc<MapSdk> {
        let map_sdk = MapSdk::new();
        map_sdk.register_geocoding_provider(Arc::new(MockGeocodingProvider));
        map_sdk.register_routing_provider(Arc::new(MockRoutingProvider));
        map_sdk.register_distance_matrix_provider(Arc::new(MockDistanceMatrixProvider));
        map_sdk.register_search_place_provider(Arc::new(MockSearchPlaceProvider));
        Arc::new(map_sdk)
    }

    fn empty_route_options() -> RouteOptions {
        RouteOptions {
            transportation_mode: TransportationMode::Automobile,
            route_strategy: RouteStrategy::Fastest,
            unit_system: UnitSystem::Metric,
            avoid_options: AvoidOptions {
                toll_roads: false,
                limited_access_highways: false,
                ferries: false,
                unpaved_roads: false,
            },
            departure_timestamp_seconds: None,
        }
    }

    #[tokio::test]
    async fn search_engine_delegates_every_search_verb_to_the_sdk() {
        let search_engine = SearchEngine::new(sdk_with_mock_providers());
        let places = search_engine
            .search(TEST_QUERY_TEXT.to_string(), None)
            .await
            .expect("the registered search provider serves the query");
        assert_eq!(places[0].structured_address_text, TEST_QUERY_TEXT);
        let suggestions = search_engine
            .suggest(TEST_QUERY_TEXT.to_string(), None)
            .await
            .expect("the registered search provider serves the suggestion");
        assert_eq!(suggestions[0].structured_address_text, TEST_QUERY_TEXT);
        let reversed_places = search_engine
            .reverse_geocode(coordinate(OTHER_LATITUDE_DEGREES, OTHER_LONGITUDE_DEGREES))
            .await
            .expect("the registered geocoder serves the coordinate");
        assert_eq!(
            reversed_places[0].coordinate.longitude,
            OTHER_LONGITUDE_DEGREES
        );
    }

    #[tokio::test]
    async fn search_engine_propagates_the_not_configured_failure_verbatim() {
        let search_engine = SearchEngine::new(Arc::new(MapSdk::new()));
        let failure = search_engine
            .search(TEST_QUERY_TEXT.to_string(), None)
            .await
            .expect_err("an unregistered search contract must throw");
        assert_eq!(
            failure,
            SdkError::ProviderNotConfigured {
                contract_name: "SearchPlaceProvider".to_string(),
            }
        );
    }

    #[tokio::test]
    async fn routing_engine_delegates_route_and_matrix_to_the_sdk() {
        let routing_engine = RoutingEngine::new(sdk_with_mock_providers());
        let route = routing_engine
            .calculate_route(
                vec![
                    coordinate(TEST_LATITUDE_DEGREES, TEST_LONGITUDE_DEGREES),
                    coordinate(OTHER_LATITUDE_DEGREES, OTHER_LONGITUDE_DEGREES),
                ],
                empty_route_options(),
            )
            .await
            .expect("the registered router serves the waypoints");
        assert_eq!(route.distance_meters, 1000.0);
        assert_eq!(route.duration_seconds, 90.0);
        let distance_matrix = routing_engine
            .calculate_distance_matrix(
                vec![coordinate(TEST_LATITUDE_DEGREES, TEST_LONGITUDE_DEGREES)],
                vec![coordinate(OTHER_LATITUDE_DEGREES, OTHER_LONGITUDE_DEGREES)],
                TransportationMode::Automobile,
            )
            .await
            .expect("the registered matrix provider serves the pair");
        assert_eq!(distance_matrix.entries.len(), 1);
        assert_eq!(distance_matrix.entries[0].distance_meters, 500.0);
    }

    #[tokio::test]
    async fn routing_engine_propagates_the_not_configured_failure_verbatim() {
        let routing_engine = RoutingEngine::new(Arc::new(MapSdk::new()));
        let route_failure = routing_engine
            .calculate_route(
                vec![coordinate(TEST_LATITUDE_DEGREES, TEST_LONGITUDE_DEGREES)],
                empty_route_options(),
            )
            .await
            .expect_err("an unregistered routing contract must throw");
        assert_eq!(
            route_failure,
            SdkError::ProviderNotConfigured {
                contract_name: "RoutingProvider".to_string(),
            }
        );
        let matrix_failure = routing_engine
            .calculate_distance_matrix(
                vec![coordinate(TEST_LATITUDE_DEGREES, TEST_LONGITUDE_DEGREES)],
                vec![coordinate(OTHER_LATITUDE_DEGREES, OTHER_LONGITUDE_DEGREES)],
                TransportationMode::Automobile,
            )
            .await
            .expect_err("an unregistered distance-matrix contract must throw");
        assert_eq!(
            matrix_failure,
            SdkError::ProviderNotConfigured {
                contract_name: "DistanceMatrixProvider".to_string(),
            }
        );
    }

    #[test]
    fn offline_manager_refuses_the_settings_calls_without_an_installed_cache() {
        let offline_manager = OfflineManager::new(Arc::new(MapSdk::new()));
        match offline_manager.tile_cache_terms() {
            Err(SdkError::ProviderNotConfigured { contract_name }) => {
                assert_eq!(contract_name, "TileCache");
            }
            other => panic!("terms without an installed cache must throw, got {other:?}"),
        }
        match offline_manager.set_tile_time_to_live(TEST_TILE_TIME_TO_LIVE_SECONDS) {
            Err(SdkError::ProviderNotConfigured { contract_name }) => {
                assert_eq!(contract_name, "TileCache");
            }
            other => panic!("the override without an installed cache must throw, got {other:?}"),
        }
        // The SDK's own zero guard still owns the validation.
        let sdk_with_cache = registered_with_labelled_tile_cache("engines-offline-manager");
        let manager_with_cache = OfflineManager::new(Arc::clone(&sdk_with_cache.0));
        match manager_with_cache.set_tile_time_to_live(0) {
            Err(SdkError::InvalidCoordinateInput { detail }) => {
                assert!(detail.contains("must be positive"), "{detail}");
            }
            other => panic!("a zero time-to-live must be refused, got {other:?}"),
        }
        std::fs::remove_dir_all(&sdk_with_cache.1).expect("the test cache directory cleans up");
    }

    #[test]
    fn offline_manager_delegates_the_installed_cache_terms_and_override() {
        let (map_sdk, cache_directory) =
            registered_with_labelled_tile_cache("engines-offline-happy");
        let offline_manager = OfflineManager::new(map_sdk);
        let default_terms = offline_manager
            .tile_cache_terms()
            .expect("an installed cache reports its terms");
        assert_eq!(
            default_terms.effective_time_to_live_seconds,
            default_terms.default_time_to_live_seconds
        );
        offline_manager
            .set_tile_time_to_live(TEST_TILE_TIME_TO_LIVE_SECONDS)
            .expect("the override applies to the installed cache");
        assert_eq!(
            offline_manager
                .tile_cache_terms()
                .expect("the terms read back after the override")
                .effective_time_to_live_seconds,
            TEST_TILE_TIME_TO_LIVE_SECONDS
        );
        std::fs::remove_dir_all(&cache_directory).expect("the test cache directory cleans up");
    }

    /// Registers the MapQuest providers with a freshly named tile cache and
    /// answers the SDK with the cache directory the test cleans up.
    fn registered_with_labelled_tile_cache(test_label: &str) -> (Arc<MapSdk>, std::path::PathBuf) {
        let map_sdk = MapSdk::new();
        let cache_directory = std::env::temp_dir().join(format!(
            "rustic-maps-native-core-{test_label}-{}",
            std::process::id()
        ));
        map_sdk
            .set_provider_credential_with_tile_cache(
                MAPQUEST_TEST_CONSUMER_KEY.to_string(),
                cache_directory
                    .join("tiles.sqlite")
                    .to_string_lossy()
                    .to_string(),
                TEST_TILE_CACHE_BUDGET_BYTES,
            )
            .expect("an empty path in an existing directory opens the cache");
        (Arc::new(map_sdk), cache_directory)
    }

    /// A diagnostics listener recording every delivered event and counting
    /// its deliveries.
    #[derive(Default)]
    struct RecordingDiagnosticEventListener {
        delivered_events: Mutex<Vec<LogEvent>>,
        delivery_count: AtomicU32,
    }

    impl SdkDiagnosticEventListener for RecordingDiagnosticEventListener {
        fn on_diagnostic_event(&self, event: LogEvent) {
            self.delivered_events.lock().unwrap().push(event);
            self.delivery_count.fetch_add(1, Ordering::SeqCst);
        }
    }

    #[test]
    fn diagnostics_delegates_the_listener_and_the_bounded_flush() {
        let diagnostics = Diagnostics::new(Arc::new(MapSdk::new()));
        let listener = Arc::new(RecordingDiagnosticEventListener::default());
        diagnostics.add_listener(
            Arc::clone(&listener) as Arc<dyn SdkDiagnosticEventListener>,
            SdkLogSeverity::Warn,
        );
        let delivered_count = diagnostics.flush_recent(
            Arc::clone(&listener) as Arc<dyn SdkDiagnosticEventListener>,
            SdkLogSeverity::Trace,
            u32::MAX,
        );
        assert_eq!(
            listener.delivery_count.load(Ordering::SeqCst),
            delivered_count,
            "the flush answers exactly the events it delivered"
        );
        assert_eq!(
            listener.delivered_events.lock().unwrap().len() as u32,
            delivered_count
        );
    }
}
