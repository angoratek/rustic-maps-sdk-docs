//! The wasm face of the `MapView` contract interface.
//!
//! The native `MapView` ([`crate::surface_view`]) drives the `wgpu` surface
//! renderer over a platform window handle; `rustic-maps-rendering`'s surface module
//! is native-only, and on the browser the canvas owns the surface, tile
//! scheduler, overlays and label pipeline. Until the generated contract
//! surface is paired with that canvas adapter, this module keeps every
//! `MapView` member of the frozen UDL available to the wasm bindings so the
//! scaffolding compiles, and answers the honest refusal from the members
//! that would need a native drawing surface. The pure lifecycle and
//! bookkeeping members answer the empty state.

use std::sync::Arc;

use crate::camera::MapCamera;
use crate::error::SdkError;
use crate::provider::MapSdk;
use crate::records::{
    FrameStatistics, LocationIndicatorState, LocationIndicatorStyle, MapOverlay, SurfaceHandle,
    UrlTemplateVectorTileSource, VectorTileSourceStatus,
};

/// The refusal every surface-touching `MapView` member reports on wasm: the
/// browser surface is owned by the hand-written canvas view beside the
/// generated contract surface.
const CANVAS_OWNED_SURFACE_DETAIL: &str =
    "the native surface view is unavailable on wasm; the browser canvas MapView owns the surface";

/// Builds the refusal for a surface-touching member.
fn canvas_owned_surface_refusal() -> SdkError {
    SdkError::RenderingSurfaceUnavailable {
        detail: CANVAS_OWNED_SURFACE_DETAIL.to_string(),
    }
}

/// The wasm `MapView` contract object: a surface-less placeholder whose
/// surface-touching members refuse and whose bookkeeping members answer the
/// empty state.
#[derive(Debug)]
pub struct MapView;

impl MapView {
    /// Builds the view over the SDK state; no surface attaches on wasm.
    pub fn new(_map_sdk: Arc<MapSdk>) -> Self {
        Self
    }

    /// Refuses: attaching a platform window handle is native-only.
    pub fn attach(
        &self,
        _surface_handle: SurfaceHandle,
        _width_pixels: u32,
        _height_pixels: u32,
    ) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Refuses: there is no attached surface to reconfigure.
    pub fn resize(&self, _width_pixels: u32, _height_pixels: u32) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Nothing is attached; detaching is idempotent.
    pub fn detach(&self) {}

    /// Refuses: the device-pixel ratio belongs to the attached surface.
    pub fn set_device_pixel_ratio(&self, _device_pixel_ratio: f64) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Refuses: the overlay list is owned by the canvas view on wasm.
    pub fn set_overlays(&self, _overlay_descriptors: Vec<MapOverlay>) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Refuses: the overlay list is owned by the canvas view on wasm.
    pub fn add_overlay(&self, _overlay: MapOverlay) -> Result<String, SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Refuses: the overlay list is owned by the canvas view on wasm.
    pub fn update_overlay(
        &self,
        _overlay_identifier: String,
        _overlay: MapOverlay,
    ) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// No addressed overlay exists on wasm, so no identifier was present.
    pub fn remove_overlay(&self, _overlay_identifier: String) -> bool {
        false
    }

    /// The overlay list is already empty.
    pub fn clear_overlays(&self) {}

    /// Refuses: the location layer is owned by the canvas view on wasm.
    pub fn set_location_indicator(
        &self,
        _state: LocationIndicatorState,
        _style: LocationIndicatorStyle,
    ) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// The location layer is already clear.
    pub fn clear_location_indicator(&self) {}

    /// Refuses: there is no drawn frame to compare against.
    pub fn is_frame_settled(&self, _camera: Arc<MapCamera>) -> Result<bool, SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// Refuses: there is no surface renderer to install a vector base on.
    pub fn set_vector_tile_source(
        &self,
        _source: UrlTemplateVectorTileSource,
    ) -> Result<(), SdkError> {
        Err(canvas_owned_surface_refusal())
    }

    /// No vector base is installed; clearing is a no-op.
    pub fn clear_vector_tile_source(&self) -> Result<(), SdkError> {
        Ok(())
    }

    /// Reports the not-configured status: no vector base can be installed
    /// without a surface renderer.
    pub fn vector_tile_source_status(&self) -> VectorTileSourceStatus {
        VectorTileSourceStatus::not_configured()
    }

    /// Refuses: there is no surface renderer to draw a frame with.
    pub async fn draw(&self, _camera: Arc<MapCamera>) -> Result<FrameStatistics, SdkError> {
        Err(canvas_owned_surface_refusal())
    }
}
