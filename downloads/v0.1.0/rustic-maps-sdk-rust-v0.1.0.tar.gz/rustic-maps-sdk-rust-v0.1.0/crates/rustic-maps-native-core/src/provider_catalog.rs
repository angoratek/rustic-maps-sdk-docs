//! The provider catalog: which provider keys this build carries, the
//! capabilities each serves, and the construction call for each.
//!
//! The registry in `rustic-maps-core` resolves calls per capability, so an
//! application can serve one capability from one provider and the next from
//! another. This module is the seam that makes that choice reachable from an
//! application: a key names a provider the binary was built with, and
//! [`ProviderCatalogEntry::install`] registers exactly the requested
//! capability, leaving every other capability's slot untouched.
//!
//! A provider's name appears here, in its own crate, in its sample-data
//! directory and in the shared registry descriptor — nowhere else. Adding a
//! provider is a crate, a descriptor, and one entry in [`PROVIDER_CATALOG`].

use crate::MapSdk;
use crate::error::SdkError;
use crate::records::{ProviderContract, ProviderRegistration};
use std::sync::Arc;

/// One provider this build can construct, keyed by its stable registry key.
pub(crate) struct ProviderCatalogEntry {
    /// The provider's stable key, matching its shared-registry descriptor.
    pub(crate) provider_key: &'static str,
    /// The provider's display name for a settings surface.
    pub(crate) display_name: &'static str,
    /// Whether the provider refuses to serve without a credential.
    pub(crate) credential_required: bool,
    /// The capabilities [`Self::install`] can register.
    pub(crate) served_contracts: &'static [ProviderContract],
    /// Registers the provider implementation for one capability on the SDK.
    pub(crate) install: fn(&MapSdk, ProviderContract, &str) -> Result<(), SdkError>,
    /// Registers every capability in [`Self::served_contracts`] from one
    /// credential, sharing whatever provider state the implementations share.
    pub(crate) install_all: fn(&MapSdk, &str) -> Result<(), SdkError>,
    /// The provider's declared raster-tile caching-terms ceiling in seconds,
    /// or `None` when the provider declares no ceiling or serves no raster
    /// tiles. The tile-cache settings surface clamps every requested
    /// time-to-live through it. The wasm build installs no disk tile cache,
    /// so it never reads the value.
    #[cfg_attr(target_arch = "wasm32", allow(dead_code))]
    pub(crate) raster_tile_cache_ceiling_seconds: Option<u64>,
    /// The deepest raster-tile zoom level the provider declares it serves, or
    /// `None` when the provider declares no maximum. An installed tile cache
    /// carries it into the tile-pack manager, which refuses a region deeper
    /// than the ceiling before downloading anything. The wasm build installs
    /// no disk tile cache, so it never reads the value.
    #[cfg_attr(target_arch = "wasm32", allow(dead_code))]
    pub(crate) raster_tile_maximum_zoom_level: Option<u8>,
}

/// Every provider this build can construct.
///
/// The order is the order a settings surface lists keys in when it offers a
/// choice: the full-service provider first, then the single-capability
/// providers.
pub(crate) const PROVIDER_CATALOG: &[ProviderCatalogEntry] = &[
    ProviderCatalogEntry {
        provider_key: "mapquest",
        display_name: "MapQuest",
        credential_required: true,
        served_contracts: &[
            ProviderContract::Geocoding,
            ProviderContract::Routing,
            ProviderContract::DistanceMatrix,
            ProviderContract::PlaceSearch,
            ProviderContract::TrafficIncidents,
            ProviderContract::TrafficFlow,
            ProviderContract::RasterTiles,
        ],
        install: install_mapquest_contract,
        install_all: install_all_mapquest_contracts,
        raster_tile_cache_ceiling_seconds: Some(
            mapquest_provider::tiles::MAPQUEST_RASTER_TILE_CACHE_CEILING_SECONDS,
        ),
        raster_tile_maximum_zoom_level: Some(
            mapquest_provider::tiles::MAPQUEST_RASTER_TILE_MAXIMUM_ZOOM_LEVEL,
        ),
    },
    ProviderCatalogEntry {
        provider_key: "osrm",
        display_name: "OSRM",
        credential_required: false,
        served_contracts: &[ProviderContract::Routing],
        install: install_osrm_contract,
        install_all: install_all_osrm_contracts,
        raster_tile_cache_ceiling_seconds: None,
        raster_tile_maximum_zoom_level: None,
    },
    ProviderCatalogEntry {
        provider_key: "valhalla",
        display_name: "Valhalla",
        credential_required: false,
        served_contracts: &[ProviderContract::Routing],
        install: install_valhalla_contract,
        install_all: install_all_valhalla_contracts,
        raster_tile_cache_ceiling_seconds: None,
        raster_tile_maximum_zoom_level: None,
    },
];

/// The catalog entry a credential-only registration installs: the first
/// credentialed provider, which the catalog orders first because a
/// credential-only call addresses the full-service provider.
pub(crate) fn credentialed_catalog_entry() -> Option<&'static ProviderCatalogEntry> {
    PROVIDER_CATALOG
        .iter()
        .find(|entry| entry.credential_required)
}

/// The credential a keyless provider reads as an optional deployment address.
///
/// A self-hosted routing engine has no key: the application supplies the base
/// URL of the deployment it uses, or leaves it empty to reach the crate's
/// documented local default.
fn deployment_base_url_or_default(credential: &str, default_base_url: &str) -> String {
    let trimmed_credential = credential.trim();
    if trimmed_credential.is_empty() {
        default_base_url.to_string()
    } else {
        trimmed_credential.to_string()
    }
}

/// Registers the OSRM routing implementation for its one capability.
///
/// The credential, when non-empty, is the deployment's base URL; an empty one
/// targets the crate's documented local default. A malformed URL is refused
/// by the provider crate before anything is registered.
fn install_osrm_contract(
    map_sdk: &MapSdk,
    contract: ProviderContract,
    credential: &str,
) -> Result<(), SdkError> {
    if contract != ProviderContract::Routing {
        return Err(SdkError::ProviderNotConfigured {
            contract_name: contract_name_of(contract),
        });
    }
    let configuration = osrm_provider::OsrmProviderConfiguration {
        base_url: deployment_base_url_or_default(credential, osrm_provider::DEFAULT_OSRM_BASE_URL),
        ..Default::default()
    };
    let provider = osrm_provider::OsrmRoutingProvider::new(configuration)?;
    map_sdk.register_routing_provider(Arc::new(provider));
    Ok(())
}

/// Registers the OSRM routing implementation for every capability it serves.
fn install_all_osrm_contracts(map_sdk: &MapSdk, credential: &str) -> Result<(), SdkError> {
    install_osrm_contract(map_sdk, ProviderContract::Routing, credential)
}

/// Registers the Valhalla routing implementation for its one capability.
///
/// The credential, when non-empty, is the deployment's base URL; an empty one
/// targets the crate's documented local default.
fn install_valhalla_contract(
    map_sdk: &MapSdk,
    contract: ProviderContract,
    credential: &str,
) -> Result<(), SdkError> {
    if contract != ProviderContract::Routing {
        return Err(SdkError::ProviderNotConfigured {
            contract_name: contract_name_of(contract),
        });
    }
    let configuration = valhalla_provider::ValhallaProviderConfiguration {
        base_url: deployment_base_url_or_default(
            credential,
            valhalla_provider::VALHALLA_DEFAULT_BASE_URL,
        ),
        ..Default::default()
    };
    let provider = valhalla_provider::ValhallaRoutingProvider::new(configuration)?;
    map_sdk.register_routing_provider(Arc::new(provider));
    Ok(())
}

/// Registers the Valhalla routing implementation for every capability it
/// serves.
fn install_all_valhalla_contracts(map_sdk: &MapSdk, credential: &str) -> Result<(), SdkError> {
    install_valhalla_contract(map_sdk, ProviderContract::Routing, credential)
}

/// Finds the catalog entry for a provider key.
pub(crate) fn catalog_entry_for_key(provider_key: &str) -> Option<&'static ProviderCatalogEntry> {
    PROVIDER_CATALOG
        .iter()
        .find(|entry| entry.provider_key == provider_key)
}

/// Registers one capability from the provider set the shared client serves.
///
/// The client is constructed per call, so a credential change takes effect
/// immediately and a refused credential leaves the previously serving
/// provider in place (nothing is registered until the client builds).
fn install_mapquest_contract(
    map_sdk: &MapSdk,
    contract: ProviderContract,
    credential: &str,
) -> Result<(), SdkError> {
    register_mapquest_contract(map_sdk, contract, mapquest_provider_client(credential)?)
}

/// Registers every capability the provider set serves from one shared client,
/// so the set keeps one rate limiter and one envelope validator.
fn install_all_mapquest_contracts(map_sdk: &MapSdk, credential: &str) -> Result<(), SdkError> {
    let provider_client = mapquest_provider_client(credential)?;
    for contract in [
        ProviderContract::Geocoding,
        ProviderContract::Routing,
        ProviderContract::DistanceMatrix,
        ProviderContract::PlaceSearch,
        ProviderContract::TrafficIncidents,
        ProviderContract::TrafficFlow,
        ProviderContract::RasterTiles,
    ] {
        register_mapquest_contract(map_sdk, contract, Arc::clone(&provider_client))?;
    }
    Ok(())
}

/// Builds the provider set's shared client from a credential.
fn mapquest_provider_client(
    credential: &str,
) -> Result<Arc<mapquest_provider::MapQuestProviderClient>, SdkError> {
    Ok(Arc::new(
        mapquest_provider::MapQuestProviderClient::new(
            mapquest_provider::MapQuestProviderConfiguration {
                api_key: credential.to_string(),
                ..Default::default()
            },
        )
        .map_err(SdkError::from)?,
    ))
}

/// Registers one capability of the provider set onto the SDK.
fn register_mapquest_contract(
    map_sdk: &MapSdk,
    contract: ProviderContract,
    provider_client: Arc<mapquest_provider::MapQuestProviderClient>,
) -> Result<(), SdkError> {
    match contract {
        ProviderContract::Geocoding => {
            map_sdk.register_geocoding_provider(Arc::new(
                mapquest_provider::MapQuestGeocodingProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::Routing => {
            map_sdk.register_routing_provider(Arc::new(
                mapquest_provider::MapQuestRoutingProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::DistanceMatrix => {
            map_sdk.register_distance_matrix_provider(Arc::new(
                mapquest_provider::MapQuestDistanceMatrixProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::PlaceSearch => {
            map_sdk.register_search_place_provider(Arc::new(
                mapquest_provider::MapQuestSearchPlaceProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::TrafficIncidents => {
            map_sdk.register_traffic_incident_provider(Arc::new(
                mapquest_provider::MapQuestTrafficIncidentProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::TrafficFlow => {
            map_sdk.register_traffic_flow_provider(Arc::new(
                mapquest_provider::MapQuestTrafficFlowProvider::new(provider_client),
            ));
            Ok(())
        }
        ProviderContract::RasterTiles => {
            map_sdk.register_raster_tile_provider(Arc::new(
                mapquest_provider::MapQuestRasterTileProvider::new(provider_client),
            ));
            Ok(())
        }
        // The catalog's served-contract list gates every other capability
        // before this call, so this arm is the compiler asking for totality
        // rather than a reachable path.
        ProviderContract::Elevation
        | ProviderContract::VectorTiles
        | ProviderContract::OfflineRouting => Err(SdkError::ProviderNotConfigured {
            contract_name: contract_name_of(contract),
        }),
    }
}

/// The name a capability reports in a not-configured detail.
pub(crate) fn contract_name_of(contract: ProviderContract) -> String {
    contract.to_core_contract().contract_name().to_string()
}

/// Builds one readback entry from the registry state and the recorded
/// selection.
pub(crate) fn registration_entry(
    contract: ProviderContract,
    selection: Option<&ProviderSelection>,
    registry_configured: bool,
) -> ProviderRegistration {
    let registered = registry_configured || selection.is_some();
    ProviderRegistration {
        contract,
        provider_key: selection
            .map(|selection| selection.provider_key.clone())
            .unwrap_or_default(),
        display_name: selection
            .map(|selection| selection.display_name.clone())
            .unwrap_or_default(),
        registered,
    }
}

/// The provider an application chose for one capability, kept so the readback
/// can name it: the registry itself answers only whether its slot is filled.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ProviderSelection {
    /// The capability the selection applies to.
    pub(crate) contract: ProviderContract,
    /// The provider's stable key.
    pub(crate) provider_key: String,
    /// The provider's display name.
    pub(crate) display_name: String,
}

#[cfg(test)]
mod tests {
    use super::{PROVIDER_CATALOG, catalog_entry_for_key};

    #[test]
    fn the_catalog_declares_the_mapquest_raster_zoom_ceiling() {
        let mapquest_entry =
            catalog_entry_for_key("mapquest").expect("the full-service provider is catalogued");
        assert_eq!(
            mapquest_entry.raster_tile_maximum_zoom_level,
            Some(mapquest_provider::tiles::MAPQUEST_RASTER_TILE_MAXIMUM_ZOOM_LEVEL),
            "the credentialed provider's declared ceiling reaches the tile-pack manager"
        );
        assert_eq!(
            mapquest_entry.raster_tile_maximum_zoom_level,
            Some(20),
            "the documented MapQuest Tiles API maximum is twenty"
        );
    }

    #[test]
    fn catalog_entries_without_raster_tiles_declare_no_zoom_ceiling() {
        for provider_key in ["osrm", "valhalla"] {
            let catalog_entry = catalog_entry_for_key(provider_key)
                .expect("the single-capability routing providers are catalogued");
            assert_eq!(
                catalog_entry.raster_tile_maximum_zoom_level, None,
                "{provider_key} serves no raster tiles and declares no zoom ceiling"
            );
        }
        assert_eq!(
            PROVIDER_CATALOG
                .iter()
                .filter(|entry| entry.raster_tile_maximum_zoom_level.is_some())
                .count(),
            1,
            "only the raster-serving provider declares a zoom ceiling"
        );
    }
}
