//! Response categories and their default freshness policies.
//!
//! Every cache entry is tagged with one [`ResponseCategory`]; the category
//! drives the default time-to-live so that volatile traffic data expires
//! minutes after capture while immutable tile imagery lives for weeks.
//! Individual calls may pass a shorter or longer TTL — the cached provider
//! wrappers in [`crate::cached_providers`] accept a per-instance override.

use geospatial_types::SDKError;
use serde::{Deserialize, Serialize};

/// Kind of provider response a cache entry holds.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResponseCategory {
    /// Forward and reverse geocoding results.
    Geocoding,
    /// Calculated routes and their maneuvers.
    Routing,
    /// Origin-destination travel-time matrices.
    DistanceMatrix,
    /// Search Ahead predictions (autocomplete and full search).
    SearchPrediction,
    /// Traffic disruption reports.
    TrafficIncidents,
    /// Traffic flow congestion polylines.
    TrafficFlow,
    /// Fetched raster XYZ tiles.
    RasterTiles,
    /// Fetched xyz vector tiles (MVT protobuf).
    VectorTiles,
}

impl ResponseCategory {
    /// Default time-to-live in seconds for this category. Values reflect
    /// how quickly the underlying MapQuest data changes; anything more
    /// aggressive than these defaults is wasteful, anything longer risks
    /// serving plainly stale live data.
    ///
    /// Tiles follow their own policy: tile imagery caches heavily by default
    /// — **30 calendar days**, the common maximum under imagery-provider
    /// terms — and an integrator tuning it shorter or longer does so
    /// knowingly per provider (the provider contract declares its own
    /// caching terms; see `mapquest-provider`'s raster-tile ceiling
    /// constant). The cached provider wrappers accept the per-instance
    /// override.
    ///
    /// Vector tiles inherit the same tile-imagery policy: 30 calendar days
    /// here, clamped against the provider's own ceiling constant (see
    /// `openstreetmap-us-vector-provider`'s lockstep test).
    pub fn default_time_to_live_seconds(self) -> u64 {
        match self {
            ResponseCategory::Geocoding => 24 * 60 * 60,
            ResponseCategory::Routing => 10 * 60,
            ResponseCategory::DistanceMatrix => 10 * 60,
            ResponseCategory::SearchPrediction => 5 * 60,
            ResponseCategory::TrafficIncidents => 60,
            ResponseCategory::TrafficFlow => 30,
            ResponseCategory::RasterTiles => 30 * 24 * 60 * 60,
            ResponseCategory::VectorTiles => 30 * 24 * 60 * 60,
        }
    }

    /// Stable name persisted in the SQLite `category` column.
    pub fn storage_name(self) -> &'static str {
        match self {
            ResponseCategory::Geocoding => "geocoding",
            ResponseCategory::Routing => "routing",
            ResponseCategory::DistanceMatrix => "distance_matrix",
            ResponseCategory::SearchPrediction => "search_prediction",
            ResponseCategory::TrafficIncidents => "traffic_incidents",
            ResponseCategory::TrafficFlow => "traffic_flow",
            ResponseCategory::RasterTiles => "raster_tiles",
            ResponseCategory::VectorTiles => "vector_tiles",
        }
    }

    /// Reverses [`ResponseCategory::storage_name`].
    pub fn from_storage_name(storage_name: &str) -> Result<Self, SDKError> {
        match storage_name {
            "geocoding" => Ok(ResponseCategory::Geocoding),
            "routing" => Ok(ResponseCategory::Routing),
            "distance_matrix" => Ok(ResponseCategory::DistanceMatrix),
            "search_prediction" => Ok(ResponseCategory::SearchPrediction),
            "traffic_incidents" => Ok(ResponseCategory::TrafficIncidents),
            "traffic_flow" => Ok(ResponseCategory::TrafficFlow),
            "raster_tiles" => Ok(ResponseCategory::RasterTiles),
            "vector_tiles" => Ok(ResponseCategory::VectorTiles),
            other => {
                let _ = other;
                Err(SDKError::CacheOperationFailure(
                    geospatial_types::CacheOperationFailureReason::RecordCorrupted,
                ))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{ResponseCategory, SDKError};

    #[test]
    fn expiry_ages_follow_data_volatility() {
        assert!(ResponseCategory::TrafficFlow.default_time_to_live_seconds() < 60);
        assert!(
            ResponseCategory::TrafficIncidents.default_time_to_live_seconds()
                < ResponseCategory::Routing.default_time_to_live_seconds()
        );
        assert_eq!(
            ResponseCategory::Geocoding.default_time_to_live_seconds(),
            86_400
        );
        assert_eq!(
            ResponseCategory::RasterTiles.default_time_to_live_seconds(),
            30 * 24 * 60 * 60
        );
    }

    #[test]
    fn storage_names_round_trip() {
        for category in [
            ResponseCategory::Geocoding,
            ResponseCategory::Routing,
            ResponseCategory::DistanceMatrix,
            ResponseCategory::SearchPrediction,
            ResponseCategory::TrafficIncidents,
            ResponseCategory::TrafficFlow,
            ResponseCategory::RasterTiles,
            ResponseCategory::VectorTiles,
        ] {
            assert_eq!(
                ResponseCategory::from_storage_name(category.storage_name()).unwrap(),
                category
            );
        }
        assert!(matches!(
            ResponseCategory::from_storage_name("unknown"),
            Err(SDKError::CacheOperationFailure(
                geospatial_types::CacheOperationFailureReason::RecordCorrupted
            ))
        ));
    }
}
