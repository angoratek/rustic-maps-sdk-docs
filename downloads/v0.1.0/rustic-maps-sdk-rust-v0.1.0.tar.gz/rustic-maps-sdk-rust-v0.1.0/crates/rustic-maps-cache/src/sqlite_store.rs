//! SQLite-backed implementation of [`rustic_maps_core::CachedResponseStore`].
//!
//! One shared cache database serves every response category; lookups,
//! entries, and eviction are keyed by request fingerprints prepared by the
//! callers. Writes run through a pool of WAL-mode connections, guarded by
//! `BEGIN IMMEDIATE` + `SAVEPOINT` so a failed upsert leaves the database
//! untouched. After every write the store evicts least-recently-used entries
//! until the total payload size fits the resolved [`CacheQuota`] budget.

pub use crate::disk_quota::{CacheQuota, DiskSpaceProbe, FixedDiskSpaceProbe, RealDiskSpaceProbe};
pub use r2d2_sqlite::rusqlite;

use crate::ResponseCategory;
use geospatial_types::{CacheOperationFailureReason, SDKError};
use r2d2::Pool;
use r2d2_sqlite::SqliteConnectionManager;
use rustic_maps_core::CachedResponseStore;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

/// Current schema and migration scripts, applied newest-last.
const SCHEMA_MIGRATIONS: &[&str] = &[
    // Version 1: entry table + recency index.
    "
    CREATE TABLE entries (
        fingerprint TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        payload BLOB NOT NULL,
        payload_size_bytes INTEGER NOT NULL,
        expires_at_unix_seconds INTEGER NOT NULL,
        created_at_unix_seconds INTEGER NOT NULL,
        last_accessed_at_unix_seconds INTEGER NOT NULL,
        recency_sequence INTEGER NOT NULL
    );
    CREATE INDEX entries_last_accessed_idx ON entries (recency_sequence);
    ",
    // Version 2: the tile-pack tables — one record per defined
    // pack, and a membership table pinning every planned tile fingerprint.
    // A membership row whose entry is absent is inert (the tile is still to
    // download); the LRU eviction excludes member fingerprints entirely, so
    // pack tiles are removed only by their pack's explicit eviction.
    "
    CREATE TABLE tile_packs (
        pack_id TEXT PRIMARY KEY,
        display_name TEXT NOT NULL,
        south_west_latitude_degrees REAL NOT NULL,
        south_west_longitude_degrees REAL NOT NULL,
        north_east_latitude_degrees REAL NOT NULL,
        north_east_longitude_degrees REAL NOT NULL,
        minimum_zoom_level INTEGER NOT NULL,
        maximum_zoom_level INTEGER NOT NULL,
        image_format_name TEXT NOT NULL,
        tile_resolution_name TEXT NOT NULL,
        effective_time_to_live_seconds INTEGER NOT NULL,
        created_at_unix_seconds INTEGER NOT NULL
    );
    CREATE TABLE tile_pack_members (
        pack_id TEXT NOT NULL,
        fingerprint TEXT NOT NULL,
        PRIMARY KEY (pack_id, fingerprint)
    );
    ",
];
const SCHEMA_TABLE_BATCH: &str = "
    CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at_unix_seconds INTEGER NOT NULL
    );
";
const WRITE_SAVEPOINT_NAME: &str = "rustic_maps_cache_write";

/// Settings for one SQLite cache database on disk.
#[derive(Debug, Clone)]
pub struct SqliteResponseCacheConfiguration {
    /// Path of the SQLite database file; the parent directory is created.
    pub database_path: PathBuf,
    /// Size constraints resolved into a byte budget before each eviction.
    pub quota: CacheQuota,
    /// Connection-pool size; WAL writes serialize on SQLite, so a small
    /// number of readers suffices.
    pub maximum_pool_connections: u32,
}

impl Default for SqliteResponseCacheConfiguration {
    fn default() -> Self {
        Self {
            database_path: std::env::temp_dir().join("map-sdk-sdk-cache.sqlite"),
            quota: CacheQuota::default(),
            maximum_pool_connections: 4,
        }
    }
}

/// SQLite-backed response cache shared by every provider contract.
pub struct SqliteResponseCache {
    pub(crate) connection_pool: Pool<SqliteConnectionManager>,
    quota: CacheQuota,
    disk_space_probe: Arc<dyn DiskSpaceProbe>,
    database_path: PathBuf,
}

impl SqliteResponseCache {
    /// Opens (creating or migrating as needed) the cache database.
    pub fn open(
        configuration: SqliteResponseCacheConfiguration,
    ) -> Result<Arc<SqliteResponseCache>, SDKError> {
        Self::with_disk_space_probe(configuration, Arc::new(RealDiskSpaceProbe))
    }

    /// Opens the cache with an injected [`DiskSpaceProbe`] (tests).
    pub fn with_disk_space_probe(
        configuration: SqliteResponseCacheConfiguration,
        disk_space_probe: Arc<dyn DiskSpaceProbe>,
    ) -> Result<Arc<SqliteResponseCache>, SDKError> {
        configuration.quota.validate()?;
        if let Some(parent_directory) = configuration.database_path.parent() {
            std::fs::create_dir_all(parent_directory).map_err(|_| {
                SDKError::CacheOperationFailure(CacheOperationFailureReason::StoreUnavailable)
            })?;
        }
        // WAL is a database-level property: enable it once on a dedicated
        // connection before the pool spins up, so concurrent inits cannot
        // race on the pragma ("database is locked").
        {
            let setup_connection = rusqlite::Connection::open(&configuration.database_path)
                .map_err(map_execution_failure)?;
            setup_connection
                .pragma_update(None, "journal_mode", "WAL")
                .map_err(map_execution_failure)?;
        }
        let connection_manager = SqliteConnectionManager::file(&configuration.database_path)
            .with_init(|connection| {
                connection.pragma_update(None, "synchronous", "NORMAL")?;
                connection.busy_timeout(Duration::from_millis(5_000))
            });
        let connection_pool = Pool::builder()
            .max_size(configuration.maximum_pool_connections)
            .build(connection_manager)
            .map_err(|_| {
                SDKError::CacheOperationFailure(CacheOperationFailureReason::StoreUnavailable)
            })?;
        let cache = SqliteResponseCache {
            connection_pool,
            quota: configuration.quota,
            disk_space_probe,
            database_path: configuration.database_path,
        };
        cache.apply_migrations()?;
        Ok(Arc::new(cache))
    }

    /// Total payload bytes currently stored; diagnostics and eviction tests.
    pub fn total_stored_bytes(&self) -> Result<u64, SDKError> {
        let connection = self.connection_pool.get().map_err(map_pool_failure)?;
        let total_bytes: i64 = connection
            .query_row(
                "SELECT COALESCE(SUM(payload_size_bytes), 0) FROM entries",
                [],
                |row| row.get(0),
            )
            .map_err(map_execution_failure)?;
        Ok(total_bytes.max(0) as u64)
    }

    /// Runs `write_operation` inside `BEGIN IMMEDIATE` + `SAVEPOINT`; on
    /// error the savepoint is rolled back and the failure surfaces, leaving
    /// any earlier writes in the transaction intact. Crate-internal so the
    /// tile-pack store methods (`tile_packs`) share the same guarded write
    /// discipline over this module's pool.
    pub(crate) fn perform_write_transaction<T>(
        &self,
        write_operation: impl FnOnce(&rusqlite::Connection) -> Result<T, SDKError>,
    ) -> Result<T, SDKError> {
        let connection = self.connection_pool.get().map_err(map_pool_failure)?;
        connection
            .execute_batch("BEGIN IMMEDIATE")
            .map_err(map_execution_failure)?;
        connection
            .execute_batch(&format!("SAVEPOINT {WRITE_SAVEPOINT_NAME}"))
            .map_err(map_execution_failure)?;
        match write_operation(&connection) {
            Ok(value) => {
                connection
                    .execute_batch(&format!("RELEASE SAVEPOINT {WRITE_SAVEPOINT_NAME}; COMMIT"))
                    .map_err(map_execution_failure)?;
                Ok(value)
            }
            Err(operation_error) => {
                let _ = connection.execute_batch(&format!(
                    "ROLLBACK TO SAVEPOINT {WRITE_SAVEPOINT_NAME}; ROLLBACK"
                ));
                Err(operation_error)
            }
        }
    }

    fn apply_migrations(&self) -> Result<(), SDKError> {
        self.perform_write_transaction(|connection| {
            connection
                .execute_batch(SCHEMA_TABLE_BATCH)
                .map_err(map_execution_failure)?;
            for (zero_based_version, migration_batch) in SCHEMA_MIGRATIONS.iter().enumerate() {
                let version_number = (zero_based_version + 1) as i64;
                let applied_version_count: i64 = connection
                    .query_row(
                        "SELECT COUNT(*) FROM schema_migrations WHERE version = ?1",
                        [version_number],
                        |row| row.get(0),
                    )
                    .map_err(map_execution_failure)?;
                if applied_version_count > 0 {
                    continue;
                }
                connection
                    .execute_batch(migration_batch)
                    .map_err(map_execution_failure)?;
                connection
                    .execute(
                        "INSERT INTO schema_migrations (version, applied_at_unix_seconds) VALUES (?1, ?2)",
                        [version_number, unix_seconds_now()],
                    )
                    .map_err(map_execution_failure)?;
            }
            Ok(())
        })
    }

    fn store_entry(
        &self,
        request_fingerprint: &str,
        response_category: ResponseCategory,
        payload_bytes: Vec<u8>,
        time_to_live_seconds: u64,
    ) -> Result<(), SDKError> {
        let payload_size_bytes = payload_bytes.len() as u64;
        let budget_bytes = self
            .quota
            .resolve_budget_bytes(self.disk_space_probe.as_ref(), &self.database_path);
        if payload_size_bytes > budget_bytes {
            return Err(SDKError::CacheOperationFailure(
                CacheOperationFailureReason::WriteRejected,
            ));
        }
        let expires_at = unix_seconds_now()
            .saturating_add(i64::try_from(time_to_live_seconds).unwrap_or(i64::MAX));
        self.perform_write_transaction(move |connection| {
            connection
                .execute(
                    "
                    INSERT OR REPLACE INTO entries (
                        fingerprint, category, payload, payload_size_bytes,
                        expires_at_unix_seconds, created_at_unix_seconds, last_accessed_at_unix_seconds, recency_sequence
                    ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?6, (SELECT COALESCE(MAX(recency_sequence), 0) + 1 FROM entries))
                    ",
                    rusqlite::params![
                        request_fingerprint,
                        response_category.storage_name(),
                        payload_bytes,
                        payload_size_bytes as i64,
                        expires_at,
                        unix_seconds_now(),
                    ],
                )
                .map_err(map_execution_failure)?;
            Ok(())
        })?;
        self.evict_to_budget(budget_bytes)
    }

    fn lookup_entry(
        &self,
        request_fingerprint: &str,
    ) -> Result<Option<(Vec<u8>, ResponseCategory)>, SDKError> {
        let connection = self.connection_pool.get().map_err(map_pool_failure)?;
        let lookup = connection.query_row(
            "
            SELECT expires_at_unix_seconds, payload, category
            FROM entries WHERE fingerprint = ?1
            ",
            [request_fingerprint],
            |row| {
                Ok((
                    row.get::<_, i64>(0)?,
                    row.get::<_, Vec<u8>>(1)?,
                    row.get::<_, String>(2)?,
                ))
            },
        );
        let (expires_at, payload, category_name) = match lookup {
            Ok(row) => row,
            Err(rusqlite::Error::QueryReturnedNoRows) => return Ok(None),
            Err(error) => return Err(map_execution_failure(error)),
        };
        if expires_at <= unix_seconds_now() {
            connection
                .execute(
                    "DELETE FROM entries WHERE fingerprint = ?1",
                    [request_fingerprint],
                )
                .map_err(map_execution_failure)?;
            return Ok(None);
        }
        let response_category =
            ResponseCategory::from_storage_name(&category_name).map_err(|_| {
                SDKError::CacheOperationFailure(CacheOperationFailureReason::RecordCorrupted)
            })?;
        connection
            .execute(
                "UPDATE entries SET last_accessed_at_unix_seconds = ?1, \
                 recency_sequence = (SELECT COALESCE(MAX(recency_sequence), 0) + 1 FROM entries) \
                 WHERE fingerprint = ?2",
                rusqlite::params![unix_seconds_now(), request_fingerprint],
            )
            .map_err(map_execution_failure)?;
        Ok(Some((payload, response_category)))
    }

    /// Deletes the least-recently-used entries one by one (recency reads
    /// from `last_accessed_at`) until the total payload fits `budget_bytes`.
    /// A single entry larger than the budget is tolerated as-is.
    ///
    /// Tile-pack members are never LRU candidates: while their
    /// pack record exists, a pack's tiles are pinned against ordinary budget
    /// pressure and leave the store only through that pack's explicit
    /// eviction or the entry's time-to-live. The budget still counts pack
    /// bytes in its total, so a packed store near its budget evicts only the
    /// ordinary entries — the integrator sizes packs against the budget.
    fn evict_to_budget(&self, budget_bytes: u64) -> Result<(), SDKError> {
        if budget_bytes == u64::MAX {
            return Ok(());
        }
        self.perform_write_transaction(move |connection| {
            loop {
                let total_bytes: i64 = connection
                    .query_row(
                        "SELECT COALESCE(SUM(payload_size_bytes), 0) FROM entries",
                        [],
                        |row| row.get(0),
                    )
                    .map_err(map_execution_failure)?;
                if total_bytes as u64 <= budget_bytes {
                    return Ok(());
                }
                let deleted_size: Option<i64> = connection
                    .query_row(
                        "
                    DELETE FROM entries
                    WHERE fingerprint = (
                        SELECT fingerprint FROM entries
                        WHERE fingerprint NOT IN (SELECT fingerprint FROM tile_pack_members)
                        ORDER BY recency_sequence ASC
                        LIMIT 1
                    )
                    RETURNING payload_size_bytes
                    ",
                        [],
                        |row| row.get(0),
                    )
                    .map(Some)
                    .or_else(|error| match error {
                        rusqlite::Error::QueryReturnedNoRows => Ok(None),
                        other => Err(map_execution_failure(other)),
                    })?;
                if deleted_size.is_none() {
                    // Only pack-pinned or oversize entries remain; both are
                    // tolerated by design.
                    return Ok(());
                }
            }
        })
    }
}

/// Any deserializable typed record can travel through the single cache.
impl<D> CachedResponseStore<D> for SqliteResponseCache
where
    D: serde::Serialize + serde::de::DeserializeOwned + Send + Sync,
{
    fn lookup_response(&self, request_fingerprint: &str) -> Result<Option<Arc<D>>, SDKError> {
        match self.lookup_entry(request_fingerprint)? {
            None => Ok(None),
            Some((payload, _response_category)) => {
                let response_value: D = serde_json::from_slice(&payload).map_err(|_| {
                    SDKError::CacheOperationFailure(CacheOperationFailureReason::RecordCorrupted)
                })?;
                Ok(Some(Arc::new(response_value)))
            }
        }
    }

    fn store_response(
        &self,
        request_fingerprint: &str,
        response_value: Arc<D>,
        time_to_live_seconds: u64,
    ) -> Result<(), SDKError> {
        let payload_bytes = serde_json::to_vec(response_value.as_ref()).map_err(|_| {
            SDKError::CacheOperationFailure(CacheOperationFailureReason::WriteRejected)
        })?;
        // Fingerprints prepared by `RequestDescriptor` name their category
        // as a `"<category>:<hash>"` prefix; unknown or bare fingerprints
        // fall back to the geocoding default (TTL stays caller-provided).
        let response_category = response_category_of_fingerprint(request_fingerprint);
        self.store_entry(
            request_fingerprint,
            response_category,
            payload_bytes,
            time_to_live_seconds,
        )
    }
}

fn response_category_of_fingerprint(request_fingerprint: &str) -> ResponseCategory {
    request_fingerprint
        .split_once(':')
        .and_then(|(prefix, _)| ResponseCategory::from_storage_name(prefix).ok())
        .unwrap_or(ResponseCategory::Geocoding)
}

pub(crate) fn unix_seconds_now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .ok()
        .and_then(|elapsed| i64::try_from(elapsed.as_secs()).ok())
        .unwrap_or(0)
}

pub(crate) fn map_pool_failure(_pool_error: r2d2::Error) -> SDKError {
    SDKError::CacheOperationFailure(CacheOperationFailureReason::StoreUnavailable)
}

pub(crate) fn map_execution_failure(_sqlite_error: rusqlite::Error) -> SDKError {
    SDKError::CacheOperationFailure(CacheOperationFailureReason::StoreUnavailable)
}

impl std::fmt::Debug for SqliteResponseCache {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("SqliteResponseCache")
            .field("database_path", &self.database_path)
            .field("quota", &self.quota)
            .finish()
    }
}

#[cfg(test)]
mod tests {
    use super::{
        CacheOperationFailureReason, SDKError, SqliteResponseCache,
        SqliteResponseCacheConfiguration,
    };
    use crate::disk_quota::{CacheQuota, FixedDiskSpaceProbe};
    use rustic_maps_core::CachedResponseStore;
    use std::sync::Arc;

    fn unique_database_path(test_name: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "rustic-maps-cache-unit-{}-{test_name}.sqlite",
            std::process::id(),
        ))
    }

    fn open_cache(test_name: &str, quota: CacheQuota) -> Arc<SqliteResponseCache> {
        let database_path = unique_database_path(test_name);
        std::fs::remove_file(database_path.with_extension("sqlite-wal")).ok();
        std::fs::remove_file(database_path.with_extension("sqlite-shm")).ok();
        std::fs::remove_file(&database_path).ok();
        SqliteResponseCache::with_disk_space_probe(
            SqliteResponseCacheConfiguration {
                database_path,
                quota,
                ..SqliteResponseCacheConfiguration::default()
            },
            Arc::new(FixedDiskSpaceProbe::reporting(u64::MAX)),
        )
        .unwrap()
    }

    fn repeated_text_entry(base_text: &str, target_bytes: usize) -> String {
        base_text.repeat(target_bytes.div_ceil(base_text.len()))
    }

    #[test]
    fn store_and_lookup_round_trip() {
        let cache = open_cache("roundtrip", CacheQuota::default());
        CachedResponseStore::<String>::store_response(
            cache.as_ref(),
            "fp-roundtrip",
            Arc::new("value".repeat(40)),
            3_600,
        )
        .unwrap();
        let looked_up =
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-roundtrip")
                .unwrap()
                .unwrap();
        assert_eq!(looked_up.as_str(), "value".repeat(40));
        assert_eq!(
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-missing").unwrap(),
            None
        );
    }

    #[test]
    fn zero_ttl_entries_expire_immediately() {
        let cache = open_cache("ttl-zero", CacheQuota::default());
        CachedResponseStore::<String>::store_response(
            cache.as_ref(),
            "fp-expired",
            Arc::new("stale".to_string()),
            0,
        )
        .unwrap();
        assert_eq!(
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-expired").unwrap(),
            None
        );
    }

    #[test]
    fn least_recently_used_entry_is_evicted_first() {
        // Three ~1 KB entries against a 2.5 KB budget: only two survive.
        let cache = open_cache(
            "lru",
            CacheQuota {
                absolute_maximum_bytes: Some(2_500),
                ..CacheQuota::default()
            },
        );
        let store = |fingerprint: &str, value: String| {
            CachedResponseStore::<String>::store_response(
                cache.as_ref(),
                fingerprint,
                Arc::new(value),
                3_600,
            )
            .unwrap();
        };
        store("fp-a", repeated_text_entry("alpha", 1_000));
        store("fp-b", repeated_text_entry("beta", 1_000));
        // Touch A so B is the least recently used when C arrives.
        let touched = CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-a")
            .unwrap()
            .unwrap();
        let _ = touched;
        store("fp-c", repeated_text_entry("gamma", 1_000));
        assert!(
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-b")
                .unwrap()
                .is_none()
        );
        assert!(
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-a")
                .unwrap()
                .is_some()
        );
        assert!(
            CachedResponseStore::<String>::lookup_response(cache.as_ref(), "fp-c")
                .unwrap()
                .is_some()
        );
    }

    #[test]
    fn payloads_larger_than_the_budget_are_rejected_outright() {
        let cache = open_cache(
            "oversized",
            CacheQuota {
                absolute_maximum_bytes: Some(2_500),
                ..CacheQuota::default()
            },
        );
        let result = CachedResponseStore::<String>::store_response(
            cache.as_ref(),
            "fp-huge",
            Arc::new(repeated_text_entry("huge", 10_000)),
            3_600,
        );
        assert!(matches!(
            result,
            Err(SDKError::CacheOperationFailure(
                CacheOperationFailureReason::WriteRejected
            ))
        ));
        assert!(cache.database_path.exists());
    }

    #[test]
    fn reopening_reuses_the_existing_schema() {
        let database_path = unique_database_path("reopen");
        std::fs::remove_file(&database_path).ok();
        let configuration = SqliteResponseCacheConfiguration {
            database_path: database_path.clone(),
            ..SqliteResponseCacheConfiguration::default()
        };
        let first_cache = SqliteResponseCache::open(configuration.clone()).unwrap();
        CachedResponseStore::<String>::store_response(
            first_cache.as_ref(),
            "fp-persisted",
            Arc::new("kept".to_string()),
            3_600,
        )
        .unwrap();
        drop(first_cache);
        let second_cache = SqliteResponseCache::open(configuration).unwrap();
        let carried =
            CachedResponseStore::<String>::lookup_response(second_cache.as_ref(), "fp-persisted")
                .unwrap()
                .unwrap();
        assert_eq!(carried.as_str(), "kept");
        std::fs::remove_file(&database_path).ok();
    }
}
