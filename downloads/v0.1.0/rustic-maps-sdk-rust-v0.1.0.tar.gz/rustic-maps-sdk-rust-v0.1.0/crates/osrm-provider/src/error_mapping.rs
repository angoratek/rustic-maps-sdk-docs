//! OSRM response interpretation: HTTP status and provider error envelopes
//! become typed [`SDKError`] values.
//!
//! OSRM reports application failures in a JSON envelope:
//!
//! ```json
//! {"code": "NoRoute", "message": "Impossible route between points"}
//! ```
//!
//! The envelope is checked before the HTTP status, so the provider's own
//! message survives even when the service returns it with a 4xx status. A
//! non-success status without such an envelope is a transport-level failure.

use geospatial_types::SDKError;
use provider_transport::{HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpResponse};
use serde_json::Value;

/// The `code` value of a successful OSRM response.
pub const OSRM_SUCCESS_CODE: &str = "Ok";

/// Interprets one OSRM JSON response.
///
/// # Parameters
/// - `response` — status, headers and raw body returned by the transport.
///
/// # Returns
/// The decoded JSON payload when the response is successful and its `code` is
/// either absent or [`OSRM_SUCCESS_CODE`].
///
/// # Errors
/// - [`SDKError::ProviderRequestRejected`] when the body carries a `code`
///   other than [`OSRM_SUCCESS_CODE`]; the detail is OSRM's `message` verbatim
///   (or the code when no message is present).
/// - [`SDKError::ResponseParsingFailure`] when a successful response body is
///   not valid JSON.
/// - [`SDKError::NetworkRequestFailed`] when the status signals failure and
///   the body is not an OSRM error envelope.
pub fn interpret_json_response(response: HttpResponse) -> Result<Value, SDKError> {
    let successful_status = response.status_code < HTTP_ERROR_STATUS_CODE_THRESHOLD;
    let body_text = String::from_utf8_lossy(&response.body);
    match serde_json::from_slice::<Value>(&response.body) {
        Ok(payload) => {
            if let Some(rejection) = provider_rejection(&payload) {
                return Err(rejection);
            }
            if successful_status {
                Ok(payload)
            } else {
                Err(network_failure(response.status_code, &body_text))
            }
        }
        Err(parse_error) if successful_status => Err(SDKError::ResponseParsingFailure(format!(
            "OSRM response body is not valid JSON: {parse_error}"
        ))),
        Err(_) => Err(network_failure(response.status_code, &body_text)),
    }
}

/// Returns the provider rejection an OSRM `code` names, or `None` for a
/// successful or code-less payload.
fn provider_rejection(payload: &Value) -> Option<SDKError> {
    let code = payload.get("code").and_then(Value::as_str)?;
    if code == OSRM_SUCCESS_CODE {
        return None;
    }
    let message = payload
        .get("message")
        .and_then(Value::as_str)
        .unwrap_or(code);
    Some(SDKError::ProviderRequestRejected(message.to_string()))
}

/// Builds the transport-level failure for an unsuccessful status without a
/// provider envelope.
fn network_failure(status_code: u16, body_text: &str) -> SDKError {
    SDKError::NetworkRequestFailed(format!(
        "OSRM responded with HTTP status {status_code}: {body_text}"
    ))
}

#[cfg(test)]
mod tests {
    use super::{OSRM_SUCCESS_CODE, interpret_json_response};
    use geospatial_types::SDKError;
    use provider_transport::HttpResponse;

    fn response(status_code: u16, body: &str) -> HttpResponse {
        HttpResponse {
            status_code,
            headers: Vec::new(),
            body: body.as_bytes().to_vec(),
        }
    }

    #[test]
    fn success_envelope_yields_the_payload() {
        let payload = interpret_json_response(response(
            200,
            &format!(r#"{{"code":"{OSRM_SUCCESS_CODE}","routes":[]}}"#),
        ))
        .unwrap();
        assert_eq!(payload["code"], OSRM_SUCCESS_CODE);
    }

    #[test]
    fn provider_rejection_keeps_the_message_verbatim() {
        let error = interpret_json_response(response(
            400,
            r#"{"code":"NoRoute","message":"Impossible route between points"}"#,
        ))
        .unwrap_err();
        match error {
            SDKError::ProviderRequestRejected(message) => {
                assert_eq!(message, "Impossible route between points");
            }
            other => panic!("expected a provider rejection, got {other:?}"),
        }
    }

    #[test]
    fn server_failure_without_an_envelope_is_a_network_failure() {
        let error = interpret_json_response(response(500, "upstream failure")).unwrap_err();
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
    }

    #[test]
    fn malformed_successful_body_is_a_parsing_failure() {
        let error = interpret_json_response(response(200, "not json")).unwrap_err();
        assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
    }
}
