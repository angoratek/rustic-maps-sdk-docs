//! Configuration and the HTTP facade shared by OSRM endpoint implementations.
//!
//! Unlike a credentialed commercial platform, OSRM is addressed by its
//! deployment URL and needs no key, so this client carries no credential
//! injection and no rate limiter: it holds one base URL and one user agent,
//! performs idempotent GETs through [`provider_transport`], and hands each
//! response to [`crate::error_mapping::interpret_json_response`].

use crate::error_mapping::interpret_json_response;
use geospatial_types::SDKError;
use provider_transport::{
    HttpMethod, HttpRequest, HttpTransport, ObservedTransport, RetryPolicy, default_transport,
    execute_idempotent_get,
};
use std::sync::Arc;
use url::Url;

/// Base URL of a locally hosted OSRM server used when no configuration is
/// provided. A local OSRM installation serves the HTTP API on port 5000.
pub const DEFAULT_OSRM_BASE_URL: &str = "http://localhost:5000";

/// The provider contract every call through this client serves.
pub const ROUTING_CONTRACT_NAME: &str = "RoutingProvider";

/// The registry key of this provider, used for request observation only.
pub const OSRM_PROVIDER_KEY: &str = "osrm";

/// User agent sent when the configuration carries none.
pub const DEFAULT_OSRM_USER_AGENT: &str =
    concat!("rustic-maps-osrm-provider/", env!("CARGO_PKG_VERSION"));

/// Retries after the first attempt for one idempotent route GET. Retries
/// apply only to transient transport and server failures.
pub const DEFAULT_MAXIMUM_RETRY_ATTEMPTS: u32 = 2;

/// Connection settings for one OSRM deployment.
///
/// OSRM is keyless, so the deployment URL is the only address information the
/// service needs. `base_url` may name any host serving the OSRM HTTP API
/// (`http://host:5000`, `https://routing.example.com`, and so on) and must be
/// an absolute URL without the route service path.
///
/// `user_agent` identifies the SDK to the deployment's operator; an empty
/// value suppresses the header entirely.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OsrmProviderConfiguration {
    /// Root URL of the OSRM deployment.
    pub base_url: String,
    /// `User-Agent` header value sent with every request.
    pub user_agent: String,
}

impl Default for OsrmProviderConfiguration {
    fn default() -> Self {
        Self {
            base_url: DEFAULT_OSRM_BASE_URL.to_string(),
            user_agent: DEFAULT_OSRM_USER_AGENT.to_string(),
        }
    }
}

/// GET-only JSON client against one OSRM base URL.
///
/// The client validates the base URL once, then builds each request as
/// `{base_url}/{path}` with the caller's query pairs. The route service has no
/// request body, so only idempotent GETs are needed.
pub struct OsrmHttpClient {
    base_url: String,
    user_agent: String,
    maximum_retry_attempts: u32,
    transport: Arc<dyn HttpTransport>,
}

impl OsrmHttpClient {
    /// Builds a client around the target's default transport.
    ///
    /// # Parameters
    /// - `configuration` — deployment base URL and user agent.
    ///
    /// # Returns
    /// A client ready to issue requests.
    ///
    /// # Errors
    /// Returns [`SDKError::NetworkRequestFailed`] when `base_url` is not an
    /// absolute http or https URL or when the native HTTP transport cannot be
    /// built.
    pub fn new(configuration: OsrmProviderConfiguration) -> Result<Self, SDKError> {
        Self::with_transport(
            configuration,
            DEFAULT_MAXIMUM_RETRY_ATTEMPTS,
            Arc::new(ObservedTransport::new(
                default_transport()?,
                ROUTING_CONTRACT_NAME,
                OSRM_PROVIDER_KEY,
            )),
        )
    }

    /// Builds a client around an explicit transport and retry budget (the
    /// registration path and tests use this seam; request building,
    /// interpretation and retry behavior are identical whichever transport is
    /// supplied).
    ///
    /// # Parameters
    /// - `configuration` — deployment base URL and user agent.
    /// - `maximum_retry_attempts` — retries after the first attempt for a
    ///   transient failure.
    /// - `transport` — the platform transport that executes requests.
    ///
    /// # Errors
    /// Returns [`SDKError::NetworkRequestFailed`] when `base_url` is not an
    /// absolute http or https URL.
    pub fn with_transport(
        configuration: OsrmProviderConfiguration,
        maximum_retry_attempts: u32,
        transport: Arc<dyn HttpTransport>,
    ) -> Result<Self, SDKError> {
        validate_base_url(&configuration.base_url)?;
        Ok(Self {
            base_url: configuration.base_url,
            user_agent: configuration.user_agent,
            maximum_retry_attempts,
            transport,
        })
    }

    /// Performs a bounded-retry GET against `{base_url}/{path}` with the given
    /// query pairs.
    ///
    /// # Parameters
    /// - `path` — service path below the base URL, without a leading slash.
    /// - `query_pairs` — query parameters appended in order.
    ///
    /// # Returns
    /// The decoded JSON payload. An OSRM payload whose `code` is not `Ok` is
    /// rejected before it reaches the caller.
    ///
    /// # Errors
    /// - [`SDKError::NetworkRequestFailed`] for a transport failure or a
    ///   non-success HTTP status that does not carry an OSRM error envelope.
    /// - [`SDKError::ResponseParsingFailure`] when a successful response body
    ///   is not JSON.
    /// - [`SDKError::ProviderRequestRejected`] when OSRM answers with the
    ///   provider's own `code`/`message` error envelope.
    pub async fn get_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
    ) -> Result<serde_json::Value, SDKError> {
        let request = self.build_request(path, query_pairs)?;
        execute_idempotent_get(
            self.transport.as_ref(),
            &request,
            RetryPolicy::new(self.maximum_retry_attempts),
            interpret_json_response,
        )
        .await
    }

    /// Builds one GET request against `{base_url}/{path}` with the configured
    /// query pairs and user agent.
    fn build_request(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
    ) -> Result<HttpRequest, SDKError> {
        let endpoint = format!(
            "{}/{}",
            self.base_url.trim_end_matches('/'),
            path.trim_start_matches('/')
        );
        let mut url = Url::parse(&endpoint).map_err(|error| {
            SDKError::NetworkRequestFailed(format!("invalid OSRM request URL {endpoint}: {error}"))
        })?;
        {
            let mut query_pairs_mut = url.query_pairs_mut();
            for (name, value) in query_pairs {
                query_pairs_mut.append_pair(name, value);
            }
        }
        let headers = if self.user_agent.is_empty() {
            Vec::new()
        } else {
            vec![("user-agent".to_string(), self.user_agent.clone())]
        };
        Ok(HttpRequest {
            method: HttpMethod::Get,
            url: url.to_string(),
            headers,
            body: None,
        })
    }
}

/// Validates that a configuration names an absolute HTTP base URL.
fn validate_base_url(base_url: &str) -> Result<(), SDKError> {
    let parsed = Url::parse(base_url).map_err(|error| {
        SDKError::NetworkRequestFailed(format!("invalid OSRM base URL {base_url}: {error}"))
    })?;
    if !matches!(parsed.scheme(), "http" | "https") || parsed.host_str().is_none() {
        return Err(SDKError::NetworkRequestFailed(format!(
            "invalid OSRM base URL {base_url}: expected an absolute http or https URL"
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{OsrmHttpClient, OsrmProviderConfiguration};
    use geospatial_types::SDKError;

    #[test]
    fn relative_base_url_is_rejected_at_construction() {
        let outcome = OsrmHttpClient::new(OsrmProviderConfiguration {
            base_url: "localhost:5000".to_string(),
            user_agent: "test-agent".to_string(),
        });
        match outcome {
            Err(SDKError::NetworkRequestFailed(detail)) => {
                assert!(detail.contains("localhost:5000"), "detail was {detail}");
            }
            Err(other) => panic!("expected a network failure, got {other:?}"),
            Ok(_) => panic!("a relative base URL must not build a client"),
        }
    }

    #[test]
    fn default_configuration_targets_the_local_osrm_port() {
        let configuration = OsrmProviderConfiguration::default();
        assert_eq!(configuration.base_url, "http://localhost:5000");
        assert!(!configuration.user_agent.is_empty());
    }
}
