//! OSRM implementation of [`geospatial_traits::RoutingProvider`] against the
//! OSRM HTTP route service (`project-osrm.org/docs/v5.24.0/api/`).
//!
//! OSRM is keyless: a deployment is reached by its base URL, so the crate
//! takes an explicit [`OsrmProviderConfiguration`] whose `base_url` names the
//! server. When no configuration is supplied the default points at a local
//! OSRM instance listening on port 5000. Every request goes through the shared
//! [`provider_transport`] seam ([`client`]) with bounded idempotent-GET
//! retries, so the same request, parsing and error-mapping code runs natively
//! and in browsers.
//!
//! # Route option mapping
//!
//! [`geospatial_traits::RoutingProvider::calculate_route`] maps the SDK
//! options onto the route service as follows:
//!
//! - [`geospatial_types::route::TransportationMode::Automobile`] selects the
//!   `driving` profile, `Bicycle` the `cycling` profile and `Pedestrian` the
//!   `walking` profile, in the request path.
//! - [`geospatial_types::route::AvoidOptions`] fields become `exclude` classes
//!   (`toll`, `motorway`, `ferry`, `unpaved`).
//! - `unit_system` does not change the request: the contract is always meters
//!   and seconds and the service always answers in those units.
//!
//! `route_strategy` and `departure_timestamp_seconds` have no route-service
//! parameter, so they do not affect the request; the deployment's profile
//! cost model decides the ranking and the service routes for "now".
//!
//! # Supported route data
//!
//! The provider reads `routes[0]` and decodes the total distance and
//! duration, the GeoJSON route geometry (from which it derives the bounding
//! box), and one leg per consecutive waypoint pair. Each leg carries its
//! steps, and each step is classified through an explicit OSRM
//! `maneuver.type`/`modifier` table ([`route::map_osrm_maneuver`]). OSRM does
//! not return human-readable instructions, so the crate authors the display
//! and speech strings from the maneuver and road name, and it does not map
//! OSRM lane records, leaving `lane_guidances` empty.

pub mod client;
pub mod error_mapping;
pub mod route;

pub use client::{
    DEFAULT_OSRM_BASE_URL, DEFAULT_OSRM_USER_AGENT, OsrmHttpClient, OsrmProviderConfiguration,
};
pub use route::OsrmRoutingProvider;

#[cfg(test)]
mod route_capability_tests {
    use geospatial_traits::RoutingProvider;
    use geospatial_types::route::{RouteCapabilities, TransportationMode};

    use crate::{OsrmProviderConfiguration, OsrmRoutingProvider};

    #[test]
    fn the_provider_reports_every_mode_and_no_shortest_strategy() {
        let provider = OsrmRoutingProvider::new(OsrmProviderConfiguration::default())
            .expect("the default configuration builds a provider");
        let capabilities = provider.route_capabilities();
        assert_eq!(
            capabilities.supported_transportation_modes,
            RouteCapabilities::all_supported().supported_transportation_modes,
        );
        assert!(!capabilities.supports_shortest_route_strategy);
        assert!(capabilities.supports_transportation_mode(TransportationMode::Automobile));
        assert!(capabilities.supports_transportation_mode(TransportationMode::Pedestrian));
    }
}
