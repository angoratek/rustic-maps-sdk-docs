//! OSRM route service implementation of
//! [`geospatial_traits::RoutingProvider`].
//!
//! # Request shape
//!
//! One request is
//! `GET {base_url}/route/v1/{profile}/{longitude},{latitude};…` with
//! `overview=full`, `geometries=geojson`, `steps=true` and, when the caller
//! asks to avoid features, `exclude` set to the requested OSRM classes.
//!
//! # Option mapping
//!
//! - [`TransportationMode::Automobile`] selects the `driving` profile,
//!   [`TransportationMode::Bicycle`] the `cycling` profile and
//!   [`TransportationMode::Pedestrian`] the `walking` profile.
//! - [`AvoidOptions::toll_roads`] becomes `toll`,
//!   [`AvoidOptions::limited_access_highways`] becomes `motorway`,
//!   [`AvoidOptions::ferries`] becomes `ferry` and
//!   [`AvoidOptions::unpaved_roads`] becomes `unpaved`, joined in one
//!   `exclude` value.
//! - [`geospatial_types::route::UnitSystem`] does not change the request: the
//!   route contract is always meters and seconds, which is also what OSRM
//!   returns.
//!
//! # Options OSRM cannot express
//!
//! These are documented rather than silently approximated:
//!
//! - [`geospatial_types::route::RouteStrategy`] has no route-service
//!   parameter. The deployed profile's cost model fixes the ranking, so
//!   `Fastest` and `Shortest` produce the same request.
//! - [`RouteOptions::departure_timestamp_seconds`] has no route-service
//!   parameter. The service routes for "now", so a requested departure instant
//!   is not honored.
//! - `exclude` classes must be declared by the deployed profile. Requesting a
//!   class the profile does not declare makes OSRM reject the request, which
//!   surfaces as [`SDKError::ProviderRequestRejected`].
//! - OSRM returns no human-readable instruction, so this provider authors
//!   display and speech text from the maneuver and road name, and it does not
//!   map OSRM intersection lane records.

use crate::client::{OsrmHttpClient, OsrmProviderConfiguration};
use async_trait::async_trait;
use geospatial_traits::RoutingProvider;
use geospatial_types::route::{
    AvoidOptions, ManeuverType, RouteCapabilities, RouteData, RouteLeg, RouteOptions, RouteStep,
    TransportationMode, TurnDirection,
};
use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};
use serde_json::Value;

/// Path prefix of the route service version the provider targets.
const ROUTE_SERVICE_PATH_PREFIX: &str = "route/v1";

/// OSRM profile segment used for automobile routing.
const DRIVING_PROFILE: &str = "driving";
/// OSRM profile segment used for bicycle routing.
const CYCLING_PROFILE: &str = "cycling";
/// OSRM profile segment used for pedestrian routing.
const WALKING_PROFILE: &str = "walking";

/// Query value requesting the full route geometry.
const OVERVIEW_FULL: &str = "full";
/// Query value requesting GeoJSON geometries.
const GEOMETRIES_GEOJSON: &str = "geojson";
/// Query value requesting turn-by-turn steps.
const STEPS_TRUE: &str = "true";

/// Separator between the coordinates of successive waypoints.
const COORDINATE_SEPARATOR: &str = ";";
/// Separator between a coordinate's longitude and latitude.
const LONGITUDE_LATITUDE_SEPARATOR: &str = ",";

/// OSRM `exclude` class for toll roads.
const TOLL_EXCLUDE_CLASS: &str = "toll";
/// OSRM `exclude` class for motorways.
const MOTORWAY_EXCLUDE_CLASS: &str = "motorway";
/// OSRM `exclude` class for ferries.
const FERRY_EXCLUDE_CLASS: &str = "ferry";
/// OSRM `exclude` class for unpaved roads.
const UNPAVED_EXCLUDE_CLASS: &str = "unpaved";
/// Separator between OSRM `exclude` classes.
const EXCLUDE_CLASS_SEPARATOR: &str = ",";

/// The fewest waypoints a route can connect.
const MINIMUM_ROUTE_WAYPOINT_COUNT: usize = 2;

/// Exit index used when OSRM reports none for a roundabout. The contract's
/// roundabout index is one-based.
const DEFAULT_ROUNDABOUT_EXIT_INDEX: u8 = 1;

/// Routing through the OSRM HTTP route service.
pub struct OsrmRoutingProvider {
    http_client: OsrmHttpClient,
}

impl OsrmRoutingProvider {
    /// Builds the provider for one OSRM deployment.
    ///
    /// # Parameters
    /// - `configuration` — deployment base URL and user agent.
    ///
    /// # Returns
    /// A provider ready to calculate routes.
    ///
    /// # Errors
    /// Returns [`SDKError::NetworkRequestFailed`] when the base URL is not an
    /// absolute http or https URL or the native HTTP transport cannot be
    /// built.
    pub fn new(configuration: OsrmProviderConfiguration) -> Result<Self, SDKError> {
        Ok(Self {
            http_client: OsrmHttpClient::new(configuration)?,
        })
    }
}

#[async_trait]
impl RoutingProvider for OsrmRoutingProvider {
    /// OSRM's route service selects a profile by mode and has no
    /// shortest-path switch, so the strategy choice cannot be honoured.
    fn route_capabilities(&self) -> RouteCapabilities {
        RouteCapabilities {
            supported_transportation_modes: vec![
                TransportationMode::Automobile,
                TransportationMode::Bicycle,
                TransportationMode::Pedestrian,
            ],
            supports_shortest_route_strategy: false,
        }
    }

    async fn calculate_route(
        &self,
        waypoints: &[GeographicCoordinate],
        route_options: &RouteOptions,
    ) -> Result<RouteData, SDKError> {
        if waypoints.len() < MINIMUM_ROUTE_WAYPOINT_COUNT {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "a route needs at least {MINIMUM_ROUTE_WAYPOINT_COUNT} waypoints; got {}",
                waypoints.len()
            )));
        }
        let request_path = route_request_path(route_options.transportation_mode, waypoints);
        let query_pairs = route_query_pairs(route_options);
        let payload = self
            .http_client
            .get_json(&request_path, &query_pairs)
            .await?;
        parse_route_payload(&payload)
    }
}

/// Builds the route-service path, including the profile and the ordered
/// `longitude,latitude` waypoint list.
fn route_request_path(
    transportation_mode: TransportationMode,
    waypoints: &[GeographicCoordinate],
) -> String {
    let coordinates = waypoints
        .iter()
        .map(|waypoint| {
            format!(
                "{}{LONGITUDE_LATITUDE_SEPARATOR}{}",
                waypoint.longitude, waypoint.latitude
            )
        })
        .collect::<Vec<String>>()
        .join(COORDINATE_SEPARATOR);
    format!(
        "{ROUTE_SERVICE_PATH_PREFIX}/{}/{}",
        profile_path_segment(transportation_mode),
        coordinates
    )
}

/// Maps the contract's transportation mode onto OSRM's profile path segment.
fn profile_path_segment(transportation_mode: TransportationMode) -> &'static str {
    match transportation_mode {
        TransportationMode::Automobile => DRIVING_PROFILE,
        TransportationMode::Bicycle => CYCLING_PROFILE,
        TransportationMode::Pedestrian => WALKING_PROFILE,
    }
}

/// Builds the route-service query pairs, including avoidance classes when the
/// caller asked for any.
fn route_query_pairs(route_options: &RouteOptions) -> Vec<(String, String)> {
    let mut query_pairs = vec![
        ("overview".to_string(), OVERVIEW_FULL.to_string()),
        ("geometries".to_string(), GEOMETRIES_GEOJSON.to_string()),
        ("steps".to_string(), STEPS_TRUE.to_string()),
    ];
    let exclude_classes = exclude_classes_text(&route_options.avoid_options);
    if !exclude_classes.is_empty() {
        query_pairs.push(("exclude".to_string(), exclude_classes));
    }
    query_pairs
}

/// Joins the requested avoidance classes into one OSRM `exclude` value.
fn exclude_classes_text(avoid_options: &AvoidOptions) -> String {
    let mut classes = Vec::new();
    if avoid_options.toll_roads {
        classes.push(TOLL_EXCLUDE_CLASS);
    }
    if avoid_options.limited_access_highways {
        classes.push(MOTORWAY_EXCLUDE_CLASS);
    }
    if avoid_options.ferries {
        classes.push(FERRY_EXCLUDE_CLASS);
    }
    if avoid_options.unpaved_roads {
        classes.push(UNPAVED_EXCLUDE_CLASS);
    }
    classes.join(EXCLUDE_CLASS_SEPARATOR)
}

/// Parses an OSRM route payload into a [`RouteData`].
///
/// # Parameters
/// - `payload` — a decoded OSRM route response whose `code` is `Ok`.
///
/// # Returns
/// The first route's total distance and duration, the bounding box derived
/// from its full geometry, and one leg per consecutive waypoint pair.
///
/// # Errors
/// Returns [`SDKError::ResponseParsingFailure`] when the payload lacks a
/// route, its numeric totals, its GeoJSON geometry, its legs or a leg's steps,
/// or when a coordinate is outside the valid ranges.
pub fn parse_route_payload(payload: &Value) -> Result<RouteData, SDKError> {
    let routes = payload
        .get("routes")
        .and_then(Value::as_array)
        .ok_or_else(|| parsing_failure("OSRM route payload carries no routes array"))?;
    let route = routes
        .first()
        .ok_or_else(|| parsing_failure("OSRM route payload carries no routes"))?;

    let distance_meters = required_number(route, "distance", "route")?;
    let duration_seconds = required_number(route, "duration", "route")?;

    let geometry = route
        .get("geometry")
        .ok_or_else(|| parsing_failure("OSRM route payload carries no geometry"))?;
    let route_shape = parse_geojson_line_string(geometry, "route geometry")?;
    let bounding_box = bounding_box_from_coordinates(&route_shape)?;

    let leg_values = route
        .get("legs")
        .and_then(Value::as_array)
        .ok_or_else(|| parsing_failure("OSRM route payload carries no legs array"))?;
    if leg_values.is_empty() {
        return Err(parsing_failure("OSRM route payload carries no legs"));
    }
    let legs = leg_values
        .iter()
        .map(parse_route_leg)
        .collect::<Result<Vec<RouteLeg>, SDKError>>()?;

    Ok(RouteData {
        distance_meters,
        duration_seconds,
        bounding_box,
        legs,
    })
}

/// Parses one leg: totals plus its ordered steps.
fn parse_route_leg(leg: &Value) -> Result<RouteLeg, SDKError> {
    let distance_meters = required_number(leg, "distance", "route leg")?;
    let duration_seconds = required_number(leg, "duration", "route leg")?;
    let step_values = leg
        .get("steps")
        .and_then(Value::as_array)
        .ok_or_else(|| parsing_failure("OSRM route leg carries no steps array"))?;
    let steps = step_values
        .iter()
        .map(parse_route_step)
        .collect::<Result<Vec<RouteStep>, SDKError>>()?;
    Ok(RouteLeg {
        distance_meters,
        duration_seconds,
        steps,
    })
}

/// Parses one step: totals, maneuver classification, authored instruction
/// text and the step's GeoJSON shape.
fn parse_route_step(step: &Value) -> Result<RouteStep, SDKError> {
    let distance_meters = required_number(step, "distance", "route step")?;
    let duration_seconds = required_number(step, "duration", "route step")?;
    let maneuver = step
        .get("maneuver")
        .ok_or_else(|| parsing_failure("OSRM route step carries no maneuver"))?;
    let maneuver_type_text = maneuver
        .get("type")
        .and_then(Value::as_str)
        .ok_or_else(|| parsing_failure("OSRM route step maneuver carries no type"))?;
    let modifier = maneuver.get("modifier").and_then(Value::as_str);
    let exit_index = maneuver
        .get("exit")
        .and_then(Value::as_u64)
        .map(|exit| exit.min(u64::from(u8::MAX)) as u8);
    let maneuver_type = map_osrm_maneuver(maneuver_type_text, modifier, exit_index);

    let road_name = step.get("name").and_then(Value::as_str).unwrap_or_default();
    let instruction_display_text = instruction_text(&maneuver_type, road_name);
    let shape = match step.get("geometry") {
        Some(geometry) => parse_geojson_line_string(geometry, "step geometry")?,
        None => Vec::new(),
    };

    Ok(RouteStep {
        distance_meters,
        duration_seconds,
        maneuver_type,
        instruction_display_text: instruction_display_text.clone(),
        instruction_speech_text: instruction_display_text,
        shape,
        // OSRM carries lane data on intersections in a provider-specific
        // vocabulary; it is not mapped into the contract's lane guidance.
        lane_guidances: Vec::new(),
    })
}

/// Reads a required numeric field from a payload object.
fn required_number(container: &Value, field_name: &str, context: &str) -> Result<f64, SDKError> {
    container
        .get(field_name)
        .and_then(Value::as_f64)
        .ok_or_else(|| parsing_failure(format!("OSRM {context} carries no numeric {field_name}")))
}

/// Parses a GeoJSON `LineString` geometry into coordinates.
///
/// GeoJSON positions are `[longitude, latitude]`; the contract's coordinate
/// exposes the same pair in named fields.
fn parse_geojson_line_string(
    geometry: &Value,
    context: &str,
) -> Result<Vec<GeographicCoordinate>, SDKError> {
    if let Some(geometry_type) = geometry.get("type").and_then(Value::as_str) {
        if geometry_type != "LineString" {
            return Err(parsing_failure(format!(
                "OSRM {context} is {geometry_type}, not LineString"
            )));
        }
    }
    let coordinate_values = geometry
        .get("coordinates")
        .and_then(Value::as_array)
        .ok_or_else(|| parsing_failure(format!("OSRM {context} carries no coordinates array")))?;
    let mut coordinates = Vec::with_capacity(coordinate_values.len());
    for coordinate_value in coordinate_values {
        let position = coordinate_value.as_array().ok_or_else(|| {
            parsing_failure(format!(
                "OSRM {context} has a position that is not an array"
            ))
        })?;
        if position.len() < 2 {
            return Err(parsing_failure(format!(
                "OSRM {context} has a position with fewer than two elements"
            )));
        }
        let longitude = position[0].as_f64().ok_or_else(|| {
            parsing_failure(format!("OSRM {context} has a non-numeric longitude"))
        })?;
        let latitude = position[1]
            .as_f64()
            .ok_or_else(|| parsing_failure(format!("OSRM {context} has a non-numeric latitude")))?;
        coordinates.push(
            GeographicCoordinate::from_degrees(latitude, longitude).map_err(|error| {
                parsing_failure(format!("OSRM {context} has an invalid coordinate: {error}"))
            })?,
        );
    }
    Ok(coordinates)
}

/// Derives the route bounding box from its full geometry.
fn bounding_box_from_coordinates(
    coordinates: &[GeographicCoordinate],
) -> Result<BoundingBox, SDKError> {
    let first = coordinates
        .first()
        .ok_or_else(|| parsing_failure("OSRM route geometry is empty"))?;
    let mut minimum_latitude = first.latitude;
    let mut maximum_latitude = first.latitude;
    let mut minimum_longitude = first.longitude;
    let mut maximum_longitude = first.longitude;
    for coordinate in coordinates {
        minimum_latitude = minimum_latitude.min(coordinate.latitude);
        maximum_latitude = maximum_latitude.max(coordinate.latitude);
        minimum_longitude = minimum_longitude.min(coordinate.longitude);
        maximum_longitude = maximum_longitude.max(coordinate.longitude);
    }
    BoundingBox::from_corners(
        GeographicCoordinate {
            latitude: minimum_latitude,
            longitude: minimum_longitude,
        },
        GeographicCoordinate {
            latitude: maximum_latitude,
            longitude: maximum_longitude,
        },
    )
    .map_err(|error| {
        parsing_failure(format!(
            "OSRM route geometry bounding box is invalid: {error}"
        ))
    })
}

/// Maps OSRM's documented maneuver vocabulary onto [`ManeuverType`].
///
/// | OSRM `maneuver.type` | Contract maneuver |
/// |---|---|
/// | `depart` | [`ManeuverType::Departure`] |
/// | `arrive` | [`ManeuverType::Arrival`] |
/// | `turn`, `end of road` | [`ManeuverType::Turn`] from `modifier`; [`ManeuverType::Continue`] when the modifier is missing or unknown |
/// | `continue` | [`ManeuverType::Turn`] from `modifier`; `Turn(Straight)` when the modifier is missing or unknown |
/// | `new name`, `use lane`, `notification` | [`ManeuverType::Continue`] |
/// | `merge` | [`ManeuverType::Merge`] |
/// | `on ramp` | [`ManeuverType::OnRamp`] |
/// | `off ramp` | [`ManeuverType::OffRamp`] |
/// | `fork` | [`ManeuverType::Fork`] |
/// | `roundabout`, `rotary`, `roundabout turn`, `exit roundabout`, `exit rotary` | [`ManeuverType::Roundabout`] with the one-based `exit` index |
/// | anything else | [`ManeuverType::Continue`] |
///
/// The modifier vocabulary is `uturn` (or `u-turn`), `sharp left`, `left`,
/// `slight left`, `straight`, `slight right`, `right` and `sharp right`. A
/// `turn` or `end of road` maneuver with no recognized modifier maps to
/// [`ManeuverType::Continue`] rather than guessing a turn direction. A
/// roundabout without a positive `exit` index maps to exit `1`, keeping every
/// maneuver's stable label valid.
///
/// # Parameters
/// - `maneuver_type` — OSRM's `maneuver.type` string.
/// - `modifier` — OSRM's optional `maneuver.modifier` string.
/// - `exit_index` — OSRM's optional one-based roundabout `exit` index.
///
/// # Returns
/// The contract maneuver for the OSRM classification. Unknown types use the
/// documented [`ManeuverType::Continue`] fallback.
pub fn map_osrm_maneuver(
    maneuver_type: &str,
    modifier: Option<&str>,
    exit_index: Option<u8>,
) -> ManeuverType {
    match maneuver_type {
        "depart" => ManeuverType::Departure,
        "arrive" => ManeuverType::Arrival,
        "turn" | "end of road" => turn_from_modifier(modifier).unwrap_or(ManeuverType::Continue),
        "continue" => {
            turn_from_modifier(modifier).unwrap_or(ManeuverType::Turn(TurnDirection::Straight))
        }
        "new name" | "use lane" | "notification" => ManeuverType::Continue,
        "merge" => ManeuverType::Merge,
        "on ramp" => ManeuverType::OnRamp,
        "off ramp" => ManeuverType::OffRamp,
        "fork" => ManeuverType::Fork,
        "roundabout" | "rotary" | "roundabout turn" | "exit roundabout" | "exit rotary" => {
            ManeuverType::Roundabout(
                exit_index
                    .filter(|index| *index >= DEFAULT_ROUNDABOUT_EXIT_INDEX)
                    .unwrap_or(DEFAULT_ROUNDABOUT_EXIT_INDEX),
            )
        }
        _ => ManeuverType::Continue,
    }
}

/// Builds the turn maneuver a recognized OSRM modifier names; `None` for an
/// absent or unrecognized modifier.
fn turn_from_modifier(modifier: Option<&str>) -> Option<ManeuverType> {
    let direction = match modifier? {
        "straight" => TurnDirection::Straight,
        "slight left" => TurnDirection::SlightLeft,
        "left" => TurnDirection::Left,
        "sharp left" => TurnDirection::SharpLeft,
        "slight right" => TurnDirection::SlightRight,
        "right" => TurnDirection::Right,
        "sharp right" => TurnDirection::SharpRight,
        "uturn" | "u-turn" => TurnDirection::UTurn,
        _ => return None,
    };
    Some(ManeuverType::Turn(direction))
}

/// Authors the display instruction for one maneuver.
///
/// OSRM returns maneuver classifications rather than prose, so the text is
/// generated from the maneuver and the road name OSRM reports for the step.
/// The speech string carries the same text; there is no separate spoken form
/// in the provider payload.
fn instruction_text(maneuver_type: &ManeuverType, road_name: &str) -> String {
    let onto = if road_name.is_empty() {
        String::new()
    } else {
        format!(" onto {road_name}")
    };
    match maneuver_type {
        ManeuverType::Departure => {
            if road_name.is_empty() {
                "Start navigation".to_string()
            } else {
                format!("Start on {road_name}")
            }
        }
        ManeuverType::Arrival => "Arrive at your destination".to_string(),
        ManeuverType::Continue => format!("Continue{onto}"),
        ManeuverType::Turn(direction) => {
            let action = match direction {
                TurnDirection::Straight => "Continue straight",
                TurnDirection::SlightLeft => "Turn slight left",
                TurnDirection::Left => "Turn left",
                TurnDirection::SharpLeft => "Turn sharp left",
                TurnDirection::SlightRight => "Turn slight right",
                TurnDirection::Right => "Turn right",
                TurnDirection::SharpRight => "Turn sharp right",
                TurnDirection::UTurn => "Make a U-turn",
                TurnDirection::LeavingRoad => "Leave the current road",
            };
            format!("{action}{onto}")
        }
        ManeuverType::Merge => format!("Merge{onto}"),
        ManeuverType::OnRamp => format!("Take the ramp{onto}"),
        ManeuverType::OffRamp => format!("Take the exit{onto}"),
        ManeuverType::Fork => format!("Take the fork{onto}"),
        ManeuverType::Roundabout(exit_index) => {
            format!("Take exit {exit_index} at the roundabout")
        }
        ManeuverType::Ferry => "Take the ferry".to_string(),
    }
}

/// Builds a parsing failure with the given detail.
fn parsing_failure(detail: impl Into<String>) -> SDKError {
    SDKError::ResponseParsingFailure(detail.into())
}

#[cfg(test)]
mod tests {
    use super::{
        OsrmRoutingProvider, exclude_classes_text, instruction_text, map_osrm_maneuver,
        parse_route_payload, profile_path_segment, route_query_pairs, route_request_path,
    };
    use crate::client::{DEFAULT_OSRM_USER_AGENT, OsrmProviderConfiguration};
    use geospatial_traits::RoutingProvider;
    use geospatial_types::route::{
        AvoidOptions, ManeuverType, RouteOptions, RouteStrategy, TransportationMode, TurnDirection,
        UnitSystem,
    };
    use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};
    use serde_json::Value;
    use wiremock::matchers::{header, method, path, query_param};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    fn fixture(name: &str) -> Value {
        let fixture_path = format!("{}/fixtures/{name}", env!("CARGO_MANIFEST_DIR"));
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    fn provider_for(base_url: String) -> OsrmRoutingProvider {
        OsrmRoutingProvider::new(OsrmProviderConfiguration {
            base_url,
            user_agent: DEFAULT_OSRM_USER_AGENT.to_string(),
        })
        .unwrap()
    }

    fn sacramento_waypoints() -> Vec<GeographicCoordinate> {
        vec![
            GeographicCoordinate::from_degrees(38.57657, -121.4936).unwrap(),
            GeographicCoordinate::from_degrees(38.5781, -121.50555).unwrap(),
        ]
    }

    fn assert_close(actual: f64, expected: f64) {
        assert!(
            (actual - expected).abs() < 1e-6,
            "expected {expected}, got {actual}"
        );
    }

    #[tokio::test]
    async fn successful_route_decodes_distance_duration_legs_steps_and_bounding_box() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path(
                "/route/v1/driving/-121.4936,38.57657;-121.50555,38.5781",
            ))
            .respond_with(
                ResponseTemplate::new(200).set_body_json(fixture("sacramento_route.json")),
            )
            .mount(&server)
            .await;

        let route = provider_for(server.uri())
            .calculate_route(&sacramento_waypoints(), &RouteOptions::default())
            .await
            .unwrap();

        assert_close(route.distance_meters, 1302.3);
        assert_close(route.duration_seconds, 157.1);
        assert_eq!(route.legs.len(), 1);

        let leg = &route.legs[0];
        assert_close(leg.distance_meters, 1302.3);
        assert_close(leg.duration_seconds, 157.1);
        assert_eq!(leg.steps.len(), 4);

        assert_eq!(leg.steps[0].maneuver_type, ManeuverType::Departure);
        assert_eq!(
            leg.steps[1].maneuver_type,
            ManeuverType::Turn(TurnDirection::Left)
        );
        assert_eq!(
            leg.steps[2].maneuver_type,
            ManeuverType::Turn(TurnDirection::Right)
        );
        assert_eq!(leg.steps[3].maneuver_type, ManeuverType::Arrival);

        assert_eq!(
            leg.steps[0].instruction_display_text,
            "Start on 10th Street"
        );
        assert_eq!(
            leg.steps[1].instruction_display_text,
            "Turn left onto L Street"
        );
        assert_eq!(
            leg.steps[2].instruction_display_text,
            "Turn right onto Front Street"
        );
        assert_eq!(
            leg.steps[3].instruction_display_text,
            "Arrive at your destination"
        );
        for step in &leg.steps {
            assert!(
                !step.shape.is_empty(),
                "every recorded step carries a shape"
            );
            assert_eq!(step.instruction_speech_text, step.instruction_display_text);
            assert!(step.lane_guidances.is_empty());
        }

        let expected_bounding_box = BoundingBox::from_corners(
            GeographicCoordinate::from_degrees(38.57657, -121.50555).unwrap(),
            GeographicCoordinate::from_degrees(38.5781, -121.4936).unwrap(),
        )
        .unwrap();
        assert_eq!(route.bounding_box, expected_bounding_box);
    }

    #[tokio::test]
    async fn request_url_carries_profile_parameters_and_waypoint_order() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path(
                "/route/v1/driving/-121.4936,38.57657;-121.50555,38.5781",
            ))
            .and(query_param("overview", "full"))
            .and(query_param("geometries", "geojson"))
            .and(query_param("steps", "true"))
            .and(header("user-agent", DEFAULT_OSRM_USER_AGENT))
            .respond_with(
                ResponseTemplate::new(200).set_body_json(fixture("sacramento_route.json")),
            )
            .expect(1)
            .mount(&server)
            .await;

        provider_for(server.uri())
            .calculate_route(&sacramento_waypoints(), &RouteOptions::default())
            .await
            .unwrap();
        server.verify().await;
    }

    #[tokio::test]
    async fn no_route_refusal_surfaces_provider_rejection_verbatim() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(400).set_body_json(fixture("no_route.json")))
            .mount(&server)
            .await;

        let error = provider_for(server.uri())
            .calculate_route(&sacramento_waypoints(), &RouteOptions::default())
            .await
            .unwrap_err();
        match error {
            SDKError::ProviderRequestRejected(message) => {
                assert_eq!(message, "Impossible route between points");
            }
            other => panic!("expected a provider rejection, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn http_server_failure_surfaces_network_failure() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(500).set_body_string("upstream failure"))
            .mount(&server)
            .await;

        let error = provider_for(server.uri())
            .calculate_route(&sacramento_waypoints(), &RouteOptions::default())
            .await
            .unwrap_err();
        match error {
            SDKError::NetworkRequestFailed(detail) => {
                assert!(detail.contains("500"), "detail was {detail}");
            }
            other => panic!("expected a network failure, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn malformed_body_surfaces_parsing_failure() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(200).set_body_string("not json"))
            .mount(&server)
            .await;

        let error = provider_for(server.uri())
            .calculate_route(&sacramento_waypoints(), &RouteOptions::default())
            .await
            .unwrap_err();
        assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
    }

    #[tokio::test]
    async fn empty_or_single_waypoint_lists_are_rejected_with_a_precise_detail() {
        let provider = provider_for("http://localhost:5000".to_string());
        let single_waypoint = [sacramento_waypoints()[0]];

        for waypoints in [Vec::new(), single_waypoint.to_vec()] {
            let error = provider
                .calculate_route(&waypoints, &RouteOptions::default())
                .await
                .unwrap_err();
            match error {
                SDKError::InvalidCoordinateInput(detail) => {
                    assert!(detail.contains("at least 2"), "detail was {detail}");
                }
                other => panic!("expected invalid coordinate input, got {other:?}"),
            }
        }
    }

    #[test]
    fn maneuver_mapping_table_covers_every_handled_osrm_type() {
        let table = [
            ("depart", None, None, ManeuverType::Departure),
            ("arrive", None, None, ManeuverType::Arrival),
            (
                "turn",
                Some("left"),
                None,
                ManeuverType::Turn(TurnDirection::Left),
            ),
            (
                "end of road",
                Some("right"),
                None,
                ManeuverType::Turn(TurnDirection::Right),
            ),
            (
                "continue",
                None,
                None,
                ManeuverType::Turn(TurnDirection::Straight),
            ),
            ("new name", None, None, ManeuverType::Continue),
            ("use lane", None, None, ManeuverType::Continue),
            ("notification", None, None, ManeuverType::Continue),
            ("merge", None, None, ManeuverType::Merge),
            ("on ramp", None, None, ManeuverType::OnRamp),
            ("off ramp", None, None, ManeuverType::OffRamp),
            ("fork", None, None, ManeuverType::Fork),
            ("roundabout", None, Some(3), ManeuverType::Roundabout(3)),
            ("rotary", None, Some(2), ManeuverType::Roundabout(2)),
            (
                "roundabout turn",
                None,
                Some(1),
                ManeuverType::Roundabout(1),
            ),
            (
                "exit roundabout",
                None,
                Some(4),
                ManeuverType::Roundabout(4),
            ),
            ("exit rotary", None, Some(5), ManeuverType::Roundabout(5)),
        ];
        for (maneuver_type, modifier, exit_index, expected) in table {
            assert_eq!(
                map_osrm_maneuver(maneuver_type, modifier, exit_index),
                expected,
                "OSRM type {maneuver_type:?} mapped incorrectly"
            );
        }
    }

    #[test]
    fn unknown_maneuver_types_and_modifiers_use_the_documented_fallbacks() {
        assert_eq!(
            map_osrm_maneuver("provider extension", None, None),
            ManeuverType::Continue
        );
        assert_eq!(
            map_osrm_maneuver("turn", Some("sideways"), None),
            ManeuverType::Continue,
            "an unrecognized turn modifier must not be guessed as a direction"
        );
        assert_eq!(
            map_osrm_maneuver("turn", None, None),
            ManeuverType::Continue
        );
        assert_eq!(
            map_osrm_maneuver("roundabout", None, None),
            ManeuverType::Roundabout(1)
        );
        assert_eq!(
            map_osrm_maneuver("roundabout", None, Some(0)),
            ManeuverType::Roundabout(1)
        );
    }

    #[test]
    fn turn_modifiers_map_to_every_contract_direction() {
        let table = [
            ("straight", TurnDirection::Straight),
            ("slight left", TurnDirection::SlightLeft),
            ("left", TurnDirection::Left),
            ("sharp left", TurnDirection::SharpLeft),
            ("slight right", TurnDirection::SlightRight),
            ("right", TurnDirection::Right),
            ("sharp right", TurnDirection::SharpRight),
            ("uturn", TurnDirection::UTurn),
            ("u-turn", TurnDirection::UTurn),
        ];
        for (modifier, expected) in table {
            assert_eq!(
                map_osrm_maneuver("turn", Some(modifier), None),
                ManeuverType::Turn(expected),
                "modifier {modifier:?} mapped incorrectly"
            );
        }
    }

    #[test]
    fn profile_segments_follow_the_transportation_mode() {
        assert_eq!(
            profile_path_segment(TransportationMode::Automobile),
            "driving"
        );
        assert_eq!(profile_path_segment(TransportationMode::Bicycle), "cycling");
        assert_eq!(
            profile_path_segment(TransportationMode::Pedestrian),
            "walking"
        );
    }

    #[test]
    fn avoidance_options_become_exclude_classes() {
        let mut route_options = RouteOptions::default();
        assert!(exclude_classes_text(&route_options.avoid_options).is_empty());

        route_options.avoid_options = AvoidOptions {
            toll_roads: true,
            limited_access_highways: true,
            ferries: true,
            unpaved_roads: true,
        };
        assert_eq!(
            exclude_classes_text(&route_options.avoid_options),
            "toll,motorway,ferry,unpaved"
        );
    }

    #[test]
    fn query_pairs_never_add_an_empty_exclude_value() {
        let route_options = RouteOptions::default();
        let names: Vec<String> = route_query_pairs(&route_options)
            .into_iter()
            .map(|(name, _)| name)
            .collect();
        assert_eq!(names, vec!["overview", "geometries", "steps"]);
    }

    #[test]
    fn strategy_and_units_do_not_change_the_request() {
        let fastest = RouteOptions {
            route_strategy: RouteStrategy::Fastest,
            unit_system: UnitSystem::Metric,
            ..RouteOptions::default()
        };
        let shortest_imperial = RouteOptions {
            route_strategy: RouteStrategy::Shortest,
            unit_system: UnitSystem::Imperial,
            ..RouteOptions::default()
        };
        assert_eq!(
            route_query_pairs(&fastest),
            route_query_pairs(&shortest_imperial)
        );
        assert_eq!(
            route_request_path(TransportationMode::Automobile, &sacramento_waypoints()),
            route_request_path(TransportationMode::Automobile, &sacramento_waypoints())
        );
    }

    #[test]
    fn instruction_text_is_authored_from_the_maneuver_and_road_name() {
        assert_eq!(
            instruction_text(&ManeuverType::Departure, ""),
            "Start navigation"
        );
        assert_eq!(
            instruction_text(&ManeuverType::Turn(TurnDirection::UTurn), "Capitol Mall"),
            "Make a U-turn onto Capitol Mall"
        );
        assert_eq!(instruction_text(&ManeuverType::Merge, ""), "Merge");
        assert_eq!(
            instruction_text(&ManeuverType::Roundabout(2), "L Street"),
            "Take exit 2 at the roundabout"
        );
    }

    #[test]
    fn payload_without_routes_is_a_parsing_failure() {
        let error = parse_route_payload(&serde_json::json!({"code": "Ok"})).unwrap_err();
        assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
    }

    #[test]
    fn empty_routes_array_is_a_parsing_failure() {
        let payload = serde_json::json!({"code": "Ok", "routes": []});
        let error = parse_route_payload(&payload).unwrap_err();
        assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
    }
}
