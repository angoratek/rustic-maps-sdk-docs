//! A provider-neutral raster-tile source driven by a `{z}/{x}/{y}` URL
//! template.
//!
//! [`UrlTemplateRasterTileProvider`] implements
//! [`geospatial_traits::RasterTileProvider`] for any web-mercator XYZ raster
//! tileset that publishes a URL template, with no vendor-specific code. The
//! template's authority, path layout and file extension all come from the
//! caller, so a base map is a template plus a
//! [`UrlTemplateRasterTileSource`], never a new provider crate.
//!
//! The family's single template validator and status vocabulary live in
//! `url-template-vector-provider`; this crate reuses both, so the two tile
//! contracts can never disagree about what a valid template is or how a
//! failed tile request classifies.

pub mod provider;

pub use provider::{UrlTemplateRasterTileProvider, UrlTemplateRasterTileSource};
