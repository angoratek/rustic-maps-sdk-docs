//! The provider-neutral, URL-template raster-tile source.
//!
//! One instance serves one raster tileset: the validated template turns tile
//! coordinates into request URLs, the source declaration names the tileset,
//! fixes the image format and resolution the tileset actually serves, and
//! carries the User-Agent a public tile service identifies its clients by.
//! Every fetch is paced by the shared token bucket and retried in bounds
//! through the shared transport.

use async_trait::async_trait;
use geospatial_traits::RasterTileProvider;
use geospatial_types::{RasterImageFormat, RasterTileData, RasterTileResolution, SDKError};
use provider_transport::{
    HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpMethod, HttpRequest, HttpResponse, HttpTransport,
    RetryPolicy, TokenBucketRateLimiter, execute_idempotent_get,
};
use std::sync::Arc;
use url_template_vector_provider::error_mapping::map_http_error_response_for_source;
use url_template_vector_provider::url_template::UrlTemplate;

/// Conservative default burst: a small batch of tiles starts immediately.
pub const DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS: f64 = 4.0;

/// Conservative default continuous refill rate, in tokens per second.
pub const DEFAULT_REFILL_TOKENS_PER_SECOND: f64 = 2.0;

/// Longest rate-limiter wait before a fetch is refused outright.
pub const DEFAULT_MAXIMUM_WAIT_SECONDS: u64 = 10;

/// Default retry budget for idempotent tile GETs.
pub const DEFAULT_MAXIMUM_RETRY_ATTEMPTS: u32 = 2;

/// Character cap on error bodies echoed into error strings, so a huge error
/// response cannot bloat the diagnostic text.
const MAXIMUM_ERROR_BODY_TAIL: usize = 256;

/// Highest zoom level whose full XYZ index range still fits a `u32`
/// (`2^zoom_level - 1 <= u32::MAX`); at deeper zooms every `u32` tile index
/// the contract carries is valid, so the index bound check does not apply.
const MAXIMUM_ZOOM_LEVEL_WITH_BOUNDED_TILE_INDICES: u8 = 32;

/// Request header naming the client to the tile service. Public tile
/// services identify their clients by it, and several usage policies refuse
/// clients that send nothing at all.
const USER_AGENT_HEADER_NAME: &str = "User-Agent";

/// What one URL-template raster source serves: the tileset's template, its
/// name for diagnostics, the zoom range it answers, the image format and
/// resolution its tiles actually arrive in, and the User-Agent its requests
/// carry.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UrlTemplateRasterTileSource {
    /// The `{z}/{x}/{y}` template the tileset publishes.
    pub url_template: String,
    /// The tileset's name, used verbatim in every diagnostic it raises.
    pub source_name: String,
    /// Lowest zoom level the tileset serves.
    pub minimum_zoom_level: u8,
    /// Highest zoom level the tileset serves.
    pub maximum_zoom_level: u8,
    /// The image format the tileset serves. Every fetched tile reports this
    /// format whatever the caller requested: the tile bytes are the truth,
    /// and the renderer decodes by the record it receives.
    pub image_format: RasterImageFormat,
    /// The resolution the tileset serves (the same caveat as the format).
    pub tile_resolution: RasterTileResolution,
    /// The `User-Agent` value every tile request sends. Empty sends no
    /// header, leaving the transport's default in place.
    pub user_agent: String,
}

/// Serves any web-mercator XYZ raster tileset that publishes a
/// `{z}/{x}/{y}` URL template.
pub struct UrlTemplateRasterTileProvider {
    url_template: UrlTemplate,
    source: UrlTemplateRasterTileSource,
    transport: Arc<dyn HttpTransport>,
    rate_limiter: TokenBucketRateLimiter,
    maximum_retry_attempts: u32,
}

impl UrlTemplateRasterTileProvider {
    /// Builds the source from its declaration and the transport every fetch
    /// executes through.
    ///
    /// The template is validated here — so a source is never constructed
    /// with a missing placeholder, an unsupported placeholder or a non-HTTP
    /// scheme — together with the source's own declaration: the name must be
    /// non-empty (it is the diagnostic's subject) and the zoom range must
    /// not be inverted.
    pub fn new(
        source: UrlTemplateRasterTileSource,
        transport: Arc<dyn HttpTransport>,
    ) -> Result<Self, SDKError> {
        if source.source_name.trim().is_empty() {
            return Err(SDKError::InvalidCoordinateInput(
                "the raster tile source name must be non-empty".to_string(),
            ));
        }
        if source.minimum_zoom_level > source.maximum_zoom_level {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "the {} raster tile source declares the inverted zoom range \
                 {}..={}",
                source.source_name, source.minimum_zoom_level, source.maximum_zoom_level
            )));
        }
        Ok(Self {
            url_template: UrlTemplate::new(source.url_template.clone())?,
            source,
            transport,
            rate_limiter: TokenBucketRateLimiter::new(
                DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS,
                DEFAULT_REFILL_TOKENS_PER_SECOND,
                DEFAULT_MAXIMUM_WAIT_SECONDS,
            )?,
            maximum_retry_attempts: DEFAULT_MAXIMUM_RETRY_ATTEMPTS,
        })
    }

    /// The declaration this instance serves.
    pub fn source(&self) -> &UrlTemplateRasterTileSource {
        &self.source
    }

    /// The noun every diagnostic of this source is phrased around.
    fn source_description(&self) -> String {
        format!("{} raster tile source", self.source.source_name)
    }

    /// Rejects tile coordinates the declared tileset cannot serve, before
    /// the rate limiter or the network is touched.
    fn validate_tile_coordinates(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
    ) -> Result<(), SDKError> {
        if zoom_level < self.source.minimum_zoom_level
            || zoom_level > self.source.maximum_zoom_level
        {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "zoom level {zoom_level} is outside the {}..={} range the {} declares",
                self.source.minimum_zoom_level,
                self.source.maximum_zoom_level,
                self.source_description()
            )));
        }
        if zoom_level < MAXIMUM_ZOOM_LEVEL_WITH_BOUNDED_TILE_INDICES {
            let maximum_tile_index = (1u32 << zoom_level) - 1;
            if tile_x > maximum_tile_index || tile_y > maximum_tile_index {
                return Err(SDKError::InvalidCoordinateInput(format!(
                    "tile x={tile_x} y={tile_y} exceeds the {maximum_tile_index} maximum at zoom \
                     {zoom_level}"
                )));
            }
        }
        Ok(())
    }

    /// The request headers every tile request carries: the source's
    /// User-Agent when it declares one.
    fn request_headers(&self) -> Vec<(String, String)> {
        if self.source.user_agent.trim().is_empty() {
            return Vec::new();
        }
        vec![(
            USER_AGENT_HEADER_NAME.to_string(),
            self.source.user_agent.clone(),
        )]
    }
}

#[async_trait]
impl RasterTileProvider for UrlTemplateRasterTileProvider {
    async fn fetch_raster_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
        _image_format: RasterImageFormat,
        _tile_resolution: RasterTileResolution,
    ) -> Result<RasterTileData, SDKError> {
        self.validate_tile_coordinates(tile_x, tile_y, zoom_level)?;
        self.rate_limiter.acquire().await?;
        let request = HttpRequest {
            method: HttpMethod::Get,
            url: self.url_template.expand(tile_x, tile_y, zoom_level),
            headers: self.request_headers(),
            body: None,
        };
        let source_description = self.source_description();
        let image_bytes = execute_idempotent_get(
            self.transport.as_ref(),
            &request,
            RetryPolicy::new(self.maximum_retry_attempts),
            |response| interpret_tile_response(&source_description, response),
        )
        .await?;
        Ok(RasterTileData {
            tile_x,
            tile_y,
            zoom_level,
            image_format: self.source.image_format,
            tile_resolution: self.source.tile_resolution,
            image_bytes,
        })
    }
}

/// Interprets one tile response: a non-success status maps through the
/// family's status vocabulary (with a bounded body tail for diagnostics),
/// anything else returns the raw image bytes.
fn interpret_tile_response(
    source_description: &str,
    response: HttpResponse,
) -> Result<Vec<u8>, SDKError> {
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        let response_body_tail = String::from_utf8_lossy(&response.body)
            .chars()
            .take(MAXIMUM_ERROR_BODY_TAIL)
            .collect::<String>();
        return Err(map_http_error_response_for_source(
            source_description,
            response.status_code,
            &response_body_tail,
        ));
    }
    Ok(response.body)
}

#[cfg(test)]
mod tests {
    use super::{DEFAULT_MAXIMUM_RETRY_ATTEMPTS, UrlTemplateRasterTileProvider};
    use super::{USER_AGENT_HEADER_NAME, UrlTemplateRasterTileSource};
    use async_trait::async_trait;
    use geospatial_traits::RasterTileProvider;
    use geospatial_types::{RasterImageFormat, RasterTileResolution, SDKError};
    use provider_transport::{
        HttpRequest, HttpResponse, HttpTransport, TransportError, is_transient_error,
    };
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// Transport that answers every request with a fixed status and body,
    /// records the requests it sees, and counts executions so a test can
    /// prove the retry budget exactly.
    struct FixedStatusTransport {
        status_code: u16,
        body: Vec<u8>,
        execution_count: AtomicUsize,
        recorded_headers: std::sync::Mutex<Vec<Vec<(String, String)>>>,
    }

    impl FixedStatusTransport {
        fn new(status_code: u16, body: Vec<u8>) -> Self {
            Self {
                status_code,
                body,
                execution_count: AtomicUsize::new(0),
                recorded_headers: std::sync::Mutex::new(Vec::new()),
            }
        }

        fn execution_count(&self) -> usize {
            self.execution_count.load(Ordering::SeqCst)
        }

        fn recorded_headers(&self) -> Vec<Vec<(String, String)>> {
            self.recorded_headers
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .clone()
        }
    }

    #[async_trait]
    impl HttpTransport for FixedStatusTransport {
        async fn execute(&self, request: HttpRequest) -> Result<HttpResponse, TransportError> {
            self.execution_count.fetch_add(1, Ordering::SeqCst);
            self.recorded_headers
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .push(request.headers.clone());
            Ok(HttpResponse {
                status_code: self.status_code,
                headers: Vec::new(),
                body: self.body.clone(),
            })
        }
    }

    /// Smallest plausible PNG envelope (the 8-byte signature).
    const SAMPLE_TILE_BYTES: [u8; 8] = [0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a];

    /// The User-Agent the sample source identifies itself with.
    const SAMPLE_USER_AGENT: &str = "RusticMapsTest/1.0 (+https://example.test)";

    fn source() -> UrlTemplateRasterTileSource {
        UrlTemplateRasterTileSource {
            url_template: "http://localhost.test/{z}/{x}/{y}.png".to_string(),
            source_name: "test/url-template".to_string(),
            minimum_zoom_level: 0,
            maximum_zoom_level: 15,
            image_format: RasterImageFormat::Png,
            tile_resolution: RasterTileResolution::Standard,
            user_agent: SAMPLE_USER_AGENT.to_string(),
        }
    }

    fn provider_with_transport(
        transport: Arc<FixedStatusTransport>,
    ) -> UrlTemplateRasterTileProvider {
        UrlTemplateRasterTileProvider::new(source(), transport).expect("the sample source is valid")
    }

    #[test]
    fn the_declaration_is_returned_verbatim() {
        let provider = provider_with_transport(Arc::new(FixedStatusTransport::new(
            200,
            SAMPLE_TILE_BYTES.to_vec(),
        )));
        assert_eq!(provider.source(), &source());
    }

    #[tokio::test]
    async fn fetches_and_reports_the_declared_format_and_resolution() {
        let provider = provider_with_transport(Arc::new(FixedStatusTransport::new(
            200,
            SAMPLE_TILE_BYTES.to_vec(),
        )));
        // A caller asking for the other format and resolution still receives
        // the tileset's own declaration: the bytes are the truth.
        let tile = provider
            .fetch_raster_tile(
                2,
                1,
                3,
                RasterImageFormat::Jpeg,
                RasterTileResolution::Retina,
            )
            .await
            .unwrap();
        assert_eq!(tile.tile_x, 2);
        assert_eq!(tile.tile_y, 1);
        assert_eq!(tile.zoom_level, 3);
        assert_eq!(tile.image_format, RasterImageFormat::Png);
        assert_eq!(tile.tile_resolution, RasterTileResolution::Standard);
        assert_eq!(tile.image_bytes, SAMPLE_TILE_BYTES.to_vec());
    }

    #[tokio::test]
    async fn every_fetch_carries_the_declared_user_agent() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        provider
            .fetch_raster_tile(
                2,
                1,
                3,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .unwrap();
        assert_eq!(
            transport.recorded_headers(),
            vec![vec![(
                USER_AGENT_HEADER_NAME.to_string(),
                SAMPLE_USER_AGENT.to_string()
            )]]
        );
    }

    #[tokio::test]
    async fn a_blank_user_agent_sends_no_header() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider_transport: Arc<dyn HttpTransport> = transport.clone();
        let provider = UrlTemplateRasterTileProvider::new(
            UrlTemplateRasterTileSource {
                user_agent: String::new(),
                ..source()
            },
            provider_transport,
        )
        .expect("a source without a user agent is valid");
        provider
            .fetch_raster_tile(
                2,
                1,
                3,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .unwrap();
        assert_eq!(transport.recorded_headers(), vec![Vec::new()]);
    }

    #[tokio::test]
    async fn zoom_outside_the_declared_bounds_is_rejected_without_a_request() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        assert!(matches!(
            provider
                .fetch_raster_tile(
                    0,
                    0,
                    source().maximum_zoom_level + 1,
                    RasterImageFormat::Png,
                    RasterTileResolution::Standard
                )
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));

        let floor_transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let floor_provider = UrlTemplateRasterTileProvider::new(
            UrlTemplateRasterTileSource {
                minimum_zoom_level: 3,
                ..source()
            },
            floor_transport.clone(),
        )
        .expect("the sample source is valid");
        assert!(matches!(
            floor_provider
                .fetch_raster_tile(
                    0,
                    0,
                    2,
                    RasterImageFormat::Png,
                    RasterTileResolution::Standard
                )
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));

        assert_eq!(transport.execution_count(), 0);
        assert_eq!(floor_transport.execution_count(), 0);
    }

    #[tokio::test]
    async fn tile_indexes_outside_the_zoom_range_are_rejected_without_a_request() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        // At zoom 3 only 0..=7 indexes exist; 8 is out of range.
        assert!(matches!(
            provider
                .fetch_raster_tile(
                    8,
                    1,
                    3,
                    RasterImageFormat::Png,
                    RasterTileResolution::Standard
                )
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        assert!(matches!(
            provider
                .fetch_raster_tile(
                    1,
                    8,
                    3,
                    RasterImageFormat::Png,
                    RasterTileResolution::Standard
                )
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        assert_eq!(transport.execution_count(), 0);
    }

    #[tokio::test]
    async fn repeated_server_errors_stop_at_the_retry_budget() {
        let transport = Arc::new(FixedStatusTransport::new(503, b"overloaded".to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        let error = provider
            .fetch_raster_tile(
                2,
                1,
                3,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .unwrap_err();
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
        assert!(is_transient_error(&error));
        assert_eq!(
            transport.execution_count(),
            (DEFAULT_MAXIMUM_RETRY_ATTEMPTS + 1) as usize
        );
    }

    #[tokio::test]
    async fn client_error_surfaces_without_retrying_and_names_the_source() {
        let transport = Arc::new(FixedStatusTransport::new(404, b"not found".to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        let error = provider
            .fetch_raster_tile(
                2,
                1,
                3,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .unwrap_err();
        match error {
            SDKError::ProviderRequestRejected(detail) => {
                assert!(detail.contains("test/url-template raster tile source returned HTTP 404"));
            }
            other => panic!("expected a provider rejection, got {other:?}"),
        }
        assert_eq!(transport.execution_count(), 1);
    }

    #[test]
    fn invalid_template_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        assert!(matches!(
            UrlTemplateRasterTileProvider::new(
                UrlTemplateRasterTileSource {
                    url_template: "http://localhost.test/{x}/{y}.png".to_string(),
                    ..source()
                },
                transport,
            ),
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }

    #[test]
    fn a_blank_source_name_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        assert!(matches!(
            UrlTemplateRasterTileProvider::new(
                UrlTemplateRasterTileSource {
                    source_name: "  ".to_string(),
                    ..source()
                },
                transport,
            ),
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }

    #[test]
    fn an_inverted_zoom_range_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        assert!(matches!(
            UrlTemplateRasterTileProvider::new(
                UrlTemplateRasterTileSource {
                    minimum_zoom_level: 12,
                    maximum_zoom_level: 8,
                    ..source()
                },
                transport,
            ),
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }
}
