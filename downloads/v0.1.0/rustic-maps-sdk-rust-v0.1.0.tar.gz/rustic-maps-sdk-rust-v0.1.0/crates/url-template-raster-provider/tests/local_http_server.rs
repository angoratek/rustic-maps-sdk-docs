//! End-to-end tests for the URL-template raster source against a local
//! `std::net::TcpListener` HTTP server.
//!
//! The server replays a scripted list of responses in order and records the
//! request line and header block of every connection, so the tests prove the
//! real fetch, the declared User-Agent surviving the transport, the status
//! mapping and the transient retry path without touching the network.

use geospatial_traits::RasterTileProvider;
use geospatial_types::{RasterImageFormat, RasterTileResolution, SDKError};
use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use url_template_raster_provider::{UrlTemplateRasterTileProvider, UrlTemplateRasterTileSource};

/// Smallest plausible PNG envelope (the 8-byte signature).
const SAMPLE_TILE_BYTES: [u8; 8] = [0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a];

/// HTTP status the scripted server returns for a successful tile.
const HTTP_OK_STATUS: u16 = 200;

/// HTTP status the scripted server returns for a missing tile.
const HTTP_NOT_FOUND_STATUS: u16 = 404;

/// HTTP status the scripted server returns for a transient failure.
const HTTP_SERVICE_UNAVAILABLE_STATUS: u16 = 503;

/// The User-Agent the sample source declares.
const SAMPLE_USER_AGENT: &str = "RusticMapsTest/1.0 (+https://example.test)";

/// One request the scripted server received.
#[derive(Debug, Clone, PartialEq, Eq)]
struct RecordedRequest {
    path: String,
    user_agent: Option<String>,
}

/// One response the scripted server writes, then closes the connection.
struct ScriptedHttpResponse {
    status_code: u16,
    body: Vec<u8>,
}

/// A local HTTP server bound to an ephemeral loopback port.
struct ScriptedHttpServer {
    base_url: String,
    recorded_requests: Arc<Mutex<Vec<RecordedRequest>>>,
}

impl ScriptedHttpServer {
    /// Starts a server answering one connection per scripted response.
    fn start(scripted_responses: Vec<ScriptedHttpResponse>) -> Self {
        let listener =
            TcpListener::bind("127.0.0.1:0").expect("the local test server must bind loopback");
        let bound_address = listener
            .local_addr()
            .expect("the bound address must be readable");
        let recorded_requests = Arc::new(Mutex::new(Vec::new()));
        let recorded_by_thread = Arc::clone(&recorded_requests);
        thread::spawn(move || {
            for scripted_response in scripted_responses {
                let Ok((stream, _peer_address)) = listener.accept() else {
                    break;
                };
                let recorded_request = read_request(&stream);
                recorded_by_thread
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner())
                    .push(recorded_request);
                write_response(stream, scripted_response);
            }
        });
        Self {
            base_url: format!("http://{bound_address}"),
            recorded_requests,
        }
    }

    /// The requests the server received, in arrival order.
    fn recorded_requests(&self) -> Vec<RecordedRequest> {
        self.recorded_requests
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
    }
}

/// Reads the request line and the `User-Agent` header, draining the block.
fn read_request(stream: &TcpStream) -> RecordedRequest {
    let mut reader = BufReader::new(
        stream
            .try_clone()
            .expect("the test server must clone its stream"),
    );
    let mut request_line = String::new();
    reader
        .read_line(&mut request_line)
        .expect("the request line must be readable");
    let path = request_line
        .split_whitespace()
        .nth(1)
        .unwrap_or_default()
        .to_string();
    let mut user_agent = None;
    let mut header_line = String::new();
    loop {
        header_line.clear();
        let bytes_read = reader
            .read_line(&mut header_line)
            .expect("the header block must be readable");
        if bytes_read == 0 || header_line == "\r\n" || header_line == "\n" {
            break;
        }
        if let Some(header_value) = header_line.strip_prefix("user-agent:") {
            user_agent = Some(header_value.trim().to_string());
        }
    }
    RecordedRequest { path, user_agent }
}

/// Writes one HTTP/1.1 response and lets the stream close.
fn write_response(mut stream: TcpStream, scripted_response: ScriptedHttpResponse) {
    let reason_phrase = match scripted_response.status_code {
        HTTP_OK_STATUS => "OK",
        HTTP_NOT_FOUND_STATUS => "Not Found",
        HTTP_SERVICE_UNAVAILABLE_STATUS => "Service Unavailable",
        _ => "Unknown",
    };
    let response_head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: image/png\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        scripted_response.status_code,
        reason_phrase,
        scripted_response.body.len()
    );
    stream
        .write_all(response_head.as_bytes())
        .expect("the response head must be writable");
    stream
        .write_all(&scripted_response.body)
        .expect("the response body must be writable");
    stream.flush().expect("the response must flush");
}

/// Builds a provider whose template points at the scripted server.
fn provider_for(server: &ScriptedHttpServer) -> UrlTemplateRasterTileProvider {
    UrlTemplateRasterTileProvider::new(
        UrlTemplateRasterTileSource {
            url_template: format!("{}/tiles/{{z}}/{{x}}/{{y}}.png", server.base_url),
            source_name: "test/local-template".to_string(),
            minimum_zoom_level: 0,
            maximum_zoom_level: 19,
            image_format: RasterImageFormat::Png,
            tile_resolution: RasterTileResolution::Standard,
            user_agent: SAMPLE_USER_AGENT.to_string(),
        },
        Arc::new(
            provider_transport::ReqwestTransport::new().expect("the test transport must build"),
        ),
    )
    .expect("the scripted source is valid")
}

/// One tile request at the format and resolution the renderer asks for.
async fn fetch_sample_tile(
    provider: &UrlTemplateRasterTileProvider,
) -> Result<geospatial_types::RasterTileData, SDKError> {
    provider
        .fetch_raster_tile(
            2,
            1,
            3,
            RasterImageFormat::Png,
            RasterTileResolution::Standard,
        )
        .await
}

#[tokio::test]
async fn fetches_a_tile_from_the_expanded_template_with_the_declared_user_agent() {
    let server = ScriptedHttpServer::start(vec![ScriptedHttpResponse {
        status_code: HTTP_OK_STATUS,
        body: SAMPLE_TILE_BYTES.to_vec(),
    }]);
    let provider = provider_for(&server);

    let tile = fetch_sample_tile(&provider).await.unwrap();

    assert_eq!(tile.tile_x, 2);
    assert_eq!(tile.tile_y, 1);
    assert_eq!(tile.zoom_level, 3);
    assert_eq!(tile.image_bytes, SAMPLE_TILE_BYTES.to_vec());
    assert_eq!(
        server.recorded_requests(),
        vec![RecordedRequest {
            path: "/tiles/3/2/1.png".to_string(),
            user_agent: Some(SAMPLE_USER_AGENT.to_string()),
        }]
    );
}

#[tokio::test]
async fn not_found_maps_to_a_provider_rejection() {
    let server = ScriptedHttpServer::start(vec![ScriptedHttpResponse {
        status_code: HTTP_NOT_FOUND_STATUS,
        body: b"tile not found".to_vec(),
    }]);
    let provider = provider_for(&server);

    let error = fetch_sample_tile(&provider).await.unwrap_err();

    assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    assert_eq!(server.recorded_requests().len(), 1);
}

#[tokio::test]
async fn transient_server_error_retries_until_success() {
    let server = ScriptedHttpServer::start(vec![
        ScriptedHttpResponse {
            status_code: HTTP_SERVICE_UNAVAILABLE_STATUS,
            body: b"overloaded".to_vec(),
        },
        ScriptedHttpResponse {
            status_code: HTTP_OK_STATUS,
            body: SAMPLE_TILE_BYTES.to_vec(),
        },
    ]);
    let provider = provider_for(&server);

    let tile = fetch_sample_tile(&provider).await.unwrap();

    assert_eq!(tile.image_bytes, SAMPLE_TILE_BYTES.to_vec());
    assert_eq!(
        server
            .recorded_requests()
            .iter()
            .map(|recorded_request| recorded_request.path.as_str())
            .collect::<Vec<_>>(),
        vec!["/tiles/3/2/1.png", "/tiles/3/2/1.png"]
    );
}
