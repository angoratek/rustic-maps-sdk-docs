//! HTTP transport for the Valhalla `/route` endpoint.
//!
//! Valhalla's routing request is a JSON POST, so this client uses the shared
//! [`provider_transport`] seam directly rather than the idempotent-GET retry
//! helper: a route POST is not retried, because a retry could ask the server
//! to calculate the same route twice. The same request code runs natively
//! (through `reqwest`) and in the browser (through `fetch`).
//!
//! The client is keyless by design; Valhalla is self-hosted and authenticates
//! at the network layer when the operator requires it.

use crate::error_mapping::interpret_route_response;
use geospatial_types::SDKError;
use provider_transport::{HttpMethod, HttpRequest, HttpTransport, default_transport};
use std::sync::Arc;
use url::Url;

/// Default base URL of a locally running Valhalla server; the reference
/// container publishes its HTTP service on this port.
pub const VALHALLA_DEFAULT_BASE_URL: &str = "http://localhost:8002";

/// Path of the route calculation endpoint below the configured base URL.
const VALHALLA_ROUTE_PATH: &str = "route";

/// Header carrying the request body's media type.
const CONTENT_TYPE_HEADER_NAME: &str = "content-type";

/// Media type of every Valhalla route request.
const CONTENT_TYPE_JSON_VALUE: &str = "application/json";

/// Header identifying the calling application to the server.
const USER_AGENT_HEADER_NAME: &str = "user-agent";

/// Low-level JSON client against one Valhalla base URL.
pub(crate) struct ValhallaHttpClient {
    route_endpoint: Url,
    user_agent: String,
    transport: Arc<dyn HttpTransport>,
}

impl ValhallaHttpClient {
    /// Builds a client for `{base_url}/route` on the target's default
    /// transport.
    ///
    /// # Parameters
    /// - `base_url` — the server root, with or without its trailing slash.
    /// - `user_agent` — the value every request sends in `User-Agent`.
    ///
    /// # Returns
    /// A client ready to calculate routes.
    ///
    /// # Errors
    /// Returns [`SDKError::NetworkRequestFailed`] when the base URL cannot be
    /// parsed or the target has no usable transport.
    pub(crate) fn new(base_url: &str, user_agent: String) -> Result<Self, SDKError> {
        let route_endpoint = Url::parse(&format!(
            "{}/{VALHALLA_ROUTE_PATH}",
            base_url.trim_end_matches('/')
        ))
        .map_err(|error| {
            SDKError::NetworkRequestFailed(format!("invalid Valhalla base URL: {error}"))
        })?;
        Ok(Self {
            route_endpoint,
            user_agent,
            transport: default_transport()?,
        })
    }

    /// Posts one route request and returns the decoded JSON response.
    ///
    /// # Parameters
    /// - `request_body` — the Valhalla route request object.
    ///
    /// # Returns
    /// The JSON object the server answered with; the caller validates its
    /// shape.
    ///
    /// # Errors
    /// Returns [`SDKError::ResponseParsingFailure`] when the request cannot
    /// be serialized or the response cannot be interpreted,
    /// [`SDKError::NetworkRequestFailed`] for transport and server failures,
    /// and [`SDKError::ProviderRequestRejected`] for a documented Valhalla
    /// refusal.
    pub(crate) async fn post_route(
        &self,
        request_body: &serde_json::Value,
    ) -> Result<serde_json::Value, SDKError> {
        let body = serde_json::to_vec(request_body).map_err(|error| {
            SDKError::ResponseParsingFailure(format!(
                "Valhalla route request could not be encoded: {error}"
            ))
        })?;
        let request = HttpRequest {
            method: HttpMethod::Post,
            url: self.route_endpoint.to_string(),
            headers: vec![
                (
                    CONTENT_TYPE_HEADER_NAME.to_string(),
                    CONTENT_TYPE_JSON_VALUE.to_string(),
                ),
                (USER_AGENT_HEADER_NAME.to_string(), self.user_agent.clone()),
            ],
            body: Some(body),
        };
        let response = self
            .transport
            .execute(request)
            .await
            .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
        interpret_route_response(response)
    }
}
