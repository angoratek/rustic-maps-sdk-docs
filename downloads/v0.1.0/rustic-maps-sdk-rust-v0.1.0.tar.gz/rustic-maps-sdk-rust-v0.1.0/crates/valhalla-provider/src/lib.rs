//! Valhalla route calculation for the Maps SDK.
//!
//! [Valhalla](https://valhalla.github.io/valhalla/) is a self-hosted,
//! keyless routing engine. This crate implements
//! [`geospatial_traits::RoutingProvider`] against its HTTP `/route` endpoint:
//! ordered waypoints and vendor-neutral [`geospatial_types::route::RouteOptions`]
//! go in, and a normalized [`geospatial_types::route::RouteData`] with legs,
//! turn-by-turn steps and the decoded geometry comes out.
//!
//! # Configuration
//!
//! [`ValhallaProviderConfiguration`] carries the operator's server base URL
//! and the `User-Agent` the server sees. The default targets the port the
//! reference Valhalla container publishes, so a locally running server works
//! without configuration.
//!
//! ```no_run
//! use valhalla_provider::{ValhallaProviderConfiguration, ValhallaRoutingProvider};
//!
//! # fn main() -> Result<(), geospatial_types::SDKError> {
//! let provider = ValhallaRoutingProvider::new(ValhallaProviderConfiguration::default())?;
//! # let _ = provider;
//! # Ok(())
//! # }
//! ```
//!
//! # Request and response
//!
//! Requests are JSON POSTs to `{base_url}/route`. Every leg shape is a
//! precision-6 encoded polyline decoded inside the crate; maneuver `type`
//! integers map onto [`geospatial_types::route::ManeuverType`] through a
//! total classification table. All distances are normalized to meters and
//! durations to seconds.
//!
//! # Failure channels
//!
//! Transport failures surface as [`geospatial_types::SDKError::NetworkRequestFailed`],
//! a body that is not a usable Valhalla trip as
//! [`geospatial_types::SDKError::ResponseParsingFailure`], and a documented
//! Valhalla `error` refusal as
//! [`geospatial_types::SDKError::ProviderRequestRejected`] carrying the
//! provider's message verbatim.

mod error_mapping;
mod http;
mod maneuver_mapping;
mod polyline;
mod routing;

pub use http::VALHALLA_DEFAULT_BASE_URL;
pub use routing::{ValhallaProviderConfiguration, ValhallaRoutingProvider};
