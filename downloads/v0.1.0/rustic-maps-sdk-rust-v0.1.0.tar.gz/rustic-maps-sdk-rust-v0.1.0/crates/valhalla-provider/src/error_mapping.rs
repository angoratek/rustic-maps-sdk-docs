//! Mapping between Valhalla service signals and the SDK error model.
//!
//! Valhalla reports a refusal as a non-success HTTP status whose JSON body
//! carries an `error_code` and a human-readable `error`. Three failure
//! channels are distinguished here:
//!
//! 1. HTTP 5xx — the server itself is unavailable, which is a transport
//!    failure in the SDK model.
//! 2. HTTP 429 — the server is throttling callers.
//! 3. Every other non-success status — the request was understood and
//!    refused, so the provider's `error` message (or, when the body is not a
//!    Valhalla error object, the status and body) is surfaced verbatim as
//!    [`SDKError::ProviderRequestRejected`].
//!
//! A success status still surfaces a body that carries an `error` message,
//! because some Valhalla deployments answer with a 200 envelope.

use geospatial_types::SDKError;
use provider_transport::{HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpResponse};
use serde_json::Value;

/// HTTP status the server uses to throttle callers.
const HTTP_TOO_MANY_REQUESTS_STATUS: u16 = 429;

/// First HTTP status that signals a server-side outage.
const HTTP_SERVER_ERROR_STATUS_THRESHOLD: u16 = 500;

/// Interprets one `/route` response, yielding the decoded JSON object or a
/// typed SDK error.
///
/// # Parameters
/// - `response` — the status, headers and body returned by the transport.
///
/// # Returns
/// The parsed JSON body for a usable success response.
///
/// # Errors
/// - [`SDKError::RateLimitExhausted`] for HTTP 429.
/// - [`SDKError::NetworkRequestFailed`] for HTTP 5xx.
/// - [`SDKError::ProviderRequestRejected`] for any other non-success status,
///   or for a success body carrying Valhalla's `error` message.
/// - [`SDKError::ResponseParsingFailure`] when a success body is not JSON.
pub(crate) fn interpret_route_response(response: HttpResponse) -> Result<Value, SDKError> {
    let response_body_text = String::from_utf8_lossy(&response.body);
    if response.status_code == HTTP_TOO_MANY_REQUESTS_STATUS {
        return Err(SDKError::RateLimitExhausted);
    }
    if response.status_code >= HTTP_SERVER_ERROR_STATUS_THRESHOLD {
        return Err(SDKError::NetworkRequestFailed(format!(
            "Valhalla server unavailable (HTTP {}): {response_body_text}",
            response.status_code
        )));
    }
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        return Err(map_error_response(
            response.status_code,
            &response_body_text,
        ));
    }
    let payload: Value = serde_json::from_slice(&response.body).map_err(|error| {
        SDKError::ResponseParsingFailure(format!("Valhalla response is not valid JSON: {error}"))
    })?;
    if let Some(error_message) = payload.get("error").and_then(Value::as_str) {
        return Err(SDKError::ProviderRequestRejected(error_message.to_string()));
    }
    Ok(payload)
}

/// Translates a non-success HTTP response into a typed SDK error, preferring
/// Valhalla's own `error` text.
///
/// # Parameters
/// - `status_code` — the HTTP status returned by the server.
/// - `response_body_text` — the decoded body; when it is a Valhalla error
///   object, its `error` field is surfaced unchanged.
///
/// # Returns
/// [`SDKError::ProviderRequestRejected`] carrying the provider's message
/// verbatim, or the status and body when no Valhalla message is present.
fn map_error_response(status_code: u16, response_body_text: &str) -> SDKError {
    if let Ok(payload) = serde_json::from_str::<Value>(response_body_text) {
        if let Some(error_message) = payload.get("error").and_then(Value::as_str) {
            return SDKError::ProviderRequestRejected(error_message.to_string());
        }
        if let Some(error_code) = payload.get("error_code") {
            return SDKError::ProviderRequestRejected(format!("Valhalla error_code {error_code}"));
        }
    }
    SDKError::ProviderRequestRejected(format!(
        "Valhalla returned HTTP {status_code}: {response_body_text}"
    ))
}

#[cfg(test)]
mod tests {
    use super::interpret_route_response;
    use geospatial_types::SDKError;
    use provider_transport::HttpResponse;

    fn response(status_code: u16, body: &str) -> HttpResponse {
        HttpResponse {
            status_code,
            headers: Vec::new(),
            body: body.as_bytes().to_vec(),
        }
    }

    #[test]
    fn valhalla_error_message_is_surfaced_verbatim() {
        let error = interpret_route_response(response(
            400,
            r#"{"error_code":440,"error":"No route found between origin and destination","status_code":400,"status":"Bad Request"}"#,
        ))
        .expect_err("a refusal must surface");
        assert_eq!(
            error,
            SDKError::ProviderRequestRejected(
                "No route found between origin and destination".to_string()
            )
        );
    }

    #[test]
    fn error_code_without_a_message_keeps_the_code() {
        let error = interpret_route_response(response(400, r#"{"error_code":120}"#))
            .expect_err("a refusal must surface");
        assert_eq!(
            error,
            SDKError::ProviderRequestRejected("Valhalla error_code 120".to_string())
        );
    }

    #[test]
    fn non_json_refusal_keeps_the_status_and_body() {
        let error = interpret_route_response(response(404, "Not Found"))
            .expect_err("a refusal must surface");
        assert_eq!(
            error,
            SDKError::ProviderRequestRejected("Valhalla returned HTTP 404: Not Found".to_string())
        );
    }

    #[test]
    fn server_errors_are_network_failures() {
        let error =
            interpret_route_response(response(500, "boom")).expect_err("an outage must surface");
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
    }

    #[test]
    fn throttling_is_rate_limit_exhaustion() {
        assert_eq!(
            interpret_route_response(response(429, "")).expect_err("throttling must surface"),
            SDKError::RateLimitExhausted
        );
    }

    #[test]
    fn a_success_body_that_is_not_json_is_a_parsing_failure() {
        assert!(matches!(
            interpret_route_response(response(200, "not json")),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }

    #[test]
    fn a_success_body_with_an_error_message_is_a_refusal() {
        let error = interpret_route_response(response(
            200,
            r#"{"error_code":440,"error":"No route found between origin and destination"}"#,
        ))
        .expect_err("a refusal must surface");
        assert_eq!(
            error,
            SDKError::ProviderRequestRejected(
                "No route found between origin and destination".to_string()
            )
        );
    }

    #[test]
    fn a_success_body_passes_through() {
        let payload = interpret_route_response(response(200, r#"{"trip":{"status":0}}"#))
            .expect("a trip body is valid");
        assert_eq!(payload["trip"]["status"], 0);
    }
}
