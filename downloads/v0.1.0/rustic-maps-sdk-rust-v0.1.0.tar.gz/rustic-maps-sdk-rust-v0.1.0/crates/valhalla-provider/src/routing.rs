//! Valhalla route calculation: request encoding, response parsing and the
//! [`RoutingProvider`] implementation.
//!
//! Valhalla is a self-hosted routing engine. Its `/route` endpoint accepts a
//! JSON POST and answers with a `trip` object whose legs carry maneuvers,
//! summaries and precision-6 encoded shapes. This module maps the
//! vendor-neutral [`RouteOptions`] onto Valhalla's `costing` vocabulary and
//! normalizes every distance to meters and every duration to seconds for
//! [`RouteData`].
//!
//! # Options Valhalla expresses differently
//!
//! - **Units.** Requests always ask for kilometers, and the parser converts
//!   the answer to meters. [`RouteOptions::unit_system`] therefore changes no
//!   wire value; it is a display convention the presentation layer applies.
//! - **Avoidance.** [`AvoidOptions::toll_roads`] and
//!   [`AvoidOptions::limited_access_highways`] become the automobile cost
//!   factors `use_tolls` and `use_highways`. Valhalla's pedestrian and
//!   bicycle costing have no equivalent, so those two flags change nothing
//!   in those modes. [`AvoidOptions::unpaved_roads`] becomes `use_tracks` for
//!   automobile and bicycle; pedestrian costing has no unpaved-road factor.
//!   [`AvoidOptions::ferries`] becomes `use_ferry` in every mode. The route
//!   contract carries no avoid-area geometry, so Valhalla's
//!   `exclude_polygons` is never sent.
//! - **Strategy.** [`RouteStrategy::Shortest`] sets the automobile `shortest`
//!   cost factor. Non-automobile costing has no time-versus-distance choice,
//!   which matches [`RouteStrategy`]'s own description.
//! - **Departure time.** [`RouteOptions::departure_timestamp_seconds`] is not
//!   forwarded. Valhalla's `date_time` expects an ISO-8601 date-time and
//!   converting a Unix instant requires the routing time zone, which the
//!   route contract does not carry.
//! - **Lane guidance.** This crate does not map Valhalla's lane records onto
//!   the contract's [`LaneGuidance`] vocabulary, so every step's lane list is
//!   empty.

use crate::http::ValhallaHttpClient;
use crate::maneuver_mapping::map_valhalla_maneuver_type;
use crate::polyline::decode_polyline6;
use async_trait::async_trait;
use geospatial_traits::RoutingProvider;
use geospatial_types::route::{
    AvoidOptions, LaneGuidance, RouteData, RouteLeg, RouteOptions, RouteStep, RouteStrategy,
    TransportationMode,
};
use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};
use serde::Deserialize;
use serde_json::Value;

/// Smallest number of waypoints a route can connect.
const MINIMUM_ROUTE_WAYPOINT_COUNT: usize = 2;

/// Conversion factor from the kilometers Valhalla reports to the meters the
/// contract carries.
const KILOMETERS_TO_METERS: f64 = 1_000.0;

/// Unit system every request asks Valhalla to report.
const VALHALLA_UNITS_KILOMETERS: &str = "kilometers";

/// Valhalla costing for private car routing.
const COSTING_AUTOMOBILE: &str = "auto";

/// Valhalla costing for bicycle routing.
const COSTING_BICYCLE: &str = "bicycle";

/// Valhalla costing for walking routing.
const COSTING_PEDESTRIAN: &str = "pedestrian";

/// Automobile cost factor selecting the shortest path rather than the
/// fastest one.
const COSTING_OPTION_SHORTEST: &str = "shortest";

/// Cost factor discouraging toll roads.
const COSTING_OPTION_USE_TOLLS: &str = "use_tolls";

/// Cost factor discouraging limited-access highways.
const COSTING_OPTION_USE_HIGHWAYS: &str = "use_highways";

/// Cost factor discouraging ferry crossings.
const COSTING_OPTION_USE_FERRY: &str = "use_ferry";

/// Cost factor discouraging unpaved tracks.
const COSTING_OPTION_USE_TRACKS: &str = "use_tracks";

/// Cost factor value that fully disallows a feature when the costing model
/// allows it.
const COSTING_FACTOR_DISALLOW: f64 = 0.0;

/// Default `User-Agent` sent to the Valhalla server.
const VALHALLA_DEFAULT_USER_AGENT: &str = concat!("rustic-maps-sdk/", env!("CARGO_PKG_VERSION"));

/// Configuration for [`ValhallaRoutingProvider`].
///
/// Valhalla is keyless; the operator supplies the address of their own
/// server and the application name the server logs.
#[derive(Debug, Clone)]
pub struct ValhallaProviderConfiguration {
    /// Server root such as `http://localhost:8002`. The `/route` path is
    /// appended to it.
    pub base_url: String,
    /// Value every request sends in the `User-Agent` header.
    pub user_agent: String,
}

impl Default for ValhallaProviderConfiguration {
    /// Configuration for the reference Valhalla container on the local host.
    fn default() -> Self {
        Self {
            base_url: crate::VALHALLA_DEFAULT_BASE_URL.to_string(),
            user_agent: VALHALLA_DEFAULT_USER_AGENT.to_string(),
        }
    }
}

/// Routing through a Valhalla server's `/route` endpoint.
pub struct ValhallaRoutingProvider {
    http_client: ValhallaHttpClient,
}

impl ValhallaRoutingProvider {
    /// Builds a provider from its configuration.
    ///
    /// # Parameters
    /// - `configuration` — the server base URL and user agent.
    ///
    /// # Returns
    /// A provider registered under `RoutingProvider`.
    ///
    /// # Errors
    /// Returns [`SDKError::NetworkRequestFailed`] when the base URL cannot be
    /// parsed or the target has no usable HTTP transport.
    pub fn new(configuration: ValhallaProviderConfiguration) -> Result<Self, SDKError> {
        Ok(Self {
            http_client: ValhallaHttpClient::new(
                &configuration.base_url,
                configuration.user_agent,
            )?,
        })
    }
}

#[async_trait]
impl RoutingProvider for ValhallaRoutingProvider {
    /// Calculates a route through the ordered waypoints.
    ///
    /// # Parameters
    /// - `waypoints` — at least two ordered stops; consecutive pairs form
    ///   the returned legs.
    /// - `route_options` — transport mode, optimization strategy, units and
    ///   features to avoid, mapped as described in the module documentation.
    ///
    /// # Returns
    /// A route whose distances are meters, whose durations are seconds, and
    /// whose bounding box encloses the decoded geometry.
    ///
    /// # Errors
    /// Returns [`SDKError::InvalidCoordinateInput`] for fewer than two
    /// waypoints, [`SDKError::NetworkRequestFailed`] when the server cannot
    /// be reached or fails, [`SDKError::ResponseParsingFailure`] when the
    /// answer is not a usable trip, and [`SDKError::ProviderRequestRejected`]
    /// when Valhalla refuses the request.
    async fn calculate_route(
        &self,
        waypoints: &[GeographicCoordinate],
        route_options: &RouteOptions,
    ) -> Result<RouteData, SDKError> {
        if waypoints.len() < MINIMUM_ROUTE_WAYPOINT_COUNT {
            return Err(SDKError::InvalidCoordinateInput(
                "a Valhalla route needs at least two waypoints".to_string(),
            ));
        }
        let request_body = build_route_request_body(waypoints, route_options)?;
        let payload = self.http_client.post_route(&request_body).await?;
        parse_route_payload(&payload)
    }
}

/// One location in a Valhalla request; latitude precedes longitude.
#[derive(Debug, serde::Serialize)]
struct ValhallaLocation {
    /// Latitude in decimal degrees.
    lat: f64,
    /// Longitude in decimal degrees.
    lon: f64,
}

/// The `directions_options` block of a Valhalla request.
#[derive(Debug, serde::Serialize)]
struct ValhallaDirectionsOptions {
    /// Unit system used in the returned instructions and lengths.
    units: &'static str,
}

/// The complete body of a Valhalla `/route` request.
#[derive(Debug, serde::Serialize)]
struct ValhallaRouteRequest {
    /// Ordered waypoints, origin first.
    locations: Vec<ValhallaLocation>,
    /// Valhalla costing model name.
    costing: &'static str,
    /// Unit system used for the returned distances.
    units: &'static str,
    /// Instruction options.
    directions_options: ValhallaDirectionsOptions,
    /// Cost factors; omitted when no requested option needs one.
    #[serde(skip_serializing_if = "Option::is_none")]
    costing_options: Option<Value>,
}

/// Encodes one route request.
///
/// # Parameters
/// - `waypoints` — the ordered stops; the caller guarantees at least two.
/// - `route_options` — the options whose expressive subset Valhalla accepts.
///
/// # Returns
/// The JSON request object, with locations in latitude/longitude order.
///
/// # Errors
/// Returns [`SDKError::ResponseParsingFailure`] when the request cannot be
/// serialized.
fn build_route_request_body(
    waypoints: &[GeographicCoordinate],
    route_options: &RouteOptions,
) -> Result<Value, SDKError> {
    let request = ValhallaRouteRequest {
        locations: waypoints
            .iter()
            .map(|waypoint| ValhallaLocation {
                lat: waypoint.latitude,
                lon: waypoint.longitude,
            })
            .collect(),
        costing: costing_text(route_options.transportation_mode),
        units: VALHALLA_UNITS_KILOMETERS,
        directions_options: ValhallaDirectionsOptions {
            units: VALHALLA_UNITS_KILOMETERS,
        },
        costing_options: costing_options(route_options),
    };
    serde_json::to_value(request).map_err(|error| {
        SDKError::ResponseParsingFailure(format!(
            "Valhalla route request could not be encoded: {error}"
        ))
    })
}

/// Names the Valhalla costing model for a transport mode.
fn costing_text(transportation_mode: TransportationMode) -> &'static str {
    match transportation_mode {
        TransportationMode::Automobile => COSTING_AUTOMOBILE,
        TransportationMode::Bicycle => COSTING_BICYCLE,
        TransportationMode::Pedestrian => COSTING_PEDESTRIAN,
    }
}

/// Builds the `costing_options` block for the requested strategy and
/// avoidance features, or `None` when no requested option needs one.
///
/// The keys are mode-specific because Valhalla validates them against the
/// selected costing model: an automobile factor sent with pedestrian costing
/// is a server-side error, not a silently ignored preference. The flags
/// Valhalla cannot express in a mode are documented on the module and change
/// nothing there.
fn costing_options(route_options: &RouteOptions) -> Option<Value> {
    let transportation_mode = route_options.transportation_mode;
    let avoid_options: &AvoidOptions = &route_options.avoid_options;
    let mut mode_options = serde_json::Map::new();
    if transportation_mode == TransportationMode::Automobile
        && route_options.route_strategy == RouteStrategy::Shortest
    {
        mode_options.insert(COSTING_OPTION_SHORTEST.to_string(), Value::Bool(true));
    }
    if transportation_mode == TransportationMode::Automobile && avoid_options.toll_roads {
        mode_options.insert(
            COSTING_OPTION_USE_TOLLS.to_string(),
            serde_json::json!(COSTING_FACTOR_DISALLOW),
        );
    }
    if transportation_mode == TransportationMode::Automobile
        && avoid_options.limited_access_highways
    {
        mode_options.insert(
            COSTING_OPTION_USE_HIGHWAYS.to_string(),
            serde_json::json!(COSTING_FACTOR_DISALLOW),
        );
    }
    if avoid_options.ferries {
        mode_options.insert(
            COSTING_OPTION_USE_FERRY.to_string(),
            serde_json::json!(COSTING_FACTOR_DISALLOW),
        );
    }
    if transportation_mode != TransportationMode::Pedestrian && avoid_options.unpaved_roads {
        mode_options.insert(
            COSTING_OPTION_USE_TRACKS.to_string(),
            serde_json::json!(COSTING_FACTOR_DISALLOW),
        );
    }
    if mode_options.is_empty() {
        return None;
    }
    let mut costing_options = serde_json::Map::new();
    costing_options.insert(
        costing_text(transportation_mode).to_string(),
        Value::Object(mode_options),
    );
    Some(Value::Object(costing_options))
}

/// A `trip` response envelope.
#[derive(Debug, Deserialize)]
struct ValhallaTripEnvelope {
    /// The calculated trip.
    trip: ValhallaTrip,
}

/// One calculated trip.
#[derive(Debug, Deserialize)]
struct ValhallaTrip {
    /// Trip-wide totals.
    summary: ValhallaSummary,
    /// One leg per consecutive waypoint pair.
    legs: Vec<ValhallaLeg>,
}

/// Distance and duration totals, in kilometers and seconds.
#[derive(Debug, Deserialize)]
struct ValhallaSummary {
    /// Total length in kilometers.
    length: f64,
    /// Total travel time in seconds.
    time: f64,
}

/// One leg between consecutive waypoints.
#[derive(Debug, Deserialize)]
struct ValhallaLeg {
    /// Leg totals.
    summary: ValhallaSummary,
    /// Precision-6 encoded leg geometry.
    shape: String,
    /// Maneuvers in traversal order.
    maneuvers: Vec<ValhallaManeuver>,
}

/// One maneuver within a leg.
#[derive(Debug, Deserialize)]
struct ValhallaManeuver {
    /// Valhalla maneuver action integer.
    #[serde(rename = "type")]
    maneuver_type: i32,
    /// Display instruction.
    instruction: String,
    /// Text-to-speech instruction; absent for some maneuvers.
    verbal_pre_transition_instruction: Option<String>,
    /// Maneuver length in kilometers.
    length: f64,
    /// Maneuver travel time in seconds.
    time: f64,
    /// First shape index of the maneuver.
    begin_shape_index: Option<usize>,
    /// Last shape index of the maneuver.
    end_shape_index: Option<usize>,
    /// Roundabout exit number when the server reports one.
    exit_number: Option<u8>,
    /// Roundabout exit count when the server reports one instead.
    roundabout_exit_count: Option<u8>,
}

/// Parses a Valhalla `trip` payload into a normalized [`RouteData`].
///
/// # Parameters
/// - `payload` — the JSON body of a successful `/route` response.
///
/// # Returns
/// The route with meters, seconds, decoded step shapes and a bounding box
/// over the decoded geometry.
///
/// # Errors
/// Returns [`SDKError::ResponseParsingFailure`] when the payload is not a
/// trip, carries no legs, or any leg shape cannot be decoded.
fn parse_route_payload(payload: &Value) -> Result<RouteData, SDKError> {
    let envelope: ValhallaTripEnvelope =
        serde_json::from_value(payload.clone()).map_err(|error| {
            SDKError::ResponseParsingFailure(format!(
                "Valhalla trip payload could not be decoded: {error}"
            ))
        })?;
    let ValhallaTrip { summary, legs } = envelope.trip;
    if legs.is_empty() {
        return Err(SDKError::ResponseParsingFailure(
            "Valhalla trip carries no legs".to_string(),
        ));
    }
    let mut route_legs = Vec::with_capacity(legs.len());
    let mut route_coordinates = Vec::new();
    for leg in legs {
        let leg_shape = decode_polyline6(&leg.shape)?;
        if leg_shape.is_empty() {
            return Err(SDKError::ResponseParsingFailure(
                "Valhalla trip leg carries an empty shape".to_string(),
            ));
        }
        let steps = leg
            .maneuvers
            .into_iter()
            .map(|maneuver| maneuver_to_step(maneuver, &leg_shape))
            .collect::<Vec<_>>();
        route_coordinates.extend_from_slice(&leg_shape);
        route_legs.push(RouteLeg {
            distance_meters: kilometers_to_meters(leg.summary.length),
            duration_seconds: leg.summary.time,
            steps,
        });
    }
    let bounding_box = bounding_box_from_coordinates(&route_coordinates)?;
    Ok(RouteData {
        distance_meters: kilometers_to_meters(summary.length),
        duration_seconds: summary.time,
        bounding_box,
        legs: route_legs,
    })
}

/// Converts one Valhalla maneuver into a contract step.
///
/// # Parameters
/// - `maneuver` — the maneuver record.
/// - `leg_shape` — the decoded geometry the maneuver's shape indexes refer
///   to.
///
/// # Returns
/// The contract step for the maneuver.
fn maneuver_to_step(maneuver: ValhallaManeuver, leg_shape: &[GeographicCoordinate]) -> RouteStep {
    let roundabout_exit_index = maneuver.exit_number.or(maneuver.roundabout_exit_count);
    let instruction_speech_text = maneuver
        .verbal_pre_transition_instruction
        .unwrap_or_else(|| maneuver.instruction.clone());
    RouteStep {
        distance_meters: kilometers_to_meters(maneuver.length),
        duration_seconds: maneuver.time,
        maneuver_type: map_valhalla_maneuver_type(maneuver.maneuver_type, roundabout_exit_index),
        instruction_display_text: maneuver.instruction,
        instruction_speech_text,
        shape: maneuver_shape_slice(
            leg_shape,
            maneuver.begin_shape_index,
            maneuver.end_shape_index,
        ),
        // Valhalla does not return the contract's per-lane guidance record.
        lane_guidances: Vec::<LaneGuidance>::new(),
    }
}

/// Slices the leg geometry covered by one maneuver.
///
/// # Parameters
/// - `leg_shape` — the decoded leg geometry.
/// - `begin_shape_index` — the maneuver's first shape index.
/// - `end_shape_index` — the maneuver's last shape index.
///
/// # Returns
/// The inclusive slice, clamped to the geometry; an absent or inverted index
/// pair yields an empty shape rather than a panic.
fn maneuver_shape_slice(
    leg_shape: &[GeographicCoordinate],
    begin_shape_index: Option<usize>,
    end_shape_index: Option<usize>,
) -> Vec<GeographicCoordinate> {
    let (Some(begin_shape_index), Some(end_shape_index)) = (begin_shape_index, end_shape_index)
    else {
        return Vec::new();
    };
    if begin_shape_index >= leg_shape.len() || end_shape_index < begin_shape_index {
        return Vec::new();
    }
    let inclusive_end_index = end_shape_index.min(leg_shape.len() - 1);
    leg_shape[begin_shape_index..=inclusive_end_index].to_vec()
}

/// Computes the bounding box that encloses every decoded geometry point.
///
/// # Parameters
/// - `coordinates` — all decoded leg points.
///
/// # Returns
/// The south-west and north-east corners of the route.
///
/// # Errors
/// Returns [`SDKError::ResponseParsingFailure`] when there is no geometry.
fn bounding_box_from_coordinates(
    coordinates: &[GeographicCoordinate],
) -> Result<BoundingBox, SDKError> {
    let Some(first_coordinate) = coordinates.first() else {
        return Err(SDKError::ResponseParsingFailure(
            "Valhalla trip carries no geometry".to_string(),
        ));
    };
    let mut minimum_latitude = first_coordinate.latitude;
    let mut minimum_longitude = first_coordinate.longitude;
    let mut maximum_latitude = first_coordinate.latitude;
    let mut maximum_longitude = first_coordinate.longitude;
    for coordinate in coordinates {
        minimum_latitude = minimum_latitude.min(coordinate.latitude);
        minimum_longitude = minimum_longitude.min(coordinate.longitude);
        maximum_latitude = maximum_latitude.max(coordinate.latitude);
        maximum_longitude = maximum_longitude.max(coordinate.longitude);
    }
    let south_west = GeographicCoordinate::from_degrees(minimum_latitude, minimum_longitude)
        .map_err(|error| {
            SDKError::ResponseParsingFailure(format!("Valhalla route bounds are invalid: {error}"))
        })?;
    let north_east = GeographicCoordinate::from_degrees(maximum_latitude, maximum_longitude)
        .map_err(|error| {
            SDKError::ResponseParsingFailure(format!("Valhalla route bounds are invalid: {error}"))
        })?;
    BoundingBox::from_corners(south_west, north_east).map_err(|error| {
        SDKError::ResponseParsingFailure(format!("Valhalla route bounds are invalid: {error}"))
    })
}

/// Converts a Valhalla length in kilometers to the contract's meters.
fn kilometers_to_meters(kilometers: f64) -> f64 {
    kilometers * KILOMETERS_TO_METERS
}

#[cfg(test)]
mod tests {
    use super::{
        ValhallaProviderConfiguration, ValhallaRoutingProvider, build_route_request_body,
        parse_route_payload,
    };
    use geospatial_traits::RoutingProvider;
    use geospatial_types::route::{
        AvoidOptions, ManeuverType, RouteOptions, RouteStrategy, TransportationMode, TurnDirection,
    };
    use geospatial_types::{GeographicCoordinate, SDKError};
    use serde_json::{Value, json};

    /// Tolerance for distances and durations asserted on the fixture.
    const FIXTURE_NUMERIC_TOLERANCE: f64 = 1e-6;

    /// Tolerance for coordinates asserted on the decoded fixture shape.
    const FIXTURE_COORDINATE_TOLERANCE_DEGREES: f64 = 1e-6;

    fn fixture(name: &str) -> Value {
        let fixture_path = format!("{}/fixtures/{name}", env!("CARGO_MANIFEST_DIR"));
        serde_json::from_str(
            &std::fs::read_to_string(fixture_path).expect("the fixture must be readable"),
        )
        .expect("the fixture must be valid JSON")
    }

    fn coordinate(latitude: f64, longitude: f64) -> GeographicCoordinate {
        GeographicCoordinate::from_degrees(latitude, longitude).unwrap()
    }

    fn recorded_waypoints() -> Vec<GeographicCoordinate> {
        vec![
            coordinate(38.57657, -121.4936),
            coordinate(38.57887, -121.50797),
        ]
    }

    #[test]
    fn request_carries_locations_in_latitude_longitude_order() {
        let body = build_route_request_body(&recorded_waypoints(), &RouteOptions::default())
            .expect("the request must encode");
        assert_eq!(
            body,
            json!({
                "locations": [
                    {"lat": 38.57657, "lon": -121.4936},
                    {"lat": 38.57887, "lon": -121.50797}
                ],
                "costing": "auto",
                "units": "kilometers",
                "directions_options": {"units": "kilometers"}
            })
        );
    }

    #[test]
    fn request_selects_the_costing_of_each_transport_mode() {
        for (transportation_mode, expected_costing) in [
            (TransportationMode::Automobile, "auto"),
            (TransportationMode::Bicycle, "bicycle"),
            (TransportationMode::Pedestrian, "pedestrian"),
        ] {
            let body = build_route_request_body(
                &recorded_waypoints(),
                &RouteOptions {
                    transportation_mode,
                    ..RouteOptions::default()
                },
            )
            .expect("the request must encode");
            assert_eq!(body["costing"], expected_costing);
        }
    }

    #[test]
    fn request_omits_costing_options_when_no_option_needs_them() {
        let body = build_route_request_body(&recorded_waypoints(), &RouteOptions::default())
            .expect("the request must encode");
        assert!(body.get("costing_options").is_none());
    }

    #[test]
    fn shortest_automobile_strategy_sets_the_shortest_factor() {
        let body = build_route_request_body(
            &recorded_waypoints(),
            &RouteOptions {
                route_strategy: RouteStrategy::Shortest,
                ..RouteOptions::default()
            },
        )
        .expect("the request must encode");
        assert_eq!(body["costing_options"]["auto"]["shortest"], true);
    }

    #[test]
    fn avoid_flags_map_to_the_automobile_cost_factors() {
        let body = build_route_request_body(
            &recorded_waypoints(),
            &RouteOptions {
                avoid_options: AvoidOptions {
                    toll_roads: true,
                    limited_access_highways: true,
                    ferries: true,
                    unpaved_roads: true,
                },
                ..RouteOptions::default()
            },
        )
        .expect("the request must encode");
        assert_eq!(
            body["costing_options"],
            json!({"auto": {
                "use_tolls": 0.0,
                "use_highways": 0.0,
                "use_ferry": 0.0,
                "use_tracks": 0.0
            }})
        );
    }

    #[test]
    fn pedestrian_avoidance_omits_factors_the_costing_cannot_express() {
        let body = build_route_request_body(
            &recorded_waypoints(),
            &RouteOptions {
                transportation_mode: TransportationMode::Pedestrian,
                route_strategy: RouteStrategy::Shortest,
                avoid_options: AvoidOptions {
                    toll_roads: true,
                    limited_access_highways: true,
                    ferries: true,
                    unpaved_roads: true,
                },
                ..RouteOptions::default()
            },
        )
        .expect("the request must encode");
        assert_eq!(
            body["costing_options"],
            json!({"pedestrian": {"use_ferry": 0.0}})
        );
    }

    #[test]
    fn recorded_trip_decodes_distance_duration_legs_and_steps() {
        let route =
            parse_route_payload(&fixture("route_sacramento.json")).expect("the trip must parse");
        assert!(
            (route.distance_meters - 3_200.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
            "distance was {}",
            route.distance_meters
        );
        assert!(
            (route.duration_seconds - 420.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
            "duration was {}",
            route.duration_seconds
        );
        assert_eq!(route.legs.len(), 1);
        let leg = &route.legs[0];
        assert!(
            (leg.distance_meters - 3_200.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
            "leg distance was {}",
            leg.distance_meters
        );
        assert!(
            (leg.duration_seconds - 420.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
            "leg duration was {}",
            leg.duration_seconds
        );
        assert_eq!(leg.steps.len(), 5);
        assert_eq!(leg.steps[0].maneuver_type, ManeuverType::Departure);
        assert_eq!(
            leg.steps[1].maneuver_type,
            ManeuverType::Turn(TurnDirection::Right)
        );
        assert_eq!(leg.steps[2].maneuver_type, ManeuverType::Continue);
        assert_eq!(
            leg.steps[3].maneuver_type,
            ManeuverType::Turn(TurnDirection::Left)
        );
        assert_eq!(leg.steps[4].maneuver_type, ManeuverType::Arrival);
        assert_eq!(
            leg.steps[0].instruction_display_text,
            "Drive west on N Street."
        );
        assert_eq!(
            leg.steps[1].instruction_display_text,
            "Turn right onto 10th Street."
        );
        assert_eq!(
            leg.steps[1].instruction_speech_text,
            "Turn right onto Tenth Street."
        );
        assert_eq!(
            leg.steps[4].instruction_display_text,
            "You have arrived at your destination."
        );
        assert_eq!(leg.steps[0].shape.len(), 3);
        assert_eq!(leg.steps[3].shape.len(), 4);
        assert_eq!(leg.steps[4].shape.len(), 3);
        let final_coordinate = leg.steps[4]
            .shape
            .last()
            .expect("the arrival step carries geometry");
        assert!(
            (final_coordinate.latitude - 38.57887).abs() < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
        assert!(
            (final_coordinate.longitude - -121.50797).abs() < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
    }

    #[test]
    fn recorded_trip_bounding_box_encloses_the_decoded_geometry() {
        let route =
            parse_route_payload(&fixture("route_sacramento.json")).expect("the trip must parse");
        assert!(
            (route.bounding_box.south_west.latitude - 38.57652).abs()
                < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
        assert!(
            (route.bounding_box.south_west.longitude - -121.50797).abs()
                < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
        assert!(
            (route.bounding_box.north_east.latitude - 38.57887).abs()
                < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
        assert!(
            (route.bounding_box.north_east.longitude - -121.4936).abs()
                < FIXTURE_COORDINATE_TOLERANCE_DEGREES
        );
    }

    #[test]
    fn a_payload_without_a_trip_is_a_parsing_failure() {
        assert!(matches!(
            parse_route_payload(&json!({"error_code": 440, "error": "refused"})),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }

    #[test]
    fn a_trip_without_legs_is_a_parsing_failure() {
        assert!(matches!(
            parse_route_payload(&json!({
                "trip": {"summary": {"length": 0.0, "time": 0.0}, "legs": []}
            })),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }

    #[tokio::test]
    async fn fewer_than_two_waypoints_is_rejected_before_any_request() {
        // The base URL names no reachable server: a rejection that arrives
        // without a network failure proves the guard runs first.
        let provider = ValhallaRoutingProvider::new(ValhallaProviderConfiguration {
            base_url: "http://127.0.0.1:1".to_string(),
            user_agent: "rustic-maps-sdk-tests".to_string(),
        })
        .expect("the provider must build");
        let error = provider
            .calculate_route(&[coordinate(38.57657, -121.4936)], &RouteOptions::default())
            .await
            .expect_err("one waypoint cannot form a route");
        assert_eq!(
            error,
            SDKError::InvalidCoordinateInput(
                "a Valhalla route needs at least two waypoints".to_string()
            )
        );
    }
}
