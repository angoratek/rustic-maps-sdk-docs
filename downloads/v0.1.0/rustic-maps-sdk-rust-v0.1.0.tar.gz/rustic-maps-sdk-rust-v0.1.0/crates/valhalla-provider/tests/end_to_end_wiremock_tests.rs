//! End-to-end tests of the Valhalla routing provider against a wiremock
//! server replaying committed fixtures. The harness asserts both directions:
//! that the POST carries the documented body and that each response channel
//! maps to the contract's typed result or error.

use geospatial_traits::RoutingProvider;
use geospatial_types::route::{
    AvoidOptions, ManeuverType, RouteOptions, RouteStrategy, TransportationMode, TurnDirection,
};
use geospatial_types::{GeographicCoordinate, SDKError};
use serde_json::json;
use valhalla_provider::{ValhallaProviderConfiguration, ValhallaRoutingProvider};
use wiremock::matchers::{body_json, header, method, path};
use wiremock::{Mock, MockServer, ResponseTemplate};

/// User agent the tests configure; also matched on the wire.
const TEST_USER_AGENT: &str = "rustic-maps-sdk-tests";

/// Tolerance for the fixture's numeric fields.
const FIXTURE_NUMERIC_TOLERANCE: f64 = 1e-6;

/// Tolerance for the fixture's decoded coordinates.
const FIXTURE_COORDINATE_TOLERANCE_DEGREES: f64 = 1e-6;

fn provider_with_base(base_url: String) -> ValhallaRoutingProvider {
    ValhallaRoutingProvider::new(ValhallaProviderConfiguration {
        base_url,
        user_agent: TEST_USER_AGENT.to_string(),
    })
    .expect("the provider must build from a mock server URL")
}

fn fixture_body(name: &str) -> ResponseTemplate {
    let fixture_path = format!("{}/fixtures/{name}", env!("CARGO_MANIFEST_DIR"));
    ResponseTemplate::new(200).set_body_string(
        std::fs::read_to_string(fixture_path).expect("the fixture must be readable"),
    )
}

fn coordinate(latitude: f64, longitude: f64) -> GeographicCoordinate {
    GeographicCoordinate::from_degrees(latitude, longitude).unwrap()
}

fn recorded_waypoints() -> Vec<GeographicCoordinate> {
    vec![
        coordinate(38.57657, -121.4936),
        coordinate(38.57887, -121.50797),
    ]
}

/// The exact body the default automobile request must post.
fn default_route_request_body() -> serde_json::Value {
    json!({
        "locations": [
            {"lat": 38.57657, "lon": -121.4936},
            {"lat": 38.57887, "lon": -121.50797}
        ],
        "costing": "auto",
        "units": "kilometers",
        "directions_options": {"units": "kilometers"}
    })
}

#[tokio::test]
async fn route_request_posts_locations_costing_and_units() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .and(header("content-type", "application/json"))
        .and(header("user-agent", TEST_USER_AGENT))
        .and(body_json(default_route_request_body()))
        .respond_with(fixture_body("route_sacramento.json"))
        .expect(1)
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let route = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect("the recorded trip must decode");
    server.verify().await;
    assert_eq!(route.legs.len(), 1);
}

#[tokio::test]
async fn recorded_sacramento_route_decodes_summary_legs_maneuvers_and_bounds() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .respond_with(fixture_body("route_sacramento.json"))
        .expect(1)
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let route = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect("the recorded trip must decode");
    assert!(
        (route.distance_meters - 3_200.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
        "distance was {}",
        route.distance_meters
    );
    assert!(
        (route.duration_seconds - 420.0).abs() < FIXTURE_NUMERIC_TOLERANCE,
        "duration was {}",
        route.duration_seconds
    );
    let leg = &route.legs[0];
    assert_eq!(leg.steps.len(), 5);
    assert_eq!(leg.steps[0].maneuver_type, ManeuverType::Departure);
    assert_eq!(
        leg.steps[1].maneuver_type,
        ManeuverType::Turn(TurnDirection::Right)
    );
    assert_eq!(leg.steps[2].maneuver_type, ManeuverType::Continue);
    assert_eq!(
        leg.steps[3].maneuver_type,
        ManeuverType::Turn(TurnDirection::Left)
    );
    assert_eq!(leg.steps[4].maneuver_type, ManeuverType::Arrival);
    assert_eq!(
        leg.steps[0].instruction_display_text,
        "Drive west on N Street."
    );
    assert_eq!(
        leg.steps[1].instruction_display_text,
        "Turn right onto 10th Street."
    );
    assert_eq!(
        leg.steps[1].instruction_speech_text,
        "Turn right onto Tenth Street."
    );
    assert_eq!(
        leg.steps[4].instruction_display_text,
        "You have arrived at your destination."
    );
    assert_eq!(
        leg.steps[4]
            .shape
            .last()
            .expect("the arrival step carries geometry")
            .latitude,
        route.bounding_box.north_east.latitude
    );
    assert!(
        (route.bounding_box.south_west.latitude - 38.57652).abs()
            < FIXTURE_COORDINATE_TOLERANCE_DEGREES
    );
    assert!(
        (route.bounding_box.south_west.longitude - -121.50797).abs()
            < FIXTURE_COORDINATE_TOLERANCE_DEGREES
    );
    assert!(
        (route.bounding_box.north_east.longitude - -121.4936).abs()
            < FIXTURE_COORDINATE_TOLERANCE_DEGREES
    );
}

#[tokio::test]
async fn pedestrian_route_selects_the_pedestrian_costing() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .and(body_json(json!({
            "locations": [
                {"lat": 38.57657, "lon": -121.4936},
                {"lat": 38.57887, "lon": -121.50797}
            ],
            "costing": "pedestrian",
            "units": "kilometers",
            "directions_options": {"units": "kilometers"}
        })))
        .respond_with(fixture_body("route_sacramento.json"))
        .expect(1)
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    provider
        .calculate_route(
            &recorded_waypoints(),
            &RouteOptions {
                transportation_mode: TransportationMode::Pedestrian,
                ..RouteOptions::default()
            },
        )
        .await
        .expect("the recorded trip must decode");
    server.verify().await;
}

#[tokio::test]
async fn shortest_strategy_and_avoidance_ride_costing_options() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .and(body_json(json!({
            "locations": [
                {"lat": 38.57657, "lon": -121.4936},
                {"lat": 38.57887, "lon": -121.50797}
            ],
            "costing": "auto",
            "units": "kilometers",
            "directions_options": {"units": "kilometers"},
            "costing_options": {
                "auto": {
                    "shortest": true,
                    "use_tolls": 0.0,
                    "use_highways": 0.0,
                    "use_ferry": 0.0,
                    "use_tracks": 0.0
                }
            }
        })))
        .respond_with(fixture_body("route_sacramento.json"))
        .expect(1)
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    provider
        .calculate_route(
            &recorded_waypoints(),
            &RouteOptions {
                route_strategy: RouteStrategy::Shortest,
                avoid_options: AvoidOptions {
                    toll_roads: true,
                    limited_access_highways: true,
                    ferries: true,
                    unpaved_roads: true,
                },
                ..RouteOptions::default()
            },
        )
        .await
        .expect("the recorded trip must decode");
    server.verify().await;
}

#[tokio::test]
async fn valhalla_error_code_surfaces_the_provider_message_verbatim() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .respond_with(
            ResponseTemplate::new(400).set_body_string(
                std::fs::read_to_string(format!(
                    "{}/fixtures/route_no_route_error.json",
                    env!("CARGO_MANIFEST_DIR")
                ))
                .expect("the error fixture must be readable"),
            ),
        )
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let error = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect_err("a refusal must surface");
    assert_eq!(
        error,
        SDKError::ProviderRequestRejected(
            "No route found between origin and destination".to_string()
        )
    );
}

#[tokio::test]
async fn http_500_surfaces_as_a_network_request_failure() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .respond_with(ResponseTemplate::new(500).set_body_string("internal server error"))
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let error = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect_err("a server outage must surface");
    assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
}

#[tokio::test]
async fn malformed_body_surfaces_as_a_parsing_failure() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .respond_with(ResponseTemplate::new(200).set_body_string(r#"{"trip": {"summary": }}"#))
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let error = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect_err("a malformed body must surface");
    assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
}

#[tokio::test]
async fn a_valid_body_without_a_trip_surfaces_as_a_parsing_failure() {
    let server = MockServer::start().await;
    Mock::given(method("POST"))
        .and(path("/route"))
        .respond_with(ResponseTemplate::new(200).set_body_json(json!({"unexpected": "payload"})))
        .mount(&server)
        .await;
    let provider = provider_with_base(server.uri());
    let error = provider
        .calculate_route(&recorded_waypoints(), &RouteOptions::default())
        .await
        .expect_err("a body without a trip must surface");
    assert!(matches!(error, SDKError::ResponseParsingFailure(_)));
}
