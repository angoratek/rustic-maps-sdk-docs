//! Live provider registration on the wasm seam: a browser application can
//! take a runtime provider credential and fetch real provider data through
//! the same provider implementations the native targets use, running on the
//! portable browser `fetch` transport.
//!
//! The registration surface is provider-generic: callers name a provider key
//! from the shared provider registry, and [`register_provider`] dispatches it
//! to the compiled provider crate. Only the dispatch arm in
//! [`provider_for_registered_key`] names a vendor; everything the live calls
//! touch is the vendor-neutral provider traits. The registry is module-local
//! and single-threaded; no credential is persisted or logged. The exports
//! offer a forward-geocode call, a two-waypoint route call and a raster-tile
//! fetch, all through the active registered provider.

use crate::exports::{
    ERROR_CODE_INVALID_ARGUMENT, ERROR_CODE_INVALID_COORDINATE_INPUT,
    ERROR_CODE_PROVIDER_NOT_CONFIGURED, failure_with_code, object_from_fields, route_data_object,
    sdk_error_failure,
};
use crate::shared::validated_coordinate;
use geospatial_traits::{
    DistanceMatrixProvider, GeocodingProvider, RasterTileProvider, RoutingProvider,
    SearchPlaceProvider, TrafficFlowProvider, TrafficIncidentProvider,
};
use geospatial_types::route::{
    AvoidOptions, RouteOptions, RouteStrategy, TransportationMode, UnitSystem,
};
use geospatial_types::{
    BoundingBox, DistanceMatrix, PlaceResult, RasterImageFormat, RasterTileResolution,
    TrafficFlowData, TrafficIncident,
};
use js_sys::{Array, Object, Uint8Array};
use mapquest_provider::{
    MapQuestDistanceMatrixProvider, MapQuestGeocodingProvider, MapQuestProviderClient,
    MapQuestProviderConfiguration, MapQuestRasterTileProvider, MapQuestRoutingProvider,
    MapQuestSearchPlaceProvider, MapQuestTrafficFlowProvider, MapQuestTrafficIncidentProvider,
};
use std::cell::RefCell;
use std::sync::Arc;
use wasm_bindgen::prelude::*;

/// Raster format the live tile call requests: the Tiles API's PNG form, the
/// encoding of the committed tile fixtures the browser canvas renders.
const LIVE_RASTER_TILE_IMAGE_FORMAT: RasterImageFormat = RasterImageFormat::Png;
/// Raster resolution the live tile call requests: the standard 256-pixel
/// edge (`256/png` in the provider path), matching the recorded tile samples.
const LIVE_RASTER_TILE_RESOLUTION: RasterTileResolution = RasterTileResolution::Standard;
/// The refusal every live call answers when no credential was applied.
const NO_REGISTERED_PROVIDER_MESSAGE: &str =
    "no live provider is registered; set a provider key first";
/// The dispatch key of the MapQuest provider crate, equal to the shared
/// registry's `wasm_registration` value.
const MAPQUEST_PROVIDER_KEY: &str = "mapquest";
/// The largest departure timestamp JavaScript can carry exactly (the safe
/// integer limit); a larger value would silently lose seconds in the f64
/// round trip the seam accepts.
const MAXIMUM_DEPARTURE_TIMESTAMP_SECONDS: f64 = 9_007_199_254_740_991.0;

/// The active registration: the vendor-neutral provider traits every live
/// call consumes. Applying a credential replaces the whole bundle, so the
/// live calls name no provider.
struct RegisteredProvider {
    geocoding_provider: Arc<dyn GeocodingProvider>,
    routing_provider: Arc<dyn RoutingProvider>,
    raster_tile_provider: Arc<dyn RasterTileProvider>,
    search_place_provider: Arc<dyn SearchPlaceProvider>,
    distance_matrix_provider: Arc<dyn DistanceMatrixProvider>,
    traffic_incident_provider: Arc<dyn TrafficIncidentProvider>,
    traffic_flow_provider: Arc<dyn TrafficFlowProvider>,
}

thread_local! {
    /// The active provider bundle (absent until a credential is applied).
    static ACTIVE_PROVIDER: RefCell<Option<Arc<RegisteredProvider>>> =
        const { RefCell::new(None) };
    /// The raster-tile provider the generated contract registry installed.
    /// When the canvas ships inside the generated module's crate graph, a
    /// source registered through the generated `MapSdk` and the canvas' live
    /// fallback are the same tile source: the binding crate mirrors every
    /// raster-tile registration here, and the canvas consults this slot
    /// before its credential-based registration. Absent when the canvas runs
    /// on its own.
    static SHARED_RASTER_TILE_PROVIDER: RefCell<Option<Arc<dyn RasterTileProvider>>> =
        const { RefCell::new(None) };
}

/// Builds the MapQuest provider client from a runtime credential; `base_url`
/// overrides the public platform endpoint, so a caller that serves the same
/// provider routes locally can point the client at them.
fn mapquest_provider_client(
    credential: String,
    base_url: Option<String>,
) -> Result<MapQuestProviderClient, JsValue> {
    let mut configuration = MapQuestProviderConfiguration {
        api_key: credential,
        ..MapQuestProviderConfiguration::default()
    };
    if let Some(override_base_url) = base_url {
        if !override_base_url.trim().is_empty() {
            configuration.base_url = override_base_url;
        }
    }
    MapQuestProviderClient::new(configuration).map_err(|error| sdk_error_failure(&error))
}

/// The compiled-provider dispatch table: one arm per provider crate this
/// wasm build carries, keyed by the shared registry's `wasm_registration`.
/// Adding a provider adds its crate dependency and this arm — nothing else in
/// this module names a vendor.
fn provider_for_registered_key(
    provider_key: &str,
    credential: String,
    base_url: Option<String>,
) -> Result<RegisteredProvider, JsValue> {
    match provider_key {
        MAPQUEST_PROVIDER_KEY => {
            let provider_client = Arc::new(mapquest_provider_client(credential, base_url)?);
            Ok(RegisteredProvider {
                geocoding_provider: Arc::new(MapQuestGeocodingProvider::new(Arc::clone(
                    &provider_client,
                ))),
                routing_provider: Arc::new(MapQuestRoutingProvider::new(Arc::clone(
                    &provider_client,
                ))),
                search_place_provider: Arc::new(MapQuestSearchPlaceProvider::new(Arc::clone(
                    &provider_client,
                ))),
                distance_matrix_provider: Arc::new(MapQuestDistanceMatrixProvider::new(
                    Arc::clone(&provider_client),
                )),
                traffic_incident_provider: Arc::new(MapQuestTrafficIncidentProvider::new(
                    Arc::clone(&provider_client),
                )),
                traffic_flow_provider: Arc::new(MapQuestTrafficFlowProvider::new(Arc::clone(
                    &provider_client,
                ))),
                raster_tile_provider: Arc::new(MapQuestRasterTileProvider::new(provider_client)),
            })
        }
        _ => Err(failure_with_code(
            ERROR_CODE_PROVIDER_NOT_CONFIGURED,
            &format!(
                "no provider implementation is compiled for the provider key \"{provider_key}\""
            ),
        )),
    }
}

/// Registers a provider for live browser calls. The caller names the shared
/// registry's provider key; a blank credential is refused. The credential
/// lives in module memory only and is never logged.
#[wasm_bindgen(js_name = registerProvider)]
pub fn register_provider(
    provider_key: String,
    credential: String,
    base_url: Option<String>,
) -> Result<(), JsValue> {
    if credential.trim().is_empty() {
        return Err(failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            "a provider credential must not be empty",
        ));
    }
    let provider = provider_for_registered_key(&provider_key, credential, base_url)?;
    ACTIVE_PROVIDER.with(|provider_slot| {
        *provider_slot.borrow_mut() = Some(Arc::new(provider));
    });
    Ok(())
}

/// Clears the active registration (the settings surface's Clear act; the
/// running page keeps nothing afterwards).
#[wasm_bindgen(js_name = clearProvider)]
pub fn clear_provider() {
    ACTIVE_PROVIDER.with(|provider_slot| {
        *provider_slot.borrow_mut() = None;
    });
}

/// The contract's single-credential registration spelling (`MapSdk::
/// set_provider_credential`) on the wasm seam: registers the MapQuest
/// provider set through the generic dispatch table.
#[wasm_bindgen(js_name = setProviderCredential)]
pub fn set_provider_credential(api_key: String, base_url: Option<String>) -> Result<(), JsValue> {
    register_provider(MAPQUEST_PROVIDER_KEY.to_string(), api_key, base_url)
}

/// Addition-only alias for the vendor-named export: clears the active
/// registration.
#[wasm_bindgen(js_name = clearMapquestProviders)]
pub fn clear_mapquest_providers() {
    clear_provider();
}

/// The active provider bundle, or the honest refusal every live call answers
/// without a credential.
fn registered_provider() -> Result<Arc<RegisteredProvider>, JsValue> {
    ACTIVE_PROVIDER
        .with(|provider_slot| provider_slot.borrow().clone())
        .ok_or_else(|| {
            failure_with_code(
                ERROR_CODE_PROVIDER_NOT_CONFIGURED,
                NO_REGISTERED_PROVIDER_MESSAGE,
            )
        })
}

/// Installs the raster-tile provider the generated contract registry holds,
/// so the canvas' live fallback fetches through the same source the contract
/// surface serves. `None` clears the shared slot. The binding crate mirrors
/// every registration here; the canvas consults it before its own
/// credential-based registration, so one provider serves both surfaces.
pub fn set_shared_raster_tile_provider(provider: Option<Arc<dyn RasterTileProvider>>) {
    SHARED_RASTER_TILE_PROVIDER.with(|provider_slot| {
        *provider_slot.borrow_mut() = provider;
    });
}

/// The active provider's raster-tile surface, when a credential is applied.
/// The GPU canvas consults it as the live fallback for addresses with no
/// recorded fixture, so the map keeps drawing real imagery while the camera
/// pans anywhere. The contract registry's raster slot, when the canvas runs
/// inside the generated module, takes precedence over this bundle: both
/// surfaces then read one registration.
pub(crate) fn registered_raster_tile_provider() -> Option<Arc<dyn RasterTileProvider>> {
    SHARED_RASTER_TILE_PROVIDER
        .with(|provider_slot| provider_slot.borrow().clone())
        .or_else(|| {
            ACTIVE_PROVIDER.with(|provider_slot| {
                provider_slot
                    .borrow()
                    .as_ref()
                    .map(|provider| Arc::clone(&provider.raster_tile_provider))
            })
        })
}

/// Forward-geocodes through the active live provider, answering the same row
/// shape the native reference applications consume. Fails with a message when no provider is
/// registered or the provider refuses the query.
#[wasm_bindgen(js_name = forwardGeocode)]
pub async fn forward_geocode_live(query_text: String) -> Result<Array, JsValue> {
    let provider = registered_provider()?;
    let place_rows = provider
        .geocoding_provider
        .forward_geocode(&query_text)
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    place_rows_array(place_rows)
}

/// Returns fast completion candidates while the visitor types, through the
/// active provider's search-place surface — the same rows the native
/// reference apps consume from `MapSdk::suggest`. Fails with a verbatim
/// message when no provider is registered or the provider refuses the query.
#[wasm_bindgen(js_name = suggestPlaces)]
pub async fn suggest_places(query_text: String) -> Result<Array, JsValue> {
    search_place_rows(query_text, None, true).await
}

/// [`suggest_places`] narrowed to a ranking boundary (the contract's
/// `MapSdk::suggest` boundary argument).
#[wasm_bindgen(js_name = suggestPlacesInBoundary)]
pub async fn suggest_places_in_boundary(
    query_text: String,
    south_west_latitude: f64,
    south_west_longitude: f64,
    north_east_latitude: f64,
    north_east_longitude: f64,
) -> Result<Array, JsValue> {
    let search_boundary = validated_search_boundary(
        south_west_latitude,
        south_west_longitude,
        north_east_latitude,
        north_east_longitude,
    )?;
    search_place_rows(query_text, Some(search_boundary), true).await
}

/// Returns full search results for a settled query through the active
/// provider's search-place surface — the same rows the native reference apps
/// consume from `MapSdk::search`.
#[wasm_bindgen(js_name = searchPlaces)]
pub async fn search_places(query_text: String) -> Result<Array, JsValue> {
    search_place_rows(query_text, None, false).await
}

/// [`search_places`] narrowed to a ranking boundary (the contract's
/// `MapSdk::search` boundary argument).
#[wasm_bindgen(js_name = searchPlacesInBoundary)]
pub async fn search_places_in_boundary(
    query_text: String,
    south_west_latitude: f64,
    south_west_longitude: f64,
    north_east_latitude: f64,
    north_east_longitude: f64,
) -> Result<Array, JsValue> {
    let search_boundary = validated_search_boundary(
        south_west_latitude,
        south_west_longitude,
        north_east_latitude,
        north_east_longitude,
    )?;
    search_place_rows(query_text, Some(search_boundary), false).await
}

/// Answers one search-place call from the active provider: autocomplete for a
/// typing visitor, the full result set for a settled query.
async fn search_place_rows(
    query_text: String,
    search_boundary: Option<BoundingBox>,
    is_autocomplete: bool,
) -> Result<Array, JsValue> {
    let provider = registered_provider()?;
    let place_rows = if is_autocomplete {
        provider
            .search_place_provider
            .search_autocomplete(&query_text, search_boundary)
            .await
    } else {
        provider
            .search_place_provider
            .search_places(&query_text, search_boundary)
            .await
    }
    .map_err(|error| sdk_error_failure(&error))?;
    place_rows_array(place_rows)
}

/// Validates the four corner scalars a boundary-taking search call accepts
/// and builds the vendor-neutral box (inverted or out-of-range corners are
/// refused verbatim).
fn validated_search_boundary(
    south_west_latitude: f64,
    south_west_longitude: f64,
    north_east_latitude: f64,
    north_east_longitude: f64,
) -> Result<BoundingBox, JsValue> {
    let south_west = validated_coordinate(south_west_latitude, south_west_longitude)
        .map_err(|message| failure_with_code(ERROR_CODE_INVALID_COORDINATE_INPUT, &message))?;
    let north_east = validated_coordinate(north_east_latitude, north_east_longitude)
        .map_err(|message| failure_with_code(ERROR_CODE_INVALID_COORDINATE_INPUT, &message))?;
    BoundingBox::from_corners(south_west, north_east).map_err(|error| sdk_error_failure(&error))
}

/// Maps the vendor-neutral place rows to the plain JavaScript row shape every
/// wasm geocoding/search call answers (the native contract's `Place` field
/// names, lower-camel-cased).
fn place_rows_array(place_rows: Vec<PlaceResult>) -> Result<Array, JsValue> {
    let row_array = Array::new();
    for place_row in place_rows {
        let row_object = object_from_fields(&[
            (
                "structuredAddressText",
                JsValue::from_str(&place_row.structured_address_text),
            ),
            (
                "latitudeDegrees",
                JsValue::from(place_row.coordinate.latitude),
            ),
            (
                "longitudeDegrees",
                JsValue::from(place_row.coordinate.longitude),
            ),
            (
                "qualityText",
                JsValue::from_str(&format!("{:?}", place_row.geocode_quality)),
            ),
        ])?;
        row_array.push(&row_object.into());
    }
    Ok(row_array)
}

/// Plans a two-waypoint route through the active live provider, answering
/// the same plain JavaScript shape
/// [`crate::exports::offline_route_from_archive_bytes`] does: `distanceMeters`,
/// `durationSeconds`, `boundingBox` and `legs` of `steps` carrying the stable
/// snake-case `maneuverType` label and the provider's end-anchored instruction
/// texts.
///
/// The request uses the SDK defaults: automobile, fastest, metric —
/// `RouteOptions::default()`, the same mode the recorded route sample was
/// produced with.
/// Failures throw an error carrying the verbatim detail and a stable code:
/// no registration, an invalid coordinate, or the provider's own refusal.
#[wasm_bindgen(js_name = calculateRoute)]
pub async fn calculate_route_live(
    origin_latitude: f64,
    origin_longitude: f64,
    destination_latitude: f64,
    destination_longitude: f64,
) -> Result<Object, JsValue> {
    route_answer(
        origin_latitude,
        origin_longitude,
        destination_latitude,
        destination_longitude,
        &RouteOptions::default(),
    )
    .await
}

/// Plans a two-waypoint route with the contract's full `RouteOptions`
/// (`MapSdk::calculate_route`'s options argument): transportation mode,
/// strategy, unit system, avoids and an optional departure instant. The
/// options arrive as one plain object; omitted fields take the contract
/// defaults, and an unknown enum name is refused before the provider is
/// asked. The answer is the same route shape [`calculate_route_live`]
/// produces.
#[wasm_bindgen(js_name = calculateRouteWithOptions)]
pub async fn calculate_route_with_options(
    origin_latitude: f64,
    origin_longitude: f64,
    destination_latitude: f64,
    destination_longitude: f64,
    options: JsValue,
) -> Result<Object, JsValue> {
    let route_options = route_options_from_object(&options)?;
    route_answer(
        origin_latitude,
        origin_longitude,
        destination_latitude,
        destination_longitude,
        &route_options,
    )
    .await
}

/// The shared route call behind both route exports.
async fn route_answer(
    origin_latitude: f64,
    origin_longitude: f64,
    destination_latitude: f64,
    destination_longitude: f64,
    route_options: &RouteOptions,
) -> Result<Object, JsValue> {
    let provider = registered_provider()?;
    let origin = validated_coordinate(origin_latitude, origin_longitude)
        .map_err(|message| failure_with_code(ERROR_CODE_INVALID_COORDINATE_INPUT, &message))?;
    let destination = validated_coordinate(destination_latitude, destination_longitude)
        .map_err(|message| failure_with_code(ERROR_CODE_INVALID_COORDINATE_INPUT, &message))?;
    let route_data = provider
        .routing_provider
        .calculate_route(&[origin, destination], route_options)
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    route_data_object(&route_data)
}

/// Reads one optional field from a JavaScript options object.
fn options_field(options: &JsValue, field_name: &str) -> Result<JsValue, JsValue> {
    js_sys::Reflect::get(options, &JsValue::from_str(field_name)).map_err(|_| {
        failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            &format!("the route options object refuses {field_name}"),
        )
    })
}

/// Reads an optional string field, falling back to `default_value` when the
/// field is absent or null.
fn options_text_field(
    options: &JsValue,
    field_name: &str,
    default_value: &str,
) -> Result<String, JsValue> {
    let field_value = options_field(options, field_name)?;
    if field_value.is_undefined() || field_value.is_null() {
        return Ok(default_value.to_string());
    }
    field_value.as_string().ok_or_else(|| {
        failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            &format!("the route option {field_name} must be a string"),
        )
    })
}

/// Reads an optional boolean field, defaulting to false.
fn options_boolean_field(options: &JsValue, field_name: &str) -> Result<bool, JsValue> {
    let field_value = options_field(options, field_name)?;
    if field_value.is_undefined() || field_value.is_null() {
        return Ok(false);
    }
    field_value.as_bool().ok_or_else(|| {
        failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            &format!("the route option {field_name} must be a boolean"),
        )
    })
}

/// Parses the plain `RouteOptions` object into the vendor-neutral record.
fn route_options_from_object(options: &JsValue) -> Result<RouteOptions, JsValue> {
    if !options.is_object() {
        return Err(failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            "the route options argument must be an object",
        ));
    }
    let transportation_mode = transportation_mode_from_name(&options_text_field(
        options,
        "transportationMode",
        "automobile",
    )?)?;
    let route_strategy = match options_text_field(options, "routeStrategy", "fastest")?
        .trim()
        .to_ascii_lowercase()
        .as_str()
    {
        "fastest" => RouteStrategy::Fastest,
        "shortest" => RouteStrategy::Shortest,
        _ => {
            return Err(failure_with_code(
                ERROR_CODE_INVALID_ARGUMENT,
                "the route strategy must be fastest or shortest",
            ));
        }
    };
    let unit_system = match options_text_field(options, "unitSystem", "metric")?
        .trim()
        .to_ascii_lowercase()
        .as_str()
    {
        "metric" => UnitSystem::Metric,
        "imperial" => UnitSystem::Imperial,
        _ => {
            return Err(failure_with_code(
                ERROR_CODE_INVALID_ARGUMENT,
                "the unit system must be metric or imperial",
            ));
        }
    };
    let avoid_field = options_field(options, "avoidOptions")?;
    let avoid_options = if avoid_field.is_undefined() || avoid_field.is_null() {
        AvoidOptions::default()
    } else if !avoid_field.is_object() {
        return Err(failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            "the avoidOptions field must be an object",
        ));
    } else {
        AvoidOptions {
            toll_roads: options_boolean_field(&avoid_field, "tollRoads")?,
            limited_access_highways: options_boolean_field(&avoid_field, "limitedAccessHighways")?,
            ferries: options_boolean_field(&avoid_field, "ferries")?,
            unpaved_roads: options_boolean_field(&avoid_field, "unpavedRoads")?,
        }
    };
    let departure_field = options_field(options, "departureTimestampSeconds")?;
    let departure_timestamp_seconds = if departure_field.is_undefined() || departure_field.is_null()
    {
        None
    } else {
        let departure_seconds = departure_field.as_f64().ok_or_else(|| {
            failure_with_code(
                ERROR_CODE_INVALID_ARGUMENT,
                "the departure timestamp must be a number of seconds",
            )
        })?;
        if !departure_seconds.is_finite()
            || departure_seconds < 0.0
            || departure_seconds > MAXIMUM_DEPARTURE_TIMESTAMP_SECONDS
        {
            return Err(failure_with_code(
                ERROR_CODE_INVALID_ARGUMENT,
                "the departure timestamp must be finite, non-negative and \
                 within the u64 second range",
            ));
        }
        Some(departure_seconds as u64)
    };
    Ok(RouteOptions {
        transportation_mode,
        route_strategy,
        unit_system,
        avoid_options,
        departure_timestamp_seconds,
    })
}

/// Calculates a travel-time matrix through the active provider's
/// distance-matrix surface — the contract's `MapSdk::calculate_distance_matrix`
/// on the wasm seam. Coordinates arrive as flat
/// `[latitude, longitude, …]` arrays; the mode is the contract enum's name
/// (or the common lowercase spelling). Answers `{originIndex,
/// destinationIndex, distanceMeters, durationSeconds}` rows.
#[wasm_bindgen(js_name = calculateDistanceMatrix)]
pub async fn calculate_distance_matrix(
    origin_coordinates: Vec<f64>,
    destination_coordinates: Vec<f64>,
    transportation_mode: String,
) -> Result<Array, JsValue> {
    let provider = registered_provider()?;
    let origins = coordinate_pairs_array(&origin_coordinates, "origin")?;
    let destinations = coordinate_pairs_array(&destination_coordinates, "destination")?;
    let mode = transportation_mode_from_name(&transportation_mode)?;
    let matrix = provider
        .distance_matrix_provider
        .calculate_distance_matrix(&origins, &destinations, mode)
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    distance_matrix_entries_array(&matrix)
}

/// Reads a flat `[latitude, longitude, …]` array into validated coordinates.
fn coordinate_pairs_array(
    flat_values: &[f64],
    label: &str,
) -> Result<Vec<geospatial_types::GeographicCoordinate>, JsValue> {
    if flat_values.is_empty() || !flat_values.len().is_multiple_of(2) {
        return Err(failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            &format!(
                "{label} coordinates must be a non-empty, even-length \
                 [latitude, longitude, …] array"
            ),
        ));
    }
    flat_values
        .chunks_exact(2)
        .map(|pair| {
            validated_coordinate(pair[0], pair[1])
                .map_err(|message| failure_with_code(ERROR_CODE_INVALID_COORDINATE_INPUT, &message))
        })
        .collect()
}

/// The contract's transportation-mode name, accepting the common lowercase
/// spellings the JavaScript side uses.
fn transportation_mode_from_name(name: &str) -> Result<TransportationMode, JsValue> {
    match name.trim().to_ascii_lowercase().as_str() {
        "automobile" | "car" => Ok(TransportationMode::Automobile),
        "bicycle" => Ok(TransportationMode::Bicycle),
        "pedestrian" | "walking" => Ok(TransportationMode::Pedestrian),
        _ => Err(failure_with_code(
            ERROR_CODE_INVALID_ARGUMENT,
            "the transportation mode must be automobile, bicycle or pedestrian",
        )),
    }
}

/// Maps the matrix record to its plain JavaScript rows.
fn distance_matrix_entries_array(matrix: &DistanceMatrix) -> Result<Array, JsValue> {
    let entry_array = Array::new();
    for entry in &matrix.entries {
        let entry_object = object_from_fields(&[
            ("originIndex", JsValue::from(entry.origin_index)),
            ("destinationIndex", JsValue::from(entry.destination_index)),
            ("distanceMeters", JsValue::from(entry.distance_meters)),
            ("durationSeconds", JsValue::from(entry.duration_seconds)),
        ])?;
        entry_array.push(&entry_object.into());
    }
    Ok(entry_array)
}

/// Fetches traffic disruptions intersecting the bounding box — the contract's
/// `MapSdk::fetch_traffic_incidents` on the wasm seam. The row shape is the
/// contract's `TrafficIncident` with lower-camel field names and enum names
/// as text (`incidentType`, `severity`).
#[wasm_bindgen(js_name = fetchTrafficIncidents)]
pub async fn fetch_traffic_incidents(
    south_west_latitude: f64,
    south_west_longitude: f64,
    north_east_latitude: f64,
    north_east_longitude: f64,
) -> Result<Array, JsValue> {
    let provider = registered_provider()?;
    let bounding_box = validated_search_boundary(
        south_west_latitude,
        south_west_longitude,
        north_east_latitude,
        north_east_longitude,
    )?;
    let incidents = provider
        .traffic_incident_provider
        .fetch_traffic_incidents(&bounding_box)
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    traffic_incidents_array(&incidents)
}

/// Fetches per-segment traffic flow inside the bounding box — the contract's
/// `MapSdk::fetch_traffic_flow` on the wasm seam. The row shape is the
/// contract's `TrafficFlowData` with lower-camel field names, speed values or
/// null, and the congestion level's enum name as text.
#[wasm_bindgen(js_name = fetchTrafficFlow)]
pub async fn fetch_traffic_flow(
    south_west_latitude: f64,
    south_west_longitude: f64,
    north_east_latitude: f64,
    north_east_longitude: f64,
) -> Result<Array, JsValue> {
    let provider = registered_provider()?;
    let bounding_box = validated_search_boundary(
        south_west_latitude,
        south_west_longitude,
        north_east_latitude,
        north_east_longitude,
    )?;
    let flow_rows = provider
        .traffic_flow_provider
        .fetch_traffic_flow(&bounding_box)
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    traffic_flow_array(&flow_rows)
}

/// One `{latitude, longitude}` object for a traffic row.
fn coordinate_object(
    coordinate: &geospatial_types::GeographicCoordinate,
) -> Result<Object, JsValue> {
    object_from_fields(&[
        ("latitude", JsValue::from(coordinate.latitude)),
        ("longitude", JsValue::from(coordinate.longitude)),
    ])
}

/// Maps the incident records to their plain JavaScript rows.
fn traffic_incidents_array(incidents: &[TrafficIncident]) -> Result<Array, JsValue> {
    let incident_array = Array::new();
    for incident in incidents {
        let start_coordinate = coordinate_object(&incident.start_coordinate)?;
        let end_coordinate = match &incident.end_coordinate {
            Some(coordinate) => coordinate_object(coordinate)?.into(),
            None => JsValue::NULL,
        };
        let incident_object = object_from_fields(&[
            ("identifier", JsValue::from_str(&incident.identifier)),
            (
                "incidentType",
                JsValue::from_str(&format!("{:?}", incident.incident_type)),
            ),
            (
                "severity",
                JsValue::from_str(&format!("{:?}", incident.severity)),
            ),
            (
                "shortDescriptionText",
                JsValue::from_str(&incident.short_description_text),
            ),
            ("startCoordinate", start_coordinate.into()),
            ("endCoordinate", end_coordinate),
        ])?;
        incident_array.push(&incident_object.into());
    }
    Ok(incident_array)
}

/// Maps the flow records to their plain JavaScript rows.
fn traffic_flow_array(flow_rows: &[TrafficFlowData]) -> Result<Array, JsValue> {
    let flow_array = Array::new();
    for flow_row in flow_rows {
        let shape_coordinates = Array::new();
        for coordinate in &flow_row.shape_coordinates {
            shape_coordinates.push(&coordinate_object(coordinate)?.into());
        }
        let current_speed = flow_row
            .current_speed_kilometers_per_hour
            .map_or(JsValue::NULL, JsValue::from);
        let free_flow_speed = flow_row
            .free_flow_speed_kilometers_per_hour
            .map_or(JsValue::NULL, JsValue::from);
        let flow_object = object_from_fields(&[
            ("shapeCoordinates", shape_coordinates.into()),
            ("currentSpeedKilometersPerHour", current_speed),
            ("freeFlowSpeedKilometersPerHour", free_flow_speed),
            (
                "congestionLevel",
                JsValue::from_str(&format!("{:?}", flow_row.congestion_level)),
            ),
        ])?;
        flow_array.push(&flow_object.into());
    }
    Ok(flow_array)
}

/// Fetches one raster tile through the active live provider, answering the
/// PNG bytes as a `Uint8Array`.
///
/// The request is the standard-resolution PNG form of the provider's
/// documented Tiles API path. Failures throw an error carrying the verbatim
/// detail and a stable code: no registration, a zoom or tile address outside
/// the Tiles API's documented bounds, or the provider's own refusal.
#[wasm_bindgen(js_name = fetchRasterTile)]
pub async fn fetch_raster_tile_live(
    zoom_level: u8,
    tile_x: u32,
    tile_y: u32,
) -> Result<Uint8Array, JsValue> {
    let provider = registered_provider()?;
    let tile_data = provider
        .raster_tile_provider
        .fetch_raster_tile(
            tile_x,
            tile_y,
            zoom_level,
            LIVE_RASTER_TILE_IMAGE_FORMAT,
            LIVE_RASTER_TILE_RESOLUTION,
        )
        .await
        .map_err(|error| sdk_error_failure(&error))?;
    Ok(Uint8Array::from(tile_data.image_bytes.as_slice()))
}
