//! The provider-neutral, URL-template vector-tile source.
//!
//! One instance serves one tileset: the validated template turns tile
//! coordinates into request URLs, the descriptor names the tileset for
//! caching and attribution, and every fetch is paced by the shared token
//! bucket and retried in bounds through the shared transport.

use crate::error_mapping::map_http_error_response;
use crate::url_template::UrlTemplate;
use async_trait::async_trait;
use geospatial_traits::{VectorTileProvider, VectorTileSourceDescriptor};
use geospatial_types::{SDKError, VectorTileData};
use provider_transport::{
    HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpMethod, HttpRequest, HttpResponse, HttpTransport,
    RetryPolicy, TokenBucketRateLimiter, execute_idempotent_get,
};
use std::sync::Arc;

/// Conservative default burst: a small batch of tiles starts immediately.
pub const DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS: f64 = 4.0;

/// Conservative default continuous refill rate, in tokens per second.
pub const DEFAULT_REFILL_TOKENS_PER_SECOND: f64 = 2.0;

/// Longest rate-limiter wait before a fetch is refused outright.
pub const DEFAULT_MAXIMUM_WAIT_SECONDS: u64 = 10;

/// Default retry budget for idempotent tile GETs.
pub const DEFAULT_MAXIMUM_RETRY_ATTEMPTS: u32 = 2;

/// Character cap on error bodies echoed into error strings, so a huge error
/// response cannot bloat the diagnostic text.
const MAXIMUM_ERROR_BODY_TAIL: usize = 256;

/// Highest zoom level whose full XYZ index range still fits a `u32`
/// (`2^zoom_level - 1 <= u32::MAX`); at deeper zooms every `u32` tile index
/// the contract carries is valid, so the index bound check does not apply.
const MAXIMUM_ZOOM_LEVEL_WITH_BOUNDED_TILE_INDICES: u8 = 32;

/// Serves any web-mercator XYZ vector tileset that publishes a
/// `{z}/{x}/{y}` URL template.
pub struct UrlTemplateVectorTileProvider {
    url_template: UrlTemplate,
    source_descriptor: VectorTileSourceDescriptor,
    transport: Arc<dyn HttpTransport>,
    rate_limiter: TokenBucketRateLimiter,
    maximum_retry_attempts: u32,
}

impl UrlTemplateVectorTileProvider {
    /// Builds the source from a URL template, the tileset descriptor it
    /// serves and the transport every fetch executes through.
    ///
    /// The template is validated here, so a source is never constructed with
    /// a missing placeholder, an unsupported placeholder or a non-HTTP
    /// scheme; the descriptor's name must be non-empty (it is every
    /// diagnostic's subject) and its zoom range must not be inverted.
    pub fn new(
        url_template: impl Into<String>,
        source_descriptor: VectorTileSourceDescriptor,
        transport: Arc<dyn HttpTransport>,
    ) -> Result<Self, SDKError> {
        if source_descriptor.source_name.trim().is_empty() {
            return Err(SDKError::InvalidCoordinateInput(
                "the vector tile source name must be non-empty".to_string(),
            ));
        }
        if source_descriptor.minimum_zoom_level > source_descriptor.maximum_zoom_level {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "the {} vector tile source declares the inverted zoom range \
                 {}..={}",
                source_descriptor.source_name,
                source_descriptor.minimum_zoom_level,
                source_descriptor.maximum_zoom_level
            )));
        }
        Ok(Self {
            url_template: UrlTemplate::new(url_template)?,
            source_descriptor,
            transport,
            rate_limiter: TokenBucketRateLimiter::new(
                DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS,
                DEFAULT_REFILL_TOKENS_PER_SECOND,
                DEFAULT_MAXIMUM_WAIT_SECONDS,
            )?,
            maximum_retry_attempts: DEFAULT_MAXIMUM_RETRY_ATTEMPTS,
        })
    }

    /// Rejects tile coordinates the declared tileset cannot serve, before
    /// the rate limiter or the network is touched.
    fn validate_tile_coordinates(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
    ) -> Result<(), SDKError> {
        if zoom_level < self.source_descriptor.minimum_zoom_level
            || zoom_level > self.source_descriptor.maximum_zoom_level
        {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "zoom level {zoom_level} is outside the {}..={} range the {} vector tile source \
                 declares",
                self.source_descriptor.minimum_zoom_level,
                self.source_descriptor.maximum_zoom_level,
                self.source_descriptor.source_name
            )));
        }
        if zoom_level < MAXIMUM_ZOOM_LEVEL_WITH_BOUNDED_TILE_INDICES {
            let maximum_tile_index = (1u32 << zoom_level) - 1;
            if tile_x > maximum_tile_index || tile_y > maximum_tile_index {
                return Err(SDKError::InvalidCoordinateInput(format!(
                    "tile x={tile_x} y={tile_y} exceeds the {maximum_tile_index} maximum at zoom \
                     {zoom_level}"
                )));
            }
        }
        Ok(())
    }
}

#[async_trait]
impl VectorTileProvider for UrlTemplateVectorTileProvider {
    fn source_descriptor(&self) -> VectorTileSourceDescriptor {
        self.source_descriptor.clone()
    }

    async fn fetch_vector_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
    ) -> Result<VectorTileData, SDKError> {
        self.validate_tile_coordinates(tile_x, tile_y, zoom_level)?;
        self.rate_limiter.acquire().await?;
        let request = HttpRequest {
            method: HttpMethod::Get,
            url: self.url_template.expand(tile_x, tile_y, zoom_level),
            headers: Vec::new(),
            body: None,
        };
        let wire_bytes = execute_idempotent_get(
            self.transport.as_ref(),
            &request,
            RetryPolicy::new(self.maximum_retry_attempts),
            interpret_tile_response,
        )
        .await?;
        VectorTileData::from_wire_bytes(tile_x, tile_y, zoom_level, wire_bytes)
    }
}

/// Interprets one tile response: a non-success status maps through the
/// source's status vocabulary (with a bounded body tail for diagnostics),
/// anything else returns the raw tile bytes.
fn interpret_tile_response(response: HttpResponse) -> Result<Vec<u8>, SDKError> {
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        let response_body_tail = String::from_utf8_lossy(&response.body)
            .chars()
            .take(MAXIMUM_ERROR_BODY_TAIL)
            .collect::<String>();
        return Err(map_http_error_response(
            response.status_code,
            &response_body_tail,
        ));
    }
    Ok(response.body)
}

#[cfg(test)]
mod tests {
    use super::{DEFAULT_MAXIMUM_RETRY_ATTEMPTS, UrlTemplateVectorTileProvider};
    use async_trait::async_trait;
    use geospatial_traits::{VectorTileProvider, VectorTileSourceDescriptor};
    use geospatial_types::{SDKError, VectorTileEncoding};
    use provider_transport::{HttpRequest, HttpResponse, HttpTransport, TransportError};
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// Transport that answers every request with a fixed status and body and
    /// counts executions, so a test can prove the retry budget exactly.
    struct FixedStatusTransport {
        status_code: u16,
        body: Vec<u8>,
        execution_count: AtomicUsize,
    }

    impl FixedStatusTransport {
        fn new(status_code: u16, body: Vec<u8>) -> Self {
            Self {
                status_code,
                body,
                execution_count: AtomicUsize::new(0),
            }
        }

        fn execution_count(&self) -> usize {
            self.execution_count.load(Ordering::SeqCst)
        }
    }

    #[async_trait]
    impl HttpTransport for FixedStatusTransport {
        async fn execute(&self, _request: HttpRequest) -> Result<HttpResponse, TransportError> {
            self.execution_count.fetch_add(1, Ordering::SeqCst);
            Ok(HttpResponse {
                status_code: self.status_code,
                headers: Vec::new(),
                body: self.body.clone(),
            })
        }
    }

    /// Smallest plausible MVT envelope (the repeated `layers` field key).
    const SAMPLE_TILE_BYTES: [u8; 2] = [0x1a, 0x00];

    /// Two-byte gzip magic, the wire encoding `VectorTileData` sniffs.
    const GZIP_MAGIC_BYTES: [u8; 2] = [0x1f, 0x8b];

    fn source_descriptor() -> VectorTileSourceDescriptor {
        VectorTileSourceDescriptor {
            source_name: "test/url-template".to_string(),
            attribution_text: "Test tiles".to_string(),
            minimum_zoom_level: 0,
            maximum_zoom_level: 15,
        }
    }

    fn provider_with_transport(
        transport: Arc<FixedStatusTransport>,
    ) -> UrlTemplateVectorTileProvider {
        UrlTemplateVectorTileProvider::new(
            "http://localhost.test/{z}/{x}/{y}.mvt",
            source_descriptor(),
            transport,
        )
        .expect("the sample template is valid")
    }

    #[test]
    fn source_descriptor_is_returned_verbatim() {
        let provider = provider_with_transport(Arc::new(FixedStatusTransport::new(
            200,
            SAMPLE_TILE_BYTES.to_vec(),
        )));
        assert_eq!(provider.source_descriptor(), source_descriptor());
    }

    #[test]
    fn an_inverted_zoom_range_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let inverted_zoom_range = UrlTemplateVectorTileProvider::new(
            "http://localhost.test/{z}/{x}/{y}.mvt",
            VectorTileSourceDescriptor {
                minimum_zoom_level: 14,
                maximum_zoom_level: 6,
                ..source_descriptor()
            },
            transport,
        );
        assert!(matches!(
            inverted_zoom_range,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }

    #[test]
    fn an_empty_source_name_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let unnamed_source = UrlTemplateVectorTileProvider::new(
            "http://localhost.test/{z}/{x}/{y}.mvt",
            VectorTileSourceDescriptor {
                source_name: "  ".to_string(),
                ..source_descriptor()
            },
            transport,
        );
        assert!(matches!(
            unnamed_source,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }

    #[tokio::test]
    async fn fetches_and_classifies_plain_wire_bytes() {
        let provider = provider_with_transport(Arc::new(FixedStatusTransport::new(
            200,
            SAMPLE_TILE_BYTES.to_vec(),
        )));
        let tile = provider.fetch_vector_tile(2, 1, 3).await.unwrap();
        assert_eq!(tile.tile_x, 2);
        assert_eq!(tile.tile_y, 1);
        assert_eq!(tile.zoom_level, 3);
        assert_eq!(tile.tile_encoding, VectorTileEncoding::MapboxVectorTile);
        assert_eq!(tile.tile_bytes, SAMPLE_TILE_BYTES.to_vec());
    }

    #[tokio::test]
    async fn gzip_wrapped_wire_bytes_report_the_gzip_encoding() {
        let provider = provider_with_transport(Arc::new(FixedStatusTransport::new(
            200,
            GZIP_MAGIC_BYTES.to_vec(),
        )));
        let tile = provider.fetch_vector_tile(2, 1, 3).await.unwrap();
        assert_eq!(
            tile.tile_encoding,
            VectorTileEncoding::GzippedMapboxVectorTile
        );
    }

    #[tokio::test]
    async fn zoom_outside_the_declared_bounds_is_rejected_without_a_request() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        assert!(matches!(
            provider
                .fetch_vector_tile(0, 0, source_descriptor().maximum_zoom_level + 1)
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));

        let floor_transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let floor_provider = UrlTemplateVectorTileProvider::new(
            "http://localhost.test/{z}/{x}/{y}.mvt",
            VectorTileSourceDescriptor {
                minimum_zoom_level: 3,
                ..source_descriptor()
            },
            floor_transport.clone(),
        )
        .expect("the sample template is valid");
        assert!(matches!(
            floor_provider.fetch_vector_tile(0, 0, 2).await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));

        assert_eq!(transport.execution_count(), 0);
        assert_eq!(floor_transport.execution_count(), 0);
    }

    #[tokio::test]
    async fn tile_indexes_outside_the_zoom_range_are_rejected_without_a_request() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        // At zoom 3 only 0..=7 indexes exist; 8 is out of range.
        assert!(matches!(
            provider.fetch_vector_tile(8, 1, 3).await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        assert!(matches!(
            provider.fetch_vector_tile(1, 8, 3).await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        assert_eq!(transport.execution_count(), 0);
    }

    #[tokio::test]
    async fn repeated_server_errors_stop_at_the_retry_budget() {
        let transport = Arc::new(FixedStatusTransport::new(503, b"overloaded".to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        let error = provider.fetch_vector_tile(2, 1, 3).await.unwrap_err();
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
        assert_eq!(
            transport.execution_count(),
            (DEFAULT_MAXIMUM_RETRY_ATTEMPTS + 1) as usize
        );
    }

    #[tokio::test]
    async fn client_error_surfaces_without_retrying() {
        let transport = Arc::new(FixedStatusTransport::new(404, b"not found".to_vec()));
        let provider = provider_with_transport(Arc::clone(&transport));
        let error = provider.fetch_vector_tile(2, 1, 3).await.unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
        assert_eq!(transport.execution_count(), 1);
    }

    #[test]
    fn invalid_template_is_refused_at_construction() {
        let transport = Arc::new(FixedStatusTransport::new(200, SAMPLE_TILE_BYTES.to_vec()));
        assert!(matches!(
            UrlTemplateVectorTileProvider::new(
                "http://localhost.test/{x}/{y}.mvt",
                source_descriptor(),
                transport,
            ),
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }
}
