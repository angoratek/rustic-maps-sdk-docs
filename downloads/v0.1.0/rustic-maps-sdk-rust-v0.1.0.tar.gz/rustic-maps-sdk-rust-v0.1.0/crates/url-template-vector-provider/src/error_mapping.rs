//! Status-to-error mapping for a vendor-neutral URL-template tile source.
//!
//! The source is one raw binary tile endpoint: failures surface as HTTP
//! statuses only. The statuses keep the SDK-wide vocabulary — 429 is the
//! provider's rate signal, 5xx is a transient provider-side overflow, and
//! everything else rejects the request itself. Both tile contracts this
//! crate family serves (vector and raster, `url-template-raster-provider`)
//! share this one mapping, so the vocabulary can never drift between them.

use geospatial_types::SDKError;

/// The HTTP status a tileset uses for its rate signal.
const HTTP_TOO_MANY_REQUESTS_STATUS: u16 = 429;

/// First status in the server-error range (transient, retried in bounds).
const SERVER_ERROR_STATUS_FLOOR: u16 = 500;

/// Translates a non-success HTTP status returned by the tileset.
pub fn map_http_error_response(status: u16, response_body_tail: &str) -> SDKError {
    map_http_error_response_for_source("vector tile source", status, response_body_tail)
}

/// Translates a non-success HTTP status for one named source: the same
/// vocabulary as [`map_http_error_response`], with the tile contract's own
/// noun in the detail so a raster source never reports itself as a vector
/// one.
pub fn map_http_error_response_for_source(
    source_description: &str,
    status: u16,
    response_body_tail: &str,
) -> SDKError {
    match status {
        HTTP_TOO_MANY_REQUESTS_STATUS => SDKError::RateLimitExhausted,
        status if status >= SERVER_ERROR_STATUS_FLOOR => SDKError::NetworkRequestFailed(format!(
            "{source_description} unavailable (HTTP {status}): {response_body_tail}"
        )),
        _ => SDKError::ProviderRequestRejected(format!(
            "{source_description} returned HTTP {status}: {response_body_tail}"
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::map_http_error_response;
    use geospatial_types::SDKError;
    use provider_transport::is_transient_error;

    #[test]
    fn http_429_maps_to_rate_limit_exhausted_and_is_retryable() {
        assert!(matches!(
            map_http_error_response(429, ""),
            SDKError::RateLimitExhausted
        ));
        assert!(is_transient_error(&map_http_error_response(429, "")));
    }

    #[test]
    fn http_404_maps_to_provider_request_rejected_non_retryably() {
        let error = map_http_error_response(404, "tile not found");
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
        assert!(!is_transient_error(&error));
    }

    #[test]
    fn http_5xx_maps_to_network_failure_and_is_retryable() {
        let error = map_http_error_response(503, "overloaded");
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
        assert!(is_transient_error(&error));
    }
}
