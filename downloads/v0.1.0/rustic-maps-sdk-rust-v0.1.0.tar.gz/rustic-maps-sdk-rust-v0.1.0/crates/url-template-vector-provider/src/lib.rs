//! A provider-neutral vector-tile source driven by a `{z}/{x}/{y}` URL
//! template.
//!
//! [`UrlTemplateVectorTileProvider`] implements
//! [`geospatial_traits::VectorTileProvider`] for any web-mercator XYZ
//! tileset that publishes a URL template — the shape a TileJSON `tiles`
//! array names — with no vendor-specific code. The template's authority,
//! path layout, file extension and query string all come from the caller,
//! so a new tileset is a template plus a
//! [`geospatial_traits::VectorTileSourceDescriptor`], never a new provider
//! crate.
//!
//! The template must carry the `{z}`, `{x}` and `{y}` placeholders and use
//! the `http` or `https` scheme; [`UrlTemplate::new`] refuses anything else
//! at construction. Requests are paced by the shared token bucket and
//! transient failures are retried in bounds through [`provider_transport`],
//! so the source behaves like the SDK's concrete providers on every target.
//! Tiles are returned in their wire encoding; gzip sniffing stays in
//! [`geospatial_types::VectorTileData`].

pub mod error_mapping;
pub mod provider;
pub mod url_template;

pub use provider::UrlTemplateVectorTileProvider;
pub use url_template::UrlTemplate;
