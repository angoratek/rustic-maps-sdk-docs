//! End-to-end tests for the URL-template source against a local
//! `std::net::TcpListener` HTTP server.
//!
//! The server replays a scripted list of responses in order and records the
//! request path of every connection, so the tests prove the real fetch, the
//! status mapping and the transient retry path without touching the network.

use geospatial_traits::{VectorTileProvider, VectorTileSourceDescriptor};
use geospatial_types::{SDKError, VectorTileEncoding};
use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use url_template_vector_provider::UrlTemplateVectorTileProvider;

/// Smallest plausible MVT envelope (the repeated `layers` field key).
const SAMPLE_TILE_BYTES: [u8; 2] = [0x1a, 0x00];

/// HTTP status the scripted server returns for a successful tile.
const HTTP_OK_STATUS: u16 = 200;

/// HTTP status the scripted server returns for a missing tile.
const HTTP_NOT_FOUND_STATUS: u16 = 404;

/// HTTP status the scripted server returns for a transient failure.
const HTTP_SERVICE_UNAVAILABLE_STATUS: u16 = 503;

/// One response the scripted server writes, then closes the connection.
struct ScriptedHttpResponse {
    status_code: u16,
    body: Vec<u8>,
}

/// A local HTTP server bound to an ephemeral loopback port.
struct ScriptedHttpServer {
    base_url: String,
    request_paths: Arc<Mutex<Vec<String>>>,
}

impl ScriptedHttpServer {
    /// Starts a server answering one connection per scripted response.
    fn start(scripted_responses: Vec<ScriptedHttpResponse>) -> Self {
        let listener =
            TcpListener::bind("127.0.0.1:0").expect("the local test server must bind loopback");
        let bound_address = listener
            .local_addr()
            .expect("the bound address must be readable");
        let request_paths = Arc::new(Mutex::new(Vec::new()));
        let recorded_paths = Arc::clone(&request_paths);
        thread::spawn(move || {
            for scripted_response in scripted_responses {
                let Ok((stream, _peer_address)) = listener.accept() else {
                    break;
                };
                let request_path = read_request_path(&stream);
                recorded_paths
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner())
                    .push(request_path);
                write_response(stream, scripted_response);
            }
        });
        Self {
            base_url: format!("http://{bound_address}"),
            request_paths,
        }
    }

    /// The request paths the server received, in arrival order.
    fn request_paths(&self) -> Vec<String> {
        self.request_paths
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
    }
}

/// Reads the request line and drains the header block, returning the path.
fn read_request_path(stream: &TcpStream) -> String {
    let mut reader = BufReader::new(
        stream
            .try_clone()
            .expect("the test server must clone its stream"),
    );
    let mut request_line = String::new();
    reader
        .read_line(&mut request_line)
        .expect("the request line must be readable");
    let mut header_line = String::new();
    loop {
        header_line.clear();
        let bytes_read = reader
            .read_line(&mut header_line)
            .expect("the header block must be readable");
        if bytes_read == 0 || header_line == "\r\n" || header_line == "\n" {
            break;
        }
    }
    request_line
        .split_whitespace()
        .nth(1)
        .unwrap_or_default()
        .to_string()
}

/// Writes one HTTP/1.1 response and lets the stream close.
fn write_response(mut stream: TcpStream, scripted_response: ScriptedHttpResponse) {
    let reason_phrase = match scripted_response.status_code {
        HTTP_OK_STATUS => "OK",
        HTTP_NOT_FOUND_STATUS => "Not Found",
        HTTP_SERVICE_UNAVAILABLE_STATUS => "Service Unavailable",
        _ => "Unknown",
    };
    let response_head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: application/x-protobuf\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        scripted_response.status_code,
        reason_phrase,
        scripted_response.body.len()
    );
    stream
        .write_all(response_head.as_bytes())
        .expect("the response head must be writable");
    stream
        .write_all(&scripted_response.body)
        .expect("the response body must be writable");
    stream.flush().expect("the response must flush");
}

/// Builds a provider whose template points at the scripted server.
fn provider_for(server: &ScriptedHttpServer) -> UrlTemplateVectorTileProvider {
    UrlTemplateVectorTileProvider::new(
        format!("{}/tiles/{{z}}/{{x}}/{{y}}.mvt", server.base_url),
        VectorTileSourceDescriptor {
            source_name: "test/local-template".to_string(),
            attribution_text: "Test tiles".to_string(),
            minimum_zoom_level: 0,
            maximum_zoom_level: 15,
        },
        Arc::new(
            provider_transport::ReqwestTransport::new().expect("the test transport must build"),
        ),
    )
    .expect("the scripted template is valid")
}

#[tokio::test]
async fn fetches_a_tile_from_the_expanded_template() {
    let server = ScriptedHttpServer::start(vec![ScriptedHttpResponse {
        status_code: HTTP_OK_STATUS,
        body: SAMPLE_TILE_BYTES.to_vec(),
    }]);
    let provider = provider_for(&server);

    let tile = provider.fetch_vector_tile(2, 1, 3).await.unwrap();

    assert_eq!(tile.tile_x, 2);
    assert_eq!(tile.tile_y, 1);
    assert_eq!(tile.zoom_level, 3);
    assert_eq!(tile.tile_encoding, VectorTileEncoding::MapboxVectorTile);
    assert_eq!(tile.tile_bytes, SAMPLE_TILE_BYTES.to_vec());
    assert_eq!(server.request_paths(), vec!["/tiles/3/2/1.mvt".to_string()]);
}

#[tokio::test]
async fn not_found_maps_to_a_provider_rejection() {
    let server = ScriptedHttpServer::start(vec![ScriptedHttpResponse {
        status_code: HTTP_NOT_FOUND_STATUS,
        body: b"tile not found".to_vec(),
    }]);
    let provider = provider_for(&server);

    let error = provider.fetch_vector_tile(2, 1, 3).await.unwrap_err();

    assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    assert_eq!(server.request_paths(), vec!["/tiles/3/2/1.mvt".to_string()]);
}

#[tokio::test]
async fn transient_server_error_retries_until_success() {
    let server = ScriptedHttpServer::start(vec![
        ScriptedHttpResponse {
            status_code: HTTP_SERVICE_UNAVAILABLE_STATUS,
            body: b"overloaded".to_vec(),
        },
        ScriptedHttpResponse {
            status_code: HTTP_OK_STATUS,
            body: SAMPLE_TILE_BYTES.to_vec(),
        },
    ]);
    let provider = provider_for(&server);

    let tile = provider.fetch_vector_tile(2, 1, 3).await.unwrap();

    assert_eq!(tile.tile_bytes, SAMPLE_TILE_BYTES.to_vec());
    assert_eq!(
        server.request_paths(),
        vec![
            "/tiles/3/2/1.mvt".to_string(),
            "/tiles/3/2/1.mvt".to_string()
        ]
    );
}
