# Render glyph fixtures

- `noto_sans_regular_0-255.pbf` — one real Mapbox glyph-protocol range (the
  `glyphs` protobuf message, 76,580 bytes, SHA-256
  `ef1f38a3f1978591e846e9eaddf8a54f7047f546fc6aaed7872cc53151a5de78`),
  fetched from
  `https://tiles.openfreemap.org/fonts/Noto%20Sans%20Regular/0-255.pbf` on
  **2026-10-30**. The address is the `glyphs_url_template`
  (`https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf`) of the
  `openfreemap` descriptor in `platform/providers.json` with the Bright
  style's font stack (`Noto Sans Regular`) and the Basic Latin range
  substituted; the OpenStreetMap US descriptor publishes the same protocol at
  `https://tiles.openstreetmap.us/fonts/{fontstack}/{range}.pbf`. The payload
  is the plain protobuf body, not gzip-wrapped.

  The font stack record names the CSS fallback list the producer rendered
  (`Noto Sans Regular, Noto Naskh Arabic Regular, Noto Sans Armenian Regular,
  …`) and carries 223 glyphs; this slice consumes the Latin ones only. Glyphs
  are signed-distance-field bitmaps with a 3-pixel border, rendered at the
  protocol's 24-pixel em.

  The fixture is served same-origin by `platform/web/serve.mjs` on
  `/glyphs/{fontstack}/{range}.pbf` (only this recorded range answers; every
  other address is a 404), exactly like the recorded raster tiles. Tests never
  touch the network: the native golden and the browser label suite read this
  committed file. Map data © OpenStreetMap contributors; glyph rendering
  served by OpenFreeMap under the OpenFreeMap terms
  (<https://openfreemap.org>).
