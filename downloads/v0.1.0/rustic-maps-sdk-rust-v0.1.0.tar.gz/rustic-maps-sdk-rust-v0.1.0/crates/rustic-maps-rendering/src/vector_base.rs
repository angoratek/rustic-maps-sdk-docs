//! Shared vector-tile base pipeline: one scheduler that fetches a vector
//! tileset through the [`VectorTileProvider`] trait, decodes each tile once,
//! styles it, and answers the overlay primitives the frame draws beneath its
//! own overlays.
//!
//! Every target serves its vector base through this one implementation, so the
//! native surfaces and the browser cannot drift in what a tile paints. The
//! scheduler owns two caches:
//!
//! - **Decoded tiles**, keyed by the tile address: a tile's bytes are fetched
//!   and decoded once and never again while it stays cached; a style change
//!   restyles the decoded tile instead of refetching it.
//! - **Styled geometry**, keyed by the tile address, the style revision and the
//!   style's zoom bucket: the style's zoom span (`min_zoom`/`max_zoom`) and
//!   width stops are evaluated at the camera's zoom level, so a camera pan
//!   across a width stop repaints the tile from the style it already carries —
//!   no refetch, no decode. The zoom level quantizes to
//!   [`VECTOR_BASE_STYLE_ZOOM_QUANTIZATION_STEPS_PER_LEVEL`] steps per level so
//!   a continuous zoom gesture cannot grow the styled cache without bound.
//!
//! A tile that fails to fetch or decode does not fail the frame: the scheduler
//! skips it, keeps painting the tiles that succeeded, and reports the failure
//! in the frame's counts and its last failure detail. The base map is one layer
//! of a frame, never the frame's reason to fail.
//!
//! # Latency: payload cache, deliberate prefetch, progressive draw
//!
//! The camera-facing [`VectorBaseScheduler::cached_frame`] never waits on the
//! network: it paints the decoded tiles the cache holds, reports the rest as
//! pending or failed, and lets a detached prefetch fill the gaps. A missing
//! tile whose ancestor is cached draws that ancestor at the same camera zoom
//! (the raster path's parent-fallback semantics), so a new area blurs in at
//! coarse detail instead of flashing holes.
//!
//! Fetched wire payloads additionally pass through a
//! [`rustic_maps_core::CachedResponseStore`] keyed by the tileset's source name
//! and the tile address. The native surfaces install their disk store (TTL,
//! LRU and quota), so a region browsed once survives the next session; the
//! browser installs [`VectorTileMemoryCache`], the same policy in memory where
//! no SQLite exists.
//!
//! [`VectorBaseScheduler::prefetch_missing_tiles`] claims the visible misses;
//! [`VectorBaseScheduler::prefetch_ring_tiles`] then claims the ring around the
//! viewport (and the coarse parents that back a fallback) under a small budget.
//! Both return cancellable detached futures: a dropped future releases its
//! claims, so a scheduler that is replaced mid-fetch never strands a tile
//! address as permanently in flight.
//!
//! The scheduler is camera-agnostic: the caller lists the visible tile
//! addresses (through `MapCamera::visible_tile_keys` or the page's own grid)
//! and names the camera's zoom level; [`VectorBaseScheduler::served_zoom_level`]
//! clamps that listing to the tileset's declared zoom span.
//!
//! Each resolved frame also carries the drawn tiles' label candidates, read
//! from the active style's symbol layers. [`VectorBaseFrame::label_layer`]
//! places them at a camera pose through the SDK's embedded default glyph font,
//! so every platform surface draws the same place names without a
//! platform-specific asset. A frame without candidates yields `None` and
//! costs the renderer nothing.

use crate::camera::{MapCamera, ViewportPixels};
use crate::labels::{
    LabelFont, LabelLayer, MapLabelCandidate, default_label_font, label_candidates_for_vector_tile,
};
use crate::overlay::MapOverlay;
use crate::tile_key::TileKey;
use crate::vector_style::{
    VectorStyleArtifactError, VectorTileAddress, vector_tile_overlay_layers_at_zoom,
    vector_tile_style_from_id,
};
use flate2::read::GzDecoder;
use futures::future::join_all;
use geospatial_traits::{VectorTileProvider, VectorTileSourceDescriptor};
use geospatial_types::{VectorTileData, VectorTileEncoding};
use rustic_maps_core::CachedResponseStore;
use rustic_maps_style::CompiledStyle;
use rustic_maps_vector_tiles::{
    MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES, VectorTile, decode_vector_tile,
};
use std::collections::{HashMap, HashSet, VecDeque};
use std::io::Read;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, PoisonError};
use web_time::{Duration, Instant};

/// The decoded-tile cache's default capacity. A 1080p frame asks for a few
/// dozen tiles, so the cache holds several camera positions' worth of decoded
/// geometry: a pan back over visited ground repaints without refetching.
pub const DEFAULT_VECTOR_BASE_MAXIMUM_CACHED_TILE_COUNT: usize = 512;

/// The styled-geometry cache's default capacity, in styled tiles. One decoded
/// tile can be styled once per zoom bucket the camera passed through, so this
/// cache is bounded on its own rather than only by decoded-tile eviction: four
/// buckets' worth of the decoded capacity covers a pan and a zoom while a
/// tile stays resident, and nothing beyond that is retained.
pub const DEFAULT_VECTOR_BASE_MAXIMUM_CACHED_STYLED_TILE_COUNT: usize =
    4 * DEFAULT_VECTOR_BASE_MAXIMUM_CACHED_TILE_COUNT;

/// How many style-zoom buckets one zoom level divides into. A bucket is the
/// granularity at which a restyle repaints: the camera zoom quantizes to the
/// nearest bucket, so a continuous zoom gesture restyles at most this many
/// times per level instead of once per frame.
pub const VECTOR_BASE_STYLE_ZOOM_QUANTIZATION_STEPS_PER_LEVEL: f64 = 4.0;

/// The default time-to-live of one persisted vector-tile payload: thirty
/// calendar days, the tile-imagery policy the provider crates assert against
/// the cache's `ResponseCategory::VectorTiles` default. A host that declares
/// a stricter ceiling passes its own value through
/// [`VectorBaseScheduler::with_payload_cache`].
pub const DEFAULT_VECTOR_TILE_PAYLOAD_TIME_TO_LIVE_SECONDS: u64 = 30 * 24 * 60 * 60;

/// The in-memory vector-tile payload cache's default capacity, in tiles. The
/// browser has no disk store, so the cache is process memory: a hundred-odd
/// wire payloads cover a viewport's worth of panning and a style switch
/// without holding a whole session's tiles decoded as well.
pub const DEFAULT_VECTOR_TILE_MEMORY_CACHE_MAXIMUM_TILE_COUNT: usize = 128;

/// How many ring tiles one detached prefetch plan may claim. The ring is an
/// anticipation, not a requirement: a few tiles around the viewport turn the
/// first pan into a cache hit without spending the service's low-volume
/// budget on a whole neighborhood.
pub const DEFAULT_VECTOR_BASE_PREFETCH_RING_TILE_BUDGET: usize = 32;

/// How many distinct failing tile addresses the scheduler keeps a failure
/// detail for. The map is a diagnostic aid, not a record: past this bound
/// each new failure evicts one existing entry, so a long session over failing
/// ground cannot grow it without limit.
const MAXIMUM_RECORDED_FAILURE_DETAILS: usize = 256;

/// The minimum interval between two ring prefetch plans. A plan is an
/// anticipation, so one every half second is enough to stay ahead of a
/// sustained pan while leaving the service and the frame loop alone; the
/// plan also waits until the visible set's own fetches have landed.
pub const DEFAULT_VECTOR_BASE_RING_PREFETCH_MINIMUM_INTERVAL_MILLISECONDS: u64 = 500;

/// The eight neighbor offsets a viewport ring is grown with, in tile units.
const VECTOR_BASE_RING_NEIGHBOR_OFFSETS: [(i32, i32); 8] = [
    (-1, -1),
    (0, -1),
    (1, -1),
    (-1, 0),
    (1, 0),
    (-1, 1),
    (0, 1),
    (1, 1),
];

/// One resolved frame's cache and latency accounting, read beside the tile
/// counts so a device measurement can answer "is it the server?" with data.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct VectorBaseFrameDiagnostics {
    /// Payload-cache lookups that hit, cumulative over this scheduler's
    /// fetches (zero while no payload cache is installed).
    pub payload_cache_hit_count: u64,
    /// Payload-cache lookups that missed (or failed to read, degrading to the
    /// network), cumulative over this scheduler's fetches.
    pub payload_cache_miss_count: u64,
    /// Tile addresses with a fetch or decode running when the frame resolved.
    pub in_flight_fetch_count: usize,
    /// Milliseconds from installing the scheduler to the first frame that
    /// painted any tile (own or fallback), or `None` while nothing has
    /// painted yet.
    pub time_to_first_drawn_tile_milliseconds: Option<u64>,
}

/// One resolved vector base frame: the overlay primitives to draw beneath the
/// caller's overlays plus the honest counts of what the frame drew.
#[derive(Debug, Clone, PartialEq)]
pub struct VectorBaseFrame {
    /// The base overlay primitives in global style order: every tile's layer 0
    /// first, then every tile's layer 1, and so on (later entries paint over
    /// earlier ones). Within one style layer the tiles keep their address
    /// order, with coarse ancestor stand-ins before the tiles they cover.
    pub overlays: Vec<MapOverlay>,
    /// The frame's label candidates, read from the drawn tiles' symbol layers
    /// under the active style, in tile-address order and then style-layer
    /// order. Empty when the style declares no symbol layer or no drawn tile
    /// carries one, so a frame without labels stays label-free.
    pub label_candidates: Vec<MapLabelCandidate>,
    /// The distinct tile addresses the frame asked for, after clamping and
    /// deduplication.
    pub requested_tile_count: usize,
    /// How many of those tiles the frame drew at their own zoom.
    pub drawn_tile_count: usize,
    /// How many of those tiles the frame covered with a cached ancestor while
    /// their own detail is missing (in flight or failed). Each covered tile
    /// also appears in [`Self::pending_tile_count`] or
    /// [`Self::failed_tile_count`], because the ancestor is a stand-in, not
    /// the tile itself; the frame's painted coverage is `drawn + fallback`.
    pub fallback_tile_count: usize,
    /// How many of those tiles failed to fetch or decode this frame.
    pub failed_tile_count: usize,
    /// How many of those tiles have a fetch in flight (or not yet started) and
    /// were therefore neither drawn nor failed this frame. A frame resolved
    /// from the cache alone reports them here, so a caller can tell "loading"
    /// from "failed" and keep presenting while the prefetch runs.
    pub pending_tile_count: usize,
    /// The style the frame painted with.
    pub style_id: String,
    /// The style's canvas background, or `None` when the style paints its own
    /// full ground fill. A surface that hides the raster base while the vector
    /// base serves clears to this color beneath the overlays, so the gaps
    /// between the style's translucent fills read as the designed map rather
    /// than as the platform's clear color.
    pub background: Option<[f32; 4]>,
    /// The failure detail of the last tile that failed this frame, if any.
    pub last_failure_detail: Option<String>,
    /// The frame's cache-hit, in-flight and first-drawn-tile accounting.
    pub diagnostics: VectorBaseFrameDiagnostics,
}

impl VectorBaseFrame {
    /// Whether the frame drew every requested tile and none failed — the
    /// base map has nothing left to fetch for this camera.
    pub fn is_idle(&self) -> bool {
        self.failed_tile_count == 0
            && self.pending_tile_count == 0
            && self.fallback_tile_count == 0
            && self.drawn_tile_count == self.requested_tile_count
    }

    /// The frame's label layer at the camera pose, measured and rasterized
    /// through the SDK's embedded default glyph font ([`default_label_font`]).
    ///
    /// `None` when the frame carries no label candidates — a style without
    /// symbol layers, a raster-only view, or no drawn tile naming anything —
    /// so a caller that forwards the layer to the renderer costs no buffer,
    /// no atlas upload and no draw on label-free frames. A frame whose
    /// candidates all collide off-screen also yields an empty layer, which the
    /// renderer treats the same way.
    pub fn label_layer(
        &self,
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
    ) -> Option<LabelLayer> {
        self.label_layer_with_font(
            camera,
            viewport,
            field_of_view_degrees,
            default_label_font(),
        )
    }

    /// [`Self::label_layer`] for a surface whose drawing buffer is not one
    /// device pixel per point: the placed glyph sizes and the fragment edge
    /// gamma follow `device_pixel_ratio`, so the labels keep their declared
    /// point size on a 2× or 3× surface (the style numbers stay the source of
    /// truth for the halo and gamma math).
    pub fn label_layer_with_device_pixel_ratio(
        &self,
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
        device_pixel_ratio: f64,
    ) -> Option<LabelLayer> {
        self.label_layer_with_font_and_device_pixel_ratio(
            camera,
            viewport,
            field_of_view_degrees,
            default_label_font(),
            device_pixel_ratio,
        )
    }

    /// [`Self::label_layer`] against an explicit glyph font: the override for
    /// a caller that supplies its own glyph source instead of the SDK's
    /// embedded Latin range.
    pub fn label_layer_with_font(
        &self,
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
        font: &LabelFont,
    ) -> Option<LabelLayer> {
        self.label_layer_with_font_and_device_pixel_ratio(
            camera,
            viewport,
            field_of_view_degrees,
            font,
            1.0,
        )
    }

    /// [`Self::label_layer_with_font`] for a surface whose drawing buffer is
    /// not one device pixel per point; see
    /// [`Self::label_layer_with_device_pixel_ratio`].
    pub fn label_layer_with_font_and_device_pixel_ratio(
        &self,
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
        font: &LabelFont,
        device_pixel_ratio: f64,
    ) -> Option<LabelLayer> {
        if self.label_candidates.is_empty() {
            return None;
        }
        Some(LabelLayer::place_with_device_pixel_ratio(
            camera,
            viewport,
            field_of_view_degrees,
            &self.label_candidates,
            font,
            device_pixel_ratio,
        ))
    }
}

/// The styled-geometry cache key: one tile's paint under one style revision at
/// one style-zoom bucket.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct StyledTileCacheKey {
    /// The tile the geometry belongs to.
    tile_key: TileKey,
    /// The style revision the overlay geometry was styled under.
    style_revision: u64,
    /// The style zoom bucket (the quantized camera zoom level).
    quantized_style_zoom: i64,
}

/// The decoded-tile cache shared between the presenting frame and its detached
/// prefetch. The frame resolves from whatever the cache already holds, while a
/// spawned prefetch fetches every missing tile concurrently and inserts it, so
/// a first frame over unvisited ground never waits on the network. The cache
/// also remembers in-flight addresses (so a repaint does not start duplicate
/// fetches) and the last failure per address (so a frame can report it until
/// the next prefetch retries).
#[derive(Debug)]
struct DecodedTileCache {
    /// Decoded tiles by address (fetched and decoded once).
    tiles: HashMap<TileKey, Arc<VectorTile>>,
    /// The cache's insertion order, for eviction.
    insertion_order: VecDeque<TileKey>,
    /// Addresses whose fetch is running.
    in_flight: HashSet<TileKey>,
    /// The last failure detail per address, cleared by the retry.
    failure_details: HashMap<TileKey, String>,
    /// The cache's capacity.
    maximum_tile_count: usize,
}

impl DecodedTileCache {
    fn new(maximum_tile_count: usize) -> Self {
        Self {
            tiles: HashMap::new(),
            insertion_order: VecDeque::new(),
            in_flight: HashSet::new(),
            failure_details: HashMap::new(),
            maximum_tile_count,
        }
    }

    fn get(&self, tile_key: &TileKey) -> Option<Arc<VectorTile>> {
        self.tiles.get(tile_key).cloned()
    }

    /// Claims the address for a fetch; `false` when it is already cached or a
    /// fetch is running. Claiming clears any previous failure so the frame
    /// reports "pending", not a stale refusal, while the retry runs.
    fn begin_fetch(&mut self, tile_key: TileKey) -> bool {
        if self.tiles.contains_key(&tile_key) || !self.in_flight.insert(tile_key) {
            return false;
        }
        self.failure_details.remove(&tile_key);
        true
    }

    /// Records one finished fetch: the decoded tile on success, the detail on
    /// failure, and clears the in-flight mark either way.
    fn finish_fetch(&mut self, tile_key: TileKey, outcome: Result<Arc<VectorTile>, String>) {
        self.in_flight.remove(&tile_key);
        match outcome {
            Ok(decoded_tile) => {
                self.failure_details.remove(&tile_key);
                self.insert_decoded_tile(tile_key, decoded_tile);
            }
            Err(failure_detail) => {
                // The failure map is a diagnostic aid, not a record: it is
                // capped so a long session over failing ground cannot grow it
                // without bound.
                if !self.failure_details.contains_key(&tile_key)
                    && self.failure_details.len() >= MAXIMUM_RECORDED_FAILURE_DETAILS
                {
                    if let Some(evicted_key) = self.failure_details.keys().next().copied() {
                        self.failure_details.remove(&evicted_key);
                    }
                }
                self.failure_details.insert(tile_key, failure_detail);
            }
        }
    }

    /// Inserts a decoded tile and evicts the oldest decoded tiles beyond the
    /// cache's capacity. Styled geometry is keyed by the address and a style
    /// revision, so it stays valid for a re-fetched address and is bounded by
    /// its own cache; eviction here never touches it.
    fn insert_decoded_tile(&mut self, tile_key: TileKey, decoded_tile: Arc<VectorTile>) {
        if self.tiles.insert(tile_key, decoded_tile).is_none() {
            self.insertion_order.push_back(tile_key);
        }
        while self.tiles.len() > self.maximum_tile_count {
            let Some(evicted_tile_key) = self.insertion_order.pop_front() else {
                break;
            };
            self.tiles.remove(&evicted_tile_key);
        }
    }
}

/// The in-memory vector-tile payload cache the browser installs where no
/// SQLite store exists: the same cache-then-network policy as the native disk
/// store (a fingerprint key, a time-to-live and a bounded capacity), held in
/// process memory with least-recently-used eviction.
///
/// The cache is shared across scheduler installs, so switching a style or
/// reinstalling the same tileset serves the region from memory instead of
/// refetching it. It never outlives the page.
#[derive(Debug)]
pub struct VectorTileMemoryCache {
    /// The cached payloads and their access order.
    state: Mutex<VectorTileMemoryCacheState>,
    /// The cache's capacity, in tiles.
    maximum_tile_count: usize,
}

#[derive(Debug, Default)]
struct VectorTileMemoryCacheState {
    /// Cached payloads by request fingerprint.
    entries: HashMap<String, VectorTileMemoryCacheEntry>,
    /// Monotonic access stamp, for least-recently-used eviction.
    access_sequence: u64,
}

#[derive(Debug)]
struct VectorTileMemoryCacheEntry {
    /// The stored wire payload.
    payload: Arc<VectorTileData>,
    /// When the entry expires.
    expires_at: Instant,
    /// The access stamp of the entry's last read or write.
    last_accessed: u64,
}

impl VectorTileMemoryCache {
    /// Builds an empty payload cache holding at most `maximum_tile_count`
    /// tiles.
    pub fn new(maximum_tile_count: usize) -> Self {
        Self {
            state: Mutex::new(VectorTileMemoryCacheState::default()),
            maximum_tile_count,
        }
    }

    /// The fingerprints the cache currently holds, for tests and diagnosis.
    pub fn cached_tile_count(&self) -> usize {
        self.state
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .entries
            .len()
    }
}

impl CachedResponseStore<VectorTileData> for VectorTileMemoryCache {
    fn lookup_response(
        &self,
        request_fingerprint: &str,
    ) -> Result<Option<Arc<VectorTileData>>, geospatial_types::SDKError> {
        let mut state = self.state.lock().unwrap_or_else(PoisonError::into_inner);
        let access_stamp = {
            state.access_sequence += 1;
            state.access_sequence
        };
        let Some(entry) = state.entries.get_mut(request_fingerprint) else {
            return Ok(None);
        };
        if entry.expires_at <= Instant::now() {
            state.entries.remove(request_fingerprint);
            return Ok(None);
        }
        entry.last_accessed = access_stamp;
        Ok(Some(Arc::clone(&entry.payload)))
    }

    fn store_response(
        &self,
        request_fingerprint: &str,
        response_value: Arc<VectorTileData>,
        time_to_live_seconds: u64,
    ) -> Result<(), geospatial_types::SDKError> {
        let mut state = self.state.lock().unwrap_or_else(PoisonError::into_inner);
        state.access_sequence += 1;
        let access_stamp = state.access_sequence;
        state.entries.insert(
            request_fingerprint.to_string(),
            VectorTileMemoryCacheEntry {
                payload: response_value,
                expires_at: Instant::now() + Duration::from_secs(time_to_live_seconds),
                last_accessed: access_stamp,
            },
        );
        while state.entries.len() > self.maximum_tile_count {
            let Some(least_recently_used_fingerprint) = state
                .entries
                .iter()
                .min_by_key(|(_, entry)| entry.last_accessed)
                .map(|(fingerprint, _)| fingerprint.clone())
            else {
                break;
            };
            state.entries.remove(&least_recently_used_fingerprint);
        }
        Ok(())
    }
}

/// The cache-then-network hit/miss counters a detached prefetch updates and a
/// frame reads. Shared by `Arc` because the prefetch outlives the frame that
/// started it.
#[derive(Debug, Default)]
struct VectorBasePayloadCacheCounters {
    /// Payload-cache lookups that hit.
    hit_count: AtomicU64,
    /// Payload-cache lookups that missed.
    miss_count: AtomicU64,
}

/// The fingerprint one vector-tile payload is stored under: the response
/// category prefix the disk store reads its TTL category from, the tileset's
/// source name (so two tilesets serving the same address never collide) and
/// the tile address.
fn vector_tile_payload_cache_fingerprint(source_name: &str, tile_key: TileKey) -> String {
    format!(
        "vector_tiles:{source_name}/{}/{}/{}",
        tile_key.zoom_level, tile_key.tile_x, tile_key.tile_y
    )
}

/// The guard of a detached prefetch: it clears the in-flight marks of every
/// claimed tile still undelivered when the future is dropped. Without it, a
/// cancelled prefetch (the runtime shutting down, or a replaced scheduler)
/// would report its addresses pending forever and no later plan would retry
/// them.
struct PrefetchClaimGuard {
    /// The cache the claims live in.
    decoded_tiles: Arc<Mutex<DecodedTileCache>>,
    /// The claimed addresses not yet finished.
    remaining_tile_keys: Vec<TileKey>,
}

impl PrefetchClaimGuard {
    fn new(decoded_tiles: Arc<Mutex<DecodedTileCache>>, claimed_tile_keys: Vec<TileKey>) -> Self {
        Self {
            decoded_tiles,
            remaining_tile_keys: claimed_tile_keys,
        }
    }

    /// Records one finished fetch, so a later drop only clears the claims that
    /// are still genuinely in flight.
    fn mark_finished(&mut self, tile_key: TileKey) {
        self.remaining_tile_keys.retain(|key| *key != tile_key);
    }
}

impl Drop for PrefetchClaimGuard {
    fn drop(&mut self) {
        let mut decoded_tiles = self
            .decoded_tiles
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        for tile_key in &self.remaining_tile_keys {
            decoded_tiles.in_flight.remove(tile_key);
        }
    }
}

/// The shared vector base pipeline: fetches, decodes, styles and caches one
/// vector tileset.
pub struct VectorBaseScheduler {
    /// The tileset the scheduler fetches through.
    provider: Arc<dyn VectorTileProvider>,
    /// The active style's identifier (the style name the status reports).
    style_id: String,
    /// The active style's compiled render plans.
    style: CompiledStyle,
    /// Bumped on every style change; part of the styled cache key so a
    /// geometry styled under a previous style is never reused.
    style_revision: u64,
    /// The decoded-tile cache shared with the detached prefetch.
    decoded_tiles: Arc<Mutex<DecodedTileCache>>,
    /// Styled overlay geometry by tile, style revision and zoom bucket,
    /// bucketed by compiled layer index so frame assembly can paint in global
    /// style order across every tile.
    styled_tiles: HashMap<StyledTileCacheKey, Vec<Vec<MapOverlay>>>,
    /// The styled cache's insertion order, for eviction.
    styled_tile_insertion_order: VecDeque<StyledTileCacheKey>,
    /// The styled cache's capacity.
    maximum_cached_styled_tile_count: usize,
    /// The persistent payload store the fetches pass through, or `None` for
    /// an uncached scheduler.
    payload_cache: Option<Arc<dyn CachedResponseStore<VectorTileData>>>,
    /// The payload store's time-to-live, in seconds.
    payload_cache_time_to_live_seconds: u64,
    /// The payload store's shared hit/miss counters.
    payload_cache_counters: Arc<VectorBasePayloadCacheCounters>,
    /// The ring prefetch's per-plan tile budget.
    maximum_prefetch_ring_tile_count: usize,
    /// The minimum interval between two ring plans.
    ring_prefetch_minimum_interval: Duration,
    /// When the last ring plan was started, for the interval gate.
    last_ring_prefetch_at: Mutex<Option<Instant>>,
    /// When this scheduler was installed, for the first-drawn-tile latency.
    installed_at: Instant,
    /// The time to the first frame that painted any tile, once it happened.
    first_drawn_tile_milliseconds: Option<u64>,
    /// The last frame's last tile failure, for the status readback.
    last_failure_detail: Option<String>,
}

impl VectorBaseScheduler {
    /// Builds a scheduler over the provider and an explicit style definition.
    ///
    /// `style_id` names the style in status readbacks and in the styled cache's
    /// revision; the scheduler itself styles with `style`.
    pub fn new(
        provider: Arc<dyn VectorTileProvider>,
        style_id: impl Into<String>,
        style: CompiledStyle,
    ) -> Self {
        Self {
            provider,
            style_id: style_id.into(),
            style,
            style_revision: 0,
            decoded_tiles: Arc::new(Mutex::new(DecodedTileCache::new(
                DEFAULT_VECTOR_BASE_MAXIMUM_CACHED_TILE_COUNT,
            ))),
            styled_tiles: HashMap::new(),
            styled_tile_insertion_order: VecDeque::new(),
            maximum_cached_styled_tile_count: DEFAULT_VECTOR_BASE_MAXIMUM_CACHED_STYLED_TILE_COUNT,
            payload_cache: None,
            payload_cache_time_to_live_seconds: DEFAULT_VECTOR_TILE_PAYLOAD_TIME_TO_LIVE_SECONDS,
            payload_cache_counters: Arc::new(VectorBasePayloadCacheCounters::default()),
            maximum_prefetch_ring_tile_count: DEFAULT_VECTOR_BASE_PREFETCH_RING_TILE_BUDGET,
            ring_prefetch_minimum_interval: Duration::from_millis(
                DEFAULT_VECTOR_BASE_RING_PREFETCH_MINIMUM_INTERVAL_MILLISECONDS,
            ),
            last_ring_prefetch_at: Mutex::new(None),
            installed_at: Instant::now(),
            first_drawn_tile_milliseconds: None,
            last_failure_detail: None,
        }
    }

    /// Builds a scheduler over the provider and one of the built-in style
    /// artifacts, named by its style id (`bright-light`, `fiord-dark`, …).
    ///
    /// # Parameters
    /// - `provider` — the vector tile source the scheduler fetches from.
    /// - `style_id` — one of the exported `VECTOR_STYLE_ID_*` identifiers.
    ///
    /// # Errors
    /// An unknown id reports the artifact error rather than a guess.
    pub fn from_style_id(
        provider: Arc<dyn VectorTileProvider>,
        style_id: &str,
    ) -> Result<Self, VectorStyleArtifactError> {
        let style = vector_tile_style_from_id(style_id)?;
        Ok(Self::new(provider, style_id, style))
    }

    /// Routes every fetched vector-tile payload through a response store
    /// before decoding it, and stores each fresh payload for
    /// `time_to_live_seconds`. A lookup hit skips the network entirely, so a
    /// region browsed once is served from the store on a later scheduler.
    ///
    /// The store is keyed by the tileset's declared source name and the tile
    /// address; a failing store degrades to network-only operation rather
    /// than failing a frame.
    ///
    /// # Parameters
    /// - `payload_cache` — the store the fetches consult and back-fill.
    /// - `time_to_live_seconds` — how long a stored payload stays valid.
    pub fn with_payload_cache(
        mut self,
        payload_cache: Arc<dyn CachedResponseStore<VectorTileData>>,
        time_to_live_seconds: u64,
    ) -> Self {
        self.payload_cache = Some(payload_cache);
        self.payload_cache_time_to_live_seconds = time_to_live_seconds;
        self
    }

    /// Overrides the ring prefetch's per-plan tile budget (the test seam and
    /// the host's tuning knob).
    pub fn with_maximum_prefetch_ring_tile_count(mut self, maximum_tile_count: usize) -> Self {
        self.maximum_prefetch_ring_tile_count = maximum_tile_count;
        self
    }

    /// Overrides the minimum interval between two ring prefetch plans (the
    /// test seam; the host keeps the default).
    pub fn with_ring_prefetch_minimum_interval(mut self, minimum_interval: Duration) -> Self {
        self.ring_prefetch_minimum_interval = minimum_interval;
        self
    }

    /// The active style's identifier.
    pub fn style_id(&self) -> &str {
        &self.style_id
    }

    /// The active style's compiled render plans.
    pub fn style(&self) -> &CompiledStyle {
        &self.style
    }

    /// The tileset's descriptor (cache namespace, attribution, zoom span).
    pub fn source_descriptor(&self) -> VectorTileSourceDescriptor {
        self.provider.source_descriptor()
    }

    /// The attribution line the tileset's terms require wherever it is shown.
    pub fn attribution_text(&self) -> String {
        self.provider.source_descriptor().attribution_text
    }

    /// The zoom level the tileset actually serves for a requested zoom level:
    /// the request clamped into the descriptor's declared span, so a camera
    /// beyond either edge keeps a base map at the nearest served resolution.
    /// A descriptor declaring an inverted span clamps to its lower edge rather
    /// than panicking (the providers refuse such a declaration at
    /// construction; a hand-written implementor might not).
    pub fn served_zoom_level(&self, requested_zoom_level: u8) -> u8 {
        let descriptor = self.provider.source_descriptor();
        let lowest_served_zoom_level = descriptor.minimum_zoom_level;
        let highest_served_zoom_level = descriptor.maximum_zoom_level.max(lowest_served_zoom_level);
        requested_zoom_level
            .max(lowest_served_zoom_level)
            .min(highest_served_zoom_level)
    }

    /// The last resolved frame's last tile failure detail, if that frame had
    /// one. Cleared by a frame whose tiles all resolved.
    pub fn last_failure_detail(&self) -> Option<&str> {
        self.last_failure_detail.as_deref()
    }

    /// Replaces the style with the built-in artifact a style id names, keeping
    /// every decoded tile: the next frame restyles the cached tiles under the
    /// new style without fetching them again. An unknown id reports the
    /// artifact error and keeps the current style in force.
    pub fn set_style(&mut self, style_id: &str) -> Result<(), VectorStyleArtifactError> {
        let style = vector_tile_style_from_id(style_id)?;
        self.style = style;
        self.style_id = style_id.to_string();
        self.style_revision += 1;
        // A different style never reuses the previous style's geometry.
        self.styled_tiles.clear();
        self.styled_tile_insertion_order.clear();
        Ok(())
    }

    /// Resolves the base map for the given visible tile addresses and camera
    /// zoom level: every missing tile is fetched and decoded once — the
    /// misses are fetched concurrently, so the frame waits for the slowest
    /// request rather than the sum of all of them — every tile is styled at
    /// the camera zoom's bucket (from the decoded cache when the bucket or
    /// the style changed), and the frame's overlay primitives are returned in
    /// tile-address order. A tile that fails to fetch or decode is skipped,
    /// counted, and covered by its nearest cached ancestor when one exists;
    /// the frame never fails as a whole.
    ///
    /// This is the blocking reference path (tests and captures that want a
    /// settled frame). A presenting surface instead resolves with
    /// [`Self::cached_frame`] and lets the returned detached prefetches fill
    /// the cache.
    pub async fn resolve_frame(
        &mut self,
        visible_tile_keys: &[TileKey],
        style_zoom_level: f64,
    ) -> VectorBaseFrame {
        if let Some(prefetch) = self.prefetch_missing_tiles(visible_tile_keys) {
            prefetch.await;
        }
        self.cached_frame(visible_tile_keys, style_zoom_level)
    }

    /// Claims every visible tile the cache does not hold and answers the
    /// prefetch to spawn detached: it fetches (through the payload cache)
    /// the claimed tiles concurrently, decodes them and writes the results
    /// into the shared cache, returning how many tiles it delivered. `None`
    /// when every visible tile is cached or already being fetched, so a
    /// repaint never starts a duplicate request. The caller presents a
    /// [`Self::cached_frame`] immediately and lets this run.
    ///
    /// The future is cancellable by dropping it: its claims are released, so
    /// no address stays in flight forever.
    pub fn prefetch_missing_tiles(
        &self,
        visible_tile_keys: &[TileKey],
    ) -> Option<impl std::future::Future<Output = usize> + Send + 'static> {
        self.prefetch_tile_keys(visible_tile_keys.to_vec(), None)
    }

    /// Claims the ring around the viewport for a detached prefetch: the eight
    /// neighbors of every visible tile at the served zoom, plus each visible
    /// tile's coarse parent (the fallback that covers the area while the
    /// detailed tile is in flight), under
    /// [`Self::with_maximum_prefetch_ring_tile_count`]'s budget.
    ///
    /// Parents come first because they can cover a missing child immediately;
    /// the rest are ordered by distance from the viewport's center, so a
    /// budgeted plan grows outward instead of claiming a scattered corner.
    /// Nothing already cached, failed or in flight is claimed. `None` when
    /// the ring has nothing left to claim, when a visible tile's own fetch is
    /// still running (the view comes first), or when the previous plan ran
    /// inside the configured interval.
    pub fn prefetch_ring_tiles(
        &self,
        visible_tile_keys: &[TileKey],
    ) -> Option<impl std::future::Future<Output = usize> + Send + 'static> {
        let visible_tiles_are_fetching = {
            let decoded_tiles = self
                .decoded_tiles
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            visible_tile_keys
                .iter()
                .any(|tile_key| decoded_tiles.in_flight.contains(tile_key))
        };
        if visible_tiles_are_fetching {
            return None;
        }
        let candidates = self.ring_prefetch_candidates(visible_tile_keys);
        if candidates.is_empty() {
            return None;
        }
        {
            let mut last_ring_prefetch_at = self
                .last_ring_prefetch_at
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let now = Instant::now();
            if last_ring_prefetch_at.is_some_and(|last_plan_at| {
                now.duration_since(last_plan_at) < self.ring_prefetch_minimum_interval
            }) {
                return None;
            }
            *last_ring_prefetch_at = Some(now);
        }
        self.prefetch_tile_keys(candidates, Some(self.maximum_prefetch_ring_tile_count))
    }

    /// The ring plan: coarse parents first, then same-zoom neighbors ordered
    /// by distance from the visible set's center. The plan is deduplicated
    /// against the visible set; the per-plan budget applies to the tiles the
    /// caches cannot already serve, so budgeted plans are not wasted on
    /// cached neighbors.
    fn ring_prefetch_candidates(&self, visible_tile_keys: &[TileKey]) -> Vec<TileKey> {
        let mut visible_tiles = visible_tile_keys.to_vec();
        visible_tiles.sort();
        visible_tiles.dedup();
        if visible_tiles.is_empty() {
            return Vec::new();
        }
        let served_zoom_level = visible_tiles
            .iter()
            .map(|tile_key| tile_key.zoom_level)
            .max()
            .unwrap_or(0);
        let tiles_per_axis = 1u64
            .checked_shl(u32::from(served_zoom_level))
            .unwrap_or(u64::MAX);
        let visible_tile_set = visible_tiles.iter().copied().collect::<HashSet<_>>();
        let center_tile_x = visible_tiles
            .iter()
            .map(|tile_key| f64::from(tile_key.tile_x))
            .sum::<f64>()
            / visible_tiles.len() as f64;
        let center_tile_y = visible_tiles
            .iter()
            .map(|tile_key| f64::from(tile_key.tile_y))
            .sum::<f64>()
            / visible_tiles.len() as f64;
        let distance_from_center = |tile_key: &TileKey| {
            let horizontal_distance = f64::from(tile_key.tile_x) - center_tile_x;
            let vertical_distance = f64::from(tile_key.tile_y) - center_tile_y;
            horizontal_distance * horizontal_distance + vertical_distance * vertical_distance
        };
        let mut parent_tile_keys = visible_tiles
            .iter()
            .filter_map(|tile_key| tile_key.parent_tile_key())
            .filter(|tile_key| !visible_tile_set.contains(tile_key))
            .collect::<Vec<_>>();
        let mut ring_tile_keys = Vec::new();
        for visible_tile in &visible_tiles {
            for (horizontal_offset, vertical_offset) in VECTOR_BASE_RING_NEIGHBOR_OFFSETS {
                let neighbor_tile_x = i64::from(visible_tile.tile_x) + i64::from(horizontal_offset);
                let neighbor_tile_y = i64::from(visible_tile.tile_y) + i64::from(vertical_offset);
                if neighbor_tile_x < 0 || neighbor_tile_y < 0 {
                    continue;
                }
                if neighbor_tile_x as u64 >= tiles_per_axis
                    || neighbor_tile_y as u64 >= tiles_per_axis
                {
                    continue;
                }
                let Ok(neighbor_tile_key) = TileKey::new(
                    neighbor_tile_x as u32,
                    neighbor_tile_y as u32,
                    served_zoom_level,
                ) else {
                    continue;
                };
                if !visible_tile_set.contains(&neighbor_tile_key) {
                    ring_tile_keys.push(neighbor_tile_key);
                }
            }
        }
        parent_tile_keys.sort_by(|first, second| {
            distance_from_center(first)
                .total_cmp(&distance_from_center(second))
                .then_with(|| first.cmp(second))
        });
        parent_tile_keys.dedup();
        ring_tile_keys.sort_by(|first, second| {
            distance_from_center(first)
                .total_cmp(&distance_from_center(second))
                .then_with(|| first.cmp(second))
        });
        let mut candidates = parent_tile_keys;
        candidates.extend(ring_tile_keys);
        let mut seen_tile_keys = HashSet::new();
        candidates
            .into_iter()
            .filter(|tile_key| seen_tile_keys.insert(*tile_key))
            .collect()
    }

    /// Claims the cache misses among `candidate_tile_keys`, up to
    /// `maximum_claim_count` when one is given, and answers the detached fetch
    /// future. Shared by the visible and ring prefetch plans: both
    /// deduplicate, claim under one short lock, and run the fetches
    /// concurrently, so neither ever duplicates another plan's request. The
    /// candidate order is the claim priority, and the budget is applied after
    /// the cached and in-flight addresses are skipped.
    fn prefetch_tile_keys(
        &self,
        candidate_tile_keys: Vec<TileKey>,
        maximum_claim_count: Option<usize>,
    ) -> Option<impl std::future::Future<Output = usize> + Send + 'static> {
        let claimed_tile_keys = {
            let mut decoded_tiles = self
                .decoded_tiles
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let mut seen_tile_keys = HashSet::new();
            candidate_tile_keys
                .into_iter()
                .filter(|tile_key| seen_tile_keys.insert(*tile_key))
                .filter(|tile_key| decoded_tiles.begin_fetch(*tile_key))
                .take(maximum_claim_count.unwrap_or(usize::MAX))
                .collect::<Vec<TileKey>>()
        };
        if claimed_tile_keys.is_empty() {
            return None;
        }
        let provider = Arc::clone(&self.provider);
        let decoded_tiles = Arc::clone(&self.decoded_tiles);
        let payload_cache = self.payload_cache.clone();
        let payload_cache_source_name = self.provider.source_descriptor().source_name;
        let payload_cache_time_to_live_seconds = self.payload_cache_time_to_live_seconds;
        let payload_cache_counters = Arc::clone(&self.payload_cache_counters);
        Some(async move {
            let mut claim_guard =
                PrefetchClaimGuard::new(Arc::clone(&decoded_tiles), claimed_tile_keys.clone());
            let fetched_tiles = join_all(claimed_tile_keys.into_iter().map(|tile_key| {
                let provider = Arc::clone(&provider);
                let payload_cache = payload_cache.clone();
                let payload_cache_source_name = payload_cache_source_name.clone();
                let payload_cache_counters = Arc::clone(&payload_cache_counters);
                async move {
                    (
                        tile_key,
                        Self::fetch_and_decode_vector_tile(
                            provider.as_ref(),
                            payload_cache.as_deref(),
                            &payload_cache_source_name,
                            payload_cache_time_to_live_seconds,
                            &payload_cache_counters,
                            tile_key,
                        )
                        .await,
                    )
                }
            }))
            .await;
            let mut delivered_tile_count = 0;
            let mut cache = decoded_tiles.lock().unwrap_or_else(PoisonError::into_inner);
            for (tile_key, fetched_tile) in fetched_tiles {
                if fetched_tile.is_ok() {
                    delivered_tile_count += 1;
                }
                cache.finish_fetch(tile_key, fetched_tile);
                claim_guard.mark_finished(tile_key);
            }
            delivered_tile_count
        })
    }

    /// Resolves one frame from the decoded cache alone — never the network:
    /// every cached tile is styled at the camera zoom's bucket (from the
    /// styled cache when the bucket or the style is unchanged) and its labels
    /// read, an address whose prefetch is running counts as pending, and a
    /// recorded failure counts as failed with its detail. A missing address
    /// whose ancestor is cached draws that ancestor's geometry once for the
    /// whole area it covers (the raster path's parent fallback), so the frame
    /// paints coarse detail instead of a hole.
    ///
    /// This is what a surface draws while a detached
    /// [`Self::prefetch_missing_tiles`] fills the cache, so a first frame over
    /// unvisited ground presents the style's background or the cached coarse
    /// detail instead of blocking on every tile's latency.
    pub fn cached_frame(
        &mut self,
        visible_tile_keys: &[TileKey],
        style_zoom_level: f64,
    ) -> VectorBaseFrame {
        let mut requested_tile_keys = visible_tile_keys.to_vec();
        requested_tile_keys.sort();
        requested_tile_keys.dedup();
        let quantized_style_zoom = quantized_style_zoom(style_zoom_level);
        let evaluated_style_zoom =
            quantized_style_zoom as f64 / VECTOR_BASE_STYLE_ZOOM_QUANTIZATION_STEPS_PER_LEVEL;
        let mut frame = VectorBaseFrame {
            overlays: Vec::new(),
            label_candidates: Vec::new(),
            requested_tile_count: requested_tile_keys.len(),
            drawn_tile_count: 0,
            fallback_tile_count: 0,
            failed_tile_count: 0,
            pending_tile_count: 0,
            style_id: self.style_id.clone(),
            background: self.style.background_at(evaluated_style_zoom),
            last_failure_detail: None,
            diagnostics: VectorBaseFrameDiagnostics::default(),
        };
        // Read the cache's verdict for every address under one lock, then
        // style from the cloned tiles without holding it.
        let (cached_tiles, in_flight_fetch_count) = {
            let decoded_tiles = self
                .decoded_tiles
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let cached_tiles = requested_tile_keys
                .iter()
                .copied()
                .map(|tile_key| {
                    (
                        tile_key,
                        decoded_tiles.get(&tile_key),
                        decoded_tiles.failure_details.get(&tile_key).cloned(),
                    )
                })
                .collect::<Vec<(TileKey, Option<Arc<VectorTile>>, Option<String>)>>();
            (cached_tiles, decoded_tiles.in_flight.len())
        };
        let mut drawable_tiles: Vec<(TileKey, Arc<VectorTile>)> = Vec::new();
        let mut missing_tile_keys = Vec::new();
        for (tile_key, decoded_tile, failure_detail) in cached_tiles {
            match decoded_tile {
                Some(decoded_tile) => drawable_tiles.push((tile_key, decoded_tile)),
                None => {
                    if let Some(failure_detail) = failure_detail {
                        frame.failed_tile_count += 1;
                        frame.last_failure_detail = Some(failure_detail);
                    } else {
                        // Neither cached nor failed: either its prefetch is
                        // running or the caller has not requested it yet. Both
                        // are pending detail a later frame draws, so the frame
                        // reports them honestly and keeps presenting.
                        frame.pending_tile_count += 1;
                    }
                    missing_tile_keys.push(tile_key);
                }
            }
        }
        frame.drawn_tile_count = drawable_tiles.len();
        // A missing tile whose nearest cached ancestor exists is painted from
        // that ancestor once per ancestor, not once per child: one coarse tile
        // covers four missing children without stacking its translucent fills
        // four times.
        let (fallback_ancestors, covered_tile_count) = {
            let decoded_tiles = self
                .decoded_tiles
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let mut fallback_ancestors: Vec<(TileKey, Arc<VectorTile>)> = Vec::new();
            let mut seen_ancestor_tile_keys = HashSet::new();
            let mut covered_tile_count = 0;
            for missing_tile_key in &missing_tile_keys {
                let mut ancestor_tile_key = missing_tile_key.parent_tile_key();
                while let Some(candidate_tile_key) = ancestor_tile_key {
                    let Some(ancestor_tile) = decoded_tiles.get(&candidate_tile_key) else {
                        ancestor_tile_key = candidate_tile_key.parent_tile_key();
                        continue;
                    };
                    covered_tile_count += 1;
                    if seen_ancestor_tile_keys.insert(candidate_tile_key) {
                        fallback_ancestors.push((candidate_tile_key, ancestor_tile));
                    }
                    break;
                }
            }
            (fallback_ancestors, covered_tile_count)
        };
        frame.fallback_tile_count = covered_tile_count;
        let drawable_tile_keys = drawable_tiles
            .iter()
            .map(|(tile_key, _)| *tile_key)
            .collect::<HashSet<_>>();
        // Style layers paint in global document order across the whole visible
        // tile set: bucket every tile's primitives by compiled layer index and
        // flatten the buckets at the end, so a later tile's layer-0 fill can
        // never paint over an earlier tile's layer-1 line.
        let mut layer_batches: Vec<Vec<MapOverlay>> = vec![Vec::new(); self.style.layer_count()];
        // Coarse stand-ins paint beneath the frame's own tiles within every
        // layer, so a sibling drawn at full detail is never overpainted by its
        // parent's coarse fills. An ancestor already drawn at its own address
        // is skipped: it is in the list once already.
        for (ancestor_tile_key, ancestor_tile) in fallback_ancestors {
            if drawable_tile_keys.contains(&ancestor_tile_key) {
                continue;
            }
            self.append_styled_tile_contents(
                &mut frame,
                &mut layer_batches,
                ancestor_tile_key,
                &ancestor_tile,
                quantized_style_zoom,
                evaluated_style_zoom,
            );
        }
        for (tile_key, decoded_tile) in drawable_tiles {
            self.append_styled_tile_contents(
                &mut frame,
                &mut layer_batches,
                tile_key,
                &decoded_tile,
                quantized_style_zoom,
                evaluated_style_zoom,
            );
        }
        frame.overlays = layer_batches.into_iter().flatten().collect();
        if self.first_drawn_tile_milliseconds.is_none()
            && (frame.drawn_tile_count > 0 || frame.fallback_tile_count > 0)
        {
            self.first_drawn_tile_milliseconds =
                Some(u64::try_from(self.installed_at.elapsed().as_millis()).unwrap_or(u64::MAX));
        }
        frame.diagnostics = VectorBaseFrameDiagnostics {
            payload_cache_hit_count: self
                .payload_cache_counters
                .hit_count
                .load(Ordering::Relaxed),
            payload_cache_miss_count: self
                .payload_cache_counters
                .miss_count
                .load(Ordering::Relaxed),
            in_flight_fetch_count,
            time_to_first_drawn_tile_milliseconds: self.first_drawn_tile_milliseconds,
        };
        self.last_failure_detail = frame.last_failure_detail.clone();
        tracing::debug!(
            target: "vector_base",
            requested_tile_count = frame.requested_tile_count,
            drawn_tile_count = frame.drawn_tile_count,
            fallback_tile_count = frame.fallback_tile_count,
            failed_tile_count = frame.failed_tile_count,
            pending_tile_count = frame.pending_tile_count,
            payload_cache_hit_count = frame.diagnostics.payload_cache_hit_count,
            payload_cache_miss_count = frame.diagnostics.payload_cache_miss_count,
            in_flight_fetch_count = frame.diagnostics.in_flight_fetch_count,
            time_to_first_drawn_tile_milliseconds =
                frame.diagnostics.time_to_first_drawn_tile_milliseconds,
            "vector base frame resolved"
        );
        frame
    }

    /// Appends one tile's styled overlays and label candidates to the frame
    /// at the camera zoom's style bucket, styling the tile into the styled
    /// cache first when the bucket or the style is new. Shared by the tiles
    /// drawn at their own address and by the ancestors that stand in for
    /// missing children.
    fn append_styled_tile_contents(
        &mut self,
        frame: &mut VectorBaseFrame,
        layer_batches: &mut [Vec<MapOverlay>],
        tile_key: TileKey,
        decoded_tile: &VectorTile,
        quantized_style_zoom: i64,
        evaluated_style_zoom: f64,
    ) {
        let styled_key = StyledTileCacheKey {
            tile_key,
            style_revision: self.style_revision,
            quantized_style_zoom,
        };
        if !self.styled_tiles.contains_key(&styled_key) {
            let styled_layers = vector_tile_overlay_layers_at_zoom(
                decoded_tile,
                VectorTileAddress {
                    zoom_level: tile_key.zoom_level,
                    tile_x: tile_key.tile_x,
                    tile_y: tile_key.tile_y,
                },
                &self.style,
                evaluated_style_zoom,
            );
            self.store_styled_tile(styled_key, styled_layers);
        }
        if let Some(styled_layers) = self.styled_tiles.get(&styled_key) {
            for (layer_batch, styled_overlays) in layer_batches.iter_mut().zip(styled_layers) {
                layer_batch.extend(styled_overlays.iter().cloned());
            }
        }
        // Labels read from the same decoded tile at the same evaluated zoom,
        // so a frame's text and geometry always agree on the camera pose. The
        // walk is GPU-free and allocates nothing when the style declares no
        // symbol layer; it is recomputed per frame rather than cached because
        // it is cheap beside the styled geometry and shares no state with the
        // overlay cache.
        frame
            .label_candidates
            .extend(label_candidates_for_vector_tile(
                decoded_tile,
                VectorTileAddress {
                    zoom_level: tile_key.zoom_level,
                    tile_x: tile_key.tile_x,
                    tile_y: tile_key.tile_y,
                },
                &self.style,
                evaluated_style_zoom,
            ));
    }

    /// The decoded tile for the address, consulted through the payload cache
    /// first and fetched from the provider only on a miss. Kept free of the
    /// scheduler's caches so the prefetch can fetch every missing tile
    /// concurrently and insert the results afterwards.
    async fn fetch_and_decode_vector_tile(
        provider: &dyn VectorTileProvider,
        payload_cache: Option<&dyn CachedResponseStore<VectorTileData>>,
        payload_cache_source_name: &str,
        payload_cache_time_to_live_seconds: u64,
        payload_cache_counters: &VectorBasePayloadCacheCounters,
        tile_key: TileKey,
    ) -> Result<Arc<VectorTile>, String> {
        let payload_cache_fingerprint =
            vector_tile_payload_cache_fingerprint(payload_cache_source_name, tile_key);
        let decode = |tile_data: &VectorTileData| -> Result<Arc<VectorTile>, String> {
            Ok(Arc::new(decode_wire_vector_tile(tile_data).map_err(
                |decode_error| {
                    format!(
                        "the vector base tile {}/{}/{} failed to decode: {decode_error}",
                        tile_key.zoom_level, tile_key.tile_x, tile_key.tile_y
                    )
                },
            )?))
        };
        if let Some(payload_cache) = payload_cache {
            match payload_cache.lookup_response(&payload_cache_fingerprint) {
                Ok(Some(cached_payload)) => {
                    payload_cache_counters
                        .hit_count
                        .fetch_add(1, Ordering::Relaxed);
                    return decode(cached_payload.as_ref());
                }
                // A miss is a fetch; a store read failure degrades to the
                // same path (the cache is an accelerator, never a gate).
                Ok(None) | Err(_) => {
                    payload_cache_counters
                        .miss_count
                        .fetch_add(1, Ordering::Relaxed);
                }
            }
        }
        let tile_data = provider
            .fetch_vector_tile(tile_key.tile_x, tile_key.tile_y, tile_key.zoom_level)
            .await
            .map_err(|fetch_error| {
                format!(
                    "the vector base tile {}/{}/{} failed to fetch: {fetch_error}",
                    tile_key.zoom_level, tile_key.tile_x, tile_key.tile_y
                )
            })?;
        let decoded_tile = decode(&tile_data)?;
        if let Some(payload_cache) = payload_cache {
            // Storage is best-effort: a failing store must not lose the
            // freshly fetched tile.
            let _ = payload_cache.store_response(
                &payload_cache_fingerprint,
                Arc::new(tile_data),
                payload_cache_time_to_live_seconds,
            );
        }
        Ok(decoded_tile)
    }

    /// Inserts a decoded tile and evicts the oldest decoded tiles beyond the
    /// cache's capacity. Styled geometry is keyed by the address and a style
    /// revision and is bounded by its own cache, so decoded-tile eviction
    /// never touches it.
    ///
    /// The decoded-tile eviction below drops a tile's styled entries, but a
    /// tile stays decoded for many frames while the camera may style it once
    /// per zoom bucket; this cache is therefore bounded on its own too.
    fn store_styled_tile(
        &mut self,
        styled_key: StyledTileCacheKey,
        overlays: Vec<Vec<MapOverlay>>,
    ) {
        if self.styled_tiles.insert(styled_key, overlays).is_none() {
            self.styled_tile_insertion_order.push_back(styled_key);
        }
        while self.styled_tiles.len() > self.maximum_cached_styled_tile_count {
            let Some(evicted_styled_key) = self.styled_tile_insertion_order.pop_front() else {
                break;
            };
            self.styled_tiles.remove(&evicted_styled_key);
        }
    }
}

/// Quantizes a camera zoom level to the styled cache's bucket (the nearest
/// [`VECTOR_BASE_STYLE_ZOOM_QUANTIZATION_STEPS_PER_LEVEL`]-th of a level).
fn quantized_style_zoom(style_zoom_level: f64) -> i64 {
    (style_zoom_level * VECTOR_BASE_STYLE_ZOOM_QUANTIZATION_STEPS_PER_LEVEL).round() as i64
}

/// Unwraps the wire envelope and decodes the tile: a gzip-wrapped body is
/// decompressed first, so the decoder only ever sees plain MVT protobuf. The
/// record is borrowed because the caller keeps the payload for its cache.
pub(crate) fn decode_wire_vector_tile(tile_data: &VectorTileData) -> Result<VectorTile, String> {
    let plain_tile_bytes = match tile_data.tile_encoding {
        VectorTileEncoding::MapboxVectorTile => tile_data.tile_bytes.clone(),
        VectorTileEncoding::GzippedMapboxVectorTile => {
            let gzip_decoder = GzDecoder::new(tile_data.tile_bytes.as_slice());
            let mut unwrapped_bytes = Vec::new();
            let mut limited_decoder =
                gzip_decoder.take(MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES as u64 + 1);
            limited_decoder
                .read_to_end(&mut unwrapped_bytes)
                .map_err(|decompress_error| {
                    format!(
                        "the gzip-wrapped vector tile payload failed to decompress: \
                         {decompress_error}"
                    )
                })?;
            if unwrapped_bytes.len() > MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES {
                return Err(format!(
                    "the gzip-wrapped vector tile payload decompressed beyond the {MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES}-byte limit"
                ));
            }
            unwrapped_bytes
        }
    };
    decode_vector_tile(&plain_tile_bytes).map_err(|decode_error| decode_error.to_string())
}

#[cfg(test)]
mod gzip_bomb_tests {
    use super::*;
    use flate2::Compression;
    use flate2::write::GzEncoder;
    use geospatial_types::VectorTileEncoding;
    use std::io::Write;

    #[test]
    fn a_decompression_bomb_is_refused_instead_of_allocating() {
        let mut encoder = GzEncoder::new(Vec::new(), Compression::fast());
        encoder
            .write_all(&vec![0_u8; MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES + 4096])
            .expect("the encoder writes");
        let compressed_bomb = encoder.finish().expect("the encoder finishes");
        assert!(
            compressed_bomb.len() < MAXIMUM_DECOMPRESSED_VECTOR_TILE_BYTES,
            "the fixture is a real bomb: a small payload expanding past the limit"
        );
        let tile_data = VectorTileData {
            tile_x: 0,
            tile_y: 0,
            zoom_level: 0,
            tile_encoding: VectorTileEncoding::GzippedMapboxVectorTile,
            tile_bytes: compressed_bomb,
        };
        let refusal =
            decode_wire_vector_tile(&tile_data).expect_err("a payload past the limit is refused");
        assert!(refusal.contains("decompressed beyond"));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES;
    use crate::vector_style::{
        VECTOR_STYLE_ID_BRIGHT_LIGHT, VECTOR_STYLE_ID_OPENMAPTILES_DARK,
        VECTOR_STYLE_ID_OPENMAPTILES_LIGHT,
    };
    use async_trait::async_trait;
    use geospatial_types::{GeographicCoordinate, SDKError};
    use std::collections::HashMap as StdHashMap;
    use std::sync::Mutex;

    /// The bundled Sourdough tile the styling tests pin (z6, x18,
    /// y27, the Bahamas area of the tileset).
    const SOURDOUGH_TILE_BYTES: &[u8] =
        include_bytes!("../../../fixtures/openstreetmap-us/sourdough_tile_z6_x18_y27.mvt");
    /// The Sourdough tile's address.
    const SOURDOUGH_TILE_KEY: TileKey = TileKey {
        tile_x: 18,
        tile_y: 27,
        zoom_level: 6,
    };

    /// The bundled OpenFreeMap z14 vector tile over Sacramento: the demo tile
    /// whose place layer names Sacramento, West Sacramento, Mikon and Bryte.
    const OPENFREEMAP_TILE_BYTES: &[u8] =
        include_bytes!("../../../fixtures/openfreemap/openmaptiles_tile_z14_x2661_y6286.pbf");
    /// The OpenFreeMap demo tile's address.
    const OPENFREEMAP_TILE_KEY: TileKey = TileKey {
        tile_x: 2661,
        tile_y: 6286,
        zoom_level: 14,
    };
    /// Sacramento's latitude, the demo camera's center, in decimal degrees.
    const SACRAMENTO_LATITUDE_DEGREES: f64 = 38.5766;
    /// Sacramento's longitude, the demo camera's center, in decimal degrees.
    const SACRAMENTO_LONGITUDE_DEGREES: f64 = -121.4944;
    /// The zoom level the demo camera and its tile resolve at.
    const SACRAMENTO_CAMERA_ZOOM_LEVEL: f64 = 14.0;
    /// Edge of the square viewport the label placement tests project into, in
    /// screen pixels.
    const LABEL_TEST_VIEWPORT_EDGE_PIXELS: f64 = 512.0;

    /// A provider serving scripted tiles and counting every fetch.
    struct ScriptedVectorTileProvider {
        served_tile_bytes: StdHashMap<TileKey, Vec<u8>>,
        failed_tile_keys: Vec<TileKey>,
        fetch_count: Mutex<usize>,
        descriptor: VectorTileSourceDescriptor,
    }

    impl ScriptedVectorTileProvider {
        fn serving_tile(tile_key: TileKey, tile_bytes: Vec<u8>) -> Arc<Self> {
            Arc::new(Self {
                served_tile_bytes: [(tile_key, tile_bytes)].into_iter().collect(),
                failed_tile_keys: Vec::new(),
                fetch_count: Mutex::new(0),
                descriptor: VectorTileSourceDescriptor {
                    source_name: "scripted".to_string(),
                    attribution_text: "Scripted vector tiles".to_string(),
                    minimum_zoom_level: 0,
                    maximum_zoom_level: 14,
                },
            })
        }

        fn fetch_count(&self) -> usize {
            *self.fetch_count.lock().unwrap()
        }
    }

    #[async_trait]
    impl VectorTileProvider for ScriptedVectorTileProvider {
        fn source_descriptor(&self) -> VectorTileSourceDescriptor {
            self.descriptor.clone()
        }

        async fn fetch_vector_tile(
            &self,
            tile_x: u32,
            tile_y: u32,
            zoom_level: u8,
        ) -> Result<VectorTileData, SDKError> {
            *self.fetch_count.lock().unwrap() += 1;
            let tile_key = TileKey::new(tile_x, tile_y, zoom_level)?;
            if self.failed_tile_keys.contains(&tile_key) {
                return Err(SDKError::ResponseParsingFailure(format!(
                    "the scripted provider refuses {zoom_level}/{tile_x}/{tile_y}"
                )));
            }
            let tile_bytes = self
                .served_tile_bytes
                .get(&tile_key)
                .cloned()
                .ok_or_else(|| {
                    SDKError::ResponseParsingFailure(format!(
                        "the scripted provider serves no {zoom_level}/{tile_x}/{tile_y}"
                    ))
                })?;
            VectorTileData::from_wire_bytes(tile_x, tile_y, zoom_level, tile_bytes)
        }
    }

    /// A provider serving the same fixture bytes at every requested address,
    /// for the ring and prefetch plans whose tiles are not individually
    /// scripted.
    struct RepeatingVectorTileProvider {
        tile_bytes: Vec<u8>,
        fetch_count: Mutex<usize>,
    }

    impl RepeatingVectorTileProvider {
        fn serving_bytes(tile_bytes: Vec<u8>) -> Arc<Self> {
            Arc::new(Self {
                tile_bytes,
                fetch_count: Mutex::new(0),
            })
        }

        fn fetch_count(&self) -> usize {
            *self.fetch_count.lock().unwrap()
        }
    }

    #[async_trait]
    impl VectorTileProvider for RepeatingVectorTileProvider {
        fn source_descriptor(&self) -> VectorTileSourceDescriptor {
            VectorTileSourceDescriptor {
                source_name: "repeating".to_string(),
                attribution_text: "Repeating vector tiles".to_string(),
                minimum_zoom_level: 0,
                maximum_zoom_level: 14,
            }
        }

        async fn fetch_vector_tile(
            &self,
            tile_x: u32,
            tile_y: u32,
            zoom_level: u8,
        ) -> Result<VectorTileData, SDKError> {
            *self.fetch_count.lock().unwrap() += 1;
            VectorTileData::from_wire_bytes(tile_x, tile_y, zoom_level, self.tile_bytes.clone())
        }
    }

    /// A provider whose fetches never answer, modelling a stalled network the
    /// cancellability test parks on.
    struct StalledVectorTileProvider;

    #[async_trait]
    impl VectorTileProvider for StalledVectorTileProvider {
        fn source_descriptor(&self) -> VectorTileSourceDescriptor {
            VectorTileSourceDescriptor {
                source_name: "stalled".to_string(),
                attribution_text: "Stalled vector tiles".to_string(),
                minimum_zoom_level: 0,
                maximum_zoom_level: 14,
            }
        }

        async fn fetch_vector_tile(
            &self,
            _tile_x: u32,
            _tile_y: u32,
            _zoom_level: u8,
        ) -> Result<VectorTileData, SDKError> {
            loop {
                std::future::pending::<()>().await;
            }
        }
    }

    /// A `std` task waker that never wakes anything: enough to drive one poll
    /// of a future to its first await point.
    fn noop_waker() -> std::task::Waker {
        use std::task::{RawWaker, RawWakerVTable, Waker};
        const NOOP_WAKER_VTABLE: RawWakerVTable = RawWakerVTable::new(
            |_| RawWaker::new(std::ptr::null::<()>(), &NOOP_WAKER_VTABLE),
            |_| {},
            |_| {},
            |_| {},
        );
        // SAFETY: every vtable function is a no-op operating on a null data
        // pointer, which the waker contract permits since nothing ever
        // dereferences it.
        unsafe { Waker::from_raw(RawWaker::new(std::ptr::null::<()>(), &NOOP_WAKER_VTABLE)) }
    }

    /// A one-layer style painting the sample tile's `highways` lines, with a
    /// width stop at each zoom level so a zoom change must repaint every line.
    fn highways_style_with_width_stops() -> CompiledStyle {
        crate::vector_style::vector_tile_style_from_json(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "highways",
                        "type": "line",
                        "source": "base",
                        "source-layer": "highways",
                        "paint": {
                            "line-color": [229.5, 153, 51, 1],
                            "line-width": ["interpolate", ["linear"], ["zoom"], 6, 2, 14, 10]
                        }
                    }
                ]
            }"#,
        )
        .expect("the test style document compiles")
    }

    fn first_line_width(frame: &VectorBaseFrame) -> f64 {
        frame
            .overlays
            .iter()
            .find_map(|overlay| match overlay {
                MapOverlay::RoutePolyline(route_overlay) => Some(route_overlay.width_pixels),
                _ => None,
            })
            .expect("the fixture's highways layer paints at least one line")
    }

    #[tokio::test]
    async fn a_resolved_frame_fetches_each_visible_tile_once_and_caches_it() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let first_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert_eq!(first_frame.requested_tile_count, 1);
        assert_eq!(first_frame.drawn_tile_count, 1);
        assert_eq!(first_frame.failed_tile_count, 0);
        assert!(first_frame.is_idle());
        assert!(!first_frame.overlays.is_empty());
        assert_eq!(provider.fetch_count(), 1);

        let second_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert_eq!(second_frame.overlays, first_frame.overlays);
        assert_eq!(
            provider.fetch_count(),
            1,
            "a cached tile resolves without a second fetch"
        );
    }

    #[tokio::test]
    async fn a_cached_frame_never_fetches_and_reports_pending_tiles() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let pending_frame = scheduler.cached_frame(&[SOURDOUGH_TILE_KEY], 6.0);
        assert_eq!(pending_frame.requested_tile_count, 1);
        assert_eq!(pending_frame.drawn_tile_count, 0);
        assert_eq!(pending_frame.failed_tile_count, 0);
        assert_eq!(pending_frame.pending_tile_count, 1);
        assert!(!pending_frame.is_idle());
        assert_eq!(provider.fetch_count(), 0, "a cached frame never fetches");

        let prefetch = scheduler
            .prefetch_missing_tiles(&[SOURDOUGH_TILE_KEY])
            .expect("the missing tile is claimed by the prefetch");
        let in_flight_frame = scheduler.cached_frame(&[SOURDOUGH_TILE_KEY], 6.0);
        assert_eq!(in_flight_frame.pending_tile_count, 1);
        assert_eq!(provider.fetch_count(), 0, "the prefetch runs detached");

        prefetch.await;
        let drawn_frame = scheduler.cached_frame(&[SOURDOUGH_TILE_KEY], 6.0);
        assert_eq!(drawn_frame.drawn_tile_count, 1);
        assert_eq!(drawn_frame.pending_tile_count, 0);
        assert_eq!(drawn_frame.failed_tile_count, 0);
        assert!(drawn_frame.is_idle());
        assert_eq!(provider.fetch_count(), 1);
        assert!(
            scheduler
                .prefetch_missing_tiles(&[SOURDOUGH_TILE_KEY])
                .is_none(),
            "a cached tile is never claimed again"
        );
    }

    #[tokio::test]
    async fn a_failed_prefetch_is_reported_and_retried_by_the_next_frame() {
        let provider = Arc::new(ScriptedVectorTileProvider {
            served_tile_bytes: StdHashMap::new(),
            failed_tile_keys: vec![SOURDOUGH_TILE_KEY],
            fetch_count: Mutex::new(0),
            descriptor: VectorTileSourceDescriptor {
                source_name: "scripted".to_string(),
                attribution_text: "Scripted vector tiles".to_string(),
                minimum_zoom_level: 0,
                maximum_zoom_level: 14,
            },
        });
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        scheduler
            .prefetch_missing_tiles(&[SOURDOUGH_TILE_KEY])
            .expect("the missing tile is claimed")
            .await;
        let failed_frame = scheduler.cached_frame(&[SOURDOUGH_TILE_KEY], 6.0);
        assert_eq!(failed_frame.failed_tile_count, 1);
        assert_eq!(failed_frame.pending_tile_count, 0);
        assert!(
            failed_frame
                .last_failure_detail
                .as_deref()
                .unwrap_or_default()
                .contains("failed to fetch"),
            "the frame reports the provider's refusal"
        );

        // The next prefetch retries the address rather than caching the
        // failure forever.
        scheduler
            .prefetch_missing_tiles(&[SOURDOUGH_TILE_KEY])
            .expect("a failed address is retried")
            .await;
        assert_eq!(provider.fetch_count(), 2);
    }

    #[tokio::test]
    async fn a_symbol_style_frame_carries_its_place_labels() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            OPENFREEMAP_TILE_KEY,
            OPENFREEMAP_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::from_style_id(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            VECTOR_STYLE_ID_BRIGHT_LIGHT,
        )
        .expect("the committed Bright style loads");
        let frame = scheduler
            .resolve_frame(&[OPENFREEMAP_TILE_KEY], SACRAMENTO_CAMERA_ZOOM_LEVEL)
            .await;
        assert_eq!(frame.failed_tile_count, 0);
        assert!(
            frame.background.is_some(),
            "the Bright style's canvas background must travel with the frame, so a \
             surface that hides the raster base can clear to it"
        );
        assert!(
            frame
                .label_candidates
                .iter()
                .any(|candidate| candidate.text == "Sacramento"),
            "the Bright style's symbol layer must read Sacramento from the demo tile"
        );

        let camera = MapCamera::new(
            GeographicCoordinate::from_degrees(
                SACRAMENTO_LATITUDE_DEGREES,
                SACRAMENTO_LONGITUDE_DEGREES,
            )
            .unwrap(),
            SACRAMENTO_CAMERA_ZOOM_LEVEL,
            0.0,
            0.0,
        );
        let viewport = ViewportPixels::new(
            LABEL_TEST_VIEWPORT_EDGE_PIXELS,
            LABEL_TEST_VIEWPORT_EDGE_PIXELS,
        )
        .unwrap();
        let label_layer = frame
            .label_layer(&camera, &viewport, DEFAULT_FIELD_OF_VIEW_DEGREES)
            .expect("a frame with candidates yields a label layer");
        assert!(
            label_layer
                .labels()
                .iter()
                .any(|label| label.text == "Sacramento"),
            "the Sacramento label anchors at the frame center"
        );
        assert!(
            !label_layer.quad_vertices(&viewport).text.is_empty(),
            "the embedded default font rasterizes the placed labels"
        );
    }

    /// The two-layer style the cross-tile ordering test paints: a water fill
    /// first in document order, then a highway line.
    fn fill_then_line_style() -> CompiledStyle {
        crate::vector_style::vector_tile_style_from_json(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "water-fill",
                        "type": "fill",
                        "source": "base",
                        "source-layer": "water",
                        "paint": { "fill-color": [51, 127.5, 229.5, 0.4] }
                    },
                    {
                        "id": "highway-line",
                        "type": "line",
                        "source": "base",
                        "source-layer": "highways",
                        "paint": { "line-color": [229.5, 153, 51, 0.9], "line-width": 2 }
                    }
                ]
            }"#,
        )
        .expect("the test style document compiles")
    }

    #[tokio::test]
    async fn a_later_tiles_fill_cannot_paint_over_an_earlier_tiles_line() {
        // Two adjacent tiles decode the committed Sourdough payload, so both
        // paint water fills and highway lines. Under tile-by-tile flattening
        // the second tile's fills land after the first tile's lines; global
        // style order must make every fill — from either tile — paint first.
        let provider = RepeatingVectorTileProvider::serving_bytes(SOURDOUGH_TILE_BYTES.to_vec());
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "cross-tile-order",
            fill_then_line_style(),
        );
        let west_tile_key = SOURDOUGH_TILE_KEY;
        let east_tile_key = TileKey {
            tile_x: SOURDOUGH_TILE_KEY.tile_x + 1,
            tile_y: SOURDOUGH_TILE_KEY.tile_y,
            zoom_level: SOURDOUGH_TILE_KEY.zoom_level,
        };
        let frame = scheduler
            .resolve_frame(&[west_tile_key, east_tile_key], 6.0)
            .await;
        assert_eq!(frame.drawn_tile_count, 2);

        let fill_count = frame
            .overlays
            .iter()
            .filter(|overlay| matches!(overlay, MapOverlay::FilledPolygon(_)))
            .count();
        let line_count = frame
            .overlays
            .iter()
            .filter(|overlay| matches!(overlay, MapOverlay::RoutePolyline(_)))
            .count();
        let last_fill_index = frame
            .overlays
            .iter()
            .rposition(|overlay| matches!(overlay, MapOverlay::FilledPolygon(_)))
            .expect("the fixture paints water fills");
        let first_line_index = frame
            .overlays
            .iter()
            .position(|overlay| matches!(overlay, MapOverlay::RoutePolyline(_)))
            .expect("the fixture paints highway lines");
        assert!(
            last_fill_index < first_line_index,
            "every tile's fill (layer 0) must paint before every tile's line (layer 1); \
             last fill index {last_fill_index}, first line index {first_line_index}"
        );

        // Both tiles contributed both kinds, so the ordering assertion above
        // is genuinely cross-tile rather than a one-tile accident.
        let decoded_tile = decode_vector_tile(SOURDOUGH_TILE_BYTES).expect("the fixture decodes");
        let style = fill_then_line_style();
        let per_tile_fill_count = crate::vector_style::vector_tile_overlays(
            &decoded_tile,
            VectorTileAddress {
                zoom_level: west_tile_key.zoom_level,
                tile_x: west_tile_key.tile_x,
                tile_y: west_tile_key.tile_y,
            },
            &style,
        )
        .iter()
        .filter(|overlay| matches!(overlay, MapOverlay::FilledPolygon(_)))
        .count();
        let per_tile_line_count = crate::vector_style::vector_tile_overlays(
            &decoded_tile,
            VectorTileAddress {
                zoom_level: west_tile_key.zoom_level,
                tile_x: west_tile_key.tile_x,
                tile_y: west_tile_key.tile_y,
            },
            &style,
        )
        .iter()
        .filter(|overlay| matches!(overlay, MapOverlay::RoutePolyline(_)))
        .count();
        assert!(per_tile_fill_count > 0 && per_tile_line_count > 0);
        assert_eq!(fill_count, per_tile_fill_count * 2);
        assert_eq!(line_count, per_tile_line_count * 2);
    }

    #[test]
    fn the_styled_cache_is_bounded_on_its_own() {
        // One decoded tile can be styled once per zoom bucket, so the styled
        // cache cannot rely on decoded-tile eviction alone: storing more
        // entries than the cap drops the oldest.
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        scheduler.maximum_cached_styled_tile_count = 3;
        for style_revision in 0_u64..6 {
            scheduler.store_styled_tile(
                StyledTileCacheKey {
                    tile_key: SOURDOUGH_TILE_KEY,
                    style_revision,
                    quantized_style_zoom: 140,
                },
                Vec::new(),
            );
        }
        assert_eq!(
            scheduler.styled_tiles.len(),
            3,
            "the styled cache never exceeds its own capacity"
        );
        assert!(
            !scheduler
                .styled_tiles
                .keys()
                .any(|key| key.style_revision == 0),
            "the oldest styled entry is the one evicted"
        );
    }

    #[tokio::test]
    async fn the_schema_styles_carry_place_and_road_labels_from_the_committed_tile() {
        // Both OpenMapTiles-schema artifacts declare the same symbol set as
        // the named styles: place names, road names along their lines and the
        // closely zoomed points of interest. Without them a descriptor that
        // offers only the schema style would paint a map with no text.
        for style_id in [
            VECTOR_STYLE_ID_OPENMAPTILES_LIGHT,
            VECTOR_STYLE_ID_OPENMAPTILES_DARK,
        ] {
            let provider = ScriptedVectorTileProvider::serving_tile(
                OPENFREEMAP_TILE_KEY,
                OPENFREEMAP_TILE_BYTES.to_vec(),
            );
            let mut scheduler = VectorBaseScheduler::from_style_id(
                Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
                style_id,
            )
            .expect("the committed OpenMapTiles style loads");
            let frame = scheduler
                .resolve_frame(&[OPENFREEMAP_TILE_KEY], SACRAMENTO_CAMERA_ZOOM_LEVEL)
                .await;
            assert_eq!(frame.failed_tile_count, 0, "{style_id} draws its tile");
            assert!(
                frame
                    .label_candidates
                    .iter()
                    .any(|candidate| candidate.text == "Sacramento"),
                "{style_id} must name the place from the committed tile"
            );
            assert!(
                frame
                    .label_candidates
                    .iter()
                    .any(|candidate| !candidate.line_coordinates.is_empty()),
                "{style_id} must place road names along their lines"
            );
        }
    }

    #[tokio::test]
    async fn a_style_without_symbol_layers_yields_no_label_layer() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert!(
            frame.label_candidates.is_empty(),
            "a style with no symbol layer reads no labels"
        );
        let camera = MapCamera::new(
            GeographicCoordinate::from_degrees(
                SACRAMENTO_LATITUDE_DEGREES,
                SACRAMENTO_LONGITUDE_DEGREES,
            )
            .unwrap(),
            6.0,
            0.0,
            0.0,
        );
        let viewport = ViewportPixels::new(
            LABEL_TEST_VIEWPORT_EDGE_PIXELS,
            LABEL_TEST_VIEWPORT_EDGE_PIXELS,
        )
        .unwrap();
        assert!(
            frame
                .label_layer(&camera, &viewport, DEFAULT_FIELD_OF_VIEW_DEGREES)
                .is_none(),
            "a label-free frame costs the renderer no layer"
        );
    }

    #[tokio::test]
    async fn a_style_change_restyles_the_cached_tile_without_refetching() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;

        scheduler
            .set_style(crate::vector_style::VECTOR_STYLE_ID_CARTO_DARK)
            .expect("the committed dark style loads");
        let restyled_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert_eq!(provider.fetch_count(), 1);
        assert_eq!(
            restyled_frame.style_id,
            crate::vector_style::VECTOR_STYLE_ID_CARTO_DARK
        );
        assert_eq!(restyled_frame.drawn_tile_count, 1);
        assert!(
            !restyled_frame.overlays.is_empty(),
            "the dark style paints the fixture's schema layers"
        );
    }

    #[tokio::test]
    async fn crossing_a_width_stop_restyles_the_cached_tile_without_refetching() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let near_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        let far_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 14.0).await;
        assert_eq!(
            provider.fetch_count(),
            1,
            "the same tile restyles across a zoom stop without a refetch"
        );
        assert_eq!(first_line_width(&near_frame), 2.0);
        assert_eq!(first_line_width(&far_frame), 10.0);
    }

    #[tokio::test]
    async fn a_zoom_within_one_bucket_reuses_the_styled_geometry() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let first_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        let same_bucket_frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.1).await;
        assert_eq!(first_frame.overlays, same_bucket_frame.overlays);
        assert_eq!(provider.fetch_count(), 1);
    }

    #[tokio::test]
    async fn a_failing_tile_is_counted_and_does_not_fail_the_frame() {
        let provider = Arc::new(ScriptedVectorTileProvider {
            served_tile_bytes: [(SOURDOUGH_TILE_KEY, SOURDOUGH_TILE_BYTES.to_vec())]
                .into_iter()
                .collect(),
            failed_tile_keys: vec![SOURDOUGH_TILE_KEY],
            fetch_count: Mutex::new(0),
            descriptor: VectorTileSourceDescriptor {
                source_name: "scripted".to_string(),
                attribution_text: "Scripted vector tiles".to_string(),
                minimum_zoom_level: 0,
                maximum_zoom_level: 14,
            },
        });
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let frame = scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert_eq!(frame.failed_tile_count, 1);
        assert_eq!(frame.drawn_tile_count, 0);
        assert!(frame.overlays.is_empty());
        assert!(!frame.is_idle());
        assert!(
            frame
                .last_failure_detail
                .as_deref()
                .unwrap_or_default()
                .contains("failed to fetch")
        );
        assert_eq!(
            scheduler.last_failure_detail(),
            frame.last_failure_detail.as_deref()
        );
    }

    #[test]
    fn the_served_zoom_level_clamps_into_the_tileset_span() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        assert_eq!(scheduler.served_zoom_level(6), 6);
        assert_eq!(scheduler.served_zoom_level(18), 14);
        assert_eq!(scheduler.attribution_text(), "Scripted vector tiles");
    }

    #[test]
    fn an_unknown_style_id_is_refused_and_keeps_the_current_style() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        assert!(scheduler.set_style("no-such-style").is_err());
        assert_eq!(scheduler.style_id(), "test-highways");
    }

    #[tokio::test]
    async fn a_payload_cache_serves_a_second_scheduler_without_refetching() {
        let provider = ScriptedVectorTileProvider::serving_tile(
            SOURDOUGH_TILE_KEY,
            SOURDOUGH_TILE_BYTES.to_vec(),
        );
        let payload_cache = Arc::new(VectorTileMemoryCache::new(16));
        let mut first_scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        )
        .with_payload_cache(
            payload_cache.clone(),
            DEFAULT_VECTOR_TILE_PAYLOAD_TIME_TO_LIVE_SECONDS,
        );
        let first_frame = first_scheduler
            .resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0)
            .await;
        assert_eq!(first_frame.drawn_tile_count, 1);
        assert_eq!(first_frame.diagnostics.payload_cache_miss_count, 1);
        assert_eq!(first_frame.diagnostics.payload_cache_hit_count, 0);
        assert_eq!(provider.fetch_count(), 1);

        // A fresh scheduler (a style reinstall or a later session on the
        // native disk store) serves the same tile from the payload cache.
        let mut second_scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        )
        .with_payload_cache(
            payload_cache.clone(),
            DEFAULT_VECTOR_TILE_PAYLOAD_TIME_TO_LIVE_SECONDS,
        );
        let second_frame = second_scheduler
            .resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0)
            .await;
        assert_eq!(second_frame.drawn_tile_count, 1);
        assert_eq!(
            second_frame.overlays, first_frame.overlays,
            "the cached payload decodes to the same geometry"
        );
        assert_eq!(
            provider.fetch_count(),
            1,
            "the second scheduler never refetches a payload the cache holds"
        );
        assert_eq!(second_frame.diagnostics.payload_cache_hit_count, 1);
        assert_eq!(second_frame.diagnostics.payload_cache_miss_count, 0);
        assert_eq!(payload_cache.cached_tile_count(), 1);
    }

    #[tokio::test]
    async fn a_memory_payload_cache_expires_entries_after_their_time_to_live() {
        use geospatial_types::VectorTileData;

        let provider = RepeatingVectorTileProvider::serving_bytes(SOURDOUGH_TILE_BYTES.to_vec());
        let payload_cache = Arc::new(VectorTileMemoryCache::new(16));
        let fingerprint = vector_tile_payload_cache_fingerprint("repeating", SOURDOUGH_TILE_KEY);
        payload_cache
            .store_response(
                &fingerprint,
                Arc::new(
                    VectorTileData::from_wire_bytes(
                        SOURDOUGH_TILE_KEY.tile_x,
                        SOURDOUGH_TILE_KEY.tile_y,
                        SOURDOUGH_TILE_KEY.zoom_level,
                        SOURDOUGH_TILE_BYTES.to_vec(),
                    )
                    .expect("the fixture payload is a valid wire record"),
                ),
                0,
            )
            .expect("the in-memory cache accepts a store");
        assert_eq!(payload_cache.cached_tile_count(), 1);

        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        )
        .with_payload_cache(payload_cache.clone(), 0);
        scheduler.resolve_frame(&[SOURDOUGH_TILE_KEY], 6.0).await;
        assert_eq!(
            provider.fetch_count(),
            1,
            "a zero time-to-live entry is expired and the tile is fetched"
        );
        assert_eq!(payload_cache.cached_tile_count(), 1);
    }

    #[tokio::test]
    async fn the_ring_prefetch_claims_the_parent_and_the_neighbors_under_a_budget() {
        let provider = RepeatingVectorTileProvider::serving_bytes(SOURDOUGH_TILE_BYTES.to_vec());
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        )
        .with_maximum_prefetch_ring_tile_count(3);
        let visible_tile_key = TileKey::new(16, 16, 5).unwrap();

        let ring_prefetch = scheduler
            .prefetch_ring_tiles(&[visible_tile_key])
            .expect("the ring has uncached candidates");
        assert_eq!(
            ring_prefetch.await,
            3,
            "the plan claims exactly its budget, parents first"
        );
        assert_eq!(provider.fetch_count(), 3);

        // The parent is the first claim, so it is cached while the visible
        // child is not: the frame paints the parent as the child's fallback.
        let frame = scheduler.cached_frame(&[visible_tile_key], 5.0);
        assert_eq!(frame.drawn_tile_count, 0);
        assert_eq!(frame.pending_tile_count, 1);
        assert_eq!(
            frame.fallback_tile_count, 1,
            "the coarse parent stands in for the missing child"
        );
        assert!(!frame.is_idle(), "the child's own detail is still owed");
        assert!(
            !frame.overlays.is_empty(),
            "the fallback parent paints its geometry"
        );
        assert!(
            frame
                .diagnostics
                .time_to_first_drawn_tile_milliseconds
                .is_some(),
            "the fallback coverage counts as the first drawn tile"
        );
    }

    #[tokio::test]
    async fn a_failed_child_draws_its_cached_parent() {
        let child_tile_key = SOURDOUGH_TILE_KEY;
        let parent_tile_key = child_tile_key
            .parent_tile_key()
            .expect("the fixture tile has a parent");
        let provider = Arc::new(ScriptedVectorTileProvider {
            served_tile_bytes: [(parent_tile_key, SOURDOUGH_TILE_BYTES.to_vec())]
                .into_iter()
                .collect(),
            failed_tile_keys: vec![child_tile_key],
            fetch_count: Mutex::new(0),
            descriptor: VectorTileSourceDescriptor {
                source_name: "scripted".to_string(),
                attribution_text: "Scripted vector tiles".to_string(),
                minimum_zoom_level: 0,
                maximum_zoom_level: 14,
            },
        });
        let mut scheduler = VectorBaseScheduler::new(
            Arc::clone(&provider) as Arc<dyn VectorTileProvider>,
            "test-highways",
            highways_style_with_width_stops(),
        );
        let parent_frame = scheduler.resolve_frame(&[parent_tile_key], 6.0).await;
        assert_eq!(parent_frame.drawn_tile_count, 1);
        let parent_overlay_count = parent_frame.overlays.len();
        assert!(parent_overlay_count > 0);

        scheduler
            .prefetch_missing_tiles(&[child_tile_key])
            .expect("the failing child is claimed")
            .await;
        let frame = scheduler.cached_frame(&[child_tile_key], 6.0);
        assert_eq!(frame.drawn_tile_count, 0);
        assert_eq!(frame.failed_tile_count, 1);
        assert_eq!(frame.fallback_tile_count, 1);
        assert_eq!(
            frame.overlays.len(),
            parent_overlay_count,
            "the cached parent paints once for the failed child"
        );
        assert!(frame.last_failure_detail.is_some());
    }

    #[tokio::test]
    async fn a_cancelled_prefetch_releases_its_in_flight_claims() {
        use std::task::{Context, Poll};

        let stalled_tile_key = TileKey::new(9, 3, 6).unwrap();
        let mut scheduler = VectorBaseScheduler::new(
            Arc::new(StalledVectorTileProvider),
            "test-highways",
            highways_style_with_width_stops(),
        );
        let prefetch = scheduler
            .prefetch_missing_tiles(&[stalled_tile_key])
            .expect("the stalled tile is claimed");
        let mut prefetch_future = Box::pin(prefetch);
        let never_waking_waker = noop_waker();
        let mut never_waking_context = Context::from_waker(&never_waking_waker);
        assert_eq!(
            prefetch_future.as_mut().poll(&mut never_waking_context),
            Poll::Pending,
            "the stalled fetch parks the prefetch at its await point"
        );
        drop(prefetch_future);

        let frame = scheduler.cached_frame(&[stalled_tile_key], 6.0);
        assert_eq!(frame.pending_tile_count, 1);
        assert_eq!(
            frame.diagnostics.in_flight_fetch_count, 0,
            "a dropped prefetch must not leave its address in flight forever"
        );
        assert!(
            scheduler
                .prefetch_missing_tiles(&[stalled_tile_key])
                .is_some(),
            "the released address is fetchable again"
        );
    }
}
