//! Vector-tile styling: a decoded [`rustic_maps_vector_tiles::VectorTile`] becomes
//! the renderer's overlay primitives under a compiled style plan.
//!
//! The style document and its expressions live in `rustic-maps-style`; this
//! module is the renderer's consumer. [`vector_tile_style_from_id`] parses a
//! committed version-8 style document and compiles it once into a
//! [`CompiledStyle`](rustic_maps_style::CompiledStyle). Each frame then resolves
//! the compiled plan at the camera's fractional zoom, so paint expressions
//! change continuously with the camera without re-parsing the document.
//!
//! Polygon features paint every exterior ring with its interior rings
//! subtracted through the overlay's hole-aware fill (see
//! [`crate::overlay::FilledPolygonOverlay`]); line features become styled
//! polylines and point features become screen-facing markers. Primitives are
//! grouped into one [`VectorOverlayBatch`] per style layer and one bucket per
//! layer in [`vector_tile_overlay_layers_at_zoom`], so a frame can paint every
//! tile's layer 0 before any tile's layer 1: global style order across the
//! visible tile set.
//!
//! Coordinates convert from tile-local extent space (`x` right, `y` down, the
//! MVT convention) through the tile's web-mercator address to geographic
//! degrees, so the overlays project exactly like every other map coordinate.
//!
//! Symbol layers paint no overlay primitive: their labels are data for the
//! frame-level label pass ([`crate::labels`]), which reads the same compiled
//! plan, filter and layout.

use crate::overlay::{
    DEFAULT_POINT_MARKER_PITCH_ALIGNMENT, DEFAULT_POINT_MARKER_PITCH_SCALE, FilledPolygonOverlay,
    MapOverlay, PointMarkersOverlay, PolylineStroke, RoutePolylineOverlay,
};
use geospatial_types::GeographicCoordinate;
use rustic_maps_style::{
    Color, CompiledLayer, CompiledLayerKind, CompiledSourceKind, CompiledStyle, EvaluationContext,
    GeometryType, MapStyleDocument, ResolvedPaint, Value, compile_style_document,
};
use rustic_maps_vector_tiles::{
    VectorTile, VectorTileAttributeValue, VectorTileFeature, VectorTileGeometry,
    VectorTileGeometryPoint, VectorTileGeometryType, VectorTileLayer, VectorTileLinearRing,
};
use std::collections::BTreeMap;
use std::f64::consts::PI;

/// The longitude span the web-mercator world covers, in degrees.
const WORLD_LONGITUDE_SPAN_DEGREES: f64 = 360.0;
/// The longitude at the world's western edge, in degrees.
const WORLD_WEST_LONGITUDE_DEGREES: f64 = -180.0;
/// The latitude the mercator projection approaches at the world's edges.
pub const MERCATOR_MAXIMUM_LATITUDE_DEGREES: f64 = 85.051_128_779_806_59;

/// The text colour a label descriptor carries when it omits one: opaque
/// black, the specification's `text-color` default.
pub const DEFAULT_VECTOR_SYMBOL_TEXT_RGBA: [f32; 4] = [0.0, 0.0, 0.0, 1.0];
/// The halo colour a label descriptor carries when it omits one: opaque
/// white.
pub const DEFAULT_VECTOR_SYMBOL_HALO_RGBA: [f32; 4] = [1.0, 1.0, 1.0, 1.0];
/// Whether a label descriptor that omits the rule may overlap other labels:
/// no, text collides and is dropped when it cannot be placed.
pub const DEFAULT_VECTOR_SYMBOL_ALLOW_OVERLAP: bool = false;

/// The tile address a decoded tile belongs to (its web-mercator position).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct VectorTileAddress {
    /// The tile's zoom level.
    pub zoom_level: u8,
    /// The tile's column at that zoom.
    pub tile_x: u32,
    /// The tile's row at that zoom.
    pub tile_y: u32,
}

/// One style layer's overlay primitives from one tile.
#[derive(Debug, Clone, PartialEq)]
pub struct VectorOverlayBatch {
    /// The compiled layer's global paint order key.
    pub layer_index: usize,
    /// The compiled layer's id.
    pub layer_id: String,
    /// The layer's overlay primitives, in feature order.
    pub overlays: Vec<MapOverlay>,
}

/// The built-in style document the default style loads from.
pub const DEFAULT_VECTOR_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style.json");

/// The style ids the built-in styles answer, keyed by the tile schema and
/// the theme. A provider registry descriptor names only the schema half
/// (`carto` or `openmaptiles`); the page joins it with the active theme.
pub const VECTOR_STYLE_ID_CARTO_LIGHT: &str = "carto-light";
/// The OSM-Carto-like schema's dark palette.
pub const VECTOR_STYLE_ID_CARTO_DARK: &str = "carto-dark";
/// The OpenMapTiles schema's light palette.
pub const VECTOR_STYLE_ID_OPENMAPTILES_LIGHT: &str = "openmaptiles-light";
/// The OpenMapTiles schema's dark palette.
pub const VECTOR_STYLE_ID_OPENMAPTILES_DARK: &str = "openmaptiles-dark";
/// OpenFreeMap's **Bright** style (the OpenMapTiles schema's rich light
/// palette): the named light style the vector base offers.
pub const VECTOR_STYLE_ID_BRIGHT_LIGHT: &str = "bright-light";
/// OpenFreeMap's **Fiord** style: the named dark palette with legible road
/// classes.
pub const VECTOR_STYLE_ID_FIORD_DARK: &str = "fiord-dark";
/// OpenFreeMap's **Positron** style: the quiet, deliberately monochrome light
/// palette.
pub const VECTOR_STYLE_ID_POSITRON_LIGHT: &str = "positron-light";

/// The dark OSM-Carto-like document: the same layer structure as the default,
/// painted for a dark map surface.
const CARTO_DARK_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-dark.json");
/// The OpenMapTiles light document: the layer and attribute vocabulary of the
/// OpenMapTiles schema.
const OPENMAPTILES_LIGHT_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-openmaptiles-light.json");
/// The OpenMapTiles dark document.
const OPENMAPTILES_DARK_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-openmaptiles-dark.json");
/// The Bright light document: the Bright palette curated to the overlay
/// pipeline's fill, line, circle and symbol kinds.
const BRIGHT_LIGHT_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-bright-light.json");
/// The Fiord dark document, curated to the same overlay kinds.
const FIORD_DARK_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-fiord-dark.json");
/// The Positron light document, curated to the same overlay kinds.
const POSITRON_LIGHT_STYLE_DOCUMENT_JSON: &str =
    include_str!("../fixtures/render/styles/vector-style-positron-light.json");

/// The style documents a style id can name; `None` names no built-in style.
fn vector_style_document_json(style_id: &str) -> Option<&'static str> {
    match style_id {
        VECTOR_STYLE_ID_CARTO_LIGHT => Some(DEFAULT_VECTOR_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_CARTO_DARK => Some(CARTO_DARK_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_OPENMAPTILES_LIGHT => Some(OPENMAPTILES_LIGHT_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_OPENMAPTILES_DARK => Some(OPENMAPTILES_DARK_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_BRIGHT_LIGHT => Some(BRIGHT_LIGHT_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_FIORD_DARK => Some(FIORD_DARK_STYLE_DOCUMENT_JSON),
        VECTOR_STYLE_ID_POSITRON_LIGHT => Some(POSITRON_LIGHT_STYLE_DOCUMENT_JSON),
        _ => None,
    }
}

/// Parses and compiles the built-in style document a style id names.
///
/// # Parameters
/// - `style_id` — one of the exported `VECTOR_STYLE_ID_*` identifiers.
///
/// # Returns
/// The compiled style, ready to resolve at a frame zoom and feature.
///
/// # Errors
/// An unknown id and a malformed document both report the typed artifact
/// error rather than a guess.
pub fn vector_tile_style_from_id(
    style_id: &str,
) -> Result<CompiledStyle, VectorStyleArtifactError> {
    let Some(style_json) = vector_style_document_json(style_id) else {
        return Err(VectorStyleArtifactError {
            detail: format!(
                "no committed vector style carries the id {style_id:?}; known ids are \
                 {VECTOR_STYLE_ID_CARTO_LIGHT}, {VECTOR_STYLE_ID_CARTO_DARK}, \
                 {VECTOR_STYLE_ID_OPENMAPTILES_LIGHT}, {VECTOR_STYLE_ID_OPENMAPTILES_DARK}, \
                 {VECTOR_STYLE_ID_BRIGHT_LIGHT}, {VECTOR_STYLE_ID_FIORD_DARK}, \
                 {VECTOR_STYLE_ID_POSITRON_LIGHT}"
            ),
        });
    };
    vector_tile_style_from_json(style_json)
}

/// Why a style document could not be parsed into a compiled style.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VectorStyleArtifactError {
    /// The underlying parser detail.
    pub detail: String,
}

impl std::fmt::Display for VectorStyleArtifactError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "vector style artifact invalid: {}", self.detail)
    }
}

impl std::error::Error for VectorStyleArtifactError {}

/// Parses and compiles a version-8 style document.
///
/// The compile step is infallible; only a malformed document reports an error.
pub fn vector_tile_style_from_json(
    style_json: &str,
) -> Result<CompiledStyle, VectorStyleArtifactError> {
    let document = MapStyleDocument::parse_json(style_json).map_err(|style_error| {
        VectorStyleArtifactError {
            detail: style_error.to_string(),
        }
    })?;
    Ok(compile_style_document(&document))
}

/// The default style, compiled from the committed default document.
pub fn default_vector_tile_style() -> CompiledStyle {
    vector_tile_style_or_fallback(DEFAULT_VECTOR_STYLE_DOCUMENT_JSON)
}

/// Compiles a style document, falling back to the committed default document
/// when the supplied one is malformed.
///
/// The default document is itself compiled at most once per call and is a
/// compile-time constant, so this cannot loop; an empty style is the last
/// resort if the committed default is ever removed from the build.
pub fn vector_tile_style_or_fallback(style_json: &str) -> CompiledStyle {
    vector_tile_style_from_json(style_json).unwrap_or_else(|_| {
        vector_tile_style_from_json(DEFAULT_VECTOR_STYLE_DOCUMENT_JSON)
            .unwrap_or_else(|_| empty_compiled_style())
    })
}

/// The style that paints nothing, used only when the committed default
/// document is unreadable.
fn empty_compiled_style() -> CompiledStyle {
    CompiledStyle {
        background: None,
        sources: std::collections::BTreeMap::new(),
        layers: Vec::new(),
        unsupported: Vec::new(),
    }
}

/// Converts one tile-local extent point into a geographic coordinate through
/// the tile's web-mercator address. Vertices at the extent boundary are legal
/// (they land on the next tile's edge); the latitude clamp keeps the projection
/// finite at the world's polar edges.
pub fn tile_local_point_to_coordinate(
    tile_address: VectorTileAddress,
    layer_extent: u64,
    point: &VectorTileGeometryPoint,
) -> GeographicCoordinate {
    let extent = layer_extent.max(1) as f64;
    let tiles_per_axis = (1u64 << tile_address.zoom_level) as f64;
    let world_x =
        (f64::from(tile_address.tile_x) + point.x_coordinate as f64 / extent) / tiles_per_axis;
    let world_y =
        (f64::from(tile_address.tile_y) + point.y_coordinate as f64 / extent) / tiles_per_axis;
    let longitude_degrees = world_x * WORLD_LONGITUDE_SPAN_DEGREES + WORLD_WEST_LONGITUDE_DEGREES;
    let latitude_degrees = (PI * (1.0 - 2.0 * world_y)).sinh().atan().to_degrees();
    GeographicCoordinate {
        latitude: latitude_degrees.clamp(
            -MERCATOR_MAXIMUM_LATITUDE_DEGREES,
            MERCATOR_MAXIMUM_LATITUDE_DEGREES,
        ),
        longitude: longitude_degrees,
    }
}

/// Converts a decoded tile into one batch per style layer whose filter and
/// geometry contribute at least one primitive. The tile's own zoom level is
/// the style zoom.
pub fn overlay_primitives_for_vector_tile(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
) -> Vec<VectorOverlayBatch> {
    overlay_primitives_for_vector_tile_at_zoom(
        tile,
        tile_address,
        style,
        f64::from(tile_address.zoom_level),
    )
}

/// The same conversion as [`overlay_primitives_for_vector_tile`], with the
/// style's zoom expressions evaluated at an explicit `style_zoom_level`.
///
/// The base-map scheduler styles a cached tile at the camera's fractional zoom
/// level, so a pan across a paint stop restyles the already-fetched tile
/// instead of fetching it again; the tile's address still converts every
/// coordinate, because the geometry belongs to the tile, not to the zoom the
/// paint is evaluated at.
pub fn overlay_primitives_for_vector_tile_at_zoom(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
    style_zoom_level: f64,
) -> Vec<VectorOverlayBatch> {
    let mut batches = Vec::new();
    for layer in &style.layers {
        let overlays = overlays_for_layer(tile, tile_address, layer, style_zoom_level);
        if !overlays.is_empty() {
            batches.push(VectorOverlayBatch {
                layer_index: layer.order_index,
                layer_id: layer.id.clone(),
                overlays,
            });
        }
    }
    batches
}

/// The tile's overlays bucketed by compiled layer index: bucket `index`
/// holds every primitive the style layer whose `order_index` is `index`
/// paints from this tile, and an empty bucket means that layer painted
/// nothing. A frame concatenates the buckets layer by layer across all tiles.
pub fn vector_tile_overlay_layers_at_zoom(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
    style_zoom_level: f64,
) -> Vec<Vec<MapOverlay>> {
    let mut layers = vec![Vec::new(); style.layer_count()];
    for layer in &style.layers {
        if let Some(bucket) = layers.get_mut(layer.order_index) {
            *bucket = overlays_for_layer(tile, tile_address, layer, style_zoom_level);
        }
    }
    layers
}

/// Converts one decoded tile into its flat overlay primitive list under the
/// style (the batches of [`overlay_primitives_for_vector_tile`] in style
/// order, concatenated).
pub fn vector_tile_overlays(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
) -> Vec<MapOverlay> {
    vector_tile_overlays_at_zoom(
        tile,
        tile_address,
        style,
        f64::from(tile_address.zoom_level),
    )
}

/// The flat overlay primitive list of [`overlay_primitives_for_vector_tile_at_zoom`]
/// (its batches in style order, concatenated).
pub fn vector_tile_overlays_at_zoom(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
    style_zoom_level: f64,
) -> Vec<MapOverlay> {
    overlay_primitives_for_vector_tile_at_zoom(tile, tile_address, style, style_zoom_level)
        .into_iter()
        .flat_map(|batch| batch.overlays)
        .collect()
}

/// Every overlay one compiled layer paints from the tile, in feature order.
///
/// This is the single-layer seam a multi-source frame assembles with: the
/// caller passes the tile fetched from the layer's own source binding, so
/// layers bound to different sources never read each other's geometry.
pub fn overlays_for_compiled_layer_at_zoom(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    layer: &CompiledLayer,
    style_zoom_level: f64,
) -> Vec<MapOverlay> {
    overlays_for_layer(tile, tile_address, layer, style_zoom_level)
}

/// The tile layers a compiled layer reads.
///
/// A layer names its `source-layer`; a GeoJSON source carries its features in
/// one implicit layer, so a GeoJSON-bound layer without `source-layer` reads
/// that single layer. A vector layer without `source-layer` reads nothing.
pub fn tile_layers_for_compiled_layer<'a>(
    tile: &'a VectorTile,
    layer: &CompiledLayer,
) -> Vec<&'a VectorTileLayer> {
    // A GeoJSON source carries every feature in one implicit layer, and the
    // style specification ignores `source-layer` for such a source.
    if layer.source_kind == Some(CompiledSourceKind::GeoJson) && tile.layers.len() == 1 {
        return tile.layers.iter().collect();
    }
    match layer.source_layer.as_deref() {
        Some(source_layer) => tile
            .layers
            .iter()
            .filter(|tile_layer| tile_layer.name == source_layer)
            .collect(),
        None => Vec::new(),
    }
}

fn overlays_for_layer(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    layer: &CompiledLayer,
    style_zoom_level: f64,
) -> Vec<MapOverlay> {
    if !matches!(
        layer.kind,
        CompiledLayerKind::Fill | CompiledLayerKind::Line | CompiledLayerKind::Circle
    ) || !layer.is_visible_at_zoom(style_zoom_level)
    {
        return Vec::new();
    }
    let mut feature_overlays: Vec<(f64, Vec<MapOverlay>)> = Vec::new();
    for tile_layer in tile_layers_for_compiled_layer(tile, layer) {
        for feature in &tile_layer.features {
            let properties = feature_properties(feature);
            let context = feature_evaluation_context(feature, &properties, style_zoom_level);
            if !layer.matches_filter(&context) {
                continue;
            }
            let mut overlays = Vec::new();
            match (&feature.geometry, layer.kind) {
                (VectorTileGeometry::Polygons(rings), CompiledLayerKind::Fill) => {
                    if let ResolvedPaint::Fill(paint) = layer.resolved_paint(&context) {
                        overlays.extend(filled_polygon_overlays_for_rings(
                            rings,
                            tile_layer.extent,
                            tile_address,
                            &paint,
                        ));
                    }
                }
                (VectorTileGeometry::LineStrings(line_strings), CompiledLayerKind::Line) => {
                    if let ResolvedPaint::Line(paint) = layer.resolved_paint(&context) {
                        let rgba_color = resolved_rgba(paint.color, paint.opacity);
                        // A layer that declares a line presentation gets the
                        // specification's stroke; one that declares nothing
                        // keeps the renderer's default route stroke, so a
                        // style that predates these properties draws exactly
                        // as before.
                        let stroke = layer.declares_line_presentation.then(|| PolylineStroke {
                            cap: layer.resolved_line_cap(&context),
                            join: layer.resolved_line_join(&context),
                            dash_array: paint.dasharray.clone(),
                            offset_pixels: paint.offset,
                            gap_width_pixels: paint.gap_width,
                            blur_pixels: paint.blur,
                        });
                        for line_string in line_strings {
                            let coordinates = line_string
                                .iter()
                                .map(|point| {
                                    tile_local_point_to_coordinate(
                                        tile_address,
                                        tile_layer.extent,
                                        point,
                                    )
                                })
                                .collect();
                            overlays.push(MapOverlay::RoutePolyline(RoutePolylineOverlay {
                                coordinates,
                                rgba_color,
                                width_pixels: paint.width,
                                stroke: stroke.clone(),
                            }));
                        }
                    }
                }
                (VectorTileGeometry::Points(points), CompiledLayerKind::Circle) => {
                    if let ResolvedPaint::Circle(paint) = layer.resolved_paint(&context) {
                        let positions = points
                            .iter()
                            .map(|point| {
                                tile_local_point_to_coordinate(
                                    tile_address,
                                    tile_layer.extent,
                                    point,
                                )
                            })
                            .collect();
                        overlays.push(MapOverlay::PointMarkers(PointMarkersOverlay {
                            positions,
                            rgba_color: resolved_rgba(paint.color, paint.opacity),
                            radius_pixels: paint.radius,
                            rgba_stroke_color: paint.stroke_color.map(|stroke_color| {
                                resolved_rgba(stroke_color, paint.stroke_opacity)
                            }),
                            stroke_width_pixels: paint.stroke_width,
                            blur_pixels: paint.blur,
                            translate_pixels: paint.translate,
                            // A layer that declares neither property keeps
                            // this renderer's screen-facing default, which
                            // the cached world-space path can express.
                            pitch_scale: if layer.declares_circle_pitch {
                                layer.resolved_circle_pitch_scale(&context)
                            } else {
                                DEFAULT_POINT_MARKER_PITCH_SCALE
                            },
                            pitch_alignment: if layer.declares_circle_pitch {
                                layer.resolved_circle_pitch_alignment(&context)
                            } else {
                                DEFAULT_POINT_MARKER_PITCH_ALIGNMENT
                            },
                        }));
                    }
                }
                // A style paints only its declared kind; a feature of
                // another kind is not this layer's paint, and a symbol
                // layer's labels belong to the frame-level label pass.
                _ => {}
            }
            if !overlays.is_empty() {
                feature_overlays.push((layer.resolved_line_sort_key(&context), overlays));
            }
        }
    }
    // `line-sort-key` orders features within the layer; a stable sort keeps
    // equal keys in source order, and features that declare no key all
    // resolve to the documented default.
    feature_overlays.sort_by(|(left_key, _), (right_key, _)| left_key.total_cmp(right_key));
    feature_overlays
        .into_iter()
        .flat_map(|(_, overlays)| overlays)
        .collect()
}

/// Converts the compiled colour and opacity into the renderer's RGBA
/// components, folding opacity into the alpha channel.
pub(crate) fn resolved_rgba(color: Color, opacity: f64) -> [f32; 4] {
    [
        color.red as f32,
        color.green as f32,
        color.blue as f32,
        (color.alpha * opacity) as f32,
    ]
}

/// The feature's attributes as the style evaluator's property map.
pub(crate) fn feature_properties(feature: &VectorTileFeature) -> BTreeMap<String, Value> {
    feature
        .attributes
        .iter()
        .map(|(attribute_name, attribute_value)| {
            (
                attribute_name.clone(),
                attribute_value_to_style_value(attribute_value),
            )
        })
        .collect()
}

/// One decoder attribute value as the style evaluator's value: text, a number
/// for every numeric wire variant, and a boolean.
fn attribute_value_to_style_value(attribute_value: &VectorTileAttributeValue) -> Value {
    match attribute_value {
        VectorTileAttributeValue::Text(text) => Value::String(text.clone()),
        VectorTileAttributeValue::Boolean(boolean) => Value::Boolean(*boolean),
        numeric_value => Value::Number(numeric_value.numeric_value().unwrap_or_default()),
    }
}

/// The feature's geometry kind as the style evaluator reports it.
pub(crate) fn feature_geometry_type(feature: &VectorTileFeature) -> GeometryType {
    match feature.geometry_type {
        VectorTileGeometryType::LineString => GeometryType::LineString,
        VectorTileGeometryType::Polygon => GeometryType::Polygon,
        VectorTileGeometryType::Point | VectorTileGeometryType::Unknown => GeometryType::Point,
    }
}

/// An evaluation context for one feature at `zoom`: its properties, geometry
/// kind and no external state.
pub(crate) fn feature_evaluation_context<'a>(
    feature: &VectorTileFeature,
    properties: &'a BTreeMap<String, Value>,
    zoom: f64,
) -> EvaluationContext<'a> {
    EvaluationContext::at_zoom(zoom).with_feature(properties, feature_geometry_type(feature))
}

/// Groups a polygon feature's rings into filled overlays: each exterior ring
/// owns its immediately following interior rings, the specification's order.
/// A leading interior ring (malformed ring order) has no exterior to subtract
/// from and is skipped rather than painted as a fill of its own.
fn filled_polygon_overlays_for_rings(
    rings: &[VectorTileLinearRing],
    layer_extent: u64,
    tile_address: VectorTileAddress,
    paint: &rustic_maps_style::ResolvedFillPaint,
) -> Vec<MapOverlay> {
    let mut overlays = Vec::new();
    let mut current_exterior_index: Option<usize> = None;
    for ring in rings {
        let ring_coordinates: Vec<GeographicCoordinate> = ring
            .vertices
            .iter()
            .map(|point| tile_local_point_to_coordinate(tile_address, layer_extent, point))
            .collect();
        if ring_is_exterior(ring) {
            overlays.push(MapOverlay::FilledPolygon(FilledPolygonOverlay {
                ring_coordinates,
                hole_ring_coordinates: Vec::new(),
                rgba_color: resolved_rgba(paint.color, paint.opacity),
                rgba_outline_color: paint
                    .outline_color
                    .map(|outline_color| resolved_rgba(outline_color, paint.opacity)),
                antialias: paint.antialias,
                translate_pixels: paint.translate,
            }));
            current_exterior_index = Some(overlays.len() - 1);
        } else if let Some(exterior_index) = current_exterior_index {
            if let Some(MapOverlay::FilledPolygon(overlay)) = overlays.get_mut(exterior_index) {
                overlay.hole_ring_coordinates.push(ring_coordinates);
            }
        }
    }
    overlays
}

/// The feature's geometry kind (the decoder's own classification).
pub fn feature_geometry_kind(feature: &VectorTileFeature) -> VectorTileGeometryType {
    feature.geometry_type
}

/// The ring's signed shoelace area in tile-local space; exterior rings are
/// positive (the specification's `y`-down convention), holes negative.
fn ring_is_exterior(ring: &VectorTileLinearRing) -> bool {
    let vertices = &ring.vertices;
    if vertices.len() < 3 {
        return false;
    }
    let mut doubled_area = 0.0;
    for vertex_index in 0..vertices.len() {
        let current = &vertices[vertex_index];
        let next = &vertices[(vertex_index + 1) % vertices.len()];
        doubled_area += current.x_coordinate as f64 * next.y_coordinate as f64
            - next.x_coordinate as f64 * current.y_coordinate as f64;
    }
    doubled_area > 0.0
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A style whose one line layer sorts by `rank`, paints a width from
    /// `width` and declares a round cap.
    fn sorted_line_style() -> CompiledStyle {
        let document = MapStyleDocument::parse_json(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "roads",
                        "type": "line",
                        "source": "base",
                        "source-layer": "roads",
                        "layout": { "line-cap": "round", "line-sort-key": ["get", "rank"] },
                        "paint": { "line-width": ["get", "width"] }
                    }
                ]
            }"#,
        )
        .expect("the fixture style parses");
        compile_style_document(&document)
    }

    /// Two road features in source order: the higher rank first, so a sort is
    /// observable.
    fn tile_with_two_roads() -> VectorTile {
        let line = |y_coordinate: i64| {
            VectorTileGeometry::LineStrings(vec![vec![
                VectorTileGeometryPoint {
                    x_coordinate: 0,
                    y_coordinate,
                },
                VectorTileGeometryPoint {
                    x_coordinate: 100,
                    y_coordinate,
                },
            ]])
        };
        let road = |identifier: u64, rank: i64, width: i64, y_coordinate: i64| VectorTileFeature {
            identifier: Some(identifier),
            geometry_type: VectorTileGeometryType::LineString,
            geometry: line(y_coordinate),
            attributes: vec![
                ("rank".to_string(), VectorTileAttributeValue::Signed(rank)),
                ("width".to_string(), VectorTileAttributeValue::Signed(width)),
            ],
        };
        VectorTile {
            layers: vec![VectorTileLayer {
                name: "roads".to_string(),
                extent: 4096,
                version: 2,
                features: vec![road(1, 2, 20, 100), road(2, 1, 10, 200)],
            }],
        }
    }

    fn route_polyline(overlay: &MapOverlay) -> &RoutePolylineOverlay {
        match overlay {
            MapOverlay::RoutePolyline(route_polyline) => route_polyline,
            other => panic!("expected a route polyline, got {other:?}"),
        }
    }

    #[test]
    fn line_sort_keys_order_features_and_paint_resolves_per_feature() {
        let style = sorted_line_style();
        let layer = style.layer("roads").expect("the roads layer compiles");
        let overlays = overlays_for_compiled_layer_at_zoom(
            &tile_with_two_roads(),
            VectorTileAddress {
                zoom_level: 0,
                tile_x: 0,
                tile_y: 0,
            },
            layer,
            0.0,
        );
        assert_eq!(overlays.len(), 2);
        // The lower sort key paints first even though its feature is second
        // in source order; every feature resolves its own width.
        assert_eq!(route_polyline(&overlays[0]).width_pixels, 10.0);
        assert_eq!(route_polyline(&overlays[1]).width_pixels, 20.0);
    }

    #[test]
    fn a_declared_line_presentation_becomes_a_styled_stroke() {
        let style = sorted_line_style();
        let layer = style.layer("roads").expect("the roads layer compiles");
        let overlays = overlays_for_compiled_layer_at_zoom(
            &tile_with_two_roads(),
            VectorTileAddress {
                zoom_level: 0,
                tile_x: 0,
                tile_y: 0,
            },
            layer,
            0.0,
        );
        let stroke = route_polyline(&overlays[0])
            .stroke
            .as_ref()
            .expect("the declared line-cap makes the stroke styled");
        assert_eq!(stroke.cap, rustic_maps_style::LineCap::Round);
        assert!(stroke.dash_array.is_empty());
    }

    #[test]
    fn a_layer_that_declares_no_line_presentation_keeps_the_default_stroke() {
        let document = MapStyleDocument::parse_json(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "roads",
                        "type": "line",
                        "source": "base",
                        "source-layer": "roads",
                        "paint": { "line-width": 2 }
                    }
                ]
            }"#,
        )
        .expect("the fixture style parses");
        let style = compile_style_document(&document);
        let layer = style.layer("roads").expect("the roads layer compiles");
        assert!(!layer.declares_line_presentation);
        let overlays = overlays_for_compiled_layer_at_zoom(
            &tile_with_two_roads(),
            VectorTileAddress {
                zoom_level: 0,
                tile_x: 0,
                tile_y: 0,
            },
            layer,
            0.0,
        );
        assert!(route_polyline(&overlays[0]).stroke.is_none());
    }
}
