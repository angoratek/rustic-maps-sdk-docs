//! The frame-level label pass: symbol-layer text from decoded vector tiles
//! becomes screen-space glyph quads, anchored at a point for place and POI
//! names and run along a line for road names.
//!
//! The pass is deliberately GPU-free, like the overlay assembly: the native
//! headless renderer, the native surface and the browser canvas all call the
//! same functions and upload the same vertices, so the backends cannot drift
//! in where a label lands or which labels survive.
//!
//! Three stages:
//!
//! 1. [`label_candidates_for_vector_tile`] walks a decoded tile's symbol-layer
//!    features and reads each label's text through the compiled style's
//!    text-field expression. Candidates keep the style's paint, size, priority,
//!    rank, placement and overlap rule. A symbol layer's filter also gates a
//!    feature before it becomes a candidate: the converted styles encode the
//!    zoom-stepped rank ceiling and the per-class minimum zooms as `step`
//!    expressions on `["zoom"]` inside an `all` filter. A
//!    [`SymbolPlacement::Point`] layer anchors a candidate at each of the
//!    feature's points; a [`SymbolPlacement::Line`] layer carries the feature's
//!    whole line geometry so the frame can place the text along it.
//! 2. [`LabelLayer::place`] projects the candidates through the frame camera,
//!    sorts them by priority, then style order, then rank (the documented
//!    collision-priority rule: lower priority is more important), and greedily
//!    rejects any label whose padded screen
//!    rectangle intersects a label already placed. `allow_overlap` labels skip
//!    the test and never block later labels. The frame places at most
//!    [`MAXIMUM_LABELS_PER_FRAME`] labels: once that budget is spent, every
//!    remaining candidate is dropped even if it would fit, so a dense downtown
//!    cannot out-shout the places that matter. A label whose text repeats an
//!    already-placed label is dropped, so the buffered overlap between
//!    adjacent tiles cannot paint one place twice. The output order is a pure
//!    function of the input order and the camera.
//!
//!    A line-placed label projects its geometry and takes its longest straight
//!    run (consecutive near-collinear segments) as the text's run: the text is
//!    centered halfway along that run, rotated to its chord bearing, flipped
//!    so it always reads upright, and skipped when the run is shorter than the
//!    text plus the collision padding at each end. The collision rectangle is
//!    the axis-aligned box around the rotated text, so it rejects exactly like
//!    a point label's.
//! 3. [`LabelLayer::quad_vertices`] lays the glyph bitmaps out on the atlas and
//!    emits clip-space textured quads, halo first and text second. A rotated
//!    label rotates each glyph's screen-space rectangle about the label's
//!    anchor before converting it to clip space, so every backend that draws
//!    these vertices carries rotation without a second vertex format.
//!
//! Latin text is measured from the decoded glyph ranges and nothing here
//! shapes complex scripts (see `rustic-maps-glyphs`). A frame with no symbol layers or
//! no glyphs produces no vertices, so the tiles-only pipelines stay
//! byte-identical.

use crate::camera::{MapCamera, ViewportPixels};
use crate::vector_style::{
    VectorTileAddress, feature_evaluation_context, feature_properties, resolved_rgba,
    tile_local_point_to_coordinate,
};
use geospatial_types::GeographicCoordinate;
use rustic_maps_glyphs::{
    GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS, GlyphAtlasError, GlyphFontStack, PackedGlyph,
    PackedGlyphAtlas, decode_glyph_font_stack, pack_glyph_atlas,
};
use rustic_maps_style::{
    CompiledLayerKind, CompiledStyle, ResolvedPaint, SymbolPlacement, TextJustify,
};
use rustic_maps_vector_tiles::{VectorTile, VectorTileFeature, VectorTileGeometry};
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};
use std::sync::{Arc, OnceLock};

/// The em size the glyph protocol rasterizes signed-distance-field glyphs at:
/// every glyph metric in a range payload is expressed in these 24-pixel em
/// units and scaled to the style's text size at draw time.
pub const GLYPH_FONT_EM_PIXELS: f64 = 24.0;

/// The line ascent the glyph protocol subtracts from each glyph's ink top
/// before storing it: fontnik writes `stored_top = ink_top_above_baseline -
/// ascender` at the protocol's 24-pixel em, so a renderer reconstructs the
/// baseline-relative ink top as `stored_top + ascender`. Noto Sans' ascender
/// at that size is 26 pixels (the payload's no-ink space glyph stores `-26`).
pub const GLYPH_FONT_ASCENDER_PIXELS: f64 = 26.0;

/// The transparent margin kept around a placed label's screen rectangle for
/// collision rejection, in pixels. Labels closer than this read as a single
/// run of text, so the padding is what keeps two names from touching.
pub const LABEL_COLLISION_PADDING_PIXELS: f64 = 2.0;

/// How far below the anchor a label's baseline sits, as a fraction of the
/// text size. Centering a line of text on its anchor point needs the baseline
/// below the visual center by roughly a third of the em.
pub const LABEL_BASELINE_OFFSET_FRACTION: f64 = 0.3;

/// The signed-distance value at which a glyph bitmap counts as covered.
///
/// The glyph protocol is node-fontnik's encoding,
/// `byte = 255 - (64 + 32 × distance_px)`, so the zero-distance contour — the
/// glyph outline — sits at `(256 − 64)/256 = 0.75`, not at 0.5. Thresholding at
/// 0.5 dilates every glyph by `(0.75 − 0.5) × 8 = 2` atlas pixels per side,
/// which closes counters and fattens strokes. Thresholding at 0.75 keeps the
/// outline faithful to the font.
pub const GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD: f32 = 0.75;

/// The glyph protocol's spread: one atlas pixel of distance is `1/8` of a
/// normalized distance-field unit. It converts atlas pixels into threshold
/// offsets.
pub const GLYPH_SIGNED_DISTANCE_FIELD_PIXELS_PER_UNIT: f32 = 8.0;

/// The glyph protocol's border, in atlas pixels: the distance field fades to
/// zero beyond this many pixels outside the ink box, so a halo can only reach
/// this far before it samples the border texel.
pub const GLYPH_SIGNED_DISTANCE_FIELD_MAXIMUM_OUTWARD_PIXELS: f64 =
    GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS as f64;

/// The half-width of the glyph shader's anti-aliasing transition, in device
/// pixels: the fragment stage's `smoothstep` half-band is
/// `0.105 / devicePixelRatio / fontScale` in normalized field units, which is
/// 0.84 device pixels at every size and pixel ratio.
pub const GLYPH_EDGE_GAMMA_DEVICE_PIXELS: f32 = 0.105;

/// The signed-distance threshold that draws a glyph's outline shifted outward
/// by `halo_width_pixels`, clamped to the field's border.
///
/// `halo_width / fontScale` is the halo in atlas pixels, and one atlas pixel
/// is `1 / 8` field unit, so the threshold moves down by that amount. The halo
/// quad itself is not inflated: the fragment stage's lower threshold is what
/// spreads the edge.
pub fn glyph_halo_signed_distance_threshold(text_size_pixels: f64, halo_width_pixels: f64) -> f32 {
    if halo_width_pixels <= 0.0 || text_size_pixels <= 0.0 {
        return GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD;
    }
    let font_scale = text_size_pixels / GLYPH_FONT_EM_PIXELS;
    let halo_atlas_pixels = halo_width_pixels / font_scale;
    let halo_units = (halo_atlas_pixels as f32)
        .min(GLYPH_SIGNED_DISTANCE_FIELD_MAXIMUM_OUTWARD_PIXELS as f32)
        / GLYPH_SIGNED_DISTANCE_FIELD_PIXELS_PER_UNIT;
    GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD - halo_units
}

/// The fragment stage's smoothstep half-band for one label, in normalized
/// distance-field units: `0.105 / devicePixelRatio / fontScale`, where
/// `fontScale = text_size_pixels / 24` (the style size, in CSS or point
/// pixels, against the atlas' 24-pixel em). The drawn text size in device
/// pixels is the same number times the device pixel ratio; the two uses keep
/// the band at 0.84 device pixels at every size and ratio.
pub fn glyph_edge_gamma(text_size_pixels: f64, device_pixel_ratio: f64) -> f32 {
    if text_size_pixels <= 0.0 || device_pixel_ratio <= 0.0 {
        return 0.0;
    }
    let font_scale = text_size_pixels / GLYPH_FONT_EM_PIXELS;
    (f64::from(GLYPH_EDGE_GAMMA_DEVICE_PIXELS) / device_pixel_ratio / font_scale) as f32
}

/// The feature attribute a symbol layer reads as its collision rank.
pub const LABEL_RANK_ATTRIBUTE_NAME: &str = "rank";

/// The feature attribute a symbol layer reads as its class (`shop`,
/// `restaurant`, `city`, …), which a style can hold back until a closer zoom.
pub const LABEL_CLASS_ATTRIBUTE_NAME: &str = "class";

/// The maximum number of labels one frame may place. The collision pass alone
/// lets a dense downtown paint far more text than a reader can parse, so the
/// frame stops at this budget after the priority sort: the most important
/// names always win, and a busy tile can only spend the frame's remaining
/// room. Thirty-two labels is about one per 8,200 screen pixels at the 512-
/// pixel label golden (whose filtered collision pass places ten), so it leaves
/// a full-screen demo headroom while capping the nine-tile downtown demo.
pub const MAXIMUM_LABELS_PER_FRAME: usize = 32;

/// The rank an unranked label carries: the highest value, so it sorts after
/// every ranked label of the same style layer.
pub const DEFAULT_LABEL_RANK: u32 = u32::MAX;

/// The bearing limit within which a line-placed label reads upright. A
/// segment whose direction would rotate the text past this angle is flipped
/// to run the other way, so a street name never paints upside down: the
/// label's rotation always lies in `[-π/2, π/2]`.
pub const LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS: f64 = std::f64::consts::FRAC_PI_2;

/// How far a segment's bearing may turn from its run's first segment and
/// still belong to the same straight run, in radians (20 degrees, a ninth of a
/// half turn). Map data splits a street into short blocks between
/// intersections, so a label must run along the straight sequence of segments,
/// not one block alone; the tolerance keeps a name off a road that bends away
/// mid-run.
pub const LINE_LABEL_STRAIGHT_RUN_ANGLE_TOLERANCE_RADIANS: f64 = std::f64::consts::PI / 9.0;

/// The gap kept between two repeated names along one long road, in pixels.
///
/// A street long enough to cross the frame is named more than once, as the
/// reference engines do: a reader then finds the name wherever they look
/// along the road instead of only at its midpoint. MapLibre's `symbol-spacing`
/// default is 250 pixels, but one frame here covers a single tile, where that
/// gap would leave nearly every road named once and the repetition invisible;
/// 90 pixels puts a name roughly every 120 pixels along a run, which is about
/// what Google Maps and HERE carry at street zooms.
pub const LINE_LABEL_REPEAT_SPACING_PIXELS: f64 = 90.0;

/// One label candidate read from a decoded tile's symbol layers, before the
/// frame projects and places it.
#[derive(Debug, Clone, PartialEq)]
pub struct MapLabelCandidate {
    /// The label text, read through the style's ordered fallbacks.
    pub text: String,
    /// The geographic anchor the label is centered on. A point-placed
    /// candidate anchors here; a line-placed candidate carries its line's
    /// first vertex, and the frame re-derives the anchor from the projected
    /// segment.
    pub anchor: GeographicCoordinate,
    /// The line geometry a line-placed candidate runs along, in the tile's
    /// order. Empty for a point-placed candidate (and a line with fewer than
    /// two vertices places like a point).
    pub line_coordinates: Vec<GeographicCoordinate>,
    /// The text paint.
    pub text_rgba: [f32; 4],
    /// The text size in screen pixels at the frame's zoom.
    pub text_size_pixels: f64,
    /// The halo paint drawn behind the text.
    pub halo_rgba: [f32; 4],
    /// The halo width in screen pixels; zero paints no halo.
    pub halo_width_pixels: f64,
    /// The style layer's priority rank (lower draws first).
    pub priority: u32,
    /// The feature's own rank (lower is more important); unranked labels carry
    /// [`DEFAULT_LABEL_RANK`].
    pub rank: u32,
    /// Whether this label may overlap others.
    pub allow_overlap: bool,
    /// Whether this label ignores collision placement entirely.
    pub ignore_placement: bool,
    /// Whether a placement crossing the viewport edge is dropped.
    pub avoid_edges: bool,
    /// The text's displacement from its anchor, in CSS pixels.
    pub text_offset_pixels: [f64; 2],
    /// The gap kept between repeated names along a line, in screen pixels.
    pub repeat_spacing_pixels: f64,
    /// Whether the label is placed once at its line's midpoint instead of
    /// being repeated along it.
    pub line_center_only: bool,
    /// The wrapping width in ems; the text size scales it to pixels.
    pub text_max_width_ems: f64,
    /// One line's height in ems.
    pub text_line_height_ems: f64,
    /// The extra space between glyphs, in ems.
    pub text_letter_spacing_ems: f64,
    /// How wrapped lines are aligned within the text block.
    pub text_justify: TextJustify,
    /// The candidate's style-layer position, the first sort key.
    pub style_order: usize,
}

/// One label that survived collision rejection, in draw order.
#[derive(Debug, Clone, PartialEq)]
pub struct PlacedLabel {
    /// The label text.
    pub text: String,
    /// The label's anchor in viewport pixels (origin top-left, y down).
    pub anchor_screen_pixels: [f64; 2],
    /// The text's baseline rotation in radians (clockwise, y down); zero for
    /// a point-placed label and the segment's upright bearing for a
    /// line-placed one.
    pub rotation_radians: f64,
    /// Whether this label was placed along a line feature (a road name)
    /// rather than at a point.
    pub placed_along_line: bool,
    /// The text size in screen pixels.
    pub text_size_pixels: f64,
    /// The text paint.
    pub text_rgba: [f32; 4],
    /// The halo paint drawn behind the text.
    pub halo_rgba: [f32; 4],
    /// The halo width in screen pixels; zero paints no halo.
    pub halo_width_pixels: f64,
    /// The label's wrapped lines, top to bottom.
    pub lines: Vec<LabelTextLine>,
    /// One line's height in screen pixels.
    pub line_height_pixels: f64,
    /// The widest line's width in screen pixels.
    pub block_width_pixels: f64,
    /// The extra space between glyphs, in screen pixels.
    pub letter_spacing_pixels: f64,
    /// How the lines are aligned within the block.
    pub text_justify: TextJustify,
    /// The style layer's priority rank.
    pub priority: u32,
}

/// One line of a wrapped label's text.
#[derive(Debug, Clone, PartialEq)]
pub struct LabelTextLine {
    /// The line's text.
    pub text: String,
    /// The line's advance width in screen pixels, letter spacing included.
    pub width_pixels: f64,
}

/// A label's text block: its wrapped lines and the box they occupy.
#[derive(Debug, Clone, PartialEq)]
pub struct LabelTextBlock {
    /// The lines, top to bottom.
    pub lines: Vec<LabelTextLine>,
    /// The widest line's advance width in screen pixels.
    pub width_pixels: f64,
    /// The block's total height in screen pixels.
    pub height_pixels: f64,
    /// One line's height in screen pixels.
    pub line_height_pixels: f64,
}

/// The measured extent of one label's text at one size.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct LabelTextMetrics {
    /// Total advance width in screen pixels.
    pub width_pixels: f64,
    /// Line height in screen pixels (the text size).
    pub height_pixels: f64,
}

/// A packed glyph atlas plus the metrics the label pass measures text with.
#[derive(Debug, Clone)]
pub struct LabelFont {
    /// The font stack name the payload declares.
    font_stack_name: Arc<str>,
    /// The packed `R8Unorm` atlas and every glyph's metrics. Shared so a
    /// per-frame label layer clone never copies the atlas page.
    atlas: Arc<PackedGlyphAtlas>,
    /// A deterministic identity for the packed pixels and metrics, so a
    /// backend uploads the atlas once per distinct font and never per frame.
    revision: u64,
}

impl PartialEq for LabelFont {
    fn eq(&self, other: &Self) -> bool {
        self.revision == other.revision
    }
}

impl LabelFont {
    /// Packs one decoded glyph range into the atlas the label pass measures
    /// and draws with.
    ///
    /// # Parameters
    /// - `font_stack` — the decoded glyph range to pack.
    ///
    /// # Errors
    /// A page too small for the range reports the packer's typed error rather
    /// than dropping glyphs.
    pub fn from_glyph_font_stack(font_stack: &GlyphFontStack) -> Result<Self, GlyphAtlasError> {
        let atlas = pack_glyph_atlas(&font_stack.glyphs, Default::default())?;
        Ok(Self {
            font_stack_name: Arc::from(font_stack.name.as_str()),
            revision: atlas_revision(&atlas),
            atlas: Arc::new(atlas),
        })
    }

    /// The font stack name the payload declares.
    pub fn font_stack_name(&self) -> &str {
        &self.font_stack_name
    }

    /// The packed atlas, for a backend uploading its pixels.
    pub fn atlas(&self) -> &PackedGlyphAtlas {
        &self.atlas
    }

    /// The atlas' content revision; a backend uploads the texture when this
    /// changes and reuses it otherwise.
    pub fn revision(&self) -> u64 {
        self.revision
    }

    /// The packed glyph for a codepoint, if the range serves it.
    pub fn glyph(&self, codepoint: u32) -> Option<&PackedGlyph> {
        self.atlas.glyph(codepoint)
    }

    /// Measures a label's text at `text_size_pixels`.
    ///
    /// Characters the font does not serve contribute no advance and paint
    /// nothing, exactly as the quad emitter skips them, so a name with one
    /// out-of-range character still draws its remaining text rather than
    /// disappearing. `None` is reported only when the font serves none of the
    /// characters at all — a label that would paint nothing is not placed.
    pub fn measure_text(&self, text: &str, text_size_pixels: f64) -> Option<LabelTextMetrics> {
        let width_pixels = self.measure_line_width(text, text_size_pixels, 0.0)?;
        Some(LabelTextMetrics {
            width_pixels,
            height_pixels: text_size_pixels,
        })
    }

    /// One line's advance width, letter spacing included between served
    /// glyphs; `None` when the font serves none of the line's characters.
    fn measure_line_width(
        &self,
        text: &str,
        text_size_pixels: f64,
        letter_spacing_pixels: f64,
    ) -> Option<f64> {
        let scale = text_size_pixels / GLYPH_FONT_EM_PIXELS;
        let mut width_pixels = 0.0;
        let mut served_glyph_count = 0_usize;
        for character in text.chars() {
            let Some(glyph) = self.glyph(u32::from(character)) else {
                continue;
            };
            if served_glyph_count > 0 {
                width_pixels += letter_spacing_pixels;
            }
            served_glyph_count += 1;
            width_pixels += f64::from(glyph.advance) * scale;
        }
        if served_glyph_count == 0 {
            return None;
        }
        Some(width_pixels)
    }

    /// Measures a label's text as a wrapped block.
    ///
    /// Words are laid out greedily: a word that would push the line past
    /// `maximum_width_pixels` starts the next one, and a word wider than the
    /// limit on its own keeps that line. `line_height_ems` multiplies the
    /// text size for one line's height. The block width is the widest line,
    /// so a centered block is centered on its longest line. `None` is
    /// reported when the font serves no character of any line.
    pub fn measure_wrapped_text(
        &self,
        text: &str,
        text_size_pixels: f64,
        maximum_width_pixels: f64,
        line_height_ems: f64,
        letter_spacing_pixels: f64,
    ) -> Option<LabelTextBlock> {
        let mut line_texts: Vec<String> = Vec::new();
        let mut current_line = String::new();
        for word in text.split_whitespace() {
            let candidate_line = if current_line.is_empty() {
                word.to_string()
            } else {
                format!("{current_line} {word}")
            };
            let candidate_width =
                self.measure_line_width(&candidate_line, text_size_pixels, letter_spacing_pixels);
            let exceeds_limit = candidate_width
                .is_some_and(|candidate_width| candidate_width > maximum_width_pixels);
            if !current_line.is_empty() && exceeds_limit {
                line_texts.push(std::mem::take(&mut current_line));
                current_line = word.to_string();
            } else {
                current_line = candidate_line;
            }
        }
        if !current_line.is_empty() {
            line_texts.push(current_line);
        }
        if line_texts.is_empty() {
            return None;
        }
        let mut lines = Vec::with_capacity(line_texts.len());
        let mut widest_line_pixels = 0.0_f64;
        let mut served_any_line = false;
        for line_text in line_texts {
            let width_pixels = self
                .measure_line_width(&line_text, text_size_pixels, letter_spacing_pixels)
                .unwrap_or(0.0);
            served_any_line |= width_pixels > 0.0;
            widest_line_pixels = widest_line_pixels.max(width_pixels);
            lines.push(LabelTextLine {
                text: line_text,
                width_pixels,
            });
        }
        if !served_any_line {
            return None;
        }
        let line_height_pixels = text_size_pixels * line_height_ems;
        Some(LabelTextBlock {
            height_pixels: line_height_pixels * lines.len() as f64,
            lines,
            width_pixels: widest_line_pixels,
            line_height_pixels,
        })
    }
}

/// A deterministic fingerprint of a packed atlas: the page dimensions, every
/// glyph's codepoint and rectangle, and the page pixels. Computed once when
/// the atlas is packed, never per frame.
fn atlas_revision(atlas: &PackedGlyphAtlas) -> u64 {
    let mut hasher = DefaultHasher::new();
    atlas.width_pixels.hash(&mut hasher);
    atlas.height_pixels.hash(&mut hasher);
    for glyph in &atlas.glyphs {
        glyph.codepoint.hash(&mut hasher);
        glyph.bitmap_rectangle.x_pixels.hash(&mut hasher);
        glyph.bitmap_rectangle.y_pixels.hash(&mut hasher);
        glyph.bitmap_rectangle.width_pixels.hash(&mut hasher);
        glyph.bitmap_rectangle.height_pixels.hash(&mut hasher);
    }
    atlas.pixels.hash(&mut hasher);
    hasher.finish()
}

/// The Latin glyph range the SDK's default label font decodes: a glyph-protocol
/// `0-255` payload in Noto Sans Regular, embedded in the library. Embedding it
/// gives every surface a glyph source without a network fetch or a
/// platform-specific asset.
pub const DEFAULT_LATIN_GLYPH_RANGE_PBF_BYTES: &[u8] =
    include_bytes!("../fixtures/render/glyphs/noto_sans_regular_0-255.pbf");

/// The default label font, decoded and packed on first use and then shared by
/// every frame and every view in the process.
static DEFAULT_LABEL_FONT: OnceLock<LabelFont> = OnceLock::new();

/// The SDK's default label font: [`DEFAULT_LATIN_GLYPH_RANGE_PBF_BYTES`]
/// decoded and packed into one atlas the first time a frame asks for it, then
/// reused. The packed atlas rides in an [`Arc`], so handing the font to
/// [`LabelLayer::place`] never re-copies the page, and the renderer's atlas
/// upload happens once per distinct revision.
///
/// The embedded bytes are part of the library; should they ever fail to
/// decode or pack (a corrupted build rather than a normal path), the in-code
/// fallback is an empty font stack: every label measures no glyph and the pass
/// paints nothing, so a map still draws instead of failing. This mirrors the
/// vector style's in-code fallback when its embedded artifact is unreadable.
/// A caller with another glyph source keeps using [`LabelLayer::place`] with
/// its own [`LabelFont`].
pub fn default_label_font() -> &'static LabelFont {
    DEFAULT_LABEL_FONT.get_or_init(|| {
        decode_glyph_font_stack(DEFAULT_LATIN_GLYPH_RANGE_PBF_BYTES)
            .ok()
            .and_then(|font_stack| LabelFont::from_glyph_font_stack(&font_stack).ok())
            .unwrap_or_else(empty_label_font)
    })
}

#[cfg(test)]
mod measurement_tests {
    use super::*;

    #[test]
    fn a_name_with_an_unservable_character_keeps_its_servable_text() {
        let font = default_label_font();
        let ascii_only = font
            .measure_text("Sibenik", 14.0)
            .expect("the default range serves Latin letters");
        // A character outside the served range contributes no advance and
        // paints nothing; the rest of the name still measures (and draws)
        // instead of the whole label disappearing.
        let with_unservable = font
            .measure_text("Sibenik\u{4e2d}", 14.0)
            .expect("one unservable character must not drop the label");
        assert_eq!(
            with_unservable.width_pixels, ascii_only.width_pixels,
            "an unservable character contributes no advance"
        );
    }

    #[test]
    fn text_the_font_cannot_serve_at_all_is_not_placed() {
        let font = default_label_font();
        assert!(
            font.measure_text("\u{4e2d}\u{6587}", 14.0).is_none(),
            "a label with no servable glyph paints nothing and is skipped"
        );
    }
}

/// The default font's documented in-code fallback: a font stack with no
/// glyphs, which packs into a valid empty atlas page. Labels measured against
/// it carry no servable glyph and are skipped, so the frame paints the map
/// without text.
fn empty_label_font() -> LabelFont {
    LabelFont::from_glyph_font_stack(&GlyphFontStack::default())
        .expect("an empty font stack packs into the default atlas page")
}

/// A label layer ready to draw: the placed labels and the font that measures
/// and rasterizes them.
#[derive(Debug, Clone)]
pub struct LabelLayer {
    labels: Vec<PlacedLabel>,
    font: LabelFont,
    /// The device pixels one point/CSS pixel covers: 1.0 for the headless
    /// golden at one device pixel per point, the display scale on a native
    /// surface, the canvas ratio in the browser. It sets the drawn text size
    /// and the fragment stage's edge gamma; the halo width already arrives in
    /// the same points the style declares.
    device_pixel_ratio: f64,
}

impl LabelLayer {
    /// Projects and places the frame's candidates: sort by priority (lower is
    /// more important, the field's documented collision rule), then style
    /// order, then feature rank; drop repeated text; reject a candidate whose
    /// padded screen rectangle collides with an already accepted label unless
    /// the candidate allows overlap; stop once the frame has placed
    /// [`MAXIMUM_LABELS_PER_FRAME`] labels. A line-placed candidate takes its
    /// longest straight projected run as the text's run and repeats along it,
    /// each label rotated to the segment beneath it; every other candidate
    /// centers on its anchor, unrotated. Repeated names of one candidate are
    /// placed together, and the text is recorded once so a later candidate
    /// carrying the same name — the same street in a neighbouring tile — is
    /// still rejected. The result keeps the sorted order, so the same
    /// candidates always paint in the same sequence.
    pub fn place(
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
        candidates: &[MapLabelCandidate],
        font: &LabelFont,
    ) -> Self {
        Self::place_with_device_pixel_ratio(
            camera,
            viewport,
            field_of_view_degrees,
            candidates,
            font,
            1.0,
        )
    }

    /// [`Self::place`] for a surface whose drawing buffer is not one device
    /// pixel per point: the drawn glyph size and the edge gamma both follow
    /// `device_pixel_ratio`, so the text keeps its declared point size and its
    /// one-pixel anti-aliased edge on a 2× or 3× surface.
    pub fn place_with_device_pixel_ratio(
        camera: &MapCamera,
        viewport: &ViewportPixels,
        field_of_view_degrees: f64,
        candidates: &[MapLabelCandidate],
        font: &LabelFont,
        device_pixel_ratio: f64,
    ) -> Self {
        let mut ordered_candidates: Vec<&MapLabelCandidate> = candidates.iter().collect();
        // `sort_by_key` is stable, so candidates that tie on the triple keep
        // the caller's own order — the frame's tiles list deterministically.
        ordered_candidates
            .sort_by_key(|candidate| (candidate.priority, candidate.style_order, candidate.rank));

        let mut occupied_rectangles: Vec<LabelScreenRectangle> = Vec::new();
        let mut placed_labels: Vec<PlacedLabel> = Vec::new();
        let mut placed_texts: Vec<String> = Vec::new();
        for candidate in ordered_candidates {
            if placed_labels.len() >= MAXIMUM_LABELS_PER_FRAME {
                break;
            }
            if placed_texts.iter().any(|text| text == &candidate.text) {
                continue;
            }
            // The style's size is a point/CSS size; the drawing buffer draws
            // device pixels, so the glyphs scale by the surface ratio while the
            // style numbers stay the source of truth for gamma and halo math.
            let text_size_pixels = candidate.text_size_pixels * device_pixel_ratio;
            let letter_spacing_pixels = candidate.text_letter_spacing_ems * text_size_pixels;
            let placed_along_line = candidate.line_coordinates.len() >= 2;
            // A line-placed name stays on one line, the specification's rule;
            // wrapping applies to point-placed text.
            let Some(text_block) = (if placed_along_line {
                font.measure_line_width(&candidate.text, text_size_pixels, letter_spacing_pixels)
                    .map(|width_pixels| LabelTextBlock {
                        lines: vec![LabelTextLine {
                            text: candidate.text.clone(),
                            width_pixels,
                        }],
                        width_pixels,
                        height_pixels: text_size_pixels,
                        line_height_pixels: text_size_pixels,
                    })
            } else {
                font.measure_wrapped_text(
                    &candidate.text,
                    text_size_pixels,
                    candidate.text_max_width_ems * text_size_pixels,
                    candidate.text_line_height_ems,
                    letter_spacing_pixels,
                )
            }) else {
                continue;
            };
            let placements = if placed_along_line {
                label_placements_along_line(
                    camera,
                    viewport,
                    field_of_view_degrees,
                    &candidate.line_coordinates,
                    text_block.width_pixels,
                    candidate.repeat_spacing_pixels,
                    candidate.line_center_only,
                )
            } else {
                match camera.project_to_screen(&candidate.anchor, viewport, field_of_view_degrees) {
                    Some(anchor_screen_pixels) => vec![LabelPlacement {
                        anchor_screen_pixels,
                        rotation_radians: 0.0,
                    }],
                    None => Vec::new(),
                }
            };
            // A text offset is a screen-space displacement from the anchor in
            // ems; the candidate carries it already scaled to CSS pixels.
            let placements: Vec<LabelPlacement> = placements
                .into_iter()
                .map(|mut placement| {
                    placement.anchor_screen_pixels[0] +=
                        candidate.text_offset_pixels[0] * device_pixel_ratio;
                    placement.anchor_screen_pixels[1] +=
                        candidate.text_offset_pixels[1] * device_pixel_ratio;
                    placement
                })
                .collect();
            let mut placed_any = false;
            for placement in placements {
                if placed_labels.len() >= MAXIMUM_LABELS_PER_FRAME {
                    break;
                }
                let label_rectangle = LabelScreenRectangle::around(
                    placement.anchor_screen_pixels,
                    text_block.width_pixels,
                    text_block.height_pixels,
                    placement.rotation_radians,
                );
                if candidate.avoid_edges {
                    if !label_rectangle.is_inside_viewport(viewport) {
                        continue;
                    }
                } else if !label_rectangle.intersects_viewport(viewport) {
                    continue;
                }
                if !candidate.allow_overlap && !candidate.ignore_placement {
                    let collides = occupied_rectangles
                        .iter()
                        .any(|occupied| occupied.intersects(&label_rectangle));
                    if collides {
                        continue;
                    }
                    occupied_rectangles.push(label_rectangle);
                }
                placed_any = true;
                placed_labels.push(PlacedLabel {
                    text: candidate.text.clone(),
                    anchor_screen_pixels: placement.anchor_screen_pixels,
                    rotation_radians: placement.rotation_radians,
                    placed_along_line,
                    text_size_pixels,
                    text_rgba: candidate.text_rgba,
                    halo_rgba: candidate.halo_rgba,
                    halo_width_pixels: candidate.halo_width_pixels * device_pixel_ratio,
                    lines: text_block.lines.clone(),
                    line_height_pixels: text_block.line_height_pixels,
                    block_width_pixels: text_block.width_pixels,
                    letter_spacing_pixels,
                    text_justify: candidate.text_justify,
                    priority: candidate.priority,
                });
            }
            if placed_any {
                placed_texts.push(candidate.text.clone());
            }
        }
        Self {
            labels: placed_labels,
            font: font.clone(),
            device_pixel_ratio,
        }
    }

    /// The placed labels, in draw order.
    pub fn labels(&self) -> &[PlacedLabel] {
        &self.labels
    }

    /// The font the layer draws with.
    pub fn font(&self) -> &LabelFont {
        &self.font
    }

    /// Whether the layer draws anything at all.
    pub fn is_empty(&self) -> bool {
        self.labels.is_empty()
    }

    /// Assembles the layer's clip-space quad vertices: one halo pass (only
    /// labels with a positive halo width) followed by the text pass. Both
    /// lists draw non-indexed through the textured glyph pipeline. A halo
    /// quad is the glyph's bitmap rectangle inflated by the halo width while
    /// keeping the glyph's texture window, which stretches the bitmap's soft
    /// edge outward; the fragment stage's lower halo threshold turns that
    /// stretched edge into the outline.
    ///
    /// A rotated label lays its glyphs out in the label's own unrotated frame
    /// and rotates each glyph rectangle about the label anchor, so rotation
    /// reaches every backend through the shared clip-space positions.
    pub fn quad_vertices(&self, viewport: &ViewportPixels) -> LabelQuadVertices {
        let mut halo_vertices = Vec::new();
        let mut text_vertices = Vec::new();
        for label in &self.labels {
            if label.rotation_radians == 0.0 {
                self.append_axis_aligned_label_quads(
                    &mut halo_vertices,
                    &mut text_vertices,
                    viewport,
                    label,
                );
            } else {
                self.append_rotated_label_quads(
                    &mut halo_vertices,
                    &mut text_vertices,
                    viewport,
                    label,
                );
            }
        }
        LabelQuadVertices {
            halo: halo_vertices,
            text: text_vertices,
        }
    }

    /// Lays out one unrotated label's glyph quads: the baseline runs along
    /// the screen's `x` axis from the label's centered pen origin.
    fn append_axis_aligned_label_quads(
        &self,
        halo_vertices: &mut Vec<ClipSpaceGlyphVertex>,
        text_vertices: &mut Vec<ClipSpaceGlyphVertex>,
        viewport: &ViewportPixels,
        label: &PlacedLabel,
    ) {
        let scale = label.text_size_pixels / GLYPH_FONT_EM_PIXELS;
        // The style's own (point/CSS) sizes drive the SDF threshold and gamma;
        // the placed sizes are already in drawing-buffer pixels.
        let style_text_size_pixels = label.text_size_pixels / self.device_pixel_ratio;
        let style_halo_width_pixels = label.halo_width_pixels / self.device_pixel_ratio;
        let edge_gamma = glyph_edge_gamma(style_text_size_pixels, self.device_pixel_ratio);
        let halo_threshold =
            glyph_halo_signed_distance_threshold(style_text_size_pixels, style_halo_width_pixels);
        let baseline_offset_pixels = label.text_size_pixels * LABEL_BASELINE_OFFSET_FRACTION;
        let line_count = label.lines.len() as f64;
        for (line_index, line) in label.lines.iter().enumerate() {
            // Lines stack around the anchor: line 0 is the top line.
            let line_offset_pixels =
                (line_index as f64 - (line_count - 1.0) / 2.0) * label.line_height_pixels;
            let baseline_y =
                label.anchor_screen_pixels[1] + line_offset_pixels + baseline_offset_pixels;
            let mut pen_x = match label.text_justify {
                TextJustify::Left => label.anchor_screen_pixels[0] - label.block_width_pixels / 2.0,
                TextJustify::Right => {
                    label.anchor_screen_pixels[0] + label.block_width_pixels / 2.0
                        - line.width_pixels
                }
                TextJustify::Auto | TextJustify::Center => {
                    label.anchor_screen_pixels[0] - line.width_pixels / 2.0
                }
            };
            for character in line.text.chars() {
                let Some(glyph) = self.font.glyph(u32::from(character)) else {
                    continue;
                };
                let advance_pixels = f64::from(glyph.advance) * scale;
                if glyph.bitmap_rectangle.width_pixels > 0
                    && glyph.bitmap_rectangle.height_pixels > 0
                {
                    let bitmap_left_pixels = pen_x
                        + f64::from(glyph.left - GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS as i32)
                            * scale;
                    let bitmap_top_pixels = baseline_y
                        - (f64::from(glyph.top)
                            + GLYPH_FONT_ASCENDER_PIXELS
                            + f64::from(GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS))
                            * scale;
                    let bitmap_width_pixels =
                        f64::from(glyph.bitmap_rectangle.width_pixels) * scale;
                    let bitmap_height_pixels =
                        f64::from(glyph.bitmap_rectangle.height_pixels) * scale;
                    if label.halo_width_pixels > 0.0 {
                        // The halo keeps the text quad's geometry: its lower
                        // threshold is what spreads the outline, exactly as
                        // MapLibre Native's `symbol_sdf` shader does.
                        append_glyph_quad(
                            halo_vertices,
                            viewport,
                            [bitmap_left_pixels, bitmap_top_pixels],
                            [bitmap_width_pixels, bitmap_height_pixels],
                            glyph,
                            halo_threshold,
                            edge_gamma,
                            &label.halo_rgba,
                        );
                    }
                    append_glyph_quad(
                        text_vertices,
                        viewport,
                        [bitmap_left_pixels, bitmap_top_pixels],
                        [bitmap_width_pixels, bitmap_height_pixels],
                        glyph,
                        GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD,
                        edge_gamma,
                        &label.text_rgba,
                    );
                }
                pen_x += advance_pixels + label.letter_spacing_pixels;
            }
        }
    }

    /// Lays out one rotated label's glyph quads: the baseline runs along the
    /// label's rotation from a centered pen origin, and each glyph rectangle
    /// rotates about the label anchor before it becomes clip-space corners.
    fn append_rotated_label_quads(
        &self,
        halo_vertices: &mut Vec<ClipSpaceGlyphVertex>,
        text_vertices: &mut Vec<ClipSpaceGlyphVertex>,
        viewport: &ViewportPixels,
        label: &PlacedLabel,
    ) {
        let scale = label.text_size_pixels / GLYPH_FONT_EM_PIXELS;
        let style_text_size_pixels = label.text_size_pixels / self.device_pixel_ratio;
        let style_halo_width_pixels = label.halo_width_pixels / self.device_pixel_ratio;
        let edge_gamma = glyph_edge_gamma(style_text_size_pixels, self.device_pixel_ratio);
        let halo_threshold =
            glyph_halo_signed_distance_threshold(style_text_size_pixels, style_halo_width_pixels);
        let baseline_offset_pixels = label.text_size_pixels * LABEL_BASELINE_OFFSET_FRACTION;
        let line_count = label.lines.len() as f64;
        for (line_index, line) in label.lines.iter().enumerate() {
            // Line offsets and pen origins are authored in the label's own
            // unrotated frame; `append_rotated_glyph_quad` rotates the whole
            // offset about the anchor.
            let line_offset_pixels =
                (line_index as f64 - (line_count - 1.0) / 2.0) * label.line_height_pixels;
            let mut pen_offset_pixels = match label.text_justify {
                TextJustify::Left => -label.block_width_pixels / 2.0,
                TextJustify::Right => label.block_width_pixels / 2.0 - line.width_pixels,
                TextJustify::Auto | TextJustify::Center => -line.width_pixels / 2.0,
            };
            for character in line.text.chars() {
                let Some(glyph) = self.font.glyph(u32::from(character)) else {
                    continue;
                };
                let advance_pixels = f64::from(glyph.advance) * scale;
                if glyph.bitmap_rectangle.width_pixels > 0
                    && glyph.bitmap_rectangle.height_pixels > 0
                {
                    let bitmap_offset_pixels = [
                        pen_offset_pixels
                            + f64::from(
                                glyph.left - GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS as i32,
                            ) * scale,
                        line_offset_pixels + baseline_offset_pixels
                            - (f64::from(glyph.top)
                                + GLYPH_FONT_ASCENDER_PIXELS
                                + f64::from(GLYPH_SIGNED_DISTANCE_FIELD_BORDER_PIXELS))
                                * scale,
                    ];
                    let bitmap_width_pixels =
                        f64::from(glyph.bitmap_rectangle.width_pixels) * scale;
                    let bitmap_height_pixels =
                        f64::from(glyph.bitmap_rectangle.height_pixels) * scale;
                    if label.halo_width_pixels > 0.0 {
                        append_rotated_glyph_quad(
                            halo_vertices,
                            viewport,
                            label.anchor_screen_pixels,
                            label.rotation_radians,
                            bitmap_offset_pixels,
                            [bitmap_width_pixels, bitmap_height_pixels],
                            glyph,
                            halo_threshold,
                            edge_gamma,
                            &label.halo_rgba,
                        );
                    }
                    append_rotated_glyph_quad(
                        text_vertices,
                        viewport,
                        label.anchor_screen_pixels,
                        label.rotation_radians,
                        bitmap_offset_pixels,
                        [bitmap_width_pixels, bitmap_height_pixels],
                        glyph,
                        GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD,
                        edge_gamma,
                        &label.text_rgba,
                    );
                }
                pen_offset_pixels += advance_pixels + label.letter_spacing_pixels;
            }
        }
    }
}

/// One glyph quad's textured vertex, as the GPU pipeline consumes it:
/// clip-space position, atlas texture coordinates, paint, and the
/// signed-distance threshold the fragment stage compares against.
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ClipSpaceGlyphVertex {
    /// Position in clip space, `[x, y, z, w]`.
    pub clip_position: [f32; 4],
    /// Atlas texture coordinates (origin top-left, `u` right, `v` down).
    pub texture_coordinates: [f32; 2],
    /// Paint, components in `[0, 1]`.
    pub rgba_color: [f32; 4],
    /// The signed-distance value the fragment stage treats as covered.
    pub signed_distance_threshold: f32,
    /// The fragment stage's smoothstep half-band in distance-field units
    /// ([`glyph_edge_gamma`]): 0.84 device pixels at every size and ratio.
    pub signed_distance_gamma: f32,
}

/// The two passes of one label layer: halo quads behind, text quads in front.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct LabelQuadVertices {
    /// The halo pass, drawn first.
    pub halo: Vec<ClipSpaceGlyphVertex>,
    /// The text pass, drawn second.
    pub text: Vec<ClipSpaceGlyphVertex>,
}

impl LabelQuadVertices {
    /// Whether either pass draws anything.
    pub fn is_empty(&self) -> bool {
        self.halo.is_empty() && self.text.is_empty()
    }
}

/// Where one label sits on screen: its anchor and the rotation its baseline
/// runs at.
#[derive(Debug, Clone, Copy, PartialEq)]
struct LabelPlacement {
    /// The label's center in viewport pixels.
    anchor_screen_pixels: [f64; 2],
    /// The baseline rotation in radians (clockwise, y down).
    rotation_radians: f64,
}

/// Places a line-placed label's run along the longest straight run of its
/// projected geometry, or reports an empty list when no run can carry it.
///
/// Vertices the camera cannot project break the polyline: runs are measured
/// over the stretches where every vertex projected. Within one stretch, a
/// straight run is the longest sequence of consecutive segments whose bearing
/// stays within [`LINE_LABEL_STRAIGHT_RUN_ANGLE_TOLERANCE_RADIANS`] of the
/// run's first segment (map data splits a street into short blocks, so a name
/// needs the block sequence, not one block). Of the stretches' runs the
/// longest wins (ties keep the earlier one).
///
/// The text repeats along that run the way the reference engines name a long
/// street: one label centers on the run when only one fits, otherwise labels
/// spread evenly from [`LABEL_COLLISION_PADDING_PIXELS`] past the first end to
/// the same distance before the last, with at least
/// [`LINE_LABEL_REPEAT_SPACING_PIXELS`] of clear space between neighbours.
/// Each label rotates to the bearing of the segment under its own anchor
/// (flipped past [`LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS`] so the text
/// always reads upright), so a name follows the road's curve rather than one
/// chord across the whole run.
fn label_placements_along_line(
    camera: &MapCamera,
    viewport: &ViewportPixels,
    field_of_view_degrees: f64,
    line_coordinates: &[GeographicCoordinate],
    text_width_pixels: f64,
    repeat_spacing_pixels: f64,
    line_center_only: bool,
) -> Vec<LabelPlacement> {
    let mut projected_stretch: Vec<[f64; 2]> = Vec::new();
    let mut longest_run: Option<StraightRun> = None;
    for coordinate in line_coordinates {
        let Some(screen_point) =
            camera.project_to_screen(coordinate, viewport, field_of_view_degrees)
        else {
            consider_longest_run(&projected_stretch, &mut longest_run);
            projected_stretch.clear();
            continue;
        };
        projected_stretch.push(screen_point);
    }
    consider_longest_run(&projected_stretch, &mut longest_run);
    let Some(run) = longest_run else {
        return Vec::new();
    };

    let required_run_pixels = text_width_pixels + 2.0 * LABEL_COLLISION_PADDING_PIXELS;
    if run.length_pixels < required_run_pixels {
        return Vec::new();
    }
    let first_anchor_pixels = text_width_pixels / 2.0 + LABEL_COLLISION_PADDING_PIXELS;
    let last_anchor_pixels = run.length_pixels - first_anchor_pixels;
    let repeat_stride_pixels = text_width_pixels + repeat_spacing_pixels;
    let label_count = if line_center_only || last_anchor_pixels <= first_anchor_pixels {
        1
    } else {
        let fitting_spans = ((last_anchor_pixels - first_anchor_pixels) / repeat_stride_pixels)
            .floor()
            .max(0.0);
        (fitting_spans as usize).saturating_add(1)
    };
    let mut placements = Vec::with_capacity(label_count);
    for label_index in 0..label_count {
        let anchor_pixels = if label_count == 1 {
            run.length_pixels / 2.0
        } else {
            let fraction = label_index as f64 / (label_count - 1) as f64;
            first_anchor_pixels + (last_anchor_pixels - first_anchor_pixels) * fraction
        };
        let Some(placement) = placement_at_arc_length(&run.points, anchor_pixels) else {
            continue;
        };
        placements.push(placement);
    }
    placements
}

/// One straight run of a projected polyline: the screen points it spans and
/// its arc length.
#[derive(Debug, Clone)]
struct StraightRun {
    /// The run's projected vertices, in order.
    points: Vec<[f64; 2]>,
    /// The run's total length in screen pixels.
    length_pixels: f64,
}

/// The placement of one label centered at `anchor_pixels` along a projected
/// polyline, walking its segments from the start.
///
/// The anchor sits on the segment that contains the target distance and the
/// rotation follows that segment's own bearing, so a repeated name turns with
/// the road under it. Reports `None` only for a polyline with no segment of
/// positive length.
fn placement_at_arc_length(points: &[[f64; 2]], anchor_pixels: f64) -> Option<LabelPlacement> {
    let mut traveled_pixels = 0.0;
    let mut last_segment: Option<([f64; 2], [f64; 2])> = None;
    for segment_points in points.windows(2) {
        let [segment_start, segment_end] = [segment_points[0], segment_points[1]];
        let segment_length_pixels =
            (segment_end[0] - segment_start[0]).hypot(segment_end[1] - segment_start[1]);
        if segment_length_pixels <= 0.0 {
            continue;
        }
        last_segment = Some((segment_start, segment_end));
        if traveled_pixels + segment_length_pixels >= anchor_pixels {
            let fraction_pixels =
                ((anchor_pixels - traveled_pixels) / segment_length_pixels).clamp(0.0, 1.0);
            let anchor_screen_pixels = [
                segment_start[0] + (segment_end[0] - segment_start[0]) * fraction_pixels,
                segment_start[1] + (segment_end[1] - segment_start[1]) * fraction_pixels,
            ];
            return Some(LabelPlacement {
                anchor_screen_pixels,
                rotation_radians: upright_segment_rotation(segment_start, segment_end),
            });
        }
        traveled_pixels += segment_length_pixels;
    }
    let (segment_start, segment_end) = last_segment?;
    Some(LabelPlacement {
        anchor_screen_pixels: segment_end,
        rotation_radians: upright_segment_rotation(segment_start, segment_end),
    })
}

/// The baseline rotation for a segment, flipped by a half turn when it would
/// put the text upside down, so the result always lies in
/// `[-π/2, π/2]`.
fn upright_segment_rotation(segment_start: [f64; 2], segment_end: [f64; 2]) -> f64 {
    let segment_rotation_radians =
        (segment_end[1] - segment_start[1]).atan2(segment_end[0] - segment_start[0]);
    if segment_rotation_radians > LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS {
        segment_rotation_radians - std::f64::consts::PI
    } else if segment_rotation_radians < -LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS {
        segment_rotation_radians + std::f64::consts::PI
    } else {
        segment_rotation_radians
    }
}

/// Appends the longest straight run of one projected stretch to
/// `longest_run` when it beats the runs already measured. A stretch with fewer
/// than two points has no run.
fn consider_longest_run(projected_stretch: &[[f64; 2]], longest_run: &mut Option<StraightRun>) {
    let mut run_start_index = 0;
    while run_start_index + 1 < projected_stretch.len() {
        let reference_bearing = segment_bearing(
            projected_stretch[run_start_index],
            projected_stretch[run_start_index + 1],
        );
        let mut run_end_index = run_start_index;
        let mut run_length_pixels = 0.0;
        while run_end_index + 1 < projected_stretch.len() {
            let segment_bearing = segment_bearing(
                projected_stretch[run_end_index],
                projected_stretch[run_end_index + 1],
            );
            let bearing_difference = (segment_bearing - reference_bearing + std::f64::consts::PI)
                .rem_euclid(2.0 * std::f64::consts::PI)
                - std::f64::consts::PI;
            if bearing_difference.abs() > LINE_LABEL_STRAIGHT_RUN_ANGLE_TOLERANCE_RADIANS {
                break;
            }
            run_length_pixels += (projected_stretch[run_end_index + 1][0]
                - projected_stretch[run_end_index][0])
                .hypot(
                    projected_stretch[run_end_index + 1][1] - projected_stretch[run_end_index][1],
                );
            run_end_index += 1;
        }
        if run_end_index > run_start_index {
            let is_longest = match longest_run {
                None => true,
                Some(existing_run) => run_length_pixels > existing_run.length_pixels,
            };
            if is_longest {
                *longest_run = Some(StraightRun {
                    points: projected_stretch[run_start_index..=run_end_index].to_vec(),
                    length_pixels: run_length_pixels,
                });
            }
        }
        run_start_index = run_end_index.max(run_start_index + 1);
    }
}

/// The bearing of the segment from `start` to `end`, in radians.
fn segment_bearing(start: [f64; 2], end: [f64; 2]) -> f64 {
    (end[1] - start[1]).atan2(end[0] - start[0])
}

/// One label's padded screen-space collision rectangle.
#[derive(Debug, Clone, Copy)]
struct LabelScreenRectangle {
    minimum_x: f64,
    minimum_y: f64,
    maximum_x: f64,
    maximum_y: f64,
}

impl LabelScreenRectangle {
    /// The collision rectangle around a centered label's text, padded by
    /// [`LABEL_COLLISION_PADDING_PIXELS`] on every side. A rotated label uses
    /// the axis-aligned box around its rotated text rectangle: the half
    /// extents are the rotated text box's own projections onto the screen
    /// axes, so the box never rejects less than the visible glyphs cover.
    fn around(
        anchor_screen_pixels: [f64; 2],
        width_pixels: f64,
        height_pixels: f64,
        rotation_radians: f64,
    ) -> Self {
        let (rotation_sine, rotation_cosine) = rotation_radians.sin_cos();
        let half_width_pixels =
            width_pixels / 2.0 * rotation_cosine.abs() + height_pixels / 2.0 * rotation_sine.abs();
        let half_height_pixels =
            width_pixels / 2.0 * rotation_sine.abs() + height_pixels / 2.0 * rotation_cosine.abs();
        Self {
            minimum_x: anchor_screen_pixels[0] - half_width_pixels - LABEL_COLLISION_PADDING_PIXELS,
            maximum_x: anchor_screen_pixels[0] + half_width_pixels + LABEL_COLLISION_PADDING_PIXELS,
            minimum_y: anchor_screen_pixels[1]
                - half_height_pixels
                - LABEL_COLLISION_PADDING_PIXELS,
            maximum_y: anchor_screen_pixels[1]
                + half_height_pixels
                + LABEL_COLLISION_PADDING_PIXELS,
        }
    }

    /// Whether the two padded rectangles share any area.
    fn intersects(&self, other: &Self) -> bool {
        self.minimum_x < other.maximum_x
            && other.minimum_x < self.maximum_x
            && self.minimum_y < other.maximum_y
            && other.minimum_y < self.maximum_y
    }

    /// Whether any part of the rectangle is inside the viewport.
    fn intersects_viewport(&self, viewport: &ViewportPixels) -> bool {
        self.minimum_x < viewport.width_pixels
            && self.maximum_x > 0.0
            && self.minimum_y < viewport.height_pixels
            && self.maximum_y > 0.0
    }

    /// Whether the padded rectangle lies entirely inside the viewport; a
    /// `symbol-avoid-edges` label must pass this instead of
    /// [`Self::intersects_viewport`].
    fn is_inside_viewport(&self, viewport: &ViewportPixels) -> bool {
        self.minimum_x >= 0.0
            && self.maximum_x <= viewport.width_pixels
            && self.minimum_y >= 0.0
            && self.maximum_y <= viewport.height_pixels
    }
}

/// Appends one glyph bitmap as two screen-space triangles (the shared
/// `0, 1, 2, 2, 1, 3` corner pattern) converted to clip space.
// The arguments mirror `append_rotated_glyph_quad`'s, minus the anchor and
// rotation; a struct would only move the same values to the call site.
#[allow(clippy::too_many_arguments)]
fn append_glyph_quad(
    vertices: &mut Vec<ClipSpaceGlyphVertex>,
    viewport: &ViewportPixels,
    top_left_pixels: [f64; 2],
    size_pixels: [f64; 2],
    glyph: &PackedGlyph,
    signed_distance_threshold: f32,
    signed_distance_gamma: f32,
    rgba_color: &[f32; 4],
) {
    let corners = axis_aligned_corners(top_left_pixels, size_pixels);
    append_glyph_quad_corners(
        vertices,
        viewport,
        &corners,
        glyph.uv_rectangle,
        signed_distance_threshold,
        signed_distance_gamma,
        rgba_color,
    );
}

/// Appends one rotated glyph bitmap: the glyph rectangle is laid out in the
/// label's own frame (offset from the anchor), rotated about the anchor by
/// `rotation_radians`, and emitted as the same two screen-space triangles the
/// unrotated path draws.
// The arguments mirror `append_glyph_quad`'s, plus the anchor and rotation;
// splitting them into a struct would only move the same values to the call
// site.
#[allow(clippy::too_many_arguments)]
fn append_rotated_glyph_quad(
    vertices: &mut Vec<ClipSpaceGlyphVertex>,
    viewport: &ViewportPixels,
    anchor_screen_pixels: [f64; 2],
    rotation_radians: f64,
    top_left_offset_pixels: [f64; 2],
    size_pixels: [f64; 2],
    glyph: &PackedGlyph,
    signed_distance_threshold: f32,
    signed_distance_gamma: f32,
    rgba_color: &[f32; 4],
) {
    let (rotation_sine, rotation_cosine) = rotation_radians.sin_cos();
    let local_corners = axis_aligned_corners(top_left_offset_pixels, size_pixels);
    let rotated_corners = local_corners.map(|local_corner| {
        [
            anchor_screen_pixels[0] + local_corner[0] * rotation_cosine
                - local_corner[1] * rotation_sine,
            anchor_screen_pixels[1]
                + local_corner[0] * rotation_sine
                + local_corner[1] * rotation_cosine,
        ]
    });
    append_glyph_quad_corners(
        vertices,
        viewport,
        &rotated_corners,
        glyph.uv_rectangle,
        signed_distance_threshold,
        signed_distance_gamma,
        rgba_color,
    );
}

/// The four screen-space corners of an axis-aligned rectangle in the
/// `top-left, top-right, bottom-left, bottom-right` order the shared index
/// pattern consumes.
fn axis_aligned_corners(top_left_pixels: [f64; 2], size_pixels: [f64; 2]) -> [[f64; 2]; 4] {
    let right_pixels = top_left_pixels[0] + size_pixels[0];
    let bottom_pixels = top_left_pixels[1] + size_pixels[1];
    [
        [top_left_pixels[0], top_left_pixels[1]],
        [right_pixels, top_left_pixels[1]],
        [top_left_pixels[0], bottom_pixels],
        [right_pixels, bottom_pixels],
    ]
}

/// Emits one glyph bitmap from its four screen-space corners, in the shared
/// `top-left, top-right, bottom-left, bottom-right` order, as two triangles.
fn append_glyph_quad_corners(
    vertices: &mut Vec<ClipSpaceGlyphVertex>,
    viewport: &ViewportPixels,
    screen_corners: &[[f64; 2]; 4],
    texture_coordinates: rustic_maps_glyphs::GlyphUvRectangle,
    signed_distance_threshold: f32,
    signed_distance_gamma: f32,
    rgba_color: &[f32; 4],
) {
    let corner_texture_coordinates = [
        [texture_coordinates.minimum_u, texture_coordinates.minimum_v],
        [texture_coordinates.maximum_u, texture_coordinates.minimum_v],
        [texture_coordinates.minimum_u, texture_coordinates.maximum_v],
        [texture_coordinates.maximum_u, texture_coordinates.maximum_v],
    ];
    for corner_index in [0usize, 1, 2, 2, 1, 3] {
        let screen_position = screen_corners[corner_index];
        vertices.push(ClipSpaceGlyphVertex {
            clip_position: [
                (2.0 * screen_position[0] / viewport.width_pixels - 1.0) as f32,
                (1.0 - 2.0 * screen_position[1] / viewport.height_pixels) as f32,
                0.0,
                1.0,
            ],
            texture_coordinates: corner_texture_coordinates[corner_index],
            rgba_color: *rgba_color,
            signed_distance_threshold,
            signed_distance_gamma,
        });
    }
}

/// Reads the label candidates from one decoded tile under the style's symbol
/// layers, at an explicit style zoom level (the frame camera's zoom, so size
/// stops evaluate where the camera is rather than where the tile belongs).
///
/// A feature becomes a candidate only when its `rank` passes the layer's
/// zoom-stepped rank ceiling and its `class` is visible at `style_zoom_level`
/// under the layer's per-class minimum zooms, so a busy poi layer draws its
/// important places at a wide zoom and its shops only once the map is closer.
/// A point-placed symbol layer then produces one candidate per feature point;
/// a line-placed one produces one candidate carrying each feature's line
/// geometry, which the frame places along its longest projected segment.
/// Features of a geometry kind the placement cannot use paint nothing for
/// that symbol layer, exactly like the overlay conversion.
pub fn label_candidates_for_vector_tile(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    style: &CompiledStyle,
    style_zoom_level: f64,
) -> Vec<MapLabelCandidate> {
    let mut candidates = Vec::new();
    for layer in &style.layers {
        candidates.extend(label_candidates_for_compiled_layer_at_zoom(
            tile,
            tile_address,
            layer,
            style_zoom_level,
        ));
    }
    candidates
}

/// Reads the label candidates one compiled symbol layer contributes from one
/// decoded tile.
///
/// A multi-source frame styles each source's tiles independently and calls this
/// per layer, so a symbol layer never reads geometry fetched for another
/// source. A non-symbol layer, an invisible layer and a layer without text
/// contribute nothing.
pub fn label_candidates_for_compiled_layer_at_zoom(
    tile: &VectorTile,
    tile_address: VectorTileAddress,
    layer: &rustic_maps_style::CompiledLayer,
    style_zoom_level: f64,
) -> Vec<MapLabelCandidate> {
    let mut candidates = Vec::new();
    if layer.kind != CompiledLayerKind::Symbol || !layer.is_visible_at_zoom(style_zoom_level) {
        return candidates;
    }
    for tile_layer in crate::vector_style::tile_layers_for_compiled_layer(tile, layer) {
        for feature in &tile_layer.features {
            let properties = feature_properties(feature);
            let context = feature_evaluation_context(feature, &properties, style_zoom_level);
            if !layer.matches_filter(&context) {
                continue;
            }
            let layout = layer.resolved_symbol_layout(&context);
            if layout.text.is_empty() {
                continue;
            }
            let ResolvedPaint::Symbol(paint) = layer.resolved_paint(&context) else {
                continue;
            };
            let text_rgba = resolved_rgba(paint.text_color, paint.text_opacity);
            let halo_rgba = resolved_rgba(paint.halo_color, 1.0);
            let priority = symbol_sort_key_priority(layout.sort_key);
            let rank = label_rank_for_feature(feature);
            let ignore_placement = layout.ignore_placement;
            let avoid_edges = layout.avoid_edges;
            let text_offset_pixels = [
                layout.text_offset[0] * layout.text_size,
                layout.text_offset[1] * layout.text_size,
            ];
            let repeat_spacing_pixels = if layer.declares_symbol_spacing {
                layout.symbol_spacing
            } else {
                LINE_LABEL_REPEAT_SPACING_PIXELS
            };
            let line_center_only = layout.placement == SymbolPlacement::LineCenter;
            let text_max_width_ems = layout.text_max_width;
            let text_line_height_ems = layout.text_line_height;
            let text_letter_spacing_ems = layout.text_letter_spacing;
            let text_justify = layout.text_justify;
            match layout.placement {
                SymbolPlacement::Point => {
                    let VectorTileGeometry::Points(points) = &feature.geometry else {
                        continue;
                    };
                    for point in points {
                        candidates.push(MapLabelCandidate {
                            text: layout.text.clone(),
                            anchor: tile_local_point_to_coordinate(
                                tile_address,
                                tile_layer.extent,
                                point,
                            ),
                            line_coordinates: Vec::new(),
                            text_rgba,
                            text_size_pixels: layout.text_size,
                            halo_rgba,
                            halo_width_pixels: paint.halo_width,
                            priority,
                            rank,
                            allow_overlap: layout.allow_overlap,
                            ignore_placement,
                            avoid_edges,
                            text_offset_pixels,
                            repeat_spacing_pixels,
                            line_center_only,
                            text_max_width_ems,
                            text_line_height_ems,
                            text_letter_spacing_ems,
                            text_justify,
                            style_order: layer.order_index,
                        });
                    }
                }
                SymbolPlacement::Line | SymbolPlacement::LineCenter => {
                    let VectorTileGeometry::LineStrings(line_strings) = &feature.geometry else {
                        continue;
                    };
                    for line_string in line_strings {
                        if line_string.len() < 2 {
                            continue;
                        }
                        let line_coordinates: Vec<GeographicCoordinate> = line_string
                            .iter()
                            .map(|point| {
                                tile_local_point_to_coordinate(
                                    tile_address,
                                    tile_layer.extent,
                                    point,
                                )
                            })
                            .collect();
                        let anchor = line_coordinates[0];
                        candidates.push(MapLabelCandidate {
                            text: layout.text.clone(),
                            anchor,
                            line_coordinates,
                            text_rgba,
                            text_size_pixels: layout.text_size,
                            halo_rgba,
                            halo_width_pixels: paint.halo_width,
                            priority,
                            rank,
                            allow_overlap: layout.allow_overlap,
                            ignore_placement,
                            avoid_edges,
                            text_offset_pixels,
                            repeat_spacing_pixels,
                            line_center_only,
                            text_max_width_ems,
                            text_line_height_ems,
                            text_letter_spacing_ems,
                            text_justify,
                            style_order: layer.order_index,
                        });
                    }
                }
            }
        }
    }
    candidates
}

/// The compiled placement key as the candidate's whole-number priority. The
/// style specification allows a fractional sort key; the label pass orders by
/// an integer column, so a fractional key truncates toward zero and a negative
/// or oversized key clamps into the column's range.
fn symbol_sort_key_priority(sort_key: f64) -> u32 {
    if !sort_key.is_finite() || sort_key <= 0.0 {
        0
    } else if sort_key >= f64::from(u32::MAX) {
        u32::MAX
    } else {
        sort_key as u32
    }
}

/// The feature's `rank` attribute as a whole number, or [`DEFAULT_LABEL_RANK`]
/// when it carries none (negative ranks clamp to zero).
fn label_rank_for_feature(feature: &VectorTileFeature) -> u32 {
    feature
        .attributes
        .iter()
        .find(|(attribute_name, _)| attribute_name == LABEL_RANK_ATTRIBUTE_NAME)
        .and_then(|(_, attribute_value)| attribute_value.numeric_value())
        .map(|rank| {
            if rank <= 0.0 {
                0
            } else if rank >= f64::from(u32::MAX) {
                u32::MAX
            } else {
                rank as u32
            }
        })
        .unwrap_or(DEFAULT_LABEL_RANK)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vector_style::{
        VECTOR_STYLE_ID_BRIGHT_LIGHT, vector_tile_style_from_id, vector_tile_style_from_json,
    };
    use rustic_maps_glyphs::decode_glyph_font_stack;
    use rustic_maps_vector_tiles::decode_vector_tile;

    /// Compiles a small inline style document for the symbol-pass tests.
    fn compiled_style(style_json: &str) -> CompiledStyle {
        vector_tile_style_from_json(style_json).expect("the test style document compiles")
    }

    /// The bundled OpenFreeMap z14 vector tile over Sacramento: the demo
    /// tile whose place layer names Sacramento, West Sacramento, Mikon and
    /// Bryte.
    const OPENFREEMAP_TILE_BYTES: &[u8] =
        include_bytes!("../../../fixtures/openfreemap/openmaptiles_tile_z14_x2661_y6286.pbf");
    /// The bundled Latin glyph range.
    const GLYPH_RANGE_BYTES: &[u8] =
        include_bytes!("../fixtures/render/glyphs/noto_sans_regular_0-255.pbf");
    /// How far past the viewport edge the avoid-edges test places a label, in
    /// screen pixels: enough to cross, too little to miss the frame.
    const LABEL_EDGE_TOLERANCE_PIXELS: f64 = 4.0;

    const TILE_ADDRESS: VectorTileAddress = VectorTileAddress {
        zoom_level: 14,
        tile_x: 2661,
        tile_y: 6286,
    };
    const SACRAMENTO_LATITUDE_DEGREES: f64 = 38.5766;
    const SACRAMENTO_LONGITUDE_DEGREES: f64 = -121.4944;
    /// The center of the sample tile (`2661.5`, `6286.5` in z14 tile units):
    /// a camera there shows the whole tile in the test viewport.
    const FIXTURE_TILE_CENTER_LATITUDE_DEGREES: f64 = 38.573_937_515_575_92;
    /// The sample tile center's longitude.
    const FIXTURE_TILE_CENTER_LONGITUDE_DEGREES: f64 = -121.519_775_390_625;

    fn fixture_font() -> LabelFont {
        let font_stack = decode_glyph_font_stack(GLYPH_RANGE_BYTES).expect("the fixture decodes");
        LabelFont::from_glyph_font_stack(&font_stack).expect("the Latin range packs")
    }

    #[test]
    fn the_embedded_default_glyph_range_is_the_committed_fixture() {
        assert_eq!(
            DEFAULT_LATIN_GLYPH_RANGE_PBF_BYTES, GLYPH_RANGE_BYTES,
            "the embedded glyph source must stay byte-identical to the fixture the \
             golden and browser label suites read"
        );
    }

    #[test]
    fn the_default_label_font_serves_latin_glyphs_and_is_shared() {
        let font = default_label_font();
        assert!(
            font.glyph(u32::from('S')).is_some(),
            "the default font must serve the Latin letters place names use"
        );
        let metrics = font
            .measure_text("Sacramento", 13.0)
            .expect("every character of the demo name has a glyph");
        assert!(metrics.width_pixels > 0.0);
        assert!(
            std::ptr::eq(font, default_label_font()),
            "the packed atlas is decoded and packed once, then shared"
        );
    }

    fn sacramento_camera() -> MapCamera {
        MapCamera::new(
            GeographicCoordinate::from_degrees(
                SACRAMENTO_LATITUDE_DEGREES,
                SACRAMENTO_LONGITUDE_DEGREES,
            )
            .unwrap(),
            14.0,
            0.0,
            0.0,
        )
    }

    fn bright_candidates() -> Vec<MapLabelCandidate> {
        bright_candidates_at_zoom(14.0)
    }

    fn bright_candidates_at_zoom(style_zoom_level: f64) -> Vec<MapLabelCandidate> {
        let tile = decode_vector_tile(OPENFREEMAP_TILE_BYTES).expect("the fixture decodes");
        let style = vector_tile_style_from_id(VECTOR_STYLE_ID_BRIGHT_LIGHT).unwrap();
        label_candidates_for_vector_tile(&tile, TILE_ADDRESS, &style, style_zoom_level)
    }

    fn candidate_texts(candidates: &[MapLabelCandidate]) -> Vec<&str> {
        candidates
            .iter()
            .map(|candidate| candidate.text.as_str())
            .collect()
    }

    #[test]
    fn the_demo_tile_reads_the_four_documented_place_names() {
        let candidates = bright_candidates();
        let texts = candidate_texts(&candidates);
        for expected_text in ["Sacramento", "West Sacramento", "Mikon", "Bryte"] {
            assert!(
                texts.contains(&expected_text),
                "the Bright symbol layers must read {expected_text:?} from the demo tile"
            );
        }
        assert!(
            texts.contains(&"Downtown"),
            "a neighbourhood name keeps drawing at the demo zoom"
        );
    }

    #[test]
    fn placing_the_frame_keeps_sacramento_and_its_font_is_available() {
        let font = fixture_font();
        assert!(font.glyph(u32::from('S')).is_some());
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &bright_candidates(),
            &font,
        );
        assert!(
            layer
                .labels()
                .iter()
                .any(|label| label.text == "Sacramento"),
            "the Sacramento label anchors at the frame center"
        );
        let vertices = layer.quad_vertices(&viewport);
        assert!(
            !vertices.text.is_empty(),
            "placed labels produce text quads"
        );
        assert_eq!(
            vertices.text.len() % 6,
            0,
            "every glyph contributes two triangles"
        );
        for vertex in &vertices.text {
            assert!(
                vertex
                    .clip_position
                    .iter()
                    .all(|component| component.is_finite())
            );
            assert_eq!(
                vertex.signed_distance_threshold,
                GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD
            );
        }
    }

    #[test]
    fn colliding_labels_are_rejected_unless_overlap_is_allowed() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let candidate = |text: &str, allow_overlap: bool| MapLabelCandidate {
            text: text.to_string(),
            anchor,
            line_coordinates: Vec::new(),
            text_rgba: [0.0, 0.0, 0.0, 1.0],
            text_size_pixels: 13.0,
            halo_rgba: [1.0, 1.0, 1.0, 1.0],
            halo_width_pixels: 1.5,
            priority: 1,
            rank: 1,
            allow_overlap,
            ignore_placement: false,
            avoid_edges: false,
            text_offset_pixels: [0.0, 0.0],
            repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
            line_center_only: false,
            text_max_width_ems: 10.0,
            text_line_height_ems: 1.2,
            text_letter_spacing_ems: 0.0,
            text_justify: rustic_maps_style::TextJustify::Auto,
            style_order: 0,
        };
        let rejected = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[
                candidate("Sacramento", false),
                candidate("West Sacramento", false),
            ],
            &font,
        );
        assert_eq!(rejected.labels().len(), 1);

        let overlapping = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[
                candidate("Sacramento", false),
                candidate("West Sacramento", true),
            ],
            &font,
        );
        assert_eq!(overlapping.labels().len(), 2);
        assert_eq!(overlapping.labels()[0].text, "Sacramento");
    }

    #[test]
    fn a_lower_priority_label_wins_over_an_earlier_style_layer() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let label = |text: &str, priority: u32, style_order: usize| MapLabelCandidate {
            text: text.to_string(),
            anchor,
            line_coordinates: Vec::new(),
            text_rgba: [0.0, 0.0, 0.0, 1.0],
            text_size_pixels: 13.0,
            halo_rgba: [1.0, 1.0, 1.0, 1.0],
            halo_width_pixels: 1.5,
            priority,
            rank: 1,
            allow_overlap: false,
            ignore_placement: false,
            avoid_edges: false,
            text_offset_pixels: [0.0, 0.0],
            repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
            line_center_only: false,
            text_max_width_ems: 10.0,
            text_line_height_ems: 1.2,
            text_letter_spacing_ems: 0.0,
            text_justify: rustic_maps_style::TextJustify::Auto,
            style_order,
        };
        // The point-of-interest layer lists first in the style but ranks less
        // important, so the city name must survive the collision.
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[label("Coffee Shop", 2, 0), label("Sacramento", 1, 1)],
            &font,
        );
        assert_eq!(layer.labels().len(), 1);
        assert_eq!(layer.labels()[0].text, "Sacramento");
    }

    #[test]
    fn repeated_text_is_painted_once_across_buffered_tiles() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let mut candidates = bright_candidates();
        let duplicated = candidates.clone();
        candidates.extend(duplicated);
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &candidates,
            &font,
        );
        let sacramento_count = layer
            .labels()
            .iter()
            .filter(|label| label.text == "Sacramento")
            .count();
        assert_eq!(sacramento_count, 1);
    }

    #[test]
    fn a_name_straddling_two_adjacent_tiles_is_painted_once() {
        // The same tile payload at two adjacent addresses stands for one place
        // named in both tiles' buffered overlap. The camera sits on the shared
        // edge so both copies project inside the frame; cross-tile suppression
        // must still paint the name once.
        let tile = decode_vector_tile(OPENFREEMAP_TILE_BYTES).expect("the fixture decodes");
        let style = vector_tile_style_from_id(VECTOR_STYLE_ID_BRIGHT_LIGHT)
            .expect("the committed Bright style loads");
        let east_tile_address = VectorTileAddress {
            tile_x: TILE_ADDRESS.tile_x + 1,
            ..TILE_ADDRESS
        };
        let west_candidates = label_candidates_for_vector_tile(&tile, TILE_ADDRESS, &style, 14.0);
        let east_candidates =
            label_candidates_for_vector_tile(&tile, east_tile_address, &style, 14.0);
        for candidates in [&west_candidates, &east_candidates] {
            assert!(
                candidate_texts(candidates).contains(&"Sacramento"),
                "each tile's buffered copy carries the straddling place name"
            );
        }
        let mut straddling_candidates = west_candidates;
        straddling_candidates.extend(east_candidates);

        let sacramento_anchors: Vec<&GeographicCoordinate> = straddling_candidates
            .iter()
            .filter(|candidate| candidate.text == "Sacramento")
            .map(|candidate| &candidate.anchor)
            .collect();
        assert_eq!(
            sacramento_anchors.len(),
            2,
            "the two tile copies carry the name at two shifted anchors"
        );
        let midpoint_latitude_degrees =
            (sacramento_anchors[0].latitude + sacramento_anchors[1].latitude) / 2.0;
        let midpoint_longitude_degrees =
            (sacramento_anchors[0].longitude + sacramento_anchors[1].longitude) / 2.0;
        let straddle_camera = MapCamera::new(
            GeographicCoordinate::from_degrees(
                midpoint_latitude_degrees,
                midpoint_longitude_degrees,
            )
            .unwrap(),
            14.0,
            0.0,
            0.0,
        );
        let viewport = ViewportPixels::new(1024.0, 1024.0).unwrap();
        let layer = LabelLayer::place(
            &straddle_camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &straddling_candidates,
            &fixture_font(),
        );
        assert_eq!(
            layer
                .labels()
                .iter()
                .filter(|label| label.text == "Sacramento")
                .count(),
            1,
            "a name repeated by two tiles over the same place is painted once"
        );
    }

    #[test]
    fn the_demo_zoom_holds_shops_back_and_caps_the_place_rank() {
        let demo_zoom_candidates = bright_candidates_at_zoom(14.0);
        let demo_zoom_texts = candidate_texts(&demo_zoom_candidates);
        for shop_text in ["7-Eleven", "McDonald's", "Chevron"] {
            assert!(
                !demo_zoom_texts.contains(&shop_text),
                "a shop label must not compete at the demo zoom, found {shop_text:?}"
            );
        }
        for important_text in [
            "Sutter Health Park",
            "Westfield Village Elementary School",
            "Sacramento",
            "Downtown",
        ] {
            assert!(
                demo_zoom_texts.contains(&important_text),
                "an important place name must survive the demo zoom, missing {important_text:?}"
            );
        }

        let close_zoom_candidates = bright_candidates_at_zoom(18.0);
        let close_zoom_texts = candidate_texts(&close_zoom_candidates);
        for shop_text in ["7-Eleven", "McDonald's", "Chevron"] {
            assert!(
                close_zoom_texts.contains(&shop_text),
                "a shop label appears once the map is close enough, missing {shop_text:?}"
            );
        }
        let mid_zoom_candidates = bright_candidates_at_zoom(16.0);
        assert!(
            !candidate_texts(&mid_zoom_candidates).contains(&"Sacramento History Museum"),
            "rank 19 stays above the zoom-16 ceiling"
        );
        assert!(
            close_zoom_texts.contains(&"Sacramento History Museum"),
            "the zoom-18 frame drops the rank ceiling and reads the museum"
        );

        let wide_zoom_candidates = bright_candidates_at_zoom(8.0);
        let wide_zoom_texts = candidate_texts(&wide_zoom_candidates);
        assert!(
            wide_zoom_texts.contains(&"Sacramento"),
            "a city name keeps drawing at a wide zoom"
        );
        assert!(
            wide_zoom_texts.contains(&"Downtown"),
            "a neighbourhood name keeps drawing at a wide zoom"
        );
    }

    /// A point candidate at the Sacramento camera centre with the shared
    /// paint, differing only in the fields a test exercises.
    fn point_candidate(
        text: &str,
        anchor: GeographicCoordinate,
        text_offset_pixels: [f64; 2],
        ignore_placement: bool,
        avoid_edges: bool,
    ) -> MapLabelCandidate {
        MapLabelCandidate {
            text: text.to_string(),
            anchor,
            line_coordinates: Vec::new(),
            text_rgba: [0.0, 0.0, 0.0, 1.0],
            text_size_pixels: 13.0,
            halo_rgba: [1.0, 1.0, 1.0, 1.0],
            halo_width_pixels: 1.5,
            priority: 0,
            rank: 1,
            allow_overlap: false,
            ignore_placement,
            avoid_edges,
            text_offset_pixels,
            repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
            line_center_only: false,
            text_max_width_ems: 10.0,
            text_line_height_ems: 1.2,
            text_letter_spacing_ems: 0.0,
            text_justify: rustic_maps_style::TextJustify::Auto,
            style_order: 0,
        }
    }

    #[test]
    fn a_text_offset_shifts_a_point_labels_anchor() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let projected = camera
            .project_to_screen(
                &anchor,
                &viewport,
                crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            )
            .expect("the camera projects its own centre");
        let layer = LabelLayer::place(
            &camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[point_candidate(
                "Sacramento",
                anchor,
                [10.0, -6.0],
                false,
                false,
            )],
            &font,
        );
        let placed = &layer.labels()[0];
        assert!((placed.anchor_screen_pixels[0] - projected[0] - 10.0).abs() < 1e-6);
        assert!((placed.anchor_screen_pixels[1] - projected[1] + 6.0).abs() < 1e-6);
    }

    #[test]
    fn ignore_placement_keeps_overlapping_labels() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let candidates = [
            point_candidate("Sacramento", anchor, [0.0, 0.0], true, false),
            point_candidate("West Sacramento", anchor, [0.0, 0.0], true, false),
        ];
        let layer = LabelLayer::place(
            &camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &candidates,
            &font,
        );
        assert_eq!(layer.labels().len(), 2);
    }

    #[test]
    fn avoid_edges_drops_a_label_that_crosses_the_viewport() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        // The offset pushes the text just past the left edge, where it still
        // intersects the viewport but no longer lies inside it.
        let metrics = font
            .measure_text("Sacramento", 13.0)
            .expect("the fixture font measures Latin text");
        let half_width_pixels = metrics.width_pixels / 2.0 + LABEL_COLLISION_PADDING_PIXELS;
        let offset_x_pixels =
            -(viewport.width_pixels / 2.0) + half_width_pixels - LABEL_EDGE_TOLERANCE_PIXELS;
        let place = |avoid_edges: bool| {
            LabelLayer::place(
                &camera,
                &viewport,
                crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
                &[point_candidate(
                    "Sacramento",
                    anchor,
                    [offset_x_pixels, 0.0],
                    false,
                    avoid_edges,
                )],
                &font,
            )
        };
        assert_eq!(place(false).labels().len(), 1);
        assert_eq!(place(true).labels().len(), 0);
    }

    #[test]
    fn a_line_center_placement_places_one_label_at_the_run_midpoint() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let metrics = font
            .measure_text("Sacramento", 13.0)
            .expect("the fixture font measures Latin text");
        let line = vec![
            coordinate_offset_from_sacramento(-0.02, 0.0),
            coordinate_offset_from_sacramento(0.02, 0.0),
        ];
        let repeated = label_placements_along_line(
            &camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &line,
            metrics.width_pixels,
            LINE_LABEL_REPEAT_SPACING_PIXELS,
            false,
        );
        let centered = label_placements_along_line(
            &camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &line,
            metrics.width_pixels,
            LINE_LABEL_REPEAT_SPACING_PIXELS,
            true,
        );
        assert!(repeated.len() > 1, "the long run repeats its name");
        assert_eq!(centered.len(), 1);
    }

    #[test]
    fn a_long_label_wraps_at_the_declared_width() {
        let font = fixture_font();
        let block = font
            .measure_wrapped_text("West Sacramento City Hall", 13.0, 60.0, 1.2, 0.0)
            .expect("the fixture font measures the label");
        assert!(block.lines.len() >= 2, "lines {:?}", block.lines);
        for line in &block.lines {
            assert!(
                line.width_pixels <= block.width_pixels + 1e-9,
                "line {:?} wider than the block",
                line
            );
        }
        assert!((block.line_height_pixels - 13.0 * 1.2).abs() < 1e-9);
        assert!(
            (block.height_pixels - block.line_height_pixels * block.lines.len() as f64).abs()
                < 1e-9
        );
    }

    #[test]
    fn letter_spacing_widens_a_measured_line() {
        let font = fixture_font();
        let plain = font
            .measure_text("Sacramento", 13.0)
            .expect("the fixture font measures the label");
        let spaced = font
            .measure_wrapped_text("Sacramento", 13.0, 10_000.0, 1.2, 2.0)
            .expect("the fixture font measures the label");
        let served_glyph_count = "Sacramento".chars().count() as f64;
        assert!(
            (spaced.width_pixels - (plain.width_pixels + 2.0 * (served_glyph_count - 1.0))).abs()
                < 1e-9
        );
    }

    #[test]
    fn justify_moves_a_short_line_within_the_block() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let place_with_justify = |justify| {
            let mut candidate =
                point_candidate("West Sacramento", anchor, [0.0, 0.0], false, false);
            candidate.text_max_width_ems = 40.0 / 13.0;
            candidate.text_justify = justify;
            LabelLayer::place(
                &camera,
                &viewport,
                crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
                &[candidate],
                &font,
            )
        };
        let centered = place_with_justify(TextJustify::Center);
        let left = place_with_justify(TextJustify::Left);
        assert_eq!(centered.labels()[0].lines.len(), 2);
        let line_minimum_x = |layer: &LabelLayer, upper_half: bool| {
            let vertices = layer.quad_vertices(&viewport).text;
            let anchor_y = layer.labels()[0].anchor_screen_pixels[1];
            vertices
                .iter()
                .map(|vertex| {
                    let clip = glam::DVec4::new(
                        f64::from(vertex.clip_position[0]),
                        f64::from(vertex.clip_position[1]),
                        f64::from(vertex.clip_position[2]),
                        f64::from(vertex.clip_position[3]),
                    );
                    let screen = crate::overlay::clip_position_to_screen_pixels(clip, &viewport);
                    (screen[0], screen[1])
                })
                .filter(|(_, screen_y)| (*screen_y < anchor_y) == upper_half)
                .map(|(screen_x, _)| screen_x)
                .fold(f64::INFINITY, f64::min)
        };
        // The upper (shorter) line's start moves inward under centered
        // justification; a left-justified block starts both lines together.
        let centered_shift = line_minimum_x(&centered, true) - line_minimum_x(&centered, false);
        let left_shift = line_minimum_x(&left, true) - line_minimum_x(&left, false);
        assert!(
            centered_shift > 4.0,
            "a centered short line starts inside the block (shift {centered_shift})"
        );
        // The per-line minimum is a glyph bitmap edge, so its left bearing
        // differs by a pixel; what matters is that left justification does
        // not apply the centered inset.
        assert!(
            left_shift.abs() < 2.0,
            "a left-justified block starts both lines together (shift {left_shift})"
        );
    }

    #[test]
    fn a_declared_symbol_spacing_changes_the_repeat_count() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let camera = sacramento_camera();
        let metrics = font
            .measure_text("Sacramento", 13.0)
            .expect("the fixture font measures Latin text");
        let line = vec![
            coordinate_offset_from_sacramento(-0.02, 0.0),
            coordinate_offset_from_sacramento(0.02, 0.0),
        ];
        let placements_at = |repeat_spacing_pixels: f64| {
            label_placements_along_line(
                &camera,
                &viewport,
                crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
                &line,
                metrics.width_pixels,
                repeat_spacing_pixels,
                false,
            )
            .len()
        };
        assert!(placements_at(60.0) > placements_at(260.0));
    }

    #[test]
    fn a_frame_places_at_most_its_label_budget_after_the_priority_sort() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(2048.0, 2048.0).unwrap();
        let candidate_count = MAXIMUM_LABELS_PER_FRAME * 2;
        let candidates: Vec<MapLabelCandidate> = (0..candidate_count)
            .map(|index| {
                let column = index % 8;
                let row = index / 8;
                MapLabelCandidate {
                    text: format!("A{index}"),
                    anchor: coordinate_offset_from_sacramento(
                        -0.028 + column as f64 * 0.008,
                        0.028 - row as f64 * 0.008,
                    ),
                    line_coordinates: Vec::new(),
                    text_rgba: [0.0, 0.0, 0.0, 1.0],
                    text_size_pixels: 12.0,
                    halo_rgba: [1.0, 1.0, 1.0, 1.0],
                    halo_width_pixels: 1.5,
                    priority: 1,
                    rank: index as u32,
                    allow_overlap: false,
                    ignore_placement: false,
                    avoid_edges: false,
                    text_offset_pixels: [0.0, 0.0],
                    repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
                    line_center_only: false,
                    text_max_width_ems: 10.0,
                    text_line_height_ems: 1.2,
                    text_letter_spacing_ems: 0.0,
                    text_justify: rustic_maps_style::TextJustify::Auto,
                    style_order: 0,
                }
            })
            .collect();
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &candidates,
            &font,
        );
        assert_eq!(
            layer.labels().len(),
            MAXIMUM_LABELS_PER_FRAME,
            "the frame stops at its label budget even though every candidate fits"
        );
        let last_label = layer
            .labels()
            .last()
            .expect("a budgeted frame places its last label");
        assert_eq!(
            last_label.text,
            format!("A{}", MAXIMUM_LABELS_PER_FRAME - 1),
            "the budget is spent after the priority sort, so the ranked names win"
        );
    }

    #[test]
    fn a_font_without_the_glyphs_places_no_labels() {
        let empty_font_stack = GlyphFontStack::default();
        let font = LabelFont::from_glyph_font_stack(&empty_font_stack)
            .expect("an empty range packs an empty atlas");
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &bright_candidates(),
            &font,
        );
        assert!(layer.is_empty());
        assert!(layer.quad_vertices(&viewport).is_empty());
    }

    #[test]
    fn a_style_without_symbol_layers_reads_no_candidates() {
        let tile = decode_vector_tile(OPENFREEMAP_TILE_BYTES).unwrap();
        let style = compiled_style(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "water",
                        "type": "fill",
                        "source": "base",
                        "source-layer": "water",
                        "paint": { "fill-color": [51, 127.5, 229.5, 0.4] }
                    }
                ]
            }"#,
        );
        assert!(label_candidates_for_vector_tile(&tile, TILE_ADDRESS, &style, 14.0).is_empty());
    }

    #[test]
    fn the_halo_pass_precedes_the_text_pass() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[MapLabelCandidate {
                text: "Sacramento".to_string(),
                anchor,
                line_coordinates: Vec::new(),
                text_rgba: [0.0, 0.0, 0.0, 1.0],
                text_size_pixels: 13.0,
                halo_rgba: [1.0, 1.0, 1.0, 1.0],
                halo_width_pixels: 1.5,
                priority: 1,
                rank: 1,
                allow_overlap: false,
                ignore_placement: false,
                avoid_edges: false,
                text_offset_pixels: [0.0, 0.0],
                repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
                line_center_only: false,
                text_max_width_ems: 10.0,
                text_line_height_ems: 1.2,
                text_letter_spacing_ems: 0.0,
                text_justify: rustic_maps_style::TextJustify::Auto,
                style_order: 0,
            }],
            &font,
        );
        let vertices = layer.quad_vertices(&viewport);
        assert_eq!(vertices.halo.len(), vertices.text.len());
        let expected_halo_threshold = glyph_halo_signed_distance_threshold(13.0, 1.5);
        assert!(
            vertices
                .halo
                .iter()
                .all(|vertex| vertex.signed_distance_threshold == expected_halo_threshold)
        );
        // The halo keeps the text quad's geometry: the lower threshold, not
        // an inflated rectangle, is what spreads the outline.
        assert_eq!(vertices.halo.len(), vertices.text.len());
        assert_eq!(
            vertices.halo[0].texture_coordinates,
            vertices.text[0].texture_coordinates
        );
        // Text sits on the glyph protocol's own 0.75 contour, and every vertex
        // carries the size-derived gamma (0.84 device pixels at 1×).
        assert!(
            vertices
                .text
                .iter()
                .all(|vertex| vertex.signed_distance_threshold
                    == GLYPH_TEXT_SIGNED_DISTANCE_THRESHOLD)
        );
        let expected_gamma = glyph_edge_gamma(13.0, 1.0);
        assert!(
            vertices
                .text
                .iter()
                .all(|vertex| vertex.signed_distance_gamma == expected_gamma)
        );
        // 0.105 / (13 / 24) ≈ 0.194 field units.
        assert!(
            (expected_gamma - 0.193_846_15).abs() < 1e-5,
            "{expected_gamma}"
        );
    }

    #[test]
    fn a_two_x_surface_draws_the_same_point_size_with_the_same_edge_band() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(1024.0, 1024.0).unwrap();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let candidate = MapLabelCandidate {
            text: "Sacramento".to_string(),
            anchor,
            line_coordinates: Vec::new(),
            text_rgba: [0.0, 0.0, 0.0, 1.0],
            text_size_pixels: 13.0,
            halo_rgba: [1.0, 1.0, 1.0, 1.0],
            halo_width_pixels: 1.5,
            priority: 1,
            rank: 1,
            allow_overlap: false,
            ignore_placement: false,
            avoid_edges: false,
            text_offset_pixels: [0.0, 0.0],
            repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
            line_center_only: false,
            text_max_width_ems: 10.0,
            text_line_height_ems: 1.2,
            text_letter_spacing_ems: 0.0,
            text_justify: rustic_maps_style::TextJustify::Auto,
            style_order: 0,
        };
        let single_pixel_layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            std::slice::from_ref(&candidate),
            &font,
        );
        let two_x_layer = LabelLayer::place_with_device_pixel_ratio(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            std::slice::from_ref(&candidate),
            &font,
            2.0,
        );
        // The placed label is drawn at twice the device size...
        let single_pixel_label = &single_pixel_layer.labels()[0];
        let two_x_label = &two_x_layer.labels()[0];
        assert_eq!(
            two_x_label.text_size_pixels,
            single_pixel_label.text_size_pixels * 2.0
        );
        assert_eq!(
            two_x_label.halo_width_pixels,
            single_pixel_label.halo_width_pixels * 2.0
        );
        // ...while the fragment stage's half-band stays 0.84 device pixels,
        // so gamma halves in field units and the halo threshold (which is in
        // the style's point units) does not move.
        let single_pixel_gamma = glyph_edge_gamma(13.0, 1.0);
        let two_x_gamma = glyph_edge_gamma(13.0, 2.0);
        assert!((two_x_gamma - single_pixel_gamma / 2.0).abs() < 1e-6);
        let single_pixel_vertices = single_pixel_layer.quad_vertices(&viewport);
        let two_x_vertices = two_x_layer.quad_vertices(&viewport);
        assert_eq!(
            two_x_vertices.text[0].signed_distance_threshold,
            single_pixel_vertices.text[0].signed_distance_threshold
        );
        assert_eq!(
            two_x_vertices.halo[0].signed_distance_threshold,
            single_pixel_vertices.halo[0].signed_distance_threshold
        );
        assert_eq!(two_x_vertices.text[0].signed_distance_gamma, two_x_gamma);
    }

    #[test]
    fn a_negative_zero_halo_draws_only_the_text() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let anchor = GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES,
            SACRAMENTO_LONGITUDE_DEGREES,
        )
        .unwrap();
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[MapLabelCandidate {
                text: "A".to_string(),
                anchor,
                line_coordinates: Vec::new(),
                text_rgba: [0.0, 0.0, 0.0, 1.0],
                text_size_pixels: 13.0,
                halo_rgba: [1.0, 1.0, 1.0, 1.0],
                halo_width_pixels: 0.0,
                priority: 1,
                rank: 1,
                allow_overlap: false,
                ignore_placement: false,
                avoid_edges: false,
                text_offset_pixels: [0.0, 0.0],
                repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
                line_center_only: false,
                text_max_width_ems: 10.0,
                text_line_height_ems: 1.2,
                text_letter_spacing_ems: 0.0,
                text_justify: rustic_maps_style::TextJustify::Auto,
                style_order: 0,
            }],
            &font,
        );
        let vertices = layer.quad_vertices(&viewport);
        assert!(vertices.halo.is_empty());
        assert!(!vertices.text.is_empty());
    }

    /// A coordinate offset from the Sacramento anchor in degrees; at zoom 14
    /// one hundredth of a degree of longitude spans roughly 230 viewport
    /// pixels, enough for a short street name.
    fn coordinate_offset_from_sacramento(
        east_degrees: f64,
        north_degrees: f64,
    ) -> GeographicCoordinate {
        GeographicCoordinate::from_degrees(
            SACRAMENTO_LATITUDE_DEGREES + north_degrees,
            SACRAMENTO_LONGITUDE_DEGREES + east_degrees,
        )
        .unwrap()
    }

    fn line_label_candidate(
        text: &str,
        line_coordinates: Vec<GeographicCoordinate>,
        text_size_pixels: f64,
    ) -> MapLabelCandidate {
        MapLabelCandidate {
            text: text.to_string(),
            anchor: line_coordinates[0],
            line_coordinates,
            text_rgba: [0.0, 0.0, 0.0, 1.0],
            text_size_pixels,
            halo_rgba: [1.0, 1.0, 1.0, 1.0],
            halo_width_pixels: 1.5,
            priority: 1,
            rank: 1,
            allow_overlap: false,
            ignore_placement: false,
            avoid_edges: false,
            text_offset_pixels: [0.0, 0.0],
            repeat_spacing_pixels: LINE_LABEL_REPEAT_SPACING_PIXELS,
            line_center_only: false,
            text_max_width_ems: 10.0,
            text_line_height_ems: 1.2,
            text_letter_spacing_ems: 0.0,
            text_justify: rustic_maps_style::TextJustify::Auto,
            style_order: 0,
        }
    }

    #[test]
    fn the_demo_tiles_street_names_place_at_the_demo_zoom() {
        // The road-name path end to end without a GPU: the Bright style's
        // transportation_name bands read the demo tile's street names, and at
        // the fixture tile's own center at the demo zoom the longest straight
        // runs carry several of them.
        let tile = decode_vector_tile(OPENFREEMAP_TILE_BYTES).unwrap();
        let style = vector_tile_style_from_id(VECTOR_STYLE_ID_BRIGHT_LIGHT)
            .expect("the committed Bright style loads");
        let line_candidates: Vec<MapLabelCandidate> =
            label_candidates_for_vector_tile(&tile, TILE_ADDRESS, &style, 14.0)
                .into_iter()
                .filter(|candidate| !candidate.line_coordinates.is_empty())
                .collect();
        assert!(!line_candidates.is_empty());
        let fixture_tile_center_camera = MapCamera::new(
            GeographicCoordinate::from_degrees(
                FIXTURE_TILE_CENTER_LATITUDE_DEGREES,
                FIXTURE_TILE_CENTER_LONGITUDE_DEGREES,
            )
            .unwrap(),
            14.0,
            0.0,
            0.0,
        );
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let layer = LabelLayer::place(
            &fixture_tile_center_camera,
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &line_candidates,
            &fixture_font(),
        );
        assert!(
            !layer.is_empty(),
            "the demo tile's street names fit the demo zoom's straight runs"
        );
        for label in layer.labels() {
            assert!(label.placed_along_line);
            assert!(
                (-crate::labels::LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS
                    ..=crate::labels::LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS)
                    .contains(&label.rotation_radians)
            );
        }
        assert!(
            !layer.quad_vertices(&viewport).text.is_empty(),
            "the placed street names rasterize into glyph quads"
        );
    }

    #[test]
    fn a_line_symbol_layer_reads_the_demo_tiles_road_names() {
        let tile = decode_vector_tile(OPENFREEMAP_TILE_BYTES).unwrap();
        let style = compiled_style(
            r#"{
                "version": 8,
                "sources": { "base": { "type": "vector" } },
                "layers": [
                    {
                        "id": "road-name",
                        "type": "symbol",
                        "source": "base",
                        "source-layer": "transportation_name",
                        "minzoom": 12,
                        "maxzoom": 18,
                        "layout": {
                            "text-field": ["coalesce", ["get", "name:latin"], ["get", "name"], ["get", "ref"]],
                            "text-size": 12,
                            "symbol-placement": "line"
                        },
                        "paint": { "text-color": [51, 51, 51, 1] }
                    }
                ]
            }"#,
        );
        let candidates = label_candidates_for_vector_tile(&tile, TILE_ADDRESS, &style, 14.0);
        assert!(
            !candidates.is_empty(),
            "the demo tile's transportation_name layer carries road names"
        );
        for candidate in &candidates {
            assert!(
                candidate.line_coordinates.len() >= 2,
                "a line candidate carries its whole line geometry"
            );
            assert!(!candidate.text.is_empty());
            assert_eq!(candidate.style_order, 0);
        }
    }

    #[test]
    fn a_line_label_centers_and_rotates_along_its_longest_straight_run() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        // Three collinear vertices are one straight run short enough for one
        // label; it centers at half of the run's arc length, which is not any
        // of the vertices.
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(-0.002, 0.003),
            coordinate_offset_from_sacramento(-0.001, 0.003),
            coordinate_offset_from_sacramento(0.002, 0.003),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("N St", line_coordinates, 12.0)],
            &font,
        );
        assert_eq!(layer.labels().len(), 1);
        let label = &layer.labels()[0];
        assert!(
            label.rotation_radians.abs() < 1e-9,
            "a horizontal run places unrotated"
        );
        let expected_anchor = sacramento_camera()
            .project_to_screen(
                &coordinate_offset_from_sacramento(0.0, 0.003),
                &viewport,
                crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            )
            .unwrap();
        assert!((label.anchor_screen_pixels[0] - expected_anchor[0]).abs() < 1e-6);
        assert!((label.anchor_screen_pixels[1] - expected_anchor[1]).abs() < 1e-6);
    }

    #[test]
    fn a_long_street_repeats_its_name_along_the_run() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        // A run long enough for several names: a street crossing the frame is
        // named more than once, so a reader finds it wherever they look.
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(-0.012, 0.002),
            coordinate_offset_from_sacramento(0.0, 0.002),
            coordinate_offset_from_sacramento(0.012, 0.002),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("Capitol Mall", line_coordinates, 12.0)],
            &font,
        );
        let labels = layer.labels();
        assert!(
            labels.len() >= 2,
            "a frame-wide street carries more than one name, got {}",
            labels.len()
        );
        for label in labels {
            assert_eq!(label.text, "Capitol Mall");
            assert!(label.placed_along_line);
            assert!(
                label.rotation_radians.abs() < 1e-9,
                "every repeated name of a horizontal run places unrotated"
            );
        }
        let mut anchor_positions: Vec<f64> = labels
            .iter()
            .map(|label| label.anchor_screen_pixels[0])
            .collect();
        anchor_positions.sort_by(f64::total_cmp);
        for anchor_pair in anchor_positions.windows(2) {
            assert!(
                anchor_pair[1] - anchor_pair[0] > LINE_LABEL_REPEAT_SPACING_PIXELS,
                "repeated names keep at least the repeat spacing between anchors"
            );
        }
    }

    #[test]
    fn a_turn_past_the_straight_run_tolerance_breaks_the_run() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        // A right angle: a short east leg and a longer north leg. The label
        // must take the north run (not straddle both legs), so its rotation
        // points along the vertical.
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(-0.002, 0.0),
            coordinate_offset_from_sacramento(0.002, 0.0),
            coordinate_offset_from_sacramento(0.002, 0.012),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("3rd Street", line_coordinates, 11.0)],
            &font,
        );
        assert!(!layer.labels().is_empty());
        for label in layer.labels() {
            assert!(
                label.rotation_radians.abs() > 1.0,
                "the longer north leg rotates every name toward vertical"
            );
        }
    }

    #[test]
    fn a_line_label_flips_its_rotation_so_the_text_reads_upright() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        // The line runs from the north-east to the south-west, a 135-degree
        // screen bearing (down and to the left); flipping it yields the
        // -45-degree upright label.
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(0.008, 0.008),
            coordinate_offset_from_sacramento(-0.008, -0.008),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("Capitol Mall", line_coordinates, 12.0)],
            &font,
        );
        assert!(!layer.labels().is_empty());
        for label in layer.labels() {
            let rotation_radians = label.rotation_radians;
            assert!(
                (-LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS
                    ..=LINE_LABEL_UPRIGHT_ROTATION_LIMIT_RADIANS)
                    .contains(&rotation_radians),
                "an upright label never rotates past a quarter turn, got {rotation_radians}"
            );
            assert!(
                rotation_radians < 0.0,
                "the up-left bearing flips to a downward-reading positive-x run"
            );
        }
    }

    #[test]
    fn a_line_label_wider_than_every_segment_is_skipped() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        // Two hundredths of a degree is a couple of pixels at zoom 14; this
        // name cannot fit between the collision paddings.
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(-0.0001, 0.0),
            coordinate_offset_from_sacramento(0.0001, 0.0),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("Sacramento", line_coordinates, 12.0)],
            &font,
        );
        assert!(layer.is_empty());
    }

    #[test]
    fn a_rotated_label_rejects_a_colliding_line_label_like_a_point_label() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let horizontal_line = || {
            vec![
                coordinate_offset_from_sacramento(-0.004, 0.0),
                coordinate_offset_from_sacramento(0.004, 0.0),
            ]
        };
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[
                line_label_candidate("N St", horizontal_line(), 12.0),
                line_label_candidate("M St", horizontal_line(), 12.0),
            ],
            &font,
        );
        let labels = layer.labels();
        assert!(!labels.is_empty());
        assert!(
            labels.iter().all(|label| label.text == "N St"),
            "the second street runs over the first and is rejected whole, repeats included"
        );
    }

    #[test]
    fn a_rotated_label_emits_finite_text_quads() {
        let font = fixture_font();
        let viewport = ViewportPixels::new(512.0, 512.0).unwrap();
        let line_coordinates = vec![
            coordinate_offset_from_sacramento(-0.006, 0.004),
            coordinate_offset_from_sacramento(0.006, -0.004),
        ];
        let layer = LabelLayer::place(
            &sacramento_camera(),
            &viewport,
            crate::camera::DEFAULT_FIELD_OF_VIEW_DEGREES,
            &[line_label_candidate("Capitol Mall", line_coordinates, 12.0)],
            &font,
        );
        assert!(!layer.labels().is_empty());
        for label in layer.labels() {
            assert_ne!(label.rotation_radians, 0.0);
        }
        let vertices = layer.quad_vertices(&viewport);
        assert!(!vertices.text.is_empty());
        assert_eq!(vertices.halo.len(), vertices.text.len());
        for vertex in &vertices.text {
            assert!(
                vertex
                    .clip_position
                    .iter()
                    .all(|component| component.is_finite())
            );
        }
    }
}
