//! Live smoke test against the real MapQuest platform.
//!
//! Requires `MAPQUEST_CONSUMER_KEY` in the environment (see `.env.example`).
//! Run manually; CI never depends on live credentials:
//!
//! ```sh
//! set -a; source .env; set +a
//! cargo run -p mapquest-provider --example live_smoke
//! ```

use geospatial_traits::{
    DistanceMatrixProvider, GeocodingProvider, RasterTileProvider, RoutingProvider,
    SearchPlaceProvider, TrafficFlowProvider, TrafficIncidentProvider,
};
use geospatial_types::route::{RouteOptions, TransportationMode};
use geospatial_types::{BoundingBox, GeographicCoordinate};
use geospatial_types::{RasterImageFormat, RasterTileResolution};
use mapquest_provider::{
    MapQuestDistanceMatrixProvider, MapQuestGeocodingProvider, MapQuestProviderClient,
    MapQuestProviderConfiguration, MapQuestRasterTileProvider, MapQuestRoutingProvider,
    MapQuestSearchPlaceProvider, MapQuestTrafficFlowProvider, MapQuestTrafficIncidentProvider,
};
use std::sync::Arc;

#[tokio::main]
async fn main() {
    let api_key = std::env::var("MAPQUEST_CONSUMER_KEY").unwrap_or_else(|_| {
        panic!("MAPQUEST_CONSUMER_KEY missing; copy .env.example to .env and fill it in")
    });
    let client = Arc::new(
        MapQuestProviderClient::new(MapQuestProviderConfiguration {
            api_key,
            ..MapQuestProviderConfiguration::default()
        })
        .unwrap(),
    );

    let geocoder = MapQuestGeocodingProvider::new(client.clone());
    let forward_places = geocoder
        .forward_geocode("Sacramento,California")
        .await
        .unwrap();
    println!(
        "forward geocode: {} -> ({:.5}, {:.5}) quality {:?}",
        forward_places[0].structured_address_text,
        forward_places[0].coordinate.latitude,
        forward_places[0].coordinate.longitude,
        forward_places[0].geocode_quality
    );

    let start = forward_places[0].coordinate;
    let router = MapQuestRoutingProvider::new(client.clone());
    let end = GeographicCoordinate::from_degrees(38.57887, -121.50797).unwrap();
    let route = router
        .calculate_route(&[start, end], &RouteOptions::default())
        .await
        .unwrap();
    println!(
        "route: {:.1} m, {:.0} s, {} steps",
        route.distance_meters,
        route.duration_seconds,
        route.legs.iter().map(|leg| leg.steps.len()).sum::<usize>()
    );

    let matrix = MapQuestDistanceMatrixProvider::new(client.clone());
    let distance_matrix = matrix
        .calculate_distance_matrix(&[start], &[end], TransportationMode::Automobile)
        .await
        .unwrap();
    println!(
        "matrix: {} entries, first = {:.0} m / {:.0} s",
        distance_matrix.entries.len(),
        distance_matrix.entries[0].distance_meters,
        distance_matrix.entries[0].duration_seconds
    );

    let search = MapQuestSearchPlaceProvider::new(client.clone());
    let suggestions = search
        .search_autocomplete("Sacramento", None)
        .await
        .unwrap();
    println!("autocomplete: {} candidates", suggestions.len());

    let bounding_box = BoundingBox::from_corners(
        GeographicCoordinate::from_degrees(39.52, -105.25).unwrap(),
        GeographicCoordinate::from_degrees(39.95, -104.71).unwrap(),
    )
    .unwrap();
    let incidents = MapQuestTrafficIncidentProvider::new(client.clone());
    let traffic_incidents = incidents
        .fetch_traffic_incidents(&bounding_box)
        .await
        .unwrap();
    println!(
        "incidents: {} reported in the Denver box, first = {:?}",
        traffic_incidents.len(),
        traffic_incidents
            .first()
            .map(|incident| incident.incident_type)
    );

    let flow = MapQuestTrafficFlowProvider::new(client.clone());
    let traffic_flow = flow.fetch_traffic_flow(&bounding_box).await.unwrap();
    println!(
        "flow: {} polylines in the Denver box, first = {:?}",
        traffic_flow.len(),
        traffic_flow.first().map(|data| data.congestion_level)
    );

    let tiles = MapQuestRasterTileProvider::new(client);
    let tile = tiles
        .fetch_raster_tile(
            137,
            335,
            9,
            RasterImageFormat::Png,
            RasterTileResolution::Standard,
        )
        .await
        .unwrap();
    println!("tile 9/137/335: {} png bytes", tile.image_bytes.len());
}
