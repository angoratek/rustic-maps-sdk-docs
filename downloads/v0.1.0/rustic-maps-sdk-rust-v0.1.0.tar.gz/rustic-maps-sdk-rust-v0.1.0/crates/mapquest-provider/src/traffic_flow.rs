//! MapQuest Traffic API v2 JSON flow implementation.
//!
//! The flow endpoint serves an image by default, but with `outFormat=json`
//! it returns a GeoJSON `FeatureCollection` of congestion polylines — the
//! same data the `L.mapquest.trafficLayer()` overlay of the mapquest-js
//! SDK draws. Each feature carries `properties.traffic` with one of the
//! documented overlay buckets (`green`, `yellow`, `red`, `black`) and a
//! `MultiLineString` of Web-Mercator road segments; no per-segment speeds
//! are reported, so [`TrafficFlowData`] observations carry the congestion
//! level only (`current_speed_kilometers_per_hour` is `None`).

use crate::client::MapQuestProviderClient;
use async_trait::async_trait;
use geospatial_traits::TrafficFlowProvider;
use geospatial_types::traffic::{TrafficFlowCongestionLevel, TrafficFlowData};
use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};
use serde_json::Value;
use std::sync::Arc;

/// Flow overlay color buckets mapped onto SDK congestion levels.
pub const MINIMUM_SEVERITY_FILTER: &str = "green";

/// Square map side (in pixels) the flow request never exceeds; smaller
/// sides keep the covered area inside the service's one-degree cap.
pub const MAXIMUM_FLOW_PIXEL_SIDE: u32 = 1600;

/// Degrees of Web-Mercator latitude covered per pixel at scale 1.0.
///
/// The service derives covered degrees as `pixels * mapScale / 72 / 5700000`
/// (verified against its "Maximum map area exceeded" error message).
const DEGREES_PER_PIXEL_PER_SCALE: f64 = 1.0 / (72.0 * 5_700_000.0);

/// Web-Mercator zoom levels the service accepts, largest scale (most zoomed
/// out) to smallest, with their documented `mapScale` values.
const MAP_SCALE_BY_ZOOM_LEVEL: [(u32, f64); 8] = [
    (11, 216_671.0),
    (12, 108_335.0),
    (13, 54_167.0),
    (14, 27_083.0),
    (15, 13_541.0),
    (16, 6_770.0),
    (17, 3_385.0),
    (18, 1_692.0),
];

/// Safety margin subtracted from the one-degree area limit to absorb the
/// mercator approximations the service applies to map width and height.
const AREA_LIMIT_SAFETY_MARGIN_DEGREES: f64 = 0.02;

/// Flow observations against the MapQuest Traffic API v2 flow endpoint.
pub struct MapQuestTrafficFlowProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestTrafficFlowProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

/// Request geometry for one flow call: the Web-Mercator zoom level chosen
/// for the bounding box, its documented `mapScale`, and the square pixel
/// side that covers the box without exceeding the one-degree area limit.
pub struct FlowViewParameters {
    /// Web-Mercator zoom level the request is expressed in.
    pub zoom_level: u32,
    /// Documented `mapScale` matching `zoom_level`.
    pub map_scale: f64,
    /// Square map width and height in pixels.
    pub side_pixels: u32,
}

#[async_trait]
impl TrafficFlowProvider for MapQuestTrafficFlowProvider {
    async fn fetch_traffic_flow(
        &self,
        bounding_box: &BoundingBox,
    ) -> Result<Vec<TrafficFlowData>, SDKError> {
        let FlowViewParameters {
            map_scale,
            side_pixels,
            ..
        } = select_flow_view(bounding_box)?;
        let center_latitude =
            (bounding_box.south_west.latitude + bounding_box.north_east.latitude) / 2.0;
        let center_longitude =
            (bounding_box.south_west.longitude + bounding_box.north_east.longitude) / 2.0;
        let query_pairs = vec![
            ("projection".to_string(), "merc".to_string()),
            ("mapLat".to_string(), format!("{center_latitude}")),
            ("mapLng".to_string(), format!("{center_longitude}")),
            ("mapWidth".to_string(), format!("{side_pixels}")),
            ("mapHeight".to_string(), format!("{side_pixels}")),
            ("mapScale".to_string(), format!("{map_scale}")),
            (
                "minSeverity".to_string(),
                MINIMUM_SEVERITY_FILTER.to_string(),
            ),
            ("maxLines".to_string(), "1000".to_string()),
            ("outFormat".to_string(), "json".to_string()),
        ];
        let payload = self
            .provider_client
            .get_json(
                "traffic/v2/flow",
                &query_pairs,
                crate::client::TRAFFIC_FLOW_CONTRACT_NAME,
            )
            .await?;
        parse_flow_payload(&payload)
    }
}

/// Picks the most detailed zoom whose square coverage still encloses the
/// bounding box and stays inside the service's one-degree area limit.
pub fn select_flow_view(bounding_box: &BoundingBox) -> Result<FlowViewParameters, SDKError> {
    let latitude_span_degrees = bounding_box.north_east.latitude - bounding_box.south_west.latitude;
    let longitude_span_degrees =
        bounding_box.north_east.longitude - bounding_box.south_west.longitude;
    let center_latitude =
        (bounding_box.south_west.latitude + bounding_box.north_east.latitude) / 2.0;
    let center_cosine = center_latitude.to_radians().cos();
    let area_limit_degrees = 1.0 - AREA_LIMIT_SAFETY_MARGIN_DEGREES;
    if latitude_span_degrees > area_limit_degrees || longitude_span_degrees > area_limit_degrees {
        return Err(SDKError::InvalidCoordinateInput(
            "traffic flow bounding box exceeds the MapQuest one-degree area limit".to_string(),
        ));
    }
    for (zoom_level, map_scale) in MAP_SCALE_BY_ZOOM_LEVEL.iter().rev() {
        // Pixels needed so the square covers both spans at this scale.
        let latitude_pixels =
            (latitude_span_degrees / (map_scale * DEGREES_PER_PIXEL_PER_SCALE)).ceil();
        let longitude_pixels = (longitude_span_degrees * center_cosine
            / (map_scale * DEGREES_PER_PIXEL_PER_SCALE))
            .ceil();
        let side_pixels = latitude_pixels.max(longitude_pixels);
        if side_pixels > f64::from(MAXIMUM_FLOW_PIXEL_SIDE) {
            continue;
        }
        let covered_degrees = side_pixels * map_scale * DEGREES_PER_PIXEL_PER_SCALE;
        // The service measures width in longitude degrees (scaled by 1/cos).
        let fits_area_limit = covered_degrees <= area_limit_degrees
            && covered_degrees / center_cosine <= area_limit_degrees;
        if fits_area_limit {
            return Ok(FlowViewParameters {
                zoom_level: *zoom_level,
                map_scale: *map_scale,
                side_pixels: side_pixels as u32,
            });
        }
    }
    Err(SDKError::InvalidCoordinateInput(
        "traffic flow bounding box cannot be served within the MapQuest area limit at this latitude"
            .to_string(),
    ))
}

/// Parses the GeoJSON flow collection into per-polyline flow observations.
pub fn parse_flow_payload(payload: &Value) -> Result<Vec<TrafficFlowData>, SDKError> {
    let features = payload
        .get("features")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("flow payload lacks the features array".to_string())
        })?;
    let mut parsed_flow = Vec::new();
    for feature in features {
        let congestion_level = map_traffic_bucket_to_congestion_level(
            feature
                .pointer("/properties/traffic")
                .and_then(Value::as_str)
                .ok_or_else(|| {
                    SDKError::ResponseParsingFailure(
                        "flow feature lacks properties.traffic".to_string(),
                    )
                })?,
        )?;
        let line_strings = feature
            .pointer("/geometry/coordinates")
            .and_then(Value::as_array)
            .ok_or_else(|| {
                SDKError::ResponseParsingFailure(
                    "flow feature lacks geometry coordinates".to_string(),
                )
            })?;
        for line_string in line_strings {
            let point_pairs = line_string.as_array().ok_or_else(|| {
                SDKError::ResponseParsingFailure("flow line string is not an array".to_string())
            })?;
            let mut shape_coordinates = Vec::with_capacity(point_pairs.len());
            for point_pair in point_pairs {
                let values = point_pair.as_array().ok_or_else(|| {
                    SDKError::ResponseParsingFailure(
                        "flow point is not an [lng, lat] array".to_string(),
                    )
                })?;
                if values.len() != 2 {
                    return Err(SDKError::ResponseParsingFailure(
                        "flow point lacks exactly lng and lat".to_string(),
                    ));
                }
                let longitude = values[0].as_f64().ok_or_else(|| {
                    SDKError::ResponseParsingFailure("flow point lacks lng".to_string())
                })?;
                let latitude = values[1].as_f64().ok_or_else(|| {
                    SDKError::ResponseParsingFailure("flow point lacks lat".to_string())
                })?;
                shape_coordinates.push(GeographicCoordinate::from_degrees(latitude, longitude)?);
            }
            if shape_coordinates.is_empty() {
                return Err(SDKError::ResponseParsingFailure(
                    "flow line string carries no points".to_string(),
                ));
            }
            parsed_flow.push(TrafficFlowData::from_congestion_level(
                shape_coordinates,
                congestion_level,
            ));
        }
    }
    Ok(parsed_flow)
}

/// Maps the documented overlay buckets (`green`, `yellow`, `red`, `black`)
/// onto SDK congestion levels.
pub fn map_traffic_bucket_to_congestion_level(
    traffic_bucket_text: &str,
) -> Result<TrafficFlowCongestionLevel, SDKError> {
    match traffic_bucket_text {
        "green" => Ok(TrafficFlowCongestionLevel::FreeFlow),
        "yellow" => Ok(TrafficFlowCongestionLevel::Slow),
        "red" => Ok(TrafficFlowCongestionLevel::Congested),
        "black" => Ok(TrafficFlowCongestionLevel::Blocked),
        other => Err(SDKError::ResponseParsingFailure(format!(
            "unknown flow traffic bucket {other:?}"
        ))),
    }
}

#[cfg(test)]
mod tests {
    use super::{map_traffic_bucket_to_congestion_level, parse_flow_payload, select_flow_view};
    use geospatial_types::traffic::TrafficFlowCongestionLevel;
    use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};

    fn fixture(name: &str) -> serde_json::Value {
        let fixture_path = format!(
            "{}/../../fixtures/mapquest/{name}",
            env!("CARGO_MANIFEST_DIR")
        );
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    fn denver_bounding_box() -> BoundingBox {
        BoundingBox::from_corners(
            GeographicCoordinate::from_degrees(39.52, -105.25).unwrap(),
            GeographicCoordinate::from_degrees(39.95, -104.71).unwrap(),
        )
        .unwrap()
    }

    #[test]
    fn parses_recorded_new_york_flow() {
        let payload = fixture("traffic_flow_new_york.json");
        let flow = parse_flow_payload(&payload).unwrap();
        assert_eq!(flow.len(), 4);
        let mut levels = flow.iter().map(|data| data.congestion_level);
        assert_eq!(levels.next(), Some(TrafficFlowCongestionLevel::FreeFlow));
        assert_eq!(levels.next(), Some(TrafficFlowCongestionLevel::Slow));
        assert_eq!(levels.next(), Some(TrafficFlowCongestionLevel::Congested));
        assert_eq!(levels.next(), Some(TrafficFlowCongestionLevel::Blocked));
        assert!(levels.next().is_none());
        let first = &flow[0];
        assert_eq!(first.shape_coordinates.len(), 23);
        assert!((first.shape_coordinates[0].latitude - 40.63701).abs() < 1e-9);
        assert!((first.shape_coordinates[0].longitude - (-74.01926)).abs() < 1e-9);
        assert_eq!(first.current_speed_kilometers_per_hour, None);
        assert_eq!(first.free_flow_speed_kilometers_per_hour, None);
    }

    #[test]
    fn unknown_bucket_rejects_the_payload() {
        assert!(map_traffic_bucket_to_congestion_level("purple").is_err());
        let payload = serde_json::json!({
            "features": [{
                "properties": {"traffic": "purple"},
                "geometry": {"coordinates": [[[-73.99, 40.73]]]}
            }]
        });
        assert!(matches!(
            parse_flow_payload(&payload),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }

    #[test]
    fn view_selection_covers_the_box_without_exceeding_the_area_limit() {
        // Denver spans 0.43° lat / 0.54° lng: the most detailed zoom that
        // covers it is level 11 with an 815 px square (level 12 needs 1630
        // px, over the 1600 px cap).
        let denver_view = select_flow_view(&denver_bounding_box()).unwrap();
        assert_eq!(denver_view.zoom_level, 11);
        assert!((denver_view.map_scale - 216_671.0).abs() < 1.0);
        assert_eq!(denver_view.side_pixels, 815);
        // A 0.005° box fits in the most detailed, documented zoom level 18.
        let small_box = BoundingBox::from_corners(
            GeographicCoordinate::from_degrees(40.73, -73.99).unwrap(),
            GeographicCoordinate::from_degrees(40.735, -73.985).unwrap(),
        )
        .unwrap();
        let small_view = select_flow_view(&small_box).unwrap();
        assert_eq!(small_view.zoom_level, 18);
        // A 0.97°-by-1.0° box trips the one-degree longitude area limit.
        let oversized_box = BoundingBox::from_corners(
            GeographicCoordinate::from_degrees(39.0, -105.0).unwrap(),
            GeographicCoordinate::from_degrees(39.97, -104.0).unwrap(),
        )
        .unwrap();
        assert!(matches!(
            select_flow_view(&oversized_box),
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }
}
