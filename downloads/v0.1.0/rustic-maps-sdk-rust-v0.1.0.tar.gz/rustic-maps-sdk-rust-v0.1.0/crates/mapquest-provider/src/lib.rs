//! MapQuest implementations of every contract in [`geospatial_traits`]
//! supported by the documented MapQuest platform
//! (`developer.mapquest.com/documentation/`):
//!
//! - Directions API v2: route + route matrix ([`directions`])
//! - Geocoding API v1: address + reverse ([`geocoding`])
//! - Search Ahead API v3: prediction ([`search`])
//! - Traffic API v2: incidents ([`traffic`]) + JSON flow ([`traffic_flow`])
//! - Tiles API: raster tiles ([`tiles`])
//!
//! The Elevation API is retired (absent from the current documentation), so
//! [`geospatial_traits::ElevationProvider`] has no MapQuest implementation
//! and its registry slot stays unconfigured.
//!
//! All calls share one rate-limited HTTP client ([`client`]) with key
//! injection, bounded idempotent-GET retries and the `info.statuscode` ->
//! [`SDKError`] mapping ([`error_mapping`]).

pub mod client;
pub mod directions;
pub mod error_mapping;
pub mod geocoding;
pub mod http;
pub mod json_coordinates;
pub mod search;
pub mod tiles;
pub mod traffic;
pub mod traffic_flow;

pub use client::{MapQuestProviderClient, MapQuestProviderConfiguration};
pub use directions::{MapQuestDistanceMatrixProvider, MapQuestRoutingProvider};
pub use geocoding::MapQuestGeocodingProvider;
pub use search::MapQuestSearchPlaceProvider;
pub use tiles::MapQuestRasterTileProvider;
pub use traffic::MapQuestTrafficIncidentProvider;
pub use traffic_flow::MapQuestTrafficFlowProvider;
