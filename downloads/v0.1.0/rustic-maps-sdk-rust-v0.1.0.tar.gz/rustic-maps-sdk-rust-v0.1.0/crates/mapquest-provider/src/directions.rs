//! MapQuest Directions API v2 implementations: point-to-point routing and
//! the route matrix, both documented at
//! `developer.mapquest.com/documentation/directions/`.

use crate::client::MapQuestProviderClient;
use async_trait::async_trait;
use geospatial_traits::{DistanceMatrixProvider, RoutingProvider};
use geospatial_types::SDKError;
use geospatial_types::route::{
    DistanceMatrix, DistanceMatrixEntry, ManeuverType, RouteData, RouteLeg, RouteOptions,
    RouteStep, RouteStrategy, TransportationMode, TurnDirection, UnitSystem,
};
use geospatial_types::{BoundingBox, GeographicCoordinate};
use serde_json::Value;
use std::sync::Arc;

/// Miles-to-meters conversion for imperial unit rows.
const METERS_PER_MILE: f64 = 1609.344;

/// Routing through the MapQuest Directions API v2 route endpoint.
pub struct MapQuestRoutingProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestRoutingProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

#[async_trait]
impl RoutingProvider for MapQuestRoutingProvider {
    async fn calculate_route(
        &self,
        waypoints: &[GeographicCoordinate],
        route_options: &RouteOptions,
    ) -> Result<RouteData, SDKError> {
        if waypoints.len() < 2 {
            return Err(SDKError::InvalidCoordinateInput(
                "a route needs at least two waypoints".to_string(),
            ));
        }
        let mut query_pairs = vec![
            ("from".to_string(), coordinate_query_text(&waypoints[0])),
            (
                "unit".to_string(),
                unit_query_text(route_options.unit_system),
            ),
            (
                "routeType".to_string(),
                route_type_query_text(
                    route_options.transportation_mode,
                    route_options.route_strategy,
                ),
            ),
            ("shapeFormat".to_string(), "raw".to_string()),
            ("fullShape".to_string(), "true".to_string()),
            ("narrativeType".to_string(), "text".to_string()),
        ];
        let avoid_list = avoid_query_text(route_options);
        if !avoid_list.is_empty() {
            query_pairs.push(("avoids".to_string(), avoid_list));
        }
        for waypoint in &waypoints[1..] {
            query_pairs.push(("to".to_string(), coordinate_query_text(waypoint)));
        }
        let payload = self
            .provider_client
            .get_json("directions/v2/route", &query_pairs)
            .await?;
        parse_route_payload(&payload, route_options.unit_system)
    }
}

/// Matrix calculation through the MapQuest route matrix endpoint.
///
/// MapQuest computes all-to-all matrices only; a rectangular origins x
/// destinations request is sent as one all-to-all call over the union of
/// both lists and the wanted cells are filtered out of the reply.
pub struct MapQuestDistanceMatrixProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestDistanceMatrixProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

#[async_trait]
impl DistanceMatrixProvider for MapQuestDistanceMatrixProvider {
    async fn calculate_distance_matrix(
        &self,
        origins: &[GeographicCoordinate],
        destinations: &[GeographicCoordinate],
        transportation_mode: TransportationMode,
    ) -> Result<DistanceMatrix, SDKError> {
        if origins.is_empty() || destinations.is_empty() {
            return Err(SDKError::InvalidCoordinateInput(
                "a distance matrix needs at least one origin and one destination".to_string(),
            ));
        }
        let mut locations = Vec::with_capacity(origins.len() + destinations.len());
        locations.extend(
            origins
                .iter()
                .chain(destinations.iter())
                .map(crate::json_coordinates::coordinate_to_request_value),
        );
        let request_body = serde_json::json!({
            "locations": locations,
            // Verified live: the matrix mode lives under `options`; a
            // top-level `allToAll` is ignored by the service.
            "options": {
                "allToAll": true,
                "unit": unit_query_text_for_options(UnitSystem::Metric),
                // The matrix contract fixes no strategy; keep the default.
                "routeType": route_type_query_text(transportation_mode, RouteStrategy::Fastest),
            }
        });
        let payload = self
            .provider_client
            .post_json("directions/v2/routematrix", &[], &request_body)
            .await?;
        parse_matrix_payload(&payload, origins.len(), destinations.len())
    }
}

fn coordinate_query_text(coordinate: &GeographicCoordinate) -> String {
    format!("{},{}", coordinate.latitude, coordinate.longitude)
}

fn unit_query_text(unit_system: UnitSystem) -> String {
    unit_query_text_for_options(unit_system)
}

fn unit_query_text_for_options(unit_system: UnitSystem) -> String {
    match unit_system {
        UnitSystem::Metric => "k",
        UnitSystem::Imperial => "m",
    }
    .to_string()
}

fn route_type_query_text(
    transportation_mode: TransportationMode,
    route_strategy: RouteStrategy,
) -> String {
    match transportation_mode {
        // Only automobile mode has both a time-based and a distance-based
        // cost model; bicycle and pedestrian routing ignore the strategy.
        TransportationMode::Automobile => match route_strategy {
            RouteStrategy::Fastest => "fastest",
            RouteStrategy::Shortest => "shortest",
        },
        TransportationMode::Bicycle => "bicycle",
        TransportationMode::Pedestrian => "pedestrian",
    }
    .to_string()
}

fn avoid_query_text(route_options: &RouteOptions) -> String {
    let avoid_options = &route_options.avoid_options;
    let mut avoid_features = Vec::new();
    if avoid_options.toll_roads {
        avoid_features.push("Toll Road");
    }
    if avoid_options.limited_access_highways {
        avoid_features.push("Limited Access");
    }
    if avoid_options.ferries {
        avoid_features.push("Ferry");
    }
    if avoid_options.unpaved_roads {
        avoid_features.push("Unpaved");
    }
    avoid_features.join(",")
}

fn distance_to_meters(distance_value: f64, unit_system: UnitSystem) -> f64 {
    match unit_system {
        UnitSystem::Metric => distance_value * 1000.0,
        UnitSystem::Imperial => distance_value * METERS_PER_MILE,
    }
}

/// Parses a documented `route` payload into a [`RouteData`], converting the
/// unit-dependent distances into meters and splitting the shared shape by
/// `shape.maneuverIndexes`.
pub fn parse_route_payload(
    payload: &Value,
    unit_system: UnitSystem,
) -> Result<RouteData, SDKError> {
    let route = payload.get("route").ok_or_else(|| {
        SDKError::ResponseParsingFailure("route payload lacks the route object".to_string())
    })?;
    let shape_points = route
        .pointer("/shape/shapePoints")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("route payload lacks shapePoints".to_string())
        })?;
    let route_shape = parse_shape_points(shape_points)?;
    let maneuver_indexes = route
        .pointer("/shape/maneuverIndexes")
        .and_then(Value::as_array)
        .map(|values| {
            values
                .iter()
                .map(|value| value.as_u64().unwrap_or_default() as usize)
                .collect::<Vec<usize>>()
        })
        .unwrap_or_default();

    let legs = route
        .get("legs")
        .and_then(Value::as_array)
        .ok_or_else(|| SDKError::ResponseParsingFailure("route payload lacks legs".to_string()))?;
    let mut parsed_legs = Vec::with_capacity(legs.len());
    let mut maneuver_offset_across_legs = 0usize;
    for leg in legs {
        let maneuvers = leg
            .get("maneuvers")
            .and_then(Value::as_array)
            .ok_or_else(|| {
                SDKError::ResponseParsingFailure("route leg lacks maneuvers".to_string())
            })?;
        let mut steps = Vec::with_capacity(maneuvers.len());
        for (maneuver_index_in_leg, maneuver) in maneuvers.iter().enumerate() {
            let global_maneuver_index = maneuver_offset_across_legs + maneuver_index_in_leg;
            steps.push(parse_maneuver_step(
                maneuver,
                maneuvers.get(maneuver_index_in_leg + 1),
                global_maneuver_index,
                &maneuver_indexes,
                &route_shape,
                unit_system,
            )?);
        }
        maneuver_offset_across_legs += maneuvers.len();
        parsed_legs.push(RouteLeg {
            distance_meters: distance_to_meters(
                leg.get("distance")
                    .and_then(Value::as_f64)
                    .unwrap_or_default(),
                unit_system,
            ),
            duration_seconds: leg.get("time").and_then(Value::as_f64).unwrap_or_default(),
            steps,
        });
    }

    // MapQuest reports `ul` (north-west: max lat, min lng) and `lr`
    // (south-east: min lat, max lng); the SDK box takes south-west and
    // north-east corners.
    let upper_left = route
        .pointer("/boundingBox/ul")
        .and_then(parse_lat_lng)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("route payload lacks boundingBox".to_string())
        })?;
    let lower_right = route
        .pointer("/boundingBox/lr")
        .and_then(parse_lat_lng)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("route payload lacks boundingBox".to_string())
        })?;
    let south_west =
        GeographicCoordinate::from_degrees(lower_right.latitude, upper_left.longitude)?;
    let north_east =
        GeographicCoordinate::from_degrees(upper_left.latitude, lower_right.longitude)?;

    Ok(RouteData {
        distance_meters: distance_to_meters(
            route
                .get("distance")
                .and_then(Value::as_f64)
                .unwrap_or_default(),
            unit_system,
        ),
        duration_seconds: route
            .get("time")
            .and_then(Value::as_f64)
            .unwrap_or_default(),
        bounding_box: BoundingBox::from_corners(south_west, north_east)?,
        legs: parsed_legs,
    })
}

/// Parses one MapQuest maneuver into the step whose shape runs from that
/// maneuver's first shape point to the next maneuver's start.
///
/// # Step text is end-anchored (the standard-map banner convention)
///
/// A MapQuest maneuver's narrative describes the action the driver takes AT
/// that maneuver's point, while a step's shape spans from one maneuver point
/// to the next and the banner counts down to a step's *end* — the NEXT
/// maneuver point, the very anchor the frozen contract's
/// `TripProgress::distance_to_next_maneuver_meters` displays. Head-anchoring
/// the narrative (this maneuver's text onto this step) would read stale the
/// moment a junction is crossed: while traversing a step the banner still
/// narrates the turn already performed, and the maneuver being approached is
/// named only by the then-line — so the approach speech never speaks it.
/// Standard-map banners therefore show one maneuver ahead while the driver
/// traverses a step, so each step's text carries the narrative of the
/// *following* maneuver (the one at the step's end): "Turn left onto X"
/// belongs to the step whose shape ends at that junction. A corollary keeps
/// the text honest: MapQuest narratives close with "Go for N" — the distance
/// until the *next* maneuver — which is exactly the following step's
/// declared distance, so the suffix lands on the step it describes.
/// The leg's final maneuver has no following maneuver; its own narrative
/// (the arrive line) stays, so the last step carries the honest arrival
/// text. The head maneuver's depart narrative is thereby never surfaced as
/// step text: the trip opens on the first turn's countdown, as Google and
/// OSRM banners do.
fn parse_maneuver_step(
    maneuver: &Value,
    following_maneuver: Option<&Value>,
    global_maneuver_index: usize,
    maneuver_indexes: &[usize],
    route_shape: &[GeographicCoordinate],
    unit_system: UnitSystem,
) -> Result<RouteStep, SDKError> {
    let narrative = maneuver
        .get("narrative")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    let following_narrative = following_maneuver
        .and_then(|following_maneuver| following_maneuver.get("narrative"))
        .and_then(Value::as_str)
        .map(str::to_string);
    // The end-anchored step text (see the module-level convention above);
    // an absent or empty following narrative keeps the step's own narrative
    // so no step ever loses an authored text outright.
    let step_text = following_narrative
        .filter(|step_text| !step_text.is_empty())
        .unwrap_or(narrative.clone());
    let turn_type = maneuver
        .get("turnType")
        .and_then(Value::as_i64)
        .ok_or_else(|| SDKError::ResponseParsingFailure("maneuver lacks turnType".to_string()))?;
    let maneuver_type = if global_maneuver_index == 0 {
        ManeuverType::Departure
    } else if global_maneuver_index + 1 == maneuver_indexes.len() {
        ManeuverType::Arrival
    } else {
        map_turn_type_to_maneuver_type(turn_type, &narrative)
    };
    Ok(RouteStep {
        distance_meters: distance_to_meters(
            maneuver
                .get("distance")
                .and_then(Value::as_f64)
                .unwrap_or_default(),
            unit_system,
        ),
        duration_seconds: maneuver
            .get("time")
            .and_then(Value::as_f64)
            .unwrap_or_default(),
        maneuver_type,
        instruction_display_text: step_text.clone(),
        // MapQuest produces a single narrative in text mode; the speech
        // string starts from the end-anchored step text and is refined by
        // the navigation engine in milestone M6.
        instruction_speech_text: step_text,
        shape: maneuver_shape_slice(global_maneuver_index, maneuver_indexes, route_shape),
        // The Directions API v2 payload carries no lane guidance records;
        // the field stays empty until a provider supplies lanes (M6+).
        lane_guidances: Vec::new(),
    })
}

/// Splits the route-wide shape at maneuver boundaries; the step shape runs
/// from this maneuver's first shape point to the next maneuver's start.
fn maneuver_shape_slice(
    global_maneuver_index: usize,
    maneuver_indexes: &[usize],
    route_shape: &[GeographicCoordinate],
) -> Vec<GeographicCoordinate> {
    if global_maneuver_index >= maneuver_indexes.len() {
        return Vec::new();
    }
    let start_index = maneuver_indexes[global_maneuver_index].min(route_shape.len());
    let end_index = if global_maneuver_index + 1 < maneuver_indexes.len() {
        maneuver_indexes[global_maneuver_index + 1].min(route_shape.len())
    } else {
        route_shape.len()
    };
    route_shape[start_index..end_index.max(start_index)].to_vec()
}

/// Maps the documented Directions API `turnType` enumeration
/// (developer.mapquest.com/documentation/directions/route/) onto
/// [`ManeuverType`]. `-1` (documented arrival marker) maps to [`ManeuverType::Arrival`].
pub fn map_turn_type_to_maneuver_type(turn_type: i64, narrative: &str) -> ManeuverType {
    match turn_type {
        -1 => ManeuverType::Arrival,
        0 => ManeuverType::Turn(TurnDirection::Straight),
        1 => ManeuverType::Turn(TurnDirection::SlightRight),
        2 => ManeuverType::Turn(TurnDirection::Right),
        3 => ManeuverType::Turn(TurnDirection::SharpRight),
        4 | 8 | 9 => ManeuverType::Turn(TurnDirection::UTurn),
        5 => ManeuverType::Turn(TurnDirection::SharpLeft),
        6 => ManeuverType::Turn(TurnDirection::Left),
        7 => ManeuverType::Turn(TurnDirection::SlightLeft),
        10 | 11 => ManeuverType::Merge,
        12 | 13 => ManeuverType::OnRamp,
        14 | 15 => ManeuverType::OffRamp,
        16..=18 => ManeuverType::Fork,
        24..=29 => ManeuverType::Roundabout(extract_roundabout_exit_index(narrative).unwrap_or(1)),
        _ => ManeuverType::Continue,
    }
}

/// MapQuest reports the roundabout traversal but not the exit index as data;
/// the ordinal is read from the narrative ("take the 2nd exit").
fn extract_roundabout_exit_index(narrative: &str) -> Option<u8> {
    let lowercase = narrative.to_lowercase();
    let exit_position = lowercase.find("exit")?;
    // The ordinal precedes the word ("take the 3rd exit onto...").
    let prefix = &lowercase[..exit_position];
    let digits_end = prefix.rfind(|character: char| character.is_ascii_digit())?;
    let digits_start = prefix[..=digits_end]
        .rfind(|character: char| !character.is_ascii_digit())
        .map_or(0, |position| position + 1);
    prefix[digits_start..=digits_end].parse::<u8>().ok()
}

fn parse_shape_points(shape_points: &[Value]) -> Result<Vec<GeographicCoordinate>, SDKError> {
    if !shape_points.len().is_multiple_of(2) {
        return Err(SDKError::ResponseParsingFailure(
            "shapePoints has an odd element count and cannot form lat/lng pairs".to_string(),
        ));
    }
    shape_points
        .chunks_exact(2)
        .map(|pair| {
            GeographicCoordinate::from_degrees(
                pair[0].as_f64().ok_or_else(|| {
                    SDKError::ResponseParsingFailure(
                        "shape point latitude is not numeric".to_string(),
                    )
                })?,
                pair[1].as_f64().ok_or_else(|| {
                    SDKError::ResponseParsingFailure(
                        "shape point longitude is not numeric".to_string(),
                    )
                })?,
            )
        })
        .collect()
}

fn parse_lat_lng(lat_lng: &Value) -> Option<GeographicCoordinate> {
    let latitude = lat_lng.get("lat")?.as_f64()?;
    let longitude = lat_lng.get("lng")?.as_f64()?;
    GeographicCoordinate::from_degrees(latitude, longitude).ok()
}

/// Parses the route matrix reply: `distance` and `time` are flat row-major
/// arrays over the concatenated origin+destination location list, distances
/// in the requested unit. Unroutable cells arrive as `null` and are skipped.
pub fn parse_matrix_payload(
    payload: &Value,
    origin_count: usize,
    destination_count: usize,
) -> Result<DistanceMatrix, SDKError> {
    let total_location_count = origin_count + destination_count;
    let distances = payload
        .get("distance")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("matrix payload lacks distance".to_string())
        })?;
    let times = payload
        .get("time")
        .and_then(Value::as_array)
        .ok_or_else(|| SDKError::ResponseParsingFailure("matrix payload lacks time".to_string()))?;
    if distances.len() != total_location_count || times.len() != total_location_count {
        return Err(SDKError::ResponseParsingFailure(format!(
            "matrix has {}x{} rows but the request needs {}x{}",
            distances.len(),
            times.len(),
            total_location_count,
            total_location_count
        )));
    }
    let mut entries = Vec::with_capacity(origin_count * destination_count);
    for (global_origin_index, distance_row) in distances.iter().enumerate().take(origin_count) {
        let time_row = times
            .get(global_origin_index)
            .and_then(Value::as_array)
            .ok_or_else(|| {
                SDKError::ResponseParsingFailure(
                    "matrix time row is not a nested array".to_string(),
                )
            })?;
        for destination_offset in 0..destination_count {
            let global_destination_index = origin_count + destination_offset;
            let (Some(distance_value), Some(time_value)) = (
                distance_row
                    .get(global_destination_index)
                    .and_then(Value::as_f64),
                time_row
                    .get(global_destination_index)
                    .and_then(Value::as_f64),
            ) else {
                continue;
            };
            entries.push(DistanceMatrixEntry {
                origin_index: global_origin_index as u32,
                destination_index: destination_offset as u32,
                distance_meters: distance_to_meters(distance_value, UnitSystem::Metric),
                duration_seconds: time_value,
            });
        }
    }
    Ok(DistanceMatrix { entries })
}

#[cfg(test)]
mod tests {
    use super::{
        extract_roundabout_exit_index, map_turn_type_to_maneuver_type, parse_matrix_payload,
        parse_route_payload, route_type_query_text,
    };
    use crate::json_coordinates::coordinate_to_request_value;
    use geospatial_types::route::{
        ManeuverType, RouteStrategy, TransportationMode, TurnDirection, UnitSystem,
    };
    use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError};
    use serde_json::Value;
    use serde_json::json;

    fn fixture(name: &str) -> serde_json::Value {
        let fixture_path = format!(
            "{}/../../fixtures/mapquest/{name}",
            env!("CARGO_MANIFEST_DIR")
        );
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    #[test]
    fn parses_recorded_two_waypoint_route() {
        let payload = fixture("directions_route_two_waypoints.json");
        let route_data = parse_route_payload(&payload, UnitSystem::Metric).unwrap();
        assert_eq!(route_data.legs.len(), 1);
        let first_leg = &route_data.legs[0];
        assert_eq!(first_leg.steps.len(), 6);
        assert!(matches!(
            first_leg.steps[0].maneuver_type,
            ManeuverType::Departure
        ));
        assert!(matches!(
            first_leg.steps[5].maneuver_type,
            ManeuverType::Arrival
        ));
        assert!(matches!(
            first_leg.steps[1].maneuver_type,
            ManeuverType::Turn(TurnDirection::Left)
        ));
        assert!(matches!(
            first_leg.steps[3].maneuver_type,
            ManeuverType::Turn(TurnDirection::Right)
        ));
        assert!(matches!(
            first_leg.steps[4].maneuver_type,
            ManeuverType::Turn(TurnDirection::Right)
        ));
        // 1.7 km recorded route distance from 1315 10th St to Front St.
        assert!((route_data.distance_meters - 1700.0).abs() < 50.0);
        assert!(route_data.distance_meters > 0.0);
        // Recorded bbox: ul 38.5806/-121.5078, lr 38.57693/-121.49439.
        assert!(
            route_data
                .bounding_box
                .contains_coordinate(&GeographicCoordinate::from_degrees(38.579, -121.5).unwrap())
        );
        // Every step carries non-empty recorded shape geometry.
        assert!(
            first_leg.steps.iter().all(|step| !step.shape.is_empty()
                || matches!(step.maneuver_type, ManeuverType::Arrival))
        );
    }

    #[test]
    fn step_texts_carry_the_maneuver_at_the_step_end() {
        // The banner-anchoring convention: a step's text is the narrative of
        // the maneuver at the step's end (the following maneuver), never the
        // step's own head maneuver — the banner shows one maneuver ahead
        // while the countdown points at the step's end. The recorded
        // fixture's first step therefore carries the first turn's narrative
        // (the head maneuver's "Head toward..." depart line is no step text)
        // and the final step keeps the arrival's.
        let payload = fixture("directions_route_two_waypoints.json");
        let recorded_narratives: Vec<String> = payload
            .pointer("/route/legs/0/maneuvers")
            .and_then(Value::as_array)
            .unwrap()
            .iter()
            .map(|maneuver| {
                maneuver
                    .get("narrative")
                    .and_then(Value::as_str)
                    .unwrap_or_default()
                    .to_string()
            })
            .collect();
        let route_data = parse_route_payload(&payload, UnitSystem::Metric).unwrap();
        let steps = &route_data.legs[0].steps;
        assert_eq!(
            steps.len(),
            recorded_narratives.len(),
            "the recorded fixture keeps one step per mapped maneuver"
        );
        for (step_index, step) in steps.iter().enumerate() {
            let expected_text = recorded_narratives
                .get(step_index + 1)
                .unwrap_or(&recorded_narratives[step_index]);
            assert_eq!(&step.instruction_display_text, expected_text);
            assert_eq!(&step.instruction_speech_text, expected_text);
        }
        assert_eq!(
            steps[0].instruction_display_text,
            "Turn left onto L St. Go for 864 m."
        );
        assert_eq!(steps[5].instruction_display_text, "Arrive at Front St.");
    }

    #[test]
    fn parses_recorded_three_location_matrix() {
        let payload = fixture("routematrix_three_locations_unit_k.json");
        let matrix = parse_matrix_payload(&payload, 1, 2).unwrap();
        assert_eq!(matrix.entries.len(), 2);
        let entry_to_first_destination = &matrix.entries[0];
        assert_eq!(entry_to_first_destination.origin_index, 0);
        assert_eq!(entry_to_first_destination.destination_index, 0);
        assert!((entry_to_first_destination.distance_meters - 1700.0).abs() < 100.0);
        assert!((entry_to_first_destination.duration_seconds - 235.0).abs() < 1.0);
        let entry_to_second_destination = &matrix.entries[1];
        assert_eq!(entry_to_second_destination.destination_index, 1);
        assert!((entry_to_second_destination.distance_meters - 2600.0).abs() < 100.0);
        assert!((entry_to_second_destination.duration_seconds - 320.0).abs() < 1.0);
    }

    #[test]
    fn matrix_skips_null_cells() {
        let payload = json!({
            "distance": [[0, 1.5, 2.5], [6.0, 7.0, 8.0], [9.0, 10.0, 11.0]],
            "time": [[5, null, 20], [30, 40, 50], [60, 70, 80]]
        });
        let matrix = parse_matrix_payload(&payload, 1, 2).unwrap();
        assert_eq!(matrix.entries.len(), 1);
        assert_eq!(matrix.entries[0].destination_index, 1);
        assert!((matrix.entries[0].distance_meters - 2500.0).abs() < 1.0);
    }

    #[test]
    fn matrix_size_mismatch_is_a_parsing_failure() {
        let payload = json!({"distance": [[0, 1]], "time": [[0, 1], [0, 1]]});
        assert!(matches!(
            parse_matrix_payload(&payload, 1, 2),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }

    #[test]
    fn documented_turn_type_table_maps_completely() {
        assert_eq!(
            map_turn_type_to_maneuver_type(0, ""),
            ManeuverType::Turn(TurnDirection::Straight)
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(1, ""),
            ManeuverType::Turn(TurnDirection::SlightRight)
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(3, ""),
            ManeuverType::Turn(TurnDirection::SharpRight)
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(4, ""),
            ManeuverType::Turn(TurnDirection::UTurn)
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(6, ""),
            ManeuverType::Turn(TurnDirection::Left)
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(7, ""),
            ManeuverType::Turn(TurnDirection::SlightLeft)
        );
        assert_eq!(map_turn_type_to_maneuver_type(10, ""), ManeuverType::Merge);
        assert_eq!(map_turn_type_to_maneuver_type(12, ""), ManeuverType::OnRamp);
        assert_eq!(
            map_turn_type_to_maneuver_type(14, ""),
            ManeuverType::OffRamp
        );
        assert_eq!(map_turn_type_to_maneuver_type(16, ""), ManeuverType::Fork);
        assert_eq!(
            map_turn_type_to_maneuver_type(-1, ""),
            ManeuverType::Arrival
        );
        assert_eq!(
            map_turn_type_to_maneuver_type(19, ""),
            ManeuverType::Continue
        );
    }

    #[test]
    fn roundabout_exit_index_is_read_from_the_narrative() {
        assert_eq!(
            map_turn_type_to_maneuver_type(24, "At the roundabout take the 3rd exit onto Broadway"),
            ManeuverType::Roundabout(3)
        );
        assert_eq!(extract_roundabout_exit_index("take the 2nd exit"), Some(2));
        assert_eq!(extract_roundabout_exit_index("no ordinal here"), None);
        assert_eq!(
            map_turn_type_to_maneuver_type(25, "Attrafficcircle exit unspecified"),
            ManeuverType::Roundabout(1)
        );
    }

    #[test]
    fn route_type_honors_the_strategy_for_automobile_mode() {
        assert_eq!(
            route_type_query_text(TransportationMode::Automobile, RouteStrategy::Fastest),
            "fastest"
        );
        assert_eq!(
            route_type_query_text(TransportationMode::Automobile, RouteStrategy::Shortest),
            "shortest"
        );
    }

    #[test]
    fn strategy_is_ignored_outside_automobile_mode() {
        assert_eq!(
            route_type_query_text(TransportationMode::Bicycle, RouteStrategy::Shortest),
            "bicycle"
        );
        assert_eq!(
            route_type_query_text(TransportationMode::Pedestrian, RouteStrategy::Fastest),
            "pedestrian"
        );
    }

    #[test]
    fn invalid_location_envelope_surfaces_as_provider_rejection() {
        let payload = fixture("directions_route_invalid_coordinates.json");
        let error = crate::error_mapping::validate_info_envelope(&payload).unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    }

    #[test]
    fn recorded_coordinates_serialize_for_requests() {
        let coordinate = GeographicCoordinate::from_degrees(38.57657, -121.4936).unwrap();
        assert_eq!(
            coordinate_to_request_value(&coordinate),
            json!({"latLng": {"lat": 38.57657, "lng": -121.4936}})
        );
        let _ = BoundingBox::from_corners;
    }
}
