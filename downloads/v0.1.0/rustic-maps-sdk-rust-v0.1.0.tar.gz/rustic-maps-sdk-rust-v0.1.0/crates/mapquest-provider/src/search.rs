//! MapQuest Search Ahead API v3 implementation (prediction endpoint).

use crate::client::MapQuestProviderClient;
use async_trait::async_trait;
use geospatial_traits::SearchPlaceProvider;
use geospatial_types::place::GeocodeQuality;
use geospatial_types::{BoundingBox, GeographicCoordinate, PlaceResult, SDKError};
use serde_json::Value;
use std::sync::Arc;

/// Collections queried on every prediction call; the Search Ahead API
/// restricts results to the comma-delimited collection list.
const QUERY_COLLECTIONS: &str = "address,adminArea,airport,category,franchise,poi";

/// Autocomplete uses a short candidate list while typing.
const AUTOCOMPLETE_LIMIT: &str = "8";
/// Settled searches may use the documented maximum of 15 candidates.
const SEARCH_LIMIT: &str = "15";

/// Search against the MapQuest Search Ahead API v3 prediction endpoint.
///
/// Both trait methods address the same endpoint: autocomplete with a small
/// limit, settled search with the maximal limit. A boundary box is passed as
/// the documented `location` ranking center at the box's center (the
/// endpoint supports a single ranking point, not an area).
pub struct MapQuestSearchPlaceProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestSearchPlaceProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

#[async_trait]
impl SearchPlaceProvider for MapQuestSearchPlaceProvider {
    async fn search_autocomplete(
        &self,
        query_text: &str,
        search_boundary: Option<BoundingBox>,
    ) -> Result<Vec<PlaceResult>, SDKError> {
        self.run_prediction(query_text, search_boundary, AUTOCOMPLETE_LIMIT)
            .await
    }

    async fn search_places(
        &self,
        query_text: &str,
        search_boundary: Option<BoundingBox>,
    ) -> Result<Vec<PlaceResult>, SDKError> {
        self.run_prediction(query_text, search_boundary, SEARCH_LIMIT)
            .await
    }
}

impl MapQuestSearchPlaceProvider {
    async fn run_prediction(
        &self,
        query_text: &str,
        search_boundary: Option<BoundingBox>,
        result_limit: &str,
    ) -> Result<Vec<PlaceResult>, SDKError> {
        if query_text.trim().is_empty() {
            return Err(SDKError::InvalidCoordinateInput(
                "search query text must not be empty".to_string(),
            ));
        }
        let mut query_pairs = vec![
            ("q".to_string(), query_text.to_string()),
            ("collection".to_string(), QUERY_COLLECTIONS.to_string()),
            ("limit".to_string(), result_limit.to_string()),
        ];
        if let Some(bounding_box) = search_boundary {
            let ranking_center = bounding_box_center(&bounding_box)?;
            // Documented format: longitude, latitude.
            query_pairs.push((
                "location".to_string(),
                format!("{},{}", ranking_center.longitude, ranking_center.latitude),
            ));
        }
        let payload = self
            .provider_client
            .get_json("search/v3/prediction", &query_pairs)
            .await?;
        parse_prediction_payload(&payload)
    }
}

fn bounding_box_center(bounding_box: &BoundingBox) -> Result<GeographicCoordinate, SDKError> {
    GeographicCoordinate::from_degrees(
        (bounding_box.south_west.latitude + bounding_box.north_east.latitude) / 2.0,
        (bounding_box.south_west.longitude + bounding_box.north_east.longitude) / 2.0,
    )
}

/// Parses the `results[]` GeoJSON features into vendor-neutral places.
pub fn parse_prediction_payload(payload: &Value) -> Result<Vec<PlaceResult>, SDKError> {
    let result_list = payload
        .get("results")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("prediction payload lacks results".to_string())
        })?;
    result_list.iter().map(parse_prediction_result).collect()
}

fn parse_prediction_result(result: &Value) -> Result<PlaceResult, SDKError> {
    let display_string = result
        .get("displayString")
        .and_then(Value::as_str)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("prediction result lacks displayString".to_string())
        })?;
    let longitude = result
        .pointer("/place/geometry/coordinates/0")
        .and_then(Value::as_f64)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure(
                "prediction result lacks place geometry coordinates".to_string(),
            )
        })?;
    let latitude = result
        .pointer("/place/geometry/coordinates/1")
        .and_then(Value::as_f64)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure(
                "prediction result lacks place geometry coordinates".to_string(),
            )
        })?;
    let coordinate = GeographicCoordinate::from_degrees(latitude, longitude)?;
    let record_type = result
        .get("recordType")
        .and_then(Value::as_str)
        .unwrap_or_default();
    Ok(PlaceResult {
        structured_address_text: display_string.to_string(),
        coordinate,
        geocode_quality: map_record_type_to_quality(record_type),
    })
}

fn map_record_type_to_quality(record_type: &str) -> GeocodeQuality {
    match record_type {
        "address" => GeocodeQuality::StreetAddress,
        "postalCode" => GeocodeQuality::PostalCode,
        "neighborhood" | "city" => GeocodeQuality::City,
        "county" => GeocodeQuality::County,
        "state" => GeocodeQuality::State,
        "country" => GeocodeQuality::Country,
        // airport, poi, category, franchise are point features.
        _ => GeocodeQuality::Point,
    }
}

#[cfg(test)]
mod tests {
    use super::{map_record_type_to_quality, parse_prediction_payload};
    use geospatial_types::place::GeocodeQuality;

    fn fixture(name: &str) -> serde_json::Value {
        let fixture_path = format!(
            "{}/../../fixtures/mapquest/{name}",
            env!("CARGO_MANIFEST_DIR")
        );
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    #[test]
    fn parses_recorded_denver_prediction() {
        let payload = fixture("search_prediction_denver.json");
        let places = parse_prediction_payload(&payload).unwrap();
        assert!(!places.is_empty());
        let airport = &places[0];
        assert!(airport.structured_address_text.contains("Denver"));
        assert!((airport.coordinate.longitude - (-104.67377)).abs() < 1e-9);
        assert!((airport.coordinate.latitude - 39.85352).abs() < 1e-9);
        assert_eq!(airport.geocode_quality, GeocodeQuality::Point);
    }

    #[test]
    fn record_type_vocabulary_maps_to_quality_levels() {
        assert_eq!(
            map_record_type_to_quality("address"),
            GeocodeQuality::StreetAddress
        );
        assert_eq!(
            map_record_type_to_quality("postalCode"),
            GeocodeQuality::PostalCode
        );
        assert_eq!(map_record_type_to_quality("city"), GeocodeQuality::City);
        assert_eq!(
            map_record_type_to_quality("franchise"),
            GeocodeQuality::Point
        );
    }
}
