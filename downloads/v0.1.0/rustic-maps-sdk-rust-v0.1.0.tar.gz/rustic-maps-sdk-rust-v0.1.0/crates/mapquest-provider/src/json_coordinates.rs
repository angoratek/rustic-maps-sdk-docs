//! Shared request encodings for coordinates and bounding boxes.

use geospatial_types::{BoundingBox, GeographicCoordinate};
use serde_json::{Value, json};

/// Encodes a coordinate as a MapQuest `latLng` location object.
pub fn coordinate_to_request_value(coordinate: &GeographicCoordinate) -> Value {
    json!({"latLng": {"lat": coordinate.latitude, "lng": coordinate.longitude}})
}

/// Encodes a bounding box for the documented
/// `ul.lat,ul.lng,lr.lat,lr.lng` query format (north-west corner first).
pub fn bounding_box_to_query_text(bounding_box: &BoundingBox) -> String {
    // Documented order: upper-left (north-west) then lower-right (south-east).
    format!(
        "{},{},{},{}",
        bounding_box.north_east.latitude,
        bounding_box.south_west.longitude,
        bounding_box.south_west.latitude,
        bounding_box.north_east.longitude
    )
}

/// Encodes a coordinate for the documented `lat,lng` location query format.
pub fn coordinate_to_location_query_text(coordinate: &GeographicCoordinate) -> String {
    format!("{},{}", coordinate.latitude, coordinate.longitude)
}

#[cfg(test)]
mod tests {
    use super::{bounding_box_to_query_text, coordinate_to_request_value};
    use geospatial_types::{BoundingBox, GeographicCoordinate};
    use serde_json::json;

    #[test]
    fn encodes_shapes_for_documented_query_formats() {
        let coordinate = GeographicCoordinate::from_degrees(39.95, -105.25).unwrap();
        assert_eq!(
            coordinate_to_request_value(&coordinate),
            json!({"latLng": {"lat": 39.95, "lng": -105.25}})
        );
        let bounding_box = BoundingBox::from_corners(
            GeographicCoordinate::from_degrees(39.52, -105.25).unwrap(),
            GeographicCoordinate::from_degrees(39.95, -104.71).unwrap(),
        )
        .unwrap();
        assert_eq!(
            bounding_box_to_query_text(&bounding_box),
            "39.95,-105.25,39.52,-104.71"
        );
    }
}
