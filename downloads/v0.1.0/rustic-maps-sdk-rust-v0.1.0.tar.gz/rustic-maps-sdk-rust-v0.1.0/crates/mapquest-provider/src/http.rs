//! HTTP transport for MapQuest web services: key injection, bounded retries
//! for idempotent GETs, and typed error mapping. The byte transport itself is
//! the shared [`provider_transport`] seam, so the same request, retry and
//! error-mapping code runs natively (reqwest) and in the browser (fetch).

use crate::error_mapping::map_http_error_response;
use geospatial_types::SDKError;
use provider_transport::{
    HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpMethod, HttpRequest, HttpResponse, HttpTransport,
    ObservedTransport, RetryPolicy, default_transport, execute_idempotent_get,
};
use std::sync::Arc;
use url::Url;

/// Default base URL of the MapQuest web services platform.
pub const MAPQUEST_BASE_URL: &str = "https://www.mapquestapi.com";

/// Low-level JSON client against one MapQuest base URL.
pub struct MapQuestHttpClient {
    base_url: String,
    api_key: String,
    maximum_retry_attempts: u32,
    transport: Arc<dyn HttpTransport>,
}

impl MapQuestHttpClient {
    /// Builds a client with the target's default transport;
    /// `maximum_retry_attempts` applies to idempotent GETs only (one attempt
    /// plus this many retries on transient failures).
    pub fn new(
        base_url: String,
        api_key: String,
        maximum_retry_attempts: u32,
    ) -> Result<Self, SDKError> {
        Ok(Self {
            base_url,
            api_key,
            maximum_retry_attempts,
            transport: default_transport()?,
        })
    }

    /// Builds a client around an explicit transport (the browser registration
    /// path and tests use this seam; the request, retry and mapping code is
    /// identical whichever transport is supplied).
    pub fn with_transport(
        base_url: String,
        api_key: String,
        maximum_retry_attempts: u32,
        transport: Arc<dyn HttpTransport>,
    ) -> Self {
        Self {
            base_url,
            api_key,
            maximum_retry_attempts,
            transport,
        }
    }

    /// Performs a GET against `{base_url}/{path}` with the given query pairs
    /// plus the injected `key`, retrying transient failures in bounds.
    pub async fn get_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
        provider_contract: &str,
    ) -> Result<serde_json::Value, SDKError> {
        let request = self.build_request(HttpMethod::Get, path, query_pairs, None)?;
        let observed_transport = ObservedTransport::new(
            Arc::clone(&self.transport),
            provider_contract,
            crate::client::MAPQUEST_PROVIDER_KEY,
        );
        execute_idempotent_get(
            &observed_transport,
            &request,
            RetryPolicy::new(self.maximum_retry_attempts),
            interpret_json_response,
        )
        .await
    }

    /// Performs a POST with a JSON body against `{base_url}/{path}`. POSTs
    /// are not retried: the platform may have already processed a retry.
    pub async fn post_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
        request_body: &serde_json::Value,
        provider_contract: &str,
    ) -> Result<serde_json::Value, SDKError> {
        let request =
            self.build_request(HttpMethod::Post, path, query_pairs, Some(request_body))?;
        let observed_transport = ObservedTransport::new(
            Arc::clone(&self.transport),
            provider_contract,
            crate::client::MAPQUEST_PROVIDER_KEY,
        );
        let response = observed_transport
            .execute(request)
            .await
            .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
        interpret_json_response(response)
    }

    /// Performs an arbitrary request returning raw bytes (used by raster
    /// tiles). The raster path makes a single attempt, as it always has.
    pub async fn get_bytes(
        &self,
        path: &str,
        provider_contract: &str,
    ) -> Result<Vec<u8>, SDKError> {
        let request = self.build_request(HttpMethod::Get, path, &[], None)?;
        let observed_transport = ObservedTransport::new(
            Arc::clone(&self.transport),
            provider_contract,
            crate::client::MAPQUEST_PROVIDER_KEY,
        );
        execute_idempotent_get(
            &observed_transport,
            &request,
            RetryPolicy::new(0),
            interpret_bytes_response,
        )
        .await
    }

    /// Builds one request against `{base_url}/{path}`, adding the injected
    /// `key` and any caller query pairs, plus a JSON body for POSTs.
    fn build_request(
        &self,
        method: HttpMethod,
        path: &str,
        query_pairs: &[(String, String)],
        json_body: Option<&serde_json::Value>,
    ) -> Result<HttpRequest, SDKError> {
        let url = self.build_url(path, query_pairs)?;
        let mut request_headers: Vec<(String, String)> = Vec::new();
        let request_body = match json_body {
            Some(body) => {
                request_headers.push(("content-type".to_string(), "application/json".to_string()));
                Some(
                    serde_json::to_vec(body)
                        .map_err(|error| SDKError::ResponseParsingFailure(error.to_string()))?,
                )
            }
            None => None,
        };
        Ok(HttpRequest {
            method,
            url: url.to_string(),
            headers: request_headers,
            body: request_body,
        })
    }

    fn build_url(&self, path: &str, query_pairs: &[(String, String)]) -> Result<Url, SDKError> {
        let mut endpoint = Url::parse(&format!("{}/{path}", self.base_url.trim_end_matches('/')))
            .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
        {
            let mut query_pairs_mut = endpoint.query_pairs_mut();
            query_pairs_mut.append_pair("key", &self.api_key);
            for (name, value) in query_pairs {
                query_pairs_mut.append_pair(name, value);
            }
        }
        Ok(endpoint)
    }
}

/// Interprets one JSON response: a non-success status maps through the
/// MapQuest status vocabulary, anything else parses as the response body.
fn interpret_json_response(response: HttpResponse) -> Result<serde_json::Value, SDKError> {
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        let response_body_text = String::from_utf8_lossy(&response.body);
        return Err(map_http_error_response(
            response.status_code,
            &response_body_text,
        ));
    }
    serde_json::from_slice(&response.body)
        .map_err(|error| SDKError::ResponseParsingFailure(error.to_string()))
}

/// Interprets one binary response: a non-success status maps through the
/// MapQuest status vocabulary, anything else returns the raw bytes.
fn interpret_bytes_response(response: HttpResponse) -> Result<Vec<u8>, SDKError> {
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        let response_body_text = String::from_utf8_lossy(&response.body);
        return Err(map_http_error_response(
            response.status_code,
            &response_body_text,
        ));
    }
    Ok(response.body)
}

#[cfg(test)]
mod tests {
    use crate::error_mapping::map_http_error_response;
    use crate::http::MapQuestHttpClient;
    use geospatial_types::SDKError;
    use wiremock::matchers::{method, path, query_param};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    fn test_client(base_url: String) -> MapQuestHttpClient {
        MapQuestHttpClient::new(base_url, "test-key".to_string(), 2).unwrap()
    }

    #[tokio::test]
    async fn retries_transient_failures_until_success() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/geocoding/v1/address"))
            .and(query_param("key", "test-key"))
            .respond_with(ResponseTemplate::new(503))
            .up_to_n_times(1)
            .mount(&server)
            .await;
        Mock::given(method("GET"))
            .and(path("/geocoding/v1/address"))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
                "info": {"statuscode": 0, "messages": []},
                "results": []
            })))
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        let payload = client
            .get_json(
                "geocoding/v1/address",
                &[],
                crate::client::GEOCODING_CONTRACT_NAME,
            )
            .await
            .unwrap();
        assert_eq!(payload["info"]["statuscode"], 0);
    }

    #[tokio::test]
    async fn exhausts_bounded_retries_then_surfaces_network_failure() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(503))
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        assert!(matches!(
            client
                .get_json(
                    "geocoding/v1/address",
                    &[],
                    crate::client::GEOCODING_CONTRACT_NAME
                )
                .await,
            Err(SDKError::NetworkRequestFailed(_))
        ));
    }

    #[tokio::test]
    async fn http_401_surfaces_immediately_without_retry() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(
                ResponseTemplate::new(401)
                    .set_body_string("The AppKey submitted with this request is invalid."),
            )
            .expect(1)
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        let error = client
            .get_json(
                "geocoding/v1/address",
                &[],
                crate::client::GEOCODING_CONTRACT_NAME,
            )
            .await
            .unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
        server.verify().await;
    }

    #[test]
    fn transient_classification_matches_retry_policy() {
        use provider_transport::is_transient_error;
        assert!(is_transient_error(&SDKError::NetworkRequestFailed(
            "connection refused".to_string()
        )));
        assert!(is_transient_error(&SDKError::RateLimitExhausted));
        assert!(!is_transient_error(&map_http_error_response(403, "")));
        assert!(!is_transient_error(&SDKError::ResponseParsingFailure(
            "bad json".to_string()
        )));
    }
}
