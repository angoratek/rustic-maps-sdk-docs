//! MapQuest Geocoding API v1 implementation (address and reverse endpoints).

use crate::client::MapQuestProviderClient;
use async_trait::async_trait;
use geospatial_traits::GeocodingProvider;
use geospatial_types::SDKError;
use geospatial_types::place::GeocodeQuality;
use geospatial_types::{GeographicCoordinate, PlaceResult};
use serde_json::Value;
use std::sync::Arc;

/// Geocoding against the MapQuest Geocoding API v1.
pub struct MapQuestGeocodingProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestGeocodingProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

#[async_trait]
impl GeocodingProvider for MapQuestGeocodingProvider {
    async fn forward_geocode(&self, address_text: &str) -> Result<Vec<PlaceResult>, SDKError> {
        if address_text.trim().is_empty() {
            return Err(SDKError::InvalidCoordinateInput(
                "address text must not be empty".to_string(),
            ));
        }
        let query_pairs = vec![("location".to_string(), address_text.to_string())];
        let payload = self
            .provider_client
            .get_json(
                "geocoding/v1/address",
                &query_pairs,
                crate::client::GEOCODING_CONTRACT_NAME,
            )
            .await?;
        parse_geocoding_payload(&payload)
    }

    async fn reverse_geocode(
        &self,
        coordinate: &GeographicCoordinate,
    ) -> Result<Vec<PlaceResult>, SDKError> {
        let query_pairs = vec![(
            "location".to_string(),
            format!("{},{}", coordinate.latitude, coordinate.longitude),
        )];
        let payload = self
            .provider_client
            .get_json(
                "geocoding/v1/reverse",
                &query_pairs,
                crate::client::GEOCODING_CONTRACT_NAME,
            )
            .await?;
        parse_geocoding_payload(&payload)
    }
}

/// Parses `results[].locations[]` into vendor-neutral places, joining the
/// populated admin-area fields into a display string and mapping the
/// documented `geocodeQuality` vocabulary onto [`GeocodeQuality`].
pub fn parse_geocoding_payload(payload: &Value) -> Result<Vec<PlaceResult>, SDKError> {
    let result_list = payload
        .get("results")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("geocoding payload lacks results".to_string())
        })?;
    let mut places = Vec::new();
    for result in result_list {
        let locations = result
            .get("locations")
            .and_then(Value::as_array)
            .ok_or_else(|| {
                SDKError::ResponseParsingFailure("geocoding result lacks locations".to_string())
            })?;
        for location in locations {
            places.push(parse_location(location)?);
        }
    }
    Ok(places)
}

fn parse_location(location: &Value) -> Result<PlaceResult, SDKError> {
    let latitude = location
        .pointer("/latLng/lat")
        .and_then(Value::as_f64)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("geocoding location lacks latLng".to_string())
        })?;
    let longitude = location
        .pointer("/latLng/lng")
        .and_then(Value::as_f64)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("geocoding location lacks latLng".to_string())
        })?;
    let coordinate = GeographicCoordinate::from_degrees(latitude, longitude)?;

    let street = location
        .get("street")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let city = location
        .get("adminArea5")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let state = location
        .get("adminArea3")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let country = location
        .get("adminArea1")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let postal_code = location
        .get("postalCode")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let structured_address_text = [street, city, state, postal_code, country]
        .iter()
        .filter(|part| !part.is_empty())
        .cloned()
        .collect::<Vec<&str>>()
        .join(", ");

    let quality_text = location
        .get("geocodeQuality")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let quality_code = location
        .get("geocodeQualityCode")
        .and_then(Value::as_str)
        .unwrap_or_default();

    Ok(PlaceResult {
        structured_address_text,
        coordinate,
        geocode_quality: map_geocode_quality(quality_text, quality_code),
    })
}

/// Maps the documented `geocodeQuality` vocabulary onto [`GeocodeQuality`],
/// falling back to the precision letter of the five-character
/// `geocodeQualityCode` when the vocabulary is unknown.
pub fn map_geocode_quality(quality_text: &str, quality_code: &str) -> GeocodeQuality {
    match quality_text {
        "POINT" => GeocodeQuality::Point,
        "ADDRESS" => GeocodeQuality::StreetAddress,
        "INTERSECTION" => GeocodeQuality::Intersection,
        "STREET" => GeocodeQuality::Street,
        "ZIP" => GeocodeQuality::PostalCode,
        "CITY" => GeocodeQuality::City,
        "COUNTY" => GeocodeQuality::County,
        "STATE" => GeocodeQuality::State,
        "COUNTRY" => GeocodeQuality::Country,
        // Neighborhood resolves below settlement level; City is the closest
        // structural precision in the SDK model.
        "NEIGHBORHOOD" => GeocodeQuality::City,
        _ => map_quality_code_letter(quality_code.chars().next().unwrap_or_default()),
    }
}

fn map_quality_code_letter(precision_letter: char) -> GeocodeQuality {
    match precision_letter {
        'P' | 'L' => GeocodeQuality::Point,
        'A' => GeocodeQuality::StreetAddress,
        'I' => GeocodeQuality::Intersection,
        'S' => GeocodeQuality::Street,
        'Z' => GeocodeQuality::PostalCode,
        'C' => GeocodeQuality::City,
        'D' => GeocodeQuality::County,
        'T' => GeocodeQuality::State,
        'R' => GeocodeQuality::Country,
        _ => GeocodeQuality::Street,
    }
}

#[cfg(test)]
mod tests {
    use super::{map_geocode_quality, parse_geocoding_payload};
    use geospatial_types::place::GeocodeQuality;

    fn fixture(name: &str) -> serde_json::Value {
        let fixture_path = format!(
            "{}/../../fixtures/mapquest/{name}",
            env!("CARGO_MANIFEST_DIR")
        );
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    #[test]
    fn parses_recorded_city_level_geocode() {
        let payload = fixture("geocode_address_city.json");
        let places = parse_geocoding_payload(&payload).unwrap();
        assert!(!places.is_empty());
        let first = &places[0];
        assert_eq!(first.coordinate.latitude, 38.57944);
        assert_eq!(first.coordinate.longitude, -121.49085);
        assert_eq!(first.geocode_quality, GeocodeQuality::City);
        assert!(first.structured_address_text.contains("Sacramento"));
        assert!(first.structured_address_text.ends_with("US"));
    }

    #[test]
    fn document_quality_vocabulary_maps_every_level() {
        assert_eq!(map_geocode_quality("POINT", ""), GeocodeQuality::Point);
        assert_eq!(
            map_geocode_quality("ADDRESS", ""),
            GeocodeQuality::StreetAddress
        );
        assert_eq!(
            map_geocode_quality("INTERSECTION", ""),
            GeocodeQuality::Intersection
        );
        assert_eq!(map_geocode_quality("STREET", ""), GeocodeQuality::Street);
        assert_eq!(map_geocode_quality("ZIP", ""), GeocodeQuality::PostalCode);
        assert_eq!(map_geocode_quality("CITY", ""), GeocodeQuality::City);
        assert_eq!(map_geocode_quality("COUNTY", ""), GeocodeQuality::County);
        assert_eq!(map_geocode_quality("STATE", ""), GeocodeQuality::State);
        assert_eq!(map_geocode_quality("COUNTRY", ""), GeocodeQuality::Country);
        assert_eq!(
            map_geocode_quality("NEIGHBORHOOD", ""),
            GeocodeQuality::City
        );
        assert_eq!(map_geocode_quality("", "P1CAA"), GeocodeQuality::Point);
        assert_eq!(
            map_geocode_quality("", "A5XAX"),
            GeocodeQuality::StreetAddress
        );
        assert_eq!(map_geocode_quality("", "Z3AAA"), GeocodeQuality::PostalCode);
        assert_eq!(map_geocode_quality("", "?9ZZZ"), GeocodeQuality::Street);
    }
}
