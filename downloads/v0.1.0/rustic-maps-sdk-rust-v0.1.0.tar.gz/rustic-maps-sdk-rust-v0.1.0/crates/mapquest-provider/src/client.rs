//! Shared facade for the MapQuest endpoint implementations: every outbound
//! call passes the rate limiter first, then transport, then the `info`
//! envelope check.

use crate::error_mapping::validate_info_envelope;
use crate::http::MapQuestHttpClient;
use geospatial_types::SDKError;
use provider_transport::TokenBucketRateLimiter;
use serde_json::Value;

/// Rate-limited, envelope-validated wrapper around [`MapQuestHttpClient`]
/// shared by all MapQuest provider implementations.
pub struct MapQuestProviderClient {
    http_client: MapQuestHttpClient,
    rate_limiter: TokenBucketRateLimiter,
}

/// Envelopes are the status channel of Directions/Geocoding/Traffic/Tiles;
/// the Search Ahead API carries none and only fails at transport level, so
/// absence of the envelope is tolerated here.
fn validate_info_envelope_if_present(payload: &Value) -> Result<(), SDKError> {
    if payload.get("info").is_some() {
        return validate_info_envelope(payload);
    }
    Ok(())
}

/// Bundled tuning for the shared client.
pub struct MapQuestProviderConfiguration {
    /// Base URL; defaults to the public MapQuest platform and is overridden
    /// in tests.
    pub base_url: String,
    /// Consumer key issued by the MapQuest developer portal.
    pub api_key: String,
    /// Bucket capacity; bursts up to this many requests start immediately.
    pub token_bucket_capacity: f64,
    /// Continuous refill rate in tokens per second.
    pub refill_tokens_per_second: f64,
    /// Longest wait accepted before surfacing [`SDKError::RateLimitExhausted`].
    pub maximum_wait_seconds: u64,
    /// Retry budget for idempotent GETs.
    pub maximum_retry_attempts: u32,
}

impl Default for MapQuestProviderConfiguration {
    fn default() -> Self {
        Self {
            base_url: crate::http::MAPQUEST_BASE_URL.to_string(),
            api_key: String::new(),
            token_bucket_capacity: 30.0,
            refill_tokens_per_second: 5.0,
            maximum_wait_seconds: 10,
            maximum_retry_attempts: 2,
        }
    }
}

impl MapQuestProviderClient {
    /// Builds the shared client from the given configuration.
    pub fn new(configuration: MapQuestProviderConfiguration) -> Result<Self, SDKError> {
        Ok(Self {
            http_client: MapQuestHttpClient::new(
                configuration.base_url,
                configuration.api_key,
                configuration.maximum_retry_attempts,
            )?,
            rate_limiter: TokenBucketRateLimiter::new(
                configuration.token_bucket_capacity,
                configuration.refill_tokens_per_second,
                configuration.maximum_wait_seconds,
            )?,
        })
    }

    /// Rate-limited GET returning a payload validated against the `info`
    /// envelope when present (Search Ahead replies carry none).
    pub async fn get_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
    ) -> Result<Value, SDKError> {
        self.rate_limiter.acquire().await?;
        let payload = self.http_client.get_json(path, query_pairs).await?;
        validate_info_envelope_if_present(&payload)?;
        Ok(payload)
    }

    /// Rate-limited POST returning a payload validated against the `info`
    /// envelope when present.
    pub async fn post_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
        request_body: &Value,
    ) -> Result<Value, SDKError> {
        self.rate_limiter.acquire().await?;
        let payload = self
            .http_client
            .post_json(path, query_pairs, request_body)
            .await?;
        validate_info_envelope_if_present(&payload)?;
        Ok(payload)
    }

    /// Rate-limited binary fetch (raster tiles have no `info` envelope).
    pub async fn get_bytes(&self, path: &str) -> Result<Vec<u8>, SDKError> {
        self.rate_limiter.acquire().await?;
        self.http_client.get_bytes(path).await
    }
}

#[cfg(test)]
mod tests {
    use super::{MapQuestProviderClient, MapQuestProviderConfiguration};
    use geospatial_types::SDKError;
    use wiremock::matchers::{method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    fn client_with_base(base_url: String) -> MapQuestProviderClient {
        MapQuestProviderClient::new(MapQuestProviderConfiguration {
            base_url,
            api_key: "test-key".to_string(),
            ..MapQuestProviderConfiguration::default()
        })
        .unwrap()
    }

    #[tokio::test]
    async fn application_level_statuscodes_reject_before_returning() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/directions/v2/route"))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
                "info": {"statuscode": 402, "messages": ["Invalid Location."]},
                "route": {}
            })))
            .mount(&server)
            .await;
        let client = client_with_base(server.uri());
        let error = client
            .get_json("directions/v2/route", &[])
            .await
            .unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    }
}
