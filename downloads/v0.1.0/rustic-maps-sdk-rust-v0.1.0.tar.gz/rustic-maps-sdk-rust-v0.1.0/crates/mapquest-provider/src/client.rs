//! Shared facade for the MapQuest endpoint implementations: every outbound
//! call passes the rate limiter first, then transport, then the `info`
//! envelope check.

use crate::error_mapping::validate_info_envelope;
use crate::http::MapQuestHttpClient;
use geospatial_types::SDKError;
use provider_transport::TokenBucketRateLimiter;
use serde_json::Value;

/// Rate-limited, envelope-validated wrapper around [`MapQuestHttpClient`]
/// shared by all MapQuest provider implementations.
pub struct MapQuestProviderClient {
    http_client: MapQuestHttpClient,
    rate_limiter: TokenBucketRateLimiter,
}

/// Envelopes are the status channel of Directions/Geocoding/Traffic/Tiles;
/// the Search Ahead API carries none and only fails at transport level, so
/// absence of the envelope is tolerated here.
fn validate_info_envelope_if_present(payload: &Value) -> Result<(), SDKError> {
    if payload.get("info").is_some() {
        return validate_info_envelope(payload);
    }
    Ok(())
}

/// The registry key of this provider, used for request observation only.
pub const MAPQUEST_PROVIDER_KEY: &str = "mapquest";

/// Contract name reported for geocoding requests.
pub const GEOCODING_CONTRACT_NAME: &str = "GeocodingProvider";
/// Contract name reported for route requests.
pub const ROUTING_CONTRACT_NAME: &str = "RoutingProvider";
/// Contract name reported for distance-matrix requests.
pub const DISTANCE_MATRIX_CONTRACT_NAME: &str = "DistanceMatrixProvider";
/// Contract name reported for place-search requests.
pub const SEARCH_PLACE_CONTRACT_NAME: &str = "SearchPlaceProvider";
/// Contract name reported for traffic-incident requests.
pub const TRAFFIC_INCIDENT_CONTRACT_NAME: &str = "TrafficIncidentProvider";
/// Contract name reported for traffic-flow requests.
pub const TRAFFIC_FLOW_CONTRACT_NAME: &str = "TrafficFlowProvider";
/// Contract name reported for raster-tile requests.
pub const RASTER_TILE_CONTRACT_NAME: &str = "RasterTileProvider";

/// Bundled tuning for the shared client.
pub struct MapQuestProviderConfiguration {
    /// Base URL; defaults to the public MapQuest platform and is overridden
    /// in tests.
    pub base_url: String,
    /// Consumer key issued by the MapQuest developer portal.
    pub api_key: String,
    /// Bucket capacity; bursts up to this many requests start immediately.
    pub token_bucket_capacity: f64,
    /// Continuous refill rate in tokens per second.
    pub refill_tokens_per_second: f64,
    /// Longest wait accepted before surfacing [`SDKError::RateLimitExhausted`].
    pub maximum_wait_seconds: u64,
    /// Retry budget for idempotent GETs.
    pub maximum_retry_attempts: u32,
}

impl Default for MapQuestProviderConfiguration {
    fn default() -> Self {
        Self {
            base_url: crate::http::MAPQUEST_BASE_URL.to_string(),
            api_key: String::new(),
            token_bucket_capacity: 30.0,
            refill_tokens_per_second: 5.0,
            maximum_wait_seconds: 10,
            maximum_retry_attempts: 2,
        }
    }
}

impl MapQuestProviderClient {
    /// Builds the shared client from the given configuration.
    pub fn new(configuration: MapQuestProviderConfiguration) -> Result<Self, SDKError> {
        Ok(Self {
            http_client: MapQuestHttpClient::new(
                configuration.base_url,
                configuration.api_key,
                configuration.maximum_retry_attempts,
            )?,
            rate_limiter: TokenBucketRateLimiter::new(
                configuration.token_bucket_capacity,
                configuration.refill_tokens_per_second,
                configuration.maximum_wait_seconds,
            )?,
        })
    }

    /// Rate-limited GET returning a payload validated against the `info`
    /// envelope when present (Search Ahead replies carry none).
    pub async fn get_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
        provider_contract: &str,
    ) -> Result<Value, SDKError> {
        self.rate_limiter.acquire().await?;
        let payload = self
            .http_client
            .get_json(path, query_pairs, provider_contract)
            .await?;
        validate_info_envelope_if_present(&payload)?;
        Ok(payload)
    }

    /// Rate-limited POST returning a payload validated against the `info`
    /// envelope when present.
    pub async fn post_json(
        &self,
        path: &str,
        query_pairs: &[(String, String)],
        request_body: &Value,
        provider_contract: &str,
    ) -> Result<Value, SDKError> {
        self.rate_limiter.acquire().await?;
        let payload = self
            .http_client
            .post_json(path, query_pairs, request_body, provider_contract)
            .await?;
        validate_info_envelope_if_present(&payload)?;
        Ok(payload)
    }

    /// Rate-limited binary fetch (raster tiles have no `info` envelope).
    pub async fn get_bytes(
        &self,
        path: &str,
        provider_contract: &str,
    ) -> Result<Vec<u8>, SDKError> {
        self.rate_limiter.acquire().await?;
        self.http_client.get_bytes(path, provider_contract).await
    }
}

#[cfg(test)]
mod tests {
    use super::{
        GEOCODING_CONTRACT_NAME, MAPQUEST_PROVIDER_KEY, MapQuestProviderClient,
        MapQuestProviderConfiguration,
    };
    use geospatial_types::SDKError;
    use provider_transport::{
        ProviderRequestObservation, ProviderRequestObserver, install_provider_request_observer,
    };
    use std::sync::{Arc, Mutex};
    use wiremock::matchers::{method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    fn client_with_base(base_url: String) -> MapQuestProviderClient {
        MapQuestProviderClient::new(MapQuestProviderConfiguration {
            base_url,
            api_key: "test-key".to_string(),
            ..MapQuestProviderConfiguration::default()
        })
        .unwrap()
    }

    /// An observer that keeps every observation it receives.
    #[derive(Default)]
    struct RecordingObserver {
        observations: Mutex<Vec<ProviderRequestObservation>>,
    }

    impl ProviderRequestObserver for RecordingObserver {
        fn on_provider_request(&self, observation: ProviderRequestObservation) {
            self.observations
                .lock()
                .expect("the observation list is never poisoned")
                .push(observation);
        }
    }

    #[tokio::test]
    async fn a_request_is_observed_with_its_contract_and_key_but_not_the_credential() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/geocoding/v1/address"))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
                "info": {"statuscode": 0, "messages": []},
                "results": []
            })))
            .mount(&server)
            .await;
        let recording_observer = Arc::new(RecordingObserver::default());
        install_provider_request_observer(Some(recording_observer.clone()));
        let client = client_with_base(server.uri());
        client
            .get_json("geocoding/v1/address", &[], GEOCODING_CONTRACT_NAME)
            .await
            .expect("the mocked provider answers");

        let observations = recording_observer
            .observations
            .lock()
            .expect("the observation list is never poisoned")
            .clone();
        // The sink is process-wide, so tests running in parallel are observed
        // too; the assertions therefore look for this call and check that no
        // observation of any call leaks the credential.
        assert!(
            observations.iter().any(|observation| {
                observation.provider_contract == GEOCODING_CONTRACT_NAME
                    && observation.provider_key == MAPQUEST_PROVIDER_KEY
                    && observation.status_class == "2xx"
                    && observation.request_path.contains("/geocoding/v1/address")
                    && observation.request_path.contains("key=<redacted>")
            }),
            "the successful geocoding request is observed with its contract and key"
        );
        assert!(observations.iter().all(|observation| {
            !observation.request_path.contains("test-key")
                && !observation.response_snippet.contains("test-key")
        }));
        install_provider_request_observer(None);
    }

    #[tokio::test]
    async fn application_level_statuscodes_reject_before_returning() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/directions/v2/route"))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
                "info": {"statuscode": 402, "messages": ["Invalid Location."]},
                "route": {}
            })))
            .mount(&server)
            .await;
        let client = client_with_base(server.uri());
        let error = client
            .get_json(
                "directions/v2/route",
                &[],
                crate::client::ROUTING_CONTRACT_NAME,
            )
            .await
            .unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    }
}
