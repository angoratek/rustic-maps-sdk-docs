//! Mapping between MapQuest service signals and the SDK error model.
//!
//! Two distinct failure channels exist for MapQuest web services and both are
//! handled here:
//!
//! 1. Transport-level failures carried in the HTTP status (for example HTTP
//!    401 for a rejected API key).
//! 2. Application-level failures where the platform replies with HTTP 200 but
//!    `info.statuscode` is non-zero together with human-readable
//!    `info.messages` (verified against the live Directions API, which returns
//!    this shape for invalid coordinates).

use geospatial_types::SDKError;
use serde_json::Value;

/// Translates a non-success HTTP status returned by a MapQuest service.
pub fn map_http_error_response(status: u16, response_body_text: &str) -> SDKError {
    match status {
        401 | 403 => SDKError::ProviderRequestRejected(format!(
            "api key rejected by MapQuest (HTTP {status}): {response_body_text}"
        )),
        429 => SDKError::RateLimitExhausted,
        status if status >= 500 => SDKError::NetworkRequestFailed(format!(
            "provider unavailable (HTTP {status}): {response_body_text}"
        )),
        _ => SDKError::ProviderRequestRejected(format!(
            "provider returned HTTP {status}: {response_body_text}"
        )),
    }
}

/// Validates the `info` envelope of a MapQuest JSON payload, mapping a
/// non-zero `info.statuscode` to a typed SDK error.
pub fn validate_info_envelope(payload: &Value) -> Result<(), SDKError> {
    let info = payload.get("info").ok_or_else(|| {
        SDKError::ResponseParsingFailure("payload lacks the MapQuest info envelope".to_string())
    })?;
    let status_code = info
        .get("statuscode")
        .and_then(Value::as_i64)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("info envelope lacks a numeric statuscode".to_string())
        })?;
    if status_code == 0 {
        return Ok(());
    }
    let messages = info
        .get("messages")
        .and_then(Value::as_array)
        .map(|values| {
            values
                .iter()
                .filter_map(Value::as_str)
                .collect::<Vec<&str>>()
                .join("; ")
        })
        .unwrap_or_default();
    Err(SDKError::ProviderRequestRejected(format!(
        "MapQuest statuscode {status_code}: {messages}"
    )))
}

#[cfg(test)]
mod tests {
    use super::{map_http_error_response, validate_info_envelope};
    use geospatial_types::SDKError;
    use serde_json::json;

    #[test]
    fn http_401_maps_to_provider_request_rejected() {
        let error =
            map_http_error_response(401, "The AppKey submitted with this request is invalid.");
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    }

    #[test]
    fn http_429_maps_to_rate_limit_exhausted() {
        assert!(matches!(
            map_http_error_response(429, ""),
            SDKError::RateLimitExhausted
        ));
    }

    #[test]
    fn envelope_accepts_success_and_rejects_documented_failure() {
        let success = json!({"info": {"statuscode": 0, "messages": []}});
        assert!(validate_info_envelope(&success).is_ok());

        let failure = json!({"info": {"statuscode": 500, "messages": [
            "Error processing request: Encountered an error while trying to batch geocode"
        ]}});
        let error = validate_info_envelope(&failure).expect_err("failure must surface");
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
    }

    #[test]
    fn envelope_without_info_is_a_parsing_failure() {
        let payload = json!({});
        assert!(matches!(
            validate_info_envelope(&payload),
            Err(SDKError::ResponseParsingFailure(_))
        ));
    }
}
