//! MapQuest Tiles API implementation of the raster tile contract.

use crate::client::MapQuestProviderClient;
use async_trait::async_trait;
use geospatial_traits::RasterTileProvider;
use geospatial_types::{RasterImageFormat, RasterTileData, RasterTileResolution, SDKError};
use std::sync::Arc;

/// Default map style served to the renderer; configurable because the Tiles
/// API documents `vivid`, `night` and `satellite` styles.
const DEFAULT_TILE_STYLE: &str = "vivid";

/// Size path segment of the standard-resolution tiles API request.
const STANDARD_TILE_SIZE_PATH_SEGMENT: &str = "256";
/// Size path segment of the retina-resolution (`@2x`) tiles API request:
/// twice the texels per edge for the same logical tile span.
const RETINA_TILE_SIZE_PATH_SEGMENT: &str = "256@2x";

/// The MapQuest terms' imagery-caching ceiling: raster-tile responses may be
/// stored for up to **30 calendar days**. Declared here as the
/// provider-specific caching term so an integrator caching tiles knows the
/// upper bound for this provider; the
/// general cache layer's tiles default equals this ceiling, enforced by
/// `tiles.rs`'s lockstep test.
pub const MAPQUEST_RASTER_TILE_CACHE_CEILING_SECONDS: u64 = 30 * 24 * 60 * 60;

/// Raster tiles served from the documented
/// `/tiles/v1/render/latest/{style}/{z}/{x}/{y}/{size}/{format}` template.
pub struct MapQuestRasterTileProvider {
    provider_client: Arc<MapQuestProviderClient>,
    tile_style: String,
}

impl MapQuestRasterTileProvider {
    /// Wraps the shared rate-limited client with the default tile style.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self::with_tile_style(provider_client, DEFAULT_TILE_STYLE.to_string())
    }

    /// Wraps the shared rate-limited client with an explicit tile style.
    pub fn with_tile_style(
        provider_client: Arc<MapQuestProviderClient>,
        tile_style: String,
    ) -> Self {
        Self {
            provider_client,
            tile_style,
        }
    }
}

#[async_trait]
impl RasterTileProvider for MapQuestRasterTileProvider {
    async fn fetch_raster_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
        image_format: RasterImageFormat,
        tile_resolution: RasterTileResolution,
    ) -> Result<RasterTileData, SDKError> {
        if zoom_level > 20 {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "zoom level {zoom_level} exceeds the documented Tiles API maximum of 20"
            )));
        }
        let maximum_tile_index = (1u32 << zoom_level) - 1;
        if tile_x > maximum_tile_index || tile_y > maximum_tile_index {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "tile x={tile_x} y={tile_y} exceeds the {maximum_tile_index} maximum at zoom {zoom_level}"
            )));
        }
        let tile_path = format!(
            "tiles/v1/render/latest/{}/{zoom_level}/{tile_x}/{tile_y}/{}/{}",
            self.tile_style,
            tile_size_path_segment(tile_resolution),
            image_format_path_segment(image_format),
        );
        let image_bytes = self.provider_client.get_bytes(&tile_path).await?;
        Ok(RasterTileData {
            tile_x,
            tile_y,
            zoom_level,
            image_format,
            tile_resolution,
            image_bytes,
        })
    }
}

/// Size path segment the Tiles API expects: the tile edge in pixels, with
/// the `@2x` marker for the retina double-texel form.
fn tile_size_path_segment(tile_resolution: RasterTileResolution) -> &'static str {
    match tile_resolution {
        RasterTileResolution::Standard => STANDARD_TILE_SIZE_PATH_SEGMENT,
        RasterTileResolution::Retina => RETINA_TILE_SIZE_PATH_SEGMENT,
    }
}

fn image_format_path_segment(image_format: RasterImageFormat) -> &'static str {
    match image_format {
        RasterImageFormat::Png => "png",
        RasterImageFormat::Jpeg => "jpeg",
    }
}

#[cfg(test)]
mod tests {
    use super::MAPQUEST_RASTER_TILE_CACHE_CEILING_SECONDS;
    use super::{image_format_path_segment, tile_size_path_segment};
    use geospatial_traits::RasterTileProvider;
    use geospatial_types::{RasterImageFormat, RasterTileResolution};
    use wiremock::matchers::{method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    /// The general cache layer's tiles default must equal this provider's
    /// documented terms ceiling, so the default-heavy posture never exceeds
    /// what the MapQuest terms allow.
    #[test]
    fn cache_tiles_default_matches_mapquest_terms_ceiling() {
        assert_eq!(
            rustic_maps_cache::ResponseCategory::RasterTiles.default_time_to_live_seconds(),
            MAPQUEST_RASTER_TILE_CACHE_CEILING_SECONDS
        );
    }

    // Smallest valid 1x1 blue PNG.
    const TINY_PNG_BYTES: [u8; 70] = [
        137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6,
        0, 0, 0, 31, 21, 196, 137, 0, 0, 0, 13, 73, 68, 65, 84, 120, 218, 99, 100, 96, 248, 95, 15,
        0, 2, 135, 1, 128, 235, 71, 186, 146, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130,
    ];

    #[test]
    fn image_formats_map_to_path_segments() {
        assert_eq!(image_format_path_segment(RasterImageFormat::Png), "png");
        assert_eq!(image_format_path_segment(RasterImageFormat::Jpeg), "jpeg");
    }

    #[test]
    fn tile_resolutions_map_to_size_path_segments() {
        assert_eq!(
            tile_size_path_segment(RasterTileResolution::Standard),
            super::STANDARD_TILE_SIZE_PATH_SEGMENT
        );
        assert_eq!(
            tile_size_path_segment(RasterTileResolution::Retina),
            super::RETINA_TILE_SIZE_PATH_SEGMENT
        );
        assert_eq!(super::STANDARD_TILE_SIZE_PATH_SEGMENT, "256");
        assert_eq!(super::RETINA_TILE_SIZE_PATH_SEGMENT, "256@2x");
    }

    #[tokio::test]
    async fn fetches_tile_bytes_from_documented_path() {
        let server = MockServer::start().await;
        let png_bytes = TINY_PNG_BYTES.to_vec();
        Mock::given(method("GET"))
            .and(path("/tiles/v1/render/latest/vivid/13/1873/3374/256/png"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(png_bytes.clone()))
            .mount(&server)
            .await;
        let client = crate::client::MapQuestProviderClient::new(
            crate::client::MapQuestProviderConfiguration {
                base_url: server.uri(),
                ..crate::client::MapQuestProviderConfiguration::default()
            },
        )
        .unwrap();
        let provider = super::MapQuestRasterTileProvider::with_tile_style(
            std::sync::Arc::new(client),
            "vivid".to_string(),
        );
        let tile = provider
            .fetch_raster_tile(
                1873,
                3374,
                13,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .unwrap();
        assert_eq!(tile.tile_x, 1873);
        assert_eq!(tile.zoom_level, 13);
        assert_eq!(tile.tile_resolution, RasterTileResolution::Standard);
        assert!(!tile.image_bytes.is_empty());
    }

    #[tokio::test]
    async fn retina_fetches_hit_the_double_resolution_size_segment() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path(
                "/tiles/v1/render/latest/vivid/13/1873/3374/256@2x/png",
            ))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(TINY_PNG_BYTES.to_vec()))
            .mount(&server)
            .await;
        let client = crate::client::MapQuestProviderClient::new(
            crate::client::MapQuestProviderConfiguration {
                base_url: server.uri(),
                ..crate::client::MapQuestProviderConfiguration::default()
            },
        )
        .unwrap();
        let provider = super::MapQuestRasterTileProvider::with_tile_style(
            std::sync::Arc::new(client),
            "vivid".to_string(),
        );
        let tile = provider
            .fetch_raster_tile(
                1873,
                3374,
                13,
                RasterImageFormat::Png,
                RasterTileResolution::Retina,
            )
            .await
            .unwrap();
        assert_eq!(tile.tile_resolution, RasterTileResolution::Retina);
        assert!(!tile.image_bytes.is_empty());
    }
}
