//! MapQuest Traffic API v2 incident implementation.
//!
//! Flow observations live in [`crate::traffic_flow`]; this module implements
//! [`TrafficIncidentProvider`] against the documented `traffic/v2/incidents`
//! endpoint.

use crate::client::MapQuestProviderClient;
use crate::json_coordinates::bounding_box_to_query_text;
use async_trait::async_trait;
use geospatial_traits::TrafficIncidentProvider;
use geospatial_types::traffic::{TrafficIncidentSeverity, TrafficIncidentType};
use geospatial_types::{BoundingBox, GeographicCoordinate, SDKError, TrafficIncident};
use serde_json::Value;
use std::sync::Arc;

/// Incidents against the MapQuest Traffic API v2 incidents endpoint.
pub struct MapQuestTrafficIncidentProvider {
    provider_client: Arc<MapQuestProviderClient>,
}

impl MapQuestTrafficIncidentProvider {
    /// Wraps the shared rate-limited client.
    pub fn new(provider_client: Arc<MapQuestProviderClient>) -> Self {
        Self { provider_client }
    }
}

#[async_trait]
impl TrafficIncidentProvider for MapQuestTrafficIncidentProvider {
    async fn fetch_traffic_incidents(
        &self,
        bounding_box: &BoundingBox,
    ) -> Result<Vec<TrafficIncident>, SDKError> {
        let query_pairs = vec![(
            "boundingBox".to_string(),
            bounding_box_to_query_text(bounding_box),
        )];
        let payload = self
            .provider_client
            .get_json("traffic/v2/incidents", &query_pairs)
            .await?;
        parse_incidents_payload(&payload)
    }
}

/// Parses the documented `incidents[]` collection. Congestion/flow entries
/// (`type == 3`) are skipped: they are flow conditions — parsed by
/// [`crate::traffic_flow`] from the flow endpoint — rather than disruptions.
pub fn parse_incidents_payload(payload: &Value) -> Result<Vec<TrafficIncident>, SDKError> {
    let incidents = payload
        .get("incidents")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            SDKError::ResponseParsingFailure("incidents payload lacks incidents".to_string())
        })?;
    let mut parsed_incidents = Vec::new();
    for incident in incidents {
        if let Some(parsed_incident) = parse_incident(incident)? {
            parsed_incidents.push(parsed_incident);
        }
    }
    Ok(parsed_incidents)
}

fn parse_incident(incident: &Value) -> Result<Option<TrafficIncident>, SDKError> {
    let incident_type = match incident.get("type").and_then(Value::as_i64) {
        Some(1) => TrafficIncidentType::Construction,
        Some(2) => TrafficIncidentType::Event,
        Some(3) => return Ok(None),
        Some(4) => TrafficIncidentType::Accident,
        Some(other) => {
            return Err(SDKError::ResponseParsingFailure(format!(
                "unknown incident type {other}"
            )));
        }
        None => {
            return Err(SDKError::ResponseParsingFailure(
                "incident lacks the type field".to_string(),
            ));
        }
    };
    let latitude = incident
        .get("lat")
        .and_then(Value::as_f64)
        .ok_or_else(|| SDKError::ResponseParsingFailure("incident lacks lat".to_string()))?;
    let longitude = incident
        .get("lng")
        .and_then(Value::as_f64)
        .ok_or_else(|| SDKError::ResponseParsingFailure("incident lacks lng".to_string()))?;
    let start_coordinate = GeographicCoordinate::from_degrees(latitude, longitude)?;
    let severity = map_severity(incident.get("severity").and_then(Value::as_i64));
    Ok(Some(TrafficIncident {
        identifier: incident
            .get("id")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string(),
        incident_type,
        severity,
        short_description_text: incident
            .get("shortDesc")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string(),
        start_coordinate,
        // The incidents payload carries no end coordinate; affected-road
        // extent arrives as `distance` only.
        end_coordinate: None,
    }))
}

/// Maps the documented 0..=4 severity scale onto the three SDK levels.
pub fn map_severity(severity_value: Option<i64>) -> TrafficIncidentSeverity {
    match severity_value.unwrap_or_default() {
        0 | 1 => TrafficIncidentSeverity::Low,
        2 | 3 => TrafficIncidentSeverity::Medium,
        _ => TrafficIncidentSeverity::High,
    }
}

#[cfg(test)]
mod tests {
    use super::{map_severity, parse_incidents_payload};
    use geospatial_types::traffic::{TrafficIncidentSeverity, TrafficIncidentType};

    fn fixture(name: &str) -> serde_json::Value {
        let fixture_path = format!(
            "{}/../../fixtures/mapquest/{name}",
            env!("CARGO_MANIFEST_DIR")
        );
        serde_json::from_str(&std::fs::read_to_string(fixture_path).unwrap()).unwrap()
    }

    #[test]
    fn parses_recorded_denver_incidents() {
        let payload = fixture("traffic_incidents_denver.json");
        let incidents = parse_incidents_payload(&payload).unwrap();
        assert_eq!(incidents.len(), 5);
        let first = &incidents[0];
        assert_eq!(first.incident_type, TrafficIncidentType::Accident);
        assert_eq!(first.severity, TrafficIncidentSeverity::Medium);
        assert!(first.identifier.contains("1396961518"));
        assert!((first.start_coordinate.latitude - 39.85682).abs() < 1e-9);
        assert!(first.end_coordinate.is_none());
    }

    #[test]
    fn severity_scale_maps_onto_three_levels() {
        assert_eq!(map_severity(Some(0)), TrafficIncidentSeverity::Low);
        assert_eq!(map_severity(Some(1)), TrafficIncidentSeverity::Low);
        assert_eq!(map_severity(Some(2)), TrafficIncidentSeverity::Medium);
        assert_eq!(map_severity(Some(3)), TrafficIncidentSeverity::Medium);
        assert_eq!(map_severity(Some(4)), TrafficIncidentSeverity::High);
        assert_eq!(map_severity(None), TrafficIncidentSeverity::Low);
    }
}
