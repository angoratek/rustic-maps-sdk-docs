//! End-to-end provider tests against wiremock servers replaying recorded
//! MapQuest fixtures, plus negative paths for every failure channel.

use geospatial_traits::{
    DistanceMatrixProvider, GeocodingProvider, RasterTileProvider, RoutingProvider,
    SearchPlaceProvider, TrafficFlowProvider, TrafficIncidentProvider,
};
use geospatial_types::route::{AvoidOptions, RouteOptions, RouteStrategy, UnitSystem};
use geospatial_types::{BoundingBox, GeographicCoordinate};
use geospatial_types::{RasterImageFormat, RasterTileResolution};
use mapquest_provider::{MapQuestProviderClient, MapQuestProviderConfiguration};
use wiremock::ResponseTemplate;

fn client_with_base(base_url: String) -> MapQuestProviderClient {
    MapQuestProviderClient::new(MapQuestProviderConfiguration {
        base_url,
        ..MapQuestProviderConfiguration::default()
    })
    .unwrap()
}

fn fixture_body(name: &str) -> ResponseTemplate {
    let fixture_path = format!(
        "{}/../../fixtures/mapquest/{name}",
        env!("CARGO_MANIFEST_DIR")
    );
    ResponseTemplate::new(200).set_body_string(std::fs::read_to_string(fixture_path).unwrap())
}

fn coordinate(latitude: f64, longitude: f64) -> GeographicCoordinate {
    GeographicCoordinate::from_degrees(latitude, longitude).unwrap()
}

/// Route origin recorded from the Capitol Park waypoint.
fn recorded_route_origin() -> GeographicCoordinate {
    coordinate(38.57657, -121.4936)
}

/// Route destination recorded from the Tower Bridge waypoint.
fn recorded_route_destination() -> GeographicCoordinate {
    coordinate(38.57887, -121.50797)
}

fn denver_bounding_box() -> BoundingBox {
    BoundingBox::from_corners(coordinate(39.52, -105.25), coordinate(39.95, -104.71)).unwrap()
}

#[tokio::test]
async fn forward_geocode_replays_recorded_city_response() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/geocoding/v1/address"))
        .and(wiremock::matchers::query_param(
            "location",
            "Sacramento,California",
        ))
        .respond_with(fixture_body("geocode_address_city.json"))
        .mount(&server)
        .await;
    let geocoding_provider = mapquest_provider::MapQuestGeocodingProvider::new(
        std::sync::Arc::new(client_with_base(server.uri())),
    );
    let places = geocoding_provider
        .forward_geocode("Sacramento,California")
        .await
        .unwrap();
    assert!(!places.is_empty());
    assert_eq!(places[0].structured_address_text, "Sacramento, CA, US");
    assert!((places[0].coordinate.latitude - 38.57944).abs() < 1e-9);
}

#[tokio::test]
async fn route_request_carries_documented_query_and_parses() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/directions/v2/route"))
        .and(wiremock::matchers::query_param(
            "from",
            "38.57657,-121.4936",
        ))
        .and(wiremock::matchers::query_param("to", "38.57887,-121.50797"))
        .and(wiremock::matchers::query_param("unit", "k"))
        .and(wiremock::matchers::query_param("routeType", "fastest"))
        .and(wiremock::matchers::query_param(
            "avoids",
            "Toll Road,Unpaved",
        ))
        .respond_with(fixture_body("directions_route_two_waypoints.json"))
        .expect(1)
        .mount(&server)
        .await;
    let routing_provider = mapquest_provider::MapQuestRoutingProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    let route_options = RouteOptions {
        unit_system: UnitSystem::Metric,
        avoid_options: AvoidOptions {
            toll_roads: true,
            unpaved_roads: true,
            ..AvoidOptions::default()
        },
        ..RouteOptions::default()
    };
    let route = routing_provider
        .calculate_route(
            &[recorded_route_origin(), recorded_route_destination()],
            &route_options,
        )
        .await
        .unwrap();
    server.verify().await;
    assert_eq!(route.legs.len(), 1);
    assert_eq!(route.legs[0].steps.len(), 6);
}

#[tokio::test]
async fn shortest_strategy_changes_the_route_type_query_parameter() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/directions/v2/route"))
        .and(wiremock::matchers::query_param("routeType", "shortest"))
        .respond_with(fixture_body("directions_route_two_waypoints.json"))
        .expect(1)
        .mount(&server)
        .await;
    let routing_provider = mapquest_provider::MapQuestRoutingProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    let route_options = RouteOptions {
        route_strategy: RouteStrategy::Shortest,
        ..RouteOptions::default()
    };
    routing_provider
        .calculate_route(
            &[recorded_route_origin(), recorded_route_destination()],
            &route_options,
        )
        .await
        .unwrap();
    server.verify().await;
}

#[tokio::test]
async fn distance_matrix_posts_alltoall_over_the_location_union() {
    let server = wiremock::MockServer::start().await;
    let expected_body = serde_json::json!({
        "locations": [
            {"latLng": {"lat": 38.57657, "lng": -121.4936}},
            {"latLng": {"lat": 38.57887, "lng": -121.50797}},
            {"latLng": {"lat": 38.57406, "lng": -121.46951}}
        ],
        "options": {"allToAll": true, "unit": "k", "routeType": "fastest"}
    });
    wiremock::Mock::given(wiremock::matchers::method("POST"))
        .and(wiremock::matchers::path("/directions/v2/routematrix"))
        .and(wiremock::matchers::body_json(expected_body))
        .respond_with(fixture_body("routematrix_three_locations_unit_k.json"))
        .mount(&server)
        .await;
    let matrix_provider = mapquest_provider::MapQuestDistanceMatrixProvider::new(
        std::sync::Arc::new(client_with_base(server.uri())),
    );
    let matrix = matrix_provider
        .calculate_distance_matrix(
            &[recorded_route_origin()],
            &[
                recorded_route_destination(),
                coordinate(38.57406, -121.46951),
            ],
            geospatial_types::route::TransportationMode::Automobile,
        )
        .await
        .unwrap();
    assert_eq!(matrix.entries.len(), 2);
    assert!((matrix.entries[0].duration_seconds - 235.0).abs() < 1.0);
}

#[tokio::test]
async fn search_prediction_passes_query_and_boundary_center() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/search/v3/prediction"))
        .and(wiremock::matchers::query_param("q", "denver"))
        .and(wiremock::matchers::query_param("limit", "15"))
        .respond_with(fixture_body("search_prediction_denver.json"))
        .mount(&server)
        .await;
    let search_provider = mapquest_provider::MapQuestSearchPlaceProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    let places = search_provider
        .search_places("denver", Some(denver_bounding_box()))
        .await
        .unwrap();
    assert!(!places.is_empty());
    assert!(places[0].structured_address_text.contains("Denver"));
    // The boundary box ranks via its center point (float arithmetic noted).
    let received_requests = server.received_requests().await.unwrap();
    assert!(received_requests.iter().any(|request| {
        let query_text = request.url.query().unwrap_or_default();
        query_text.contains("location=-104.9") && query_text.contains("39.735")
    }));
}

#[tokio::test]
async fn traffic_incidents_replay_the_recorded_bounding_box_query() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/traffic/v2/incidents"))
        .and(wiremock::matchers::query_param(
            "boundingBox",
            "39.95,-105.25,39.52,-104.71",
        ))
        .respond_with(fixture_body("traffic_incidents_denver.json"))
        .expect(1)
        .mount(&server)
        .await;
    let incident_provider = mapquest_provider::MapQuestTrafficIncidentProvider::new(
        std::sync::Arc::new(client_with_base(server.uri())),
    );
    let incidents = incident_provider
        .fetch_traffic_incidents(&denver_bounding_box())
        .await
        .unwrap();
    server.verify().await;
    assert_eq!(incidents.len(), 5);
}

#[tokio::test]
async fn traffic_flow_replays_the_recorded_geojson_with_out_format_json() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path("/traffic/v2/flow"))
        .and(wiremock::matchers::query_param("outFormat", "json"))
        .and(wiremock::matchers::query_param("projection", "merc"))
        .and(wiremock::matchers::query_param("mapScale", "216671"))
        .respond_with(fixture_body("traffic_flow_new_york.json"))
        .expect(1)
        .mount(&server)
        .await;
    let flow_provider = mapquest_provider::MapQuestTrafficFlowProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    let flow = flow_provider
        .fetch_traffic_flow(&denver_bounding_box())
        .await
        .unwrap();
    server.verify().await;
    assert_eq!(flow.len(), 4);
    assert_eq!(
        flow[0].congestion_level,
        geospatial_types::traffic::TrafficFlowCongestionLevel::FreeFlow
    );
    assert_eq!(
        flow[3].congestion_level,
        geospatial_types::traffic::TrafficFlowCongestionLevel::Blocked
    );
}

#[tokio::test]
async fn raster_tiles_fetch_through_the_shared_client() {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::method("GET"))
        .and(wiremock::matchers::path(
            "/tiles/v1/render/latest/vivid/13/1873/3374/256/png",
        ))
        .respond_with(ResponseTemplateWithTinyPng::template())
        .mount(&server)
        .await;
    let tile_provider = mapquest_provider::MapQuestRasterTileProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    let tile = tile_provider
        .fetch_raster_tile(
            1873,
            3374,
            13,
            RasterImageFormat::Png,
            RasterTileResolution::Standard,
        )
        .await
        .unwrap();
    assert_eq!(tile.image_format, RasterImageFormat::Png);
    assert!(tile.image_bytes.starts_with(&[0x89, b'P', b'N', b'G']));
}

/// A 1x1 blue PNG served as tile bytes.
struct ResponseTemplateWithTinyPng;

impl ResponseTemplateWithTinyPng {
    fn template() -> ResponseTemplate {
        ResponseTemplate::new(200).set_body_bytes(TINY_PNG.to_vec())
    }
}

const TINY_PNG: [u8; 70] = [
    137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0,
    0, 0, 31, 21, 196, 137, 0, 0, 0, 13, 73, 68, 65, 84, 120, 218, 99, 100, 96, 248, 95, 15, 0, 2,
    135, 1, 128, 235, 71, 186, 146, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130,
];

#[tokio::test]
async fn out_of_range_tiles_reject_before_any_network_call() {
    let server = wiremock::MockServer::start().await;
    let tile_provider = mapquest_provider::MapQuestRasterTileProvider::new(std::sync::Arc::new(
        client_with_base(server.uri()),
    ));
    assert!(
        tile_provider
            .fetch_raster_tile(
                5,
                5,
                12,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .is_err()
    );
    assert!(
        tile_provider
            .fetch_raster_tile(
                0,
                0,
                21,
                RasterImageFormat::Png,
                RasterTileResolution::Standard,
            )
            .await
            .is_err()
    );
    server.verify().await;
}
