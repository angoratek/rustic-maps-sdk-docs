//! OpenStreetMap US tileservice implementation of
//! [`geospatial_traits::VectorTileProvider`].
//!
//! # Service facts (from the service's own pages)
//!
//! - Service: the [OpenStreetMap US tileservice](https://openstreetmap.us/our-work/tileservice/),
//!   operated by OpenStreetMap US (the US chapter of the OSM Foundation).
//!   Vector tilesets are listed at
//!   <https://tiles.openstreetmap.us/vector/>; this implementation serves the
//!   **Sourdough** tileset, osmus's homegrown schema, documented at
//!   <https://sourdough.osm.fyi/schema/> and mirrored in the TileJSON at
//!   <https://tiles.openstreetmap.us/vector/sourdough.json>.
//! - Tile URL template (verbatim from the TileJSON `tiles` array):
//!   `https://tiles.openstreetmap.us/vector/sourdough/{z}/{x}/{y}.mvt`.
//! - Zoom span (TileJSON `minzoom`/`maxzoom`): 0 through 15; scheme `xyz`.
//! - Wire format (live probe, 2026-10-29): `application/x-protobuf`
//!   MVT protobuf, served gzip-wrapped (`Content-Encoding: gzip`); the
//!   provider records the encoding it received instead of decompressing.
//! - Attribution (usage policy, <https://tiles.openstreetmap.us/usage-policy/>):
//!   OSM-derived tiles require **all** of `Tiles by OSM US` (linked to
//!   <https://tiles.openstreetmap.us>), `© OpenStreetMap` (linked to
//!   <https://www.openstreetmap.org/copyright>), and — on OpenMapTiles-schema
//!   tilesets — `© OpenMapTiles` (linked to <https://openmaptiles.org>);
//!   surfaced on the provider through
//!   [`geospatial_traits::VectorTileProvider::source_descriptor`].
//! - Usage policy: the service is free for low-volume, non-commercial use
//!   (Development/Starter tiers; commercial or higher-volume use requires an
//!   approved partnership application). Requests must carry accurate
//!   identifying headers ([`vector_tiles::OSMUS_USER_AGENT_TEXT_PREFIX`]),
//!   must not be spoofed, must honor `Cache-Control` responses, and must
//!   back off on HTTP 429. The fixtures-first tests of this crate and of its
//!   consumers keep the SDK from ever downloading tiles during tests; the
//!   reference apps' posture stays low-volume non-commercial.
//!
//! # Crate posture
//!
//! Like `mapquest-provider`, this crate performs its requests through the
//! shared `provider-transport` seam: the same request, retry and
//! rate-limiting code runs natively and in the browser. The crate itself
//! targets native platforms; the contract it implements in
//! `geospatial-traits` is wasm-clean.

pub mod error_mapping;
pub mod http;
pub mod vector_tiles;

pub use http::{OpenStreetMapUsTileHttpClient, OpenStreetMapUsVectorTileConfiguration};
pub use vector_tiles::OpenStreetMapUsVectorTileProvider;
