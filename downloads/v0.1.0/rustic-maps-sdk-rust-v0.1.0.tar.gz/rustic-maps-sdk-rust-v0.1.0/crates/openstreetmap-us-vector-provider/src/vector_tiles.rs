//! OpenStreetMap US tileservice implementation of the vector-tile provider
//! contract: rate-limited binary tile GETs against the Sourdough tileset.

use crate::http::{OpenStreetMapUsTileHttpClient, OpenStreetMapUsVectorTileConfiguration};
use async_trait::async_trait;
use geospatial_traits::{VectorTileProvider, VectorTileSourceDescriptor};
use geospatial_types::{SDKError, VectorTileData};
use provider_transport::TokenBucketRateLimiter;

/// Public base URL of the OpenStreetMap US tileservice.
pub const OSMUS_TILESERVICE_BASE_URL: &str = "https://tiles.openstreetmap.us";

/// Usage-policy document every integrator must comply with.
pub const OSMUS_TILESERVICE_USAGE_POLICY_URL: &str = "https://tiles.openstreetmap.us/usage-policy/";

/// Vector tileset listing page the tilesets are documented on.
pub const OSMUS_VECTOR_TILESETS_PAGE_URL: &str = "https://tiles.openstreetmap.us/vector/";

/// TileJSON address of the Sourdough tileset this provider serves.
pub const SOURDOUGH_TILEJSON_URL: &str = "https://tiles.openstreetmap.us/vector/sourdough.json";

/// Sourdough tile URL template, verbatim from the TileJSON `tiles` array
/// (fetched 2026-10-29).
pub const SOURDOUGH_URL_TEMPLATE: &str =
    "https://tiles.openstreetmap.us/vector/sourdough/{z}/{x}/{y}.mvt";

/// Request path root of the Sourdough tileset, relative to the base URL.
pub const SOURDOUGH_TILE_PATH_ROOT: &str = "vector/sourdough";

/// File extension the Sourdough tile template names (MVT protobuf).
pub const SOURDOUGH_TILE_FILE_EXTENSION: &str = "mvt";

/// Stable source name the tileset is cached and referenced under.
pub const SOURDOUGH_TILESET_SOURCE_NAME: &str = "openstreetmap-us/sourdough";

/// Sourdough schema documentation (the schema mirrors OSM tagging).
pub const SOURDOUGH_SCHEMA_DOCUMENTATION_URL: &str = "https://sourdough.osm.fyi/schema/";

/// Zoom floor from the Sourdough TileJSON `minzoom` (fetched 2026-10-29).
pub const SOURDOUGH_MINIMUM_ZOOM_LEVEL: u8 = 0;

/// Zoom ceiling from the Sourdough TileJSON `maxzoom` (fetched 2026-10-29).
pub const SOURDOUGH_MAXIMUM_ZOOM_LEVEL: u8 = 15;

/// Human-readable attribution line the usage policy requires wherever the
/// imagery is shown. The policy's example reads `Tiles by OSM US ©
/// OpenStreetMap` and the displayed parts must link to
/// <https://tiles.openstreetmap.us> and
/// <https://www.openstreetmap.org/copyright> respectively; rendering
/// surfaces translate this line into their own linked markup.
pub const OSMUS_SOURDOUGH_ATTRIBUTION_TEXT: &str = "Tiles by OSM US © OpenStreetMap contributors";

/// The imagery-caching ceiling this provider installs: **30 calendar days**,
/// the common maximum under imagery-provider terms and the same ceiling the
/// MapQuest raster path inherits. The
/// usage policy separately requires honoring `Cache-Control` response
/// headers; a live probe (2026-10-29) observed
/// `Cache-Control: public, max-age=86400` — an 86400-second per-response
/// tightening is a possible refinement, while this 30-day
/// value remains the SDK's terms ceiling, enforced by this crate's lockstep
/// test against `rustic_maps_cache::ResponseCategory::VectorTiles`.
pub const OSMUS_VECTOR_TILE_CACHE_CEILING_SECONDS: u64 = 30 * 24 * 60 * 60;

/// Prefix of the identifying User-Agent the usage policy requires. The
/// configuration appends an integrator-provided contact; spoofing the
/// client identity is explicitly forbidden.
pub const OSMUS_USER_AGENT_TEXT_PREFIX: &str = "rustic-maps-sdk";

/// Serves the Sourdough tileset of the OpenStreetMap US tileservice.
pub struct OpenStreetMapUsVectorTileProvider {
    http_client: OpenStreetMapUsTileHttpClient,
    rate_limiter: TokenBucketRateLimiter,
}

impl OpenStreetMapUsVectorTileProvider {
    /// Builds the provider from the given configuration.
    pub fn new(configuration: OpenStreetMapUsVectorTileConfiguration) -> Result<Self, SDKError> {
        Ok(Self {
            http_client: OpenStreetMapUsTileHttpClient::new(
                configuration.base_url,
                configuration.user_agent_text,
                configuration.maximum_retry_attempts,
            )?,
            rate_limiter: TokenBucketRateLimiter::new(
                configuration.token_bucket_capacity,
                configuration.refill_tokens_per_second,
                configuration.maximum_wait_seconds,
            )?,
        })
    }

    /// Builds the provider with the default configuration's pacing against
    /// an explicit base URL (the test seam; production code uses
    /// [`OpenStreetMapUsVectorTileProvider::new`] with the defaults).
    #[cfg(test)]
    pub(crate) fn with_default_pacing(base_url: String) -> Self {
        Self::new(OpenStreetMapUsVectorTileConfiguration {
            base_url,
            ..OpenStreetMapUsVectorTileConfiguration::default()
        })
        .expect("the default configuration is valid")
    }

    /// Request path of one tile, per the documented URL template
    /// `[SOURDOUGH_TILE_PATH_ROOT]/{zoom}/{x}/{y}[.mvt]`.
    fn tile_request_path(&self, tile_x: u32, tile_y: u32, zoom_level: u8) -> String {
        format!(
            "{SOURDOUGH_TILE_PATH_ROOT}/{zoom_level}/{tile_x}/{tile_y}.{SOURDOUGH_TILE_FILE_EXTENSION}"
        )
    }
}

#[async_trait]
impl VectorTileProvider for OpenStreetMapUsVectorTileProvider {
    fn source_descriptor(&self) -> VectorTileSourceDescriptor {
        VectorTileSourceDescriptor {
            source_name: SOURDOUGH_TILESET_SOURCE_NAME.to_string(),
            attribution_text: OSMUS_SOURDOUGH_ATTRIBUTION_TEXT.to_string(),
            minimum_zoom_level: SOURDOUGH_MINIMUM_ZOOM_LEVEL,
            maximum_zoom_level: SOURDOUGH_MAXIMUM_ZOOM_LEVEL,
        }
    }

    async fn fetch_vector_tile(
        &self,
        tile_x: u32,
        tile_y: u32,
        zoom_level: u8,
    ) -> Result<VectorTileData, SDKError> {
        if zoom_level > SOURDOUGH_MAXIMUM_ZOOM_LEVEL {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "zoom level {zoom_level} exceeds the Sourdough TileJSON maximum of \
                 {SOURDOUGH_MAXIMUM_ZOOM_LEVEL}"
            )));
        }
        let maximum_tile_index = (1u32 << zoom_level) - 1;
        if tile_x > maximum_tile_index || tile_y > maximum_tile_index {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "tile x={tile_x} y={tile_y} exceeds the {maximum_tile_index} maximum at zoom \
                 {zoom_level}"
            )));
        }
        self.rate_limiter.acquire().await?;
        let wire_bytes = self
            .http_client
            .get_tile_bytes(&self.tile_request_path(tile_x, tile_y, zoom_level))
            .await?;
        VectorTileData::from_wire_bytes(tile_x, tile_y, zoom_level, wire_bytes)
    }
}

#[cfg(test)]
mod tests {
    use super::OpenStreetMapUsVectorTileProvider;
    use super::{
        OSMUS_SOURDOUGH_ATTRIBUTION_TEXT, OSMUS_VECTOR_TILE_CACHE_CEILING_SECONDS,
        SOURDOUGH_MAXIMUM_ZOOM_LEVEL, SOURDOUGH_MINIMUM_ZOOM_LEVEL, SOURDOUGH_TILESET_SOURCE_NAME,
        SOURDOUGH_URL_TEMPLATE,
    };
    use geospatial_traits::VectorTileProvider;
    use geospatial_types::{SDKError, VectorTileEncoding};
    use wiremock::matchers::{method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    /// Provenance for the committed fixture: source
    /// `https://tiles.openstreetmap.us/vector/sourdough/6/18/27.mvt`
    /// (the URL-template form; gzip `Content-Encoding` decoded for storage),
    /// fetched 2026-10-29. License/attribution: tile data © OpenStreetMap
    /// contributors (https://www.openstreetmap.org/copyright), tiles served
    /// by OSM US (https://tiles.openstreetmap.us) under the published usage
    /// policy. Recorded in `fixtures/openstreetmap-us/README.md`.
    const FIXTURE_TILE_NAME: &str = "sourdough_tile_z6_x18_y27.mvt";

    /// Protobuf key for MVT's repeated `layers` field (field 3, wire type 2)
    /// — the top-level envelope mark of the MVT Tile message.
    const MVT_LAYER_FIELD_PROTOBUF_KEY: u8 = 0x1a;

    /// Protobuf key for a vector-tile layer's `name` field (field 1, wire
    /// type 2) — the first entry of every layer inside the envelope.
    const MVT_LAYER_NAME_FIELD_PROTOBUF_KEY: u8 = 0x0a;

    fn fixture_tile() -> Vec<u8> {
        let fixture_path = format!(
            "{}/../../fixtures/openstreetmap-us/{FIXTURE_TILE_NAME}",
            env!("CARGO_MANIFEST_DIR")
        );
        std::fs::read(&fixture_path).expect("committed fixture tile must be present")
    }

    #[test]
    fn recorded_service_facts_hold() {
        assert_eq!(
            SOURDOUGH_URL_TEMPLATE,
            "https://tiles.openstreetmap.us/vector/sourdough/{z}/{x}/{y}.mvt"
        );
        let descriptor = OpenStreetMapUsVectorTileProvider::with_default_pacing(
            "http://localhost/dummy".to_string(),
        )
        .source_descriptor();
        assert_eq!(descriptor.source_name, SOURDOUGH_TILESET_SOURCE_NAME);
        assert_eq!(descriptor.source_name, "openstreetmap-us/sourdough");
        assert_eq!(
            descriptor.attribution_text,
            OSMUS_SOURDOUGH_ATTRIBUTION_TEXT
        );
        assert_eq!(descriptor.minimum_zoom_level, SOURDOUGH_MINIMUM_ZOOM_LEVEL);
        assert_eq!(descriptor.maximum_zoom_level, SOURDOUGH_MAXIMUM_ZOOM_LEVEL);
        assert_eq!(SOURDOUGH_MINIMUM_ZOOM_LEVEL, 0);
        assert_eq!(SOURDOUGH_MAXIMUM_ZOOM_LEVEL, 15);
    }

    /// The general cache layer's vector-tiles default must equal this
    /// provider's terms ceiling, so the default-heavy posture never exceeds
    /// what the terms allow, mirroring the raster path's
    /// lockstep test.
    #[test]
    fn cache_vector_tiles_default_matches_provider_terms_ceiling() {
        assert_eq!(
            rustic_maps_cache::ResponseCategory::VectorTiles.default_time_to_live_seconds(),
            OSMUS_VECTOR_TILE_CACHE_CEILING_SECONDS
        );
    }

    #[tokio::test]
    async fn fetches_tile_bytes_from_the_documented_template() {
        let server = MockServer::start().await;
        let fixture_bytes = fixture_tile();
        Mock::given(method("GET"))
            .and(path("/vector/sourdough/6/18/27.mvt"))
            .respond_with(
                ResponseTemplate::new(200)
                    .set_body_bytes(fixture_bytes.to_vec())
                    .insert_header("Content-Type", "application/x-protobuf"),
            )
            .mount(&server)
            .await;
        let provider = OpenStreetMapUsVectorTileProvider::with_default_pacing(server.uri());
        let tile = provider.fetch_vector_tile(18, 27, 6).await.unwrap();
        assert_eq!(tile.tile_x, 18);
        assert_eq!(tile.tile_y, 27);
        assert_eq!(tile.zoom_level, 6);
        assert_eq!(tile.tile_encoding, VectorTileEncoding::MapboxVectorTile);
        assert_eq!(tile.tile_bytes, fixture_bytes);
    }

    #[tokio::test]
    async fn gzip_wrapped_wire_payload_reports_the_gzip_encoding() {
        let server = MockServer::start().await;
        // Two-byte gzip magic (`1f 8b`) plus an opaque body: the provider
        // records the encoding it received and never decodes on the fetch
        // path (decompression belongs to the M9 decoder).
        let gzipped_mock_bytes: [u8; 3] = [0x1f, 0x8b, 0x08];
        Mock::given(method("GET"))
            .and(path("/vector/sourdough/6/18/27.mvt"))
            .respond_with(
                ResponseTemplate::new(200)
                    .set_body_bytes(gzipped_mock_bytes.to_vec())
                    .insert_header("Content-Encoding", "gzip"),
            )
            .mount(&server)
            .await;
        let provider = OpenStreetMapUsVectorTileProvider::with_default_pacing(server.uri());
        let tile = provider.fetch_vector_tile(18, 27, 6).await.unwrap();
        assert_eq!(
            tile.tile_encoding,
            VectorTileEncoding::GzippedMapboxVectorTile
        );
    }

    #[tokio::test]
    async fn zoom_and_tile_indexes_outside_the_tileset_are_rejected_without_requests() {
        let server = MockServer::start().await;
        let provider = OpenStreetMapUsVectorTileProvider::with_default_pacing(server.uri());
        assert!(matches!(
            provider
                .fetch_vector_tile(0, 0, SOURDOUGH_MAXIMUM_ZOOM_LEVEL + 1)
                .await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        // At zoom 6 only 0..=63 indexes exist; 64 is out of range.
        assert!(matches!(
            provider.fetch_vector_tile(64, 27, 6).await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
        assert!(matches!(
            provider.fetch_vector_tile(18, 64, 6).await,
            Err(SDKError::InvalidCoordinateInput(_))
        ));
    }

    /// ASCII name the fixture's first layer carries (its `name` string
    /// field, read out at fetch time 2026-10-29): the schema pin the other
    /// decoded assertion compares against.
    const FIRST_SAMPLE_LAYER_NAME: &[u8] = b"aeroways";

    #[test]
    fn committed_fixture_tile_carries_the_mvt_envelope() {
        // Byte-level envelope sanity only: the MVT Tile protobuf leads with
        // the repeated `layers` field, and the first layer leads with its
        // `name` string field. Parsing beyond that is the decoder slice's
        // job (M9) — this asserts the committed bytes look like an MVT
        // tile, with no decoder involved.
        let fixture_bytes = fixture_tile();
        assert_eq!(fixture_bytes[0], MVT_LAYER_FIELD_PROTOBUF_KEY);
        let (_layer_length, layer_length_varint_width) = read_varint(&fixture_bytes[1..]);
        let layer_bytes = &fixture_bytes[1 + layer_length_varint_width..];
        assert_eq!(layer_bytes[0], MVT_LAYER_NAME_FIELD_PROTOBUF_KEY);
        let (name_length, name_varint_width) = read_varint(&layer_bytes[1..]);
        let name_start = 1 + name_varint_width;
        let layer_name = &layer_bytes[name_start..name_start + name_length as usize];
        assert_eq!(layer_name, FIRST_SAMPLE_LAYER_NAME);
    }

    /// Reads one protobuf varint from the front of `bytes`, returning
    /// `(value, bytes consumed)`.
    fn read_varint(bytes: &[u8]) -> (u64, usize) {
        let mut value: u64 = 0;
        for (shift_offset, byte) in bytes.iter().take(10).enumerate() {
            value |= u64::from(byte & 0x7f) << (7 * shift_offset);
            if byte & 0x80 == 0 {
                return (value, shift_offset + 1);
            }
        }
        panic!("varint over ten bytes cannot appear in an MVT envelope");
    }
}
