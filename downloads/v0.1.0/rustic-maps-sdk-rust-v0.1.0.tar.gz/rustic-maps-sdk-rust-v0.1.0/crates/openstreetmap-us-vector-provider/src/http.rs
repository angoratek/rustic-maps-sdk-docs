//! HTTP transport for the OpenStreetMap US tileservice: contact-identifying
//! headers, bounded retries for idempotent tile GETs, and typed error
//! mapping. There is no API key: access tiering runs off the request's own
//! identity headers, so the User-Agent is the honest software marker the
//! usage policy requires. The byte transport and the retry loop are the
//! shared [`provider_transport`] seam.

use crate::error_mapping::map_http_error_response;
use geospatial_types::SDKError;
use provider_transport::{
    HTTP_ERROR_STATUS_CODE_THRESHOLD, HttpMethod, HttpRequest, HttpResponse, HttpTransport,
    RetryPolicy, default_transport, execute_idempotent_get,
};
use std::sync::Arc;
use url::Url;

/// Request header the usage policy's identifying identity travels in.
const USER_AGENT_HEADER_NAME: &str = "user-agent";

/// Character cap on error bodies echoed into error strings, so a huge error
/// response cannot bloat the diagnostic text.
const MAXIMUM_ERROR_BODY_TAIL: usize = 256;

/// Low-level binary client against one tileservice base URL.
pub struct OpenStreetMapUsTileHttpClient {
    base_url: String,
    user_agent_text: String,
    maximum_retry_attempts: u32,
    transport: Arc<dyn HttpTransport>,
}

impl OpenStreetMapUsTileHttpClient {
    /// Builds a client; `maximum_retry_attempts` applies to tile GETs (one
    /// attempt plus this many retries on transient failures, per the usage
    /// policy's back-off guidance).
    pub fn new(
        base_url: String,
        user_agent_text: String,
        maximum_retry_attempts: u32,
    ) -> Result<Self, SDKError> {
        Ok(Self {
            base_url,
            user_agent_text,
            maximum_retry_attempts,
            transport: default_transport()?,
        })
    }

    /// Performs a GET against `{base_url}/{path}` with the client's
    /// identifying headers, retrying transient failures in bounds.
    pub async fn get_tile_bytes(&self, path: &str) -> Result<Vec<u8>, SDKError> {
        let request = self.build_request(path)?;
        execute_idempotent_get(
            self.transport.as_ref(),
            &request,
            RetryPolicy::new(self.maximum_retry_attempts),
            interpret_tile_response,
        )
        .await
    }

    /// Builds the identifying GET for one tileservice path.
    fn build_request(&self, path: &str) -> Result<HttpRequest, SDKError> {
        let url = Url::parse(&format!("{}/{path}", self.base_url.trim_end_matches('/')))
            .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
        Ok(HttpRequest {
            method: HttpMethod::Get,
            url: url.to_string(),
            headers: vec![(
                USER_AGENT_HEADER_NAME.to_string(),
                self.user_agent_text.clone(),
            )],
            body: None,
        })
    }
}

/// Interprets one tile response: a non-success status maps through the
/// tileservice status vocabulary (with a bounded body tail for diagnostics),
/// anything else returns the raw tile bytes.
fn interpret_tile_response(response: HttpResponse) -> Result<Vec<u8>, SDKError> {
    if response.status_code >= HTTP_ERROR_STATUS_CODE_THRESHOLD {
        // The body is noise on a binary endpoint; the status carries the
        // meaning and a bounded tail keeps diagnostics readable without
        // buffering the whole error payload.
        let response_body_tail = String::from_utf8_lossy(&response.body)
            .chars()
            .take(MAXIMUM_ERROR_BODY_TAIL)
            .collect::<String>();
        return Err(map_http_error_response(
            response.status_code,
            &response_body_tail,
        ));
    }
    Ok(response.body)
}

/// Bundled tuning for the tileservice client.
pub struct OpenStreetMapUsVectorTileConfiguration {
    /// Tileservice base URL; defaults to the public service and is
    /// overridden in tests.
    pub base_url: String,
    /// Identifying User-Agent text the usage policy requires: honest
    /// software marker plus an integrator-provided contact. Never spoofed.
    pub user_agent_text: String,
    /// Bucket capacity; bursts up to this many tile requests start
    /// immediately.
    pub token_bucket_capacity: f64,
    /// Continuous refill rate in tokens per second.
    pub refill_tokens_per_second: f64,
    /// Longest wait accepted before surfacing [`SDKError::RateLimitExhausted`].
    pub maximum_wait_seconds: u64,
    /// Retry budget for tile GETs.
    pub maximum_retry_attempts: u32,
}

/// Conservative anonymous-tier pacing: a small burst (one map view's worth
/// of tiles) plus a slow refill keeps usage inside the tileservice's
/// low-volume posture, whose numeric limits the usage policy leaves
/// unpublished (tiered server-side instead).
pub const DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS: f64 = 4.0;
/// Conservative continuous refill (one tile per half second).
pub const DEFAULT_REFILL_TOKENS_PER_SECOND: f64 = 2.0;
/// Longest rate-limiter wait before a fetch is refused outright.
pub const DEFAULT_MAXIMUM_WAIT_SECONDS: u64 = 10;
/// Retry budget for tile GETs.
pub const DEFAULT_MAXIMUM_RETRY_ATTEMPTS: u32 = 2;

impl Default for OpenStreetMapUsVectorTileConfiguration {
    fn default() -> Self {
        Self {
            base_url: crate::vector_tiles::OSMUS_TILESERVICE_BASE_URL.to_string(),
            user_agent_text: format!(
                "{}/{} (OpenStreetMap US tileservice; low-volume non-commercial use)",
                crate::vector_tiles::OSMUS_USER_AGENT_TEXT_PREFIX,
                env!("CARGO_PKG_VERSION")
            ),
            token_bucket_capacity: DEFAULT_TOKEN_BUCKET_CAPACITY_TOKENS,
            refill_tokens_per_second: DEFAULT_REFILL_TOKENS_PER_SECOND,
            maximum_wait_seconds: DEFAULT_MAXIMUM_WAIT_SECONDS,
            maximum_retry_attempts: DEFAULT_MAXIMUM_RETRY_ATTEMPTS,
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::http::OpenStreetMapUsTileHttpClient;
    use geospatial_types::SDKError;
    use wiremock::matchers::{header, method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    /// Smallest meaningful envelope for envelope-sanity assertions.
    const SAMPLE_TILE_BYTES: [u8; 2] = [0x1a, 0x00];

    fn test_client(base_url: String) -> OpenStreetMapUsTileHttpClient {
        OpenStreetMapUsTileHttpClient::new(base_url, "sdk-test-agent".to_string(), 2).unwrap()
    }

    #[test]
    fn default_configuration_is_honest_about_the_client_identity() {
        let configuration = crate::http::OpenStreetMapUsVectorTileConfiguration::default();
        assert!(
            configuration
                .user_agent_text
                .starts_with(crate::vector_tiles::OSMUS_USER_AGENT_TEXT_PREFIX)
        );
        assert_eq!(
            configuration.base_url,
            crate::vector_tiles::OSMUS_TILESERVICE_BASE_URL
        );
    }

    #[tokio::test]
    async fn sends_identifying_user_agent_and_returns_bytes() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/vector/sourdough/3/2/3.mvt"))
            .and(header("user-agent", "sdk-test-agent"))
            .respond_with(
                ResponseTemplate::new(200)
                    .set_body_bytes(SAMPLE_TILE_BYTES.to_vec())
                    .insert_header("Content-Type", "application/x-protobuf"),
            )
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        let tile_bytes = client
            .get_tile_bytes("vector/sourdough/3/2/3.mvt")
            .await
            .unwrap();
        assert_eq!(tile_bytes, SAMPLE_TILE_BYTES.to_vec());
    }

    #[tokio::test]
    async fn retries_transient_failures_until_success() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(503))
            .up_to_n_times(1)
            .mount(&server)
            .await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(SAMPLE_TILE_BYTES.to_vec()))
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        let tile_bytes = client
            .get_tile_bytes("vector/sourdough/0/0/0.mvt")
            .await
            .unwrap();
        assert!(!tile_bytes.is_empty());
    }

    #[tokio::test]
    async fn http_429_surfaces_the_rate_limit_error() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(429))
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        assert!(matches!(
            client.get_tile_bytes("vector/sourdough/0/0/0.mvt").await,
            Err(SDKError::RateLimitExhausted)
        ));
    }

    #[tokio::test]
    async fn exhausts_bounded_retries_then_surfaces_network_failure() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(503))
            .mount(&server)
            .await;
        let client = test_client(server.uri());
        assert!(matches!(
            client.get_tile_bytes("vector/sourdough/0/0/0.mvt").await,
            Err(SDKError::NetworkRequestFailed(_))
        ));
    }
}
