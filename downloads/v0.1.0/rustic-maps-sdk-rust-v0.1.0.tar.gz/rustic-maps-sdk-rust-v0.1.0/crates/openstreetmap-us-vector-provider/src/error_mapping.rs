//! Mapping between tileservice signals and the SDK error model.
//!
//! The tileservice is a raw binary tile endpoint: failures surface as HTTP
//! statuses only. The usage policy additionally requires clients to back off
//! on HTTP 429, which the SDK-wide transient classification treats as
//! retryable alongside transport trouble.

use geospatial_types::SDKError;

/// The HTTP status the service returns when the usage-policy limits apply.
const HTTP_TOO_MANY_REQUESTS_STATUS: u16 = 429;

/// Translates a non-success HTTP status returned by the tileservice.
pub fn map_http_error_response(status: u16, response_body_tail: &str) -> SDKError {
    match status {
        HTTP_TOO_MANY_REQUESTS_STATUS => SDKError::RateLimitExhausted,
        status if status >= 500 => SDKError::NetworkRequestFailed(format!(
            "tileservice unavailable (HTTP {status}): {response_body_tail}"
        )),
        _ => SDKError::ProviderRequestRejected(format!(
            "tileservice returned HTTP {status}: {response_body_tail}"
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::map_http_error_response;
    use geospatial_types::SDKError;
    use provider_transport::is_transient_error;

    #[test]
    fn http_429_maps_to_rate_limit_exhausted_and_is_retryable() {
        assert!(matches!(
            map_http_error_response(429, ""),
            SDKError::RateLimitExhausted
        ));
        assert!(is_transient_error(&map_http_error_response(429, "")));
    }

    #[test]
    fn http_403_maps_to_provider_request_rejected_non_retryably() {
        let error = map_http_error_response(403, "usage policy violation");
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
        assert!(!is_transient_error(&error));
    }

    #[test]
    fn http_5xx_maps_to_network_failure_and_is_retryable() {
        let error = map_http_error_response(503, "overloaded");
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
        assert!(is_transient_error(&error));
    }
}
