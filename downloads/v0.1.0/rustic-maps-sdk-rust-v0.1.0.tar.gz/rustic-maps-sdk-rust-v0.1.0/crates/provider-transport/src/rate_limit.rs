//! One token-bucket rate limiter shared by every provider crate.
//!
//! The limiter is portable: it measures time with `web_time::Instant` and
//! waits through the shared [`crate::sleep`] timer, so the same pacing code
//! runs natively and in the browser. The mutable schedule sits behind a
//! synchronous mutex that is never held across an await point, so every
//! provider future stays `Send`.

use crate::sleep;
use geospatial_types::SDKError;
use std::sync::Mutex;
use std::time::Duration;
use web_time::Instant;

/// Smallest burst capacity a limiter accepts.
const MINIMUM_CAPACITY_TOKENS: f64 = 1.0;

/// Tokens one acquisition consumes.
const TOKENS_PER_ACQUISITION: f64 = 1.0;

/// Refill rate at or below which a limiter is refused at construction: it
/// would never make progress.
const MINIMUM_EXCLUSIVE_REFILL_TOKENS_PER_SECOND: f64 = 0.0;

/// Refillable token bucket that paces a provider's outbound requests.
///
/// The bucket starts full, refills continuously at
/// `refill_tokens_per_second`, and never holds more than
/// `capacity_tokens`. Callers await [`TokenBucketRateLimiter::acquire`];
/// when even the earliest possible refill lies past the caller's declared
/// maximum wait, [`SDKError::RateLimitExhausted`] is returned instead.
pub struct TokenBucketRateLimiter {
    capacity_tokens: f64,
    refill_tokens_per_second: f64,
    maximum_wait_duration: Duration,
    state: Mutex<TokenBucketState>,
}

/// The mutable half of the bucket: the tokens available at
/// `last_refill_instant`.
struct TokenBucketState {
    available_tokens: f64,
    last_refill_instant: Instant,
}

impl TokenBucketRateLimiter {
    /// Builds a limiter; capacities below one token or a non-positive refill
    /// rate are rejected at construction.
    pub fn new(
        capacity_tokens: f64,
        refill_tokens_per_second: f64,
        maximum_wait_seconds: u64,
    ) -> Result<Self, SDKError> {
        // A non-finite value would slip past the comparisons below and panic
        // later in `Duration::from_secs_f64`, so reject it explicitly.
        if !capacity_tokens.is_finite() || capacity_tokens < MINIMUM_CAPACITY_TOKENS {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "token bucket capacity {capacity_tokens} must be a finite number of at least one token"
            )));
        }
        if !refill_tokens_per_second.is_finite()
            || refill_tokens_per_second <= MINIMUM_EXCLUSIVE_REFILL_TOKENS_PER_SECOND
        {
            return Err(SDKError::InvalidCoordinateInput(format!(
                "token bucket refill rate {refill_tokens_per_second} must be a finite positive number"
            )));
        }
        Ok(Self {
            capacity_tokens,
            refill_tokens_per_second,
            maximum_wait_duration: Duration::from_secs(maximum_wait_seconds),
            state: Mutex::new(TokenBucketState {
                available_tokens: capacity_tokens,
                last_refill_instant: Instant::now(),
            }),
        })
    }

    /// Waits for one token, bounded by the limiter's maximum wait duration.
    pub async fn acquire(&self) -> Result<(), SDKError> {
        let acquired_instant = self.reserve_slot()?;
        let minimum_delay_until_refill = acquired_instant
            .checked_duration_since(Instant::now())
            .unwrap_or_default();
        if minimum_delay_until_refill > Duration::ZERO {
            sleep(minimum_delay_until_refill).await;
        }
        Ok(())
    }

    /// Reserves the next free slot, returning the instant from which the
    /// caller may proceed. The lock is taken and released within this
    /// synchronous method, never across an await point; a poisoned lock is
    /// recovered because the schedule stays internally consistent.
    fn reserve_slot(&self) -> Result<Instant, SDKError> {
        let mut state = self
            .state
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let current_instant = Instant::now();
        let elapsed_seconds = current_instant
            .duration_since(state.last_refill_instant)
            .as_secs_f64();
        state.available_tokens = (state.available_tokens
            + elapsed_seconds * self.refill_tokens_per_second)
            .min(self.capacity_tokens);
        state.last_refill_instant = current_instant;

        // The reservation is always deducted, even when it takes the balance
        // negative: the next caller's deficit then includes this wait, so
        // concurrent callers queue behind one another instead of waking
        // together for the same slot.
        state.available_tokens -= TOKENS_PER_ACQUISITION;
        if state.available_tokens >= 0.0 {
            return Ok(current_instant);
        }
        let deficit_tokens = -state.available_tokens;
        let wait_duration = Duration::from_secs_f64(deficit_tokens / self.refill_tokens_per_second);
        if wait_duration > self.maximum_wait_duration {
            // A refused caller consumes nothing: restore the reservation.
            state.available_tokens += TOKENS_PER_ACQUISITION;
            return Err(SDKError::RateLimitExhausted);
        }
        Ok(current_instant + wait_duration)
    }
}

#[cfg(test)]
mod tests {
    use super::TokenBucketRateLimiter;
    use geospatial_types::SDKError;
    use std::sync::Arc;

    #[tokio::test]
    async fn full_bucket_admits_initial_burst() {
        let limiter = TokenBucketRateLimiter::new(5.0, 0.5, 10).unwrap();
        for _ in 0..5 {
            limiter.acquire().await.unwrap();
        }
    }

    #[tokio::test]
    async fn exhausted_bucket_reports_rate_limit_before_maximum_wait() {
        let limiter = TokenBucketRateLimiter::new(1.0, 0.01, 1).unwrap();
        limiter.acquire().await.unwrap();
        assert!(matches!(
            limiter.acquire().await,
            Err(SDKError::RateLimitExhausted)
        ));
    }

    #[tokio::test]
    async fn limiter_paces_concurrent_callers_beyond_capacity() {
        let limiter = Arc::new(TokenBucketRateLimiter::new(2.0, 2.0, 10).unwrap());
        let handles: Vec<_> = (0..4)
            .map(|_| {
                let limiter = Arc::clone(&limiter);
                tokio::spawn(async move { limiter.acquire().await })
            })
            .collect();
        for handle in handles {
            handle.await.unwrap().unwrap();
        }
    }

    #[test]
    fn reservations_pace_concurrent_callers_instead_of_waking_together() {
        let limiter = TokenBucketRateLimiter::new(1.0, 1.0, 10).unwrap();
        let first = limiter.reserve_slot().unwrap();
        let second = limiter.reserve_slot().unwrap();
        let third = limiter.reserve_slot().unwrap();
        assert!(second > first, "the second caller waits behind the first");
        assert!(third > second, "the third caller waits behind the second");
        assert!(
            second.duration_since(first).as_secs_f64() >= 0.9,
            "each reservation is spaced by about one refill period"
        );
    }

    #[test]
    fn non_finite_configuration_is_rejected_without_panicking() {
        assert!(TokenBucketRateLimiter::new(f64::NAN, 1.0, 10).is_err());
        assert!(TokenBucketRateLimiter::new(f64::INFINITY, 1.0, 10).is_err());
        assert!(TokenBucketRateLimiter::new(1.0, f64::NAN, 10).is_err());
        assert!(TokenBucketRateLimiter::new(1.0, f64::INFINITY, 10).is_err());
    }

    #[test]
    fn invalid_configuration_is_rejected() {
        assert!(TokenBucketRateLimiter::new(0.5, 1.0, 10).is_err());
        assert!(TokenBucketRateLimiter::new(5.0, 0.0, 10).is_err());
    }
}
