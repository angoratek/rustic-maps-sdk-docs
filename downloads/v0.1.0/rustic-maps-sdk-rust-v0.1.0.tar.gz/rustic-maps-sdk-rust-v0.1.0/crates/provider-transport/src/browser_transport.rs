//! The browser transport: `fetch` through `gloo-net`, behind the same
//! portable [`HttpTransport`] contract the native transport implements.
//!
//! Browser futures are not `Send`, while the provider traits require `Send`
//! futures. The fetch runs on the local executor (`spawn_local`) and reports
//! its result through a oneshot channel, so the awaited half is a plain
//! `Send` channel receive. The runtime is single-threaded on wasm.

use crate::{HttpMethod, HttpRequest, HttpResponse, HttpTransport, TransportError};
use async_trait::async_trait;
use futures::channel::oneshot;
use gloo_net::http::Request;
use wasm_bindgen_futures::spawn_local;

/// A `fetch`-backed transport for the browser target.
#[derive(Debug, Default)]
pub struct BrowserFetchTransport;

impl BrowserFetchTransport {
    /// Builds the transport (no configuration is needed).
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl HttpTransport for BrowserFetchTransport {
    async fn execute(&self, request: HttpRequest) -> Result<HttpResponse, TransportError> {
        let (outcome_sender, outcome_receiver) = oneshot::channel();
        spawn_local(async move {
            let fetch_outcome = execute_fetch(request).await;
            let _ = outcome_sender.send(fetch_outcome);
        });
        outcome_receiver
            .await
            .map_err(|_| TransportError::Network("fetch task was cancelled".to_string()))?
    }
}

/// One `fetch` execution; kept separate so the `spawn_local` wrapper stays a
/// thin channel bridge.
async fn execute_fetch(request: HttpRequest) -> Result<HttpResponse, TransportError> {
    let mut request_builder = match request.method {
        HttpMethod::Get => Request::get(&request.url),
        HttpMethod::Post => Request::post(&request.url),
    };
    for (header_name, header_value) in &request.headers {
        // A forbidden header is dropped here rather than at the provider, so
        // every browser caller is safe: forwarding one turns a cross-origin
        // request into a preflight the host may refuse.
        if crate::browser_headers::is_forbidden_browser_request_header(header_name) {
            continue;
        }
        request_builder = request_builder.header(header_name, header_value);
    }
    let response = match request.body {
        Some(body) => {
            let sent_request = request_builder
                .body(body)
                .map_err(|error| TransportError::Network(error.to_string()))?;
            sent_request
                .send()
                .await
                .map_err(|error| TransportError::Network(error.to_string()))?
        }
        None => request_builder
            .send()
            .await
            .map_err(|error| TransportError::Network(error.to_string()))?,
    };
    let status_code = response.status();
    let body = response
        .binary()
        .await
        .map_err(|error| TransportError::Network(error.to_string()))?;
    Ok(HttpResponse {
        status_code,
        headers: Vec::new(),
        body,
    })
}
