//! The browser transport: `fetch` through `gloo-net`, behind the same
//! portable [`HttpTransport`] contract the native transport implements.
//!
//! Browser futures are not `Send`, while the provider traits require `Send`
//! futures. The fetch runs on the local executor (`spawn_local`) and reports
//! its result through a oneshot channel, so the awaited half is a plain
//! `Send` channel receive. The runtime is single-threaded on wasm.

use crate::{
    BROWSER_REQUEST_TIMEOUT, HttpMethod, HttpRequest, HttpResponse, HttpTransport, TransportError,
};
use async_trait::async_trait;
use futures::channel::oneshot;
use futures::future::{Either, select};
use gloo_net::http::Request;
use gloo_timers::future::TimeoutFuture;
use wasm_bindgen_futures::spawn_local;
use web_sys::AbortController;

/// A `fetch`-backed transport for the browser target.
#[derive(Debug, Default)]
pub struct BrowserFetchTransport;

impl BrowserFetchTransport {
    /// Builds the transport (no configuration is needed).
    pub fn new() -> Self {
        Self
    }
}

#[async_trait]
impl HttpTransport for BrowserFetchTransport {
    async fn execute(&self, request: HttpRequest) -> Result<HttpResponse, TransportError> {
        let (outcome_sender, outcome_receiver) = oneshot::channel();
        spawn_local(async move {
            let fetch_outcome = execute_fetch(request).await;
            let _ = outcome_sender.send(fetch_outcome);
        });
        outcome_receiver
            .await
            .map_err(|_| TransportError::Network("fetch task was cancelled".to_string()))?
    }
}

/// Sends a built request under the transport's whole-request deadline: when
/// the timer elapses first, the abort controller cancels the underlying
/// `fetch`, so a stalled connection can neither hold an in-flight request slot
/// nor outlive its turn. The send future is dropped on the timeout branch; the
/// abort is what actually stops the browser request.
async fn send_with_deadline<SendFuture>(
    send_future: SendFuture,
    abort_controller: AbortController,
) -> Result<gloo_net::http::Response, TransportError>
where
    SendFuture: std::future::Future<Output = Result<gloo_net::http::Response, gloo_net::Error>>,
{
    // Browser timers take millisecond integers; the deadline is well inside
    // the representable range, and the clamp keeps the conversion total.
    let deadline_milliseconds =
        u32::try_from(BROWSER_REQUEST_TIMEOUT.as_millis()).unwrap_or(u32::MAX);
    let send_future = std::pin::pin!(send_future);
    let deadline = std::pin::pin!(TimeoutFuture::new(deadline_milliseconds));
    match select(send_future, deadline).await {
        Either::Left((send_outcome, _)) => {
            send_outcome.map_err(|error| TransportError::Network(error.to_string()))
        }
        Either::Right(((), _)) => {
            abort_controller.abort();
            Err(TransportError::Timeout(format!(
                "the browser fetch exceeded the {} second request deadline",
                BROWSER_REQUEST_TIMEOUT.as_secs()
            )))
        }
    }
}

/// One `fetch` execution; kept separate so the `spawn_local` wrapper stays a
/// thin channel bridge.
async fn execute_fetch(request: HttpRequest) -> Result<HttpResponse, TransportError> {
    let abort_controller = AbortController::new().map_err(|error| {
        TransportError::Network(format!(
            "the browser refused an abort controller for the request: {error:?}"
        ))
    })?;
    let abort_signal = abort_controller.signal();
    let mut request_builder = match request.method {
        HttpMethod::Get => Request::get(&request.url),
        HttpMethod::Post => Request::post(&request.url),
    };
    for (header_name, header_value) in &request.headers {
        // A forbidden header is dropped here rather than at the provider, so
        // every browser caller is safe: forwarding one turns a cross-origin
        // request into a preflight the host may refuse.
        if crate::browser_headers::is_forbidden_browser_request_header(header_name) {
            continue;
        }
        request_builder = request_builder.header(header_name, header_value);
    }
    let response = match request.body {
        Some(body) => {
            let sent_request = request_builder
                .abort_signal(Some(&abort_signal))
                .body(body)
                .map_err(|error| TransportError::Network(error.to_string()))?;
            send_with_deadline(sent_request.send(), abort_controller).await?
        }
        None => {
            let sent_request = request_builder.abort_signal(Some(&abort_signal));
            send_with_deadline(sent_request.send(), abort_controller).await?
        }
    };
    let status_code = response.status();
    let body = response
        .binary()
        .await
        .map_err(|error| TransportError::Network(error.to_string()))?;
    Ok(HttpResponse {
        status_code,
        headers: Vec::new(),
        body,
    })
}
