//! Provider-request observation: the record a console shows for one provider
//! call, and the sink the SDK installs to receive it.
//!
//! The observation is built here rather than in a provider crate so the
//! redaction rule has one home: a request path keeps its structure, query
//! values are dropped except the documented non-secret parameters, and the
//! response snippet is capped at [`RESPONSE_SNIPPET_MAXIMUM_BYTES`] on a
//! character boundary. A credential reaches this module as part of the request
//! and never leaves it — the tests feed one through a request and assert the
//! observation carries neither the value nor the parameter pair.
//!
//! The sink is process-wide because the provider crates are stateless with
//! respect to the SDK: the native binding and the browser façade each install
//! one observer at startup, and a provider crate used on its own (a unit test,
//! a stand-alone integration) runs with none installed and pays no cost.

use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;

use url::Url;

use crate::HttpMethod;

/// Maximum length of the response snippet in an observation, in bytes,
/// counted on character boundaries so a multi-byte glyph is never split.
pub const RESPONSE_SNIPPET_MAXIMUM_BYTES: usize = 512;

/// Query parameters whose values may appear in an observation because they
/// describe the request shape rather than carry data or a secret. Every other
/// parameter's value is dropped; its name is not.
pub const OBSERVABLE_QUERY_PARAMETER_NAMES: [&str; 4] =
    ["format", "overview", "geometries", "units"];

/// The status class an observation reports when no HTTP response arrived.
pub const TRANSPORT_FAILURE_STATUS_CLASS: &str = "transport-failure";

/// One provider call, already redacted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderRequestObservation {
    /// The provider contract the call served, for example `RoutingProvider`.
    pub provider_contract: String,
    /// The registry key of the serving provider.
    pub provider_key: String,
    /// The HTTP method as a two-to-four-letter word (`GET`, `POST`).
    pub http_method: String,
    /// The redacted request path, query names included and values removed.
    pub request_path: String,
    /// `2xx`, `3xx`, `4xx`, `5xx` or [`TRANSPORT_FAILURE_STATUS_CLASS`].
    pub status_class: String,
    /// Wall-clock duration of the attempt, in milliseconds.
    pub duration_milliseconds: u64,
    /// Response payload size in bytes; zero when no response arrived.
    pub response_bytes: u64,
    /// The response prefix, capped at [`RESPONSE_SNIPPET_MAXIMUM_BYTES`].
    pub response_snippet: String,
}

/// Receives one observation per completed provider call.
pub trait ProviderRequestObserver: Send + Sync {
    /// Records one provider call. Called synchronously on the request's
    /// task, so an implementation must not block.
    fn on_provider_request(&self, observation: ProviderRequestObservation);
}

/// A transport decorator that reports every attempt to the installed
/// observer before returning its result.
///
/// A provider client wraps its transport once at construction, so every call
/// through that client is observed with the same contract and key without
/// any request-building site changing. Retries are observed per attempt,
/// which is what a reader debugging a failure needs to see.
pub struct ObservedTransport {
    /// The transport that performs the request.
    inner: Arc<dyn crate::HttpTransport>,
    /// The contract the calls through this transport serve.
    provider_contract: String,
    /// The registry key of the provider that owns this transport.
    provider_key: String,
}

impl ObservedTransport {
    /// Wraps a transport with the provider identity its calls serve.
    pub fn new(
        inner: Arc<dyn crate::HttpTransport>,
        provider_contract: &str,
        provider_key: &str,
    ) -> Self {
        Self {
            inner,
            provider_contract: provider_contract.to_string(),
            provider_key: provider_key.to_string(),
        }
    }
}

#[async_trait::async_trait]
impl crate::HttpTransport for ObservedTransport {
    async fn execute(
        &self,
        request: crate::HttpRequest,
    ) -> Result<crate::HttpResponse, crate::TransportError> {
        let http_method = request.method;
        let request_url = request.url.clone();
        let started_at = web_time::Instant::now();
        let outcome = self.inner.execute(request).await;
        let duration = started_at.elapsed();
        let observed_outcome = outcome
            .as_ref()
            .ok()
            .map(|response| (response.status_code, response.body.as_slice()));
        observe_provider_request(
            &self.provider_contract,
            &self.provider_key,
            http_method,
            &request_url,
            observed_outcome,
            duration,
        );
        outcome
    }
}

/// The installed observer, if any.
static INSTALLED_OBSERVER: OnceLock<Mutex<Option<Arc<dyn ProviderRequestObserver>>>> =
    OnceLock::new();

/// Installs the observer that receives every provider call made afterwards.
///
/// Replacing an installed observer is allowed: a binding constructs its SDK
/// more than once in the same process, and the last installed observer is the
/// one that matters. Passing no observer (`None`) stops delivery.
pub fn install_provider_request_observer(observer: Option<Arc<dyn ProviderRequestObserver>>) {
    let installed_observer = INSTALLED_OBSERVER.get_or_init(|| Mutex::new(None));
    *installed_observer
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner) = observer;
}

/// Builds one redacted observation for a completed attempt and hands it to
/// the installed observer. Returns immediately when none is installed.
///
/// # Parameters
/// - `provider_contract` — the contract the call served.
/// - `provider_key` — the serving provider's registry key.
/// - `http_method` — the request's method.
/// - `request_url` — the fully built request URL, before redaction.
/// - `outcome` — the status code and body, when a response arrived.
/// - `duration` — how long the attempt took.
pub fn observe_provider_request(
    provider_contract: &str,
    provider_key: &str,
    http_method: HttpMethod,
    request_url: &str,
    outcome: Option<(u16, &[u8])>,
    duration: Duration,
) {
    let Some(observer) = installed_observer() else {
        return;
    };
    let (status_class, response_bytes, response_snippet) = match outcome {
        Some((status_code, body)) => (
            status_class_text(status_code),
            body.len() as u64,
            response_snippet_text(body),
        ),
        None => (TRANSPORT_FAILURE_STATUS_CLASS.to_string(), 0, String::new()),
    };
    observer.on_provider_request(ProviderRequestObservation {
        provider_contract: provider_contract.to_string(),
        provider_key: provider_key.to_string(),
        http_method: http_method_text(http_method).to_string(),
        request_path: redacted_request_path(request_url),
        status_class,
        duration_milliseconds: duration.as_millis().min(u64::MAX as u128) as u64,
        response_bytes,
        response_snippet,
    });
}

/// Reduces a request URL to what an observation may show: the path, plus the
/// names of its query parameters with values removed except the parameters
/// whose value describes the request shape.
pub fn redacted_request_path(request_url: &str) -> String {
    let Ok(parsed_url) = Url::parse(request_url) else {
        // An unparseable URL never reaches a provider in practice; refuse to
        // echo it verbatim, because it may carry a credential in any shape.
        return String::from("<unparseable request url>");
    };
    let mut redacted_path = parsed_url.path().to_string();
    let mut redacted_parameters: Vec<String> = parsed_url
        .query_pairs()
        .map(|(parameter_name, parameter_value)| {
            if OBSERVABLE_QUERY_PARAMETER_NAMES.contains(&parameter_name.as_ref()) {
                format!("{parameter_name}={parameter_value}")
            } else {
                format!("{parameter_name}=<redacted>")
            }
        })
        .collect();
    redacted_parameters.sort();
    if !redacted_parameters.is_empty() {
        redacted_path.push('?');
        redacted_path.push_str(&redacted_parameters.join("&"));
    }
    redacted_path
}

/// Caps a response body at [`RESPONSE_SNIPPET_MAXIMUM_BYTES`] on a character
/// boundary, so a multi-byte glyph is never split.
pub fn response_snippet_text(response_body: &[u8]) -> String {
    let text = String::from_utf8_lossy(response_body);
    if text.len() <= RESPONSE_SNIPPET_MAXIMUM_BYTES {
        return text.into_owned();
    }
    let mut snippet_end = RESPONSE_SNIPPET_MAXIMUM_BYTES;
    while !text.is_char_boundary(snippet_end) {
        snippet_end -= 1;
    }
    text[..snippet_end].to_string()
}

/// The status class an observation reports for one HTTP status code.
fn status_class_text(status_code: u16) -> String {
    let status_class_prefix = status_code / 100;
    format!("{status_class_prefix}xx")
}

/// The word an observation reports for one HTTP method.
fn http_method_text(http_method: HttpMethod) -> &'static str {
    match http_method {
        HttpMethod::Get => "GET",
        HttpMethod::Post => "POST",
    }
}

/// The installed observer, cloned out of the process-wide slot so delivery
/// never holds the lock across the observer's own work.
fn installed_observer() -> Option<Arc<dyn ProviderRequestObserver>> {
    INSTALLED_OBSERVER
        .get()?
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .clone()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The installed observer is process-wide, so the tests that install one
    /// take this lock: two of them running at once would see each other's
    /// observations (a parallel `cargo test` run did exactly that).
    ///
    /// The lock is async-aware because some of these tests await the transport
    /// while they hold it; a standard-library guard must never be held across
    /// an await.
    static OBSERVER_TEST_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

    /// Takes the process-wide observer lock from a synchronous test.
    fn lock_installed_observer() -> tokio::sync::MutexGuard<'static, ()> {
        OBSERVER_TEST_LOCK.blocking_lock()
    }

    /// Takes the process-wide observer lock from an asynchronous test.
    async fn lock_installed_observer_async() -> tokio::sync::MutexGuard<'static, ()> {
        OBSERVER_TEST_LOCK.lock().await
    }

    /// An observer that keeps every observation it receives.
    #[derive(Default)]
    struct RecordingObserver {
        observations: Mutex<Vec<ProviderRequestObservation>>,
    }

    impl ProviderRequestObserver for RecordingObserver {
        fn on_provider_request(&self, observation: ProviderRequestObservation) {
            self.observations
                .lock()
                .expect("the observation list is never poisoned")
                .push(observation);
        }
    }

    #[test]
    fn a_credential_never_reaches_the_redacted_path() {
        let redacted_path = redacted_request_path(
            "https://provider.invalid/route?key=SECRET_VALUE&overview=full&units=metric",
        );
        assert!(!redacted_path.contains("SECRET_VALUE"));
        assert!(redacted_path.contains("key=<redacted>"));
        assert!(redacted_path.contains("overview=full"));
        assert!(redacted_path.contains("units=metric"));
        assert_eq!(redacted_path.split('?').next(), Some("/route"));
    }

    #[test]
    fn query_parameter_order_does_not_change_the_redacted_path() {
        let first_path = redacted_request_path("https://provider.invalid/a?b=1&a=2");
        let second_path = redacted_request_path("https://provider.invalid/a?a=2&b=1");
        assert_eq!(first_path, second_path);
    }

    #[test]
    fn an_unparseable_url_is_never_echoed() {
        assert_eq!(
            redacted_request_path("not a url with SECRET_VALUE"),
            "<unparseable request url>",
        );
    }

    #[test]
    fn the_status_class_groups_codes() {
        assert_eq!(status_class_text(200), "2xx");
        assert_eq!(status_class_text(404), "4xx");
        assert_eq!(status_class_text(503), "5xx");
    }

    #[test]
    fn the_snippet_caps_at_the_documented_bytes_on_a_character_boundary() {
        let multi_byte_body = "é".repeat(RESPONSE_SNIPPET_MAXIMUM_BYTES);
        let snippet = response_snippet_text(multi_byte_body.as_bytes());
        assert!(snippet.len() <= RESPONSE_SNIPPET_MAXIMUM_BYTES);
        assert_eq!(snippet, "é".repeat(RESPONSE_SNIPPET_MAXIMUM_BYTES / 2));
    }

    #[test]
    fn an_observation_reaches_the_installed_observer() {
        let _observer_lock = lock_installed_observer();
        let recording_observer = Arc::new(RecordingObserver::default());
        install_provider_request_observer(Some(recording_observer.clone()));
        observe_provider_request(
            "RoutingProvider",
            "test-provider",
            HttpMethod::Get,
            "https://provider.invalid/route/v1/driving/a;b?key=SECRET_VALUE",
            Some((200, b"{}".as_slice())),
            Duration::from_millis(12),
        );
        let observations = recording_observer
            .observations
            .lock()
            .expect("the observation list is never poisoned")
            .clone();
        assert_eq!(observations.len(), 1);
        let observation = &observations[0];
        assert_eq!(observation.provider_contract, "RoutingProvider");
        assert_eq!(observation.provider_key, "test-provider");
        assert_eq!(observation.http_method, "GET");
        assert_eq!(observation.status_class, "2xx");
        assert_eq!(observation.response_bytes, 2);
        assert_eq!(observation.response_snippet, "{}");
        assert!(observation.duration_milliseconds >= 12);
        assert!(!observation.request_path.contains("SECRET_VALUE"));
    }

    #[test]
    fn a_transport_failure_is_reported_without_a_status() {
        let _observer_lock = lock_installed_observer();
        let recording_observer = Arc::new(RecordingObserver::default());
        install_provider_request_observer(Some(recording_observer.clone()));
        observe_provider_request(
            "GeocodingProvider",
            "test-provider",
            HttpMethod::Post,
            "https://provider.invalid/search",
            None,
            Duration::ZERO,
        );
        let observations = recording_observer
            .observations
            .lock()
            .expect("the observation list is never poisoned")
            .clone();
        assert_eq!(observations[0].status_class, TRANSPORT_FAILURE_STATUS_CLASS);
        assert_eq!(observations[0].response_bytes, 0);
        assert!(observations[0].response_snippet.is_empty());
    }

    /// A transport answering with a fixed status and body.
    struct FixedTransport {
        status_code: u16,
        body: Vec<u8>,
    }

    #[async_trait::async_trait]
    impl crate::HttpTransport for FixedTransport {
        async fn execute(
            &self,
            _request: crate::HttpRequest,
        ) -> Result<crate::HttpResponse, crate::TransportError> {
            Ok(crate::HttpResponse {
                status_code: self.status_code,
                headers: Vec::new(),
                body: self.body.clone(),
            })
        }
    }

    #[tokio::test]
    async fn the_observed_transport_reports_the_attempt_with_the_provider_identity() {
        let _observer_lock = lock_installed_observer_async().await;
        let recording_observer = Arc::new(RecordingObserver::default());
        install_provider_request_observer(Some(recording_observer.clone()));
        let observed_transport = ObservedTransport::new(
            Arc::new(FixedTransport {
                status_code: 404,
                body: b"not found".to_vec(),
            }),
            "RoutingProvider",
            "test-provider",
        );
        let request = crate::HttpRequest {
            method: HttpMethod::Get,
            url: "https://provider.invalid/route/v1/driving/a;b?key=SECRET_VALUE".to_string(),
            headers: Vec::new(),
            body: None,
        };
        let response = crate::HttpTransport::execute(&observed_transport, request)
            .await
            .expect("the fixed transport always answers");
        assert_eq!(response.status_code, 404);
        let observations = recording_observer
            .observations
            .lock()
            .expect("the observation list is never poisoned")
            .clone();
        assert_eq!(observations.len(), 1);
        assert_eq!(observations[0].status_class, "4xx");
        assert_eq!(observations[0].response_snippet, "not found");
        assert_eq!(observations[0].provider_key, "test-provider");
        assert!(!observations[0].request_path.contains("SECRET_VALUE"));
    }

    #[test]
    fn no_observation_is_built_without_an_installed_observer() {
        let _observer_lock = lock_installed_observer();
        install_provider_request_observer(None);
        observe_provider_request(
            "RoutingProvider",
            "test-provider",
            HttpMethod::Get,
            "https://provider.invalid/route",
            Some((200, b"{}".as_slice())),
            Duration::ZERO,
        );
    }
}
