//! The native transport: `reqwest` behind the portable [`HttpTransport`]
//! contract, with the connect and whole-request deadlines the provider client
//! has always applied.

use crate::{
    CONNECT_TIMEOUT, HttpMethod, HttpRequest, HttpResponse, HttpTransport, REQUEST_TIMEOUT,
    TransportError,
};
use async_trait::async_trait;

/// A `reqwest`-backed transport shared by every provider request.
pub struct ReqwestTransport {
    http_client: reqwest::Client,
}

impl ReqwestTransport {
    /// Builds the transport with the provider deadlines; a client build
    /// failure surfaces as a transport error.
    pub fn new() -> Result<Self, TransportError> {
        let http_client = reqwest::Client::builder()
            .connect_timeout(CONNECT_TIMEOUT)
            .timeout(REQUEST_TIMEOUT)
            .build()
            .map_err(|error| TransportError::Network(error.to_string()))?;
        Ok(Self { http_client })
    }
}

impl Default for ReqwestTransport {
    fn default() -> Self {
        Self::new().unwrap_or_else(|_| Self {
            http_client: fallback_client_with_timeouts(),
        })
    }
}

/// The client `Default` falls back to when the configured builder fails: it
/// keeps the transport's request timeout, so a caller that constructs the
/// default can never inherit a request that hangs forever.
fn fallback_client_with_timeouts() -> reqwest::Client {
    reqwest::Client::builder()
        .connect_timeout(crate::CONNECT_TIMEOUT)
        .timeout(crate::REQUEST_TIMEOUT)
        .build()
        .unwrap_or_default()
}

#[async_trait]
impl HttpTransport for ReqwestTransport {
    async fn execute(&self, request: HttpRequest) -> Result<HttpResponse, TransportError> {
        let method = match request.method {
            HttpMethod::Get => reqwest::Method::GET,
            HttpMethod::Post => reqwest::Method::POST,
        };
        let mut request_builder = self.http_client.request(method, &request.url);
        for (header_name, header_value) in &request.headers {
            request_builder = request_builder.header(header_name, header_value);
        }
        if let Some(body) = request.body {
            request_builder = request_builder.body(body);
        }
        let response = request_builder.send().await.map_err(|error| {
            if error.is_timeout() {
                TransportError::Timeout(error.to_string())
            } else {
                TransportError::Network(error.to_string())
            }
        })?;
        let status_code = response.status().as_u16();
        let headers = response
            .headers()
            .iter()
            .map(|(header_name, header_value)| {
                (
                    header_name.as_str().to_string(),
                    header_value.to_str().unwrap_or_default().to_string(),
                )
            })
            .collect();
        let body = response
            .bytes()
            .await
            .map_err(|error| TransportError::Network(error.to_string()))?
            .to_vec();
        Ok(HttpResponse {
            status_code,
            headers,
            body,
        })
    }
}
