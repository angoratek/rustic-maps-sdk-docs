//! Request headers a browser must not set.
//!
//! The Fetch specification reserves a set of header names for the user agent;
//! page code may not set them. Forwarding one anyway advertises the name in a
//! cross-origin request's CORS preflight, and a host whose policy does not
//! allow it answers the preflight with a failure — a tile host that refuses a
//! `user-agent` header, for example, then serves no tiles at all.
//!
//! The predicate is portable so it is unit-tested on every host, while only
//! the browser transport applies it. The native transport keeps the declared
//! user agent: a server is free to send one.

/// Header names the Fetch specification forbids page code to set, matched
/// case-insensitively.
pub const FORBIDDEN_BROWSER_REQUEST_HEADER_NAMES: [&str; 8] = [
    "accept-encoding",
    "connection",
    "content-length",
    "cookie",
    "host",
    "origin",
    "referer",
    "user-agent",
];

/// Header-name prefixes the Fetch specification reserves for the user agent.
pub const FORBIDDEN_BROWSER_REQUEST_HEADER_PREFIXES: [&str; 2] = ["proxy-", "sec-"];

/// Whether the browser transport must drop `header_name` before building the
/// request.
pub fn is_forbidden_browser_request_header(header_name: &str) -> bool {
    let normalized_name = header_name.trim().to_ascii_lowercase();
    FORBIDDEN_BROWSER_REQUEST_HEADER_NAMES.contains(&normalized_name.as_str())
        || FORBIDDEN_BROWSER_REQUEST_HEADER_PREFIXES
            .iter()
            .any(|prefix| normalized_name.starts_with(prefix))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_reserved_name_is_forbidden_regardless_of_case_and_space() {
        for reserved_name in FORBIDDEN_BROWSER_REQUEST_HEADER_NAMES {
            assert!(is_forbidden_browser_request_header(reserved_name));
            assert!(is_forbidden_browser_request_header(
                &reserved_name.to_uppercase()
            ));
            assert!(is_forbidden_browser_request_header(&format!(
                "  {reserved_name}\t"
            )));
        }
    }

    #[test]
    fn reserved_prefixes_cover_the_sec_and_proxy_families() {
        for prefixed_name in ["Sec-Fetch-Site", "sec-ch-ua", "Proxy-Authorization"] {
            assert!(is_forbidden_browser_request_header(prefixed_name));
        }
    }

    #[test]
    fn ordinary_request_headers_are_forwarded() {
        for allowed_name in ["Authorization", "Content-Type", "Accept", "X-Request-Id"] {
            assert!(!is_forbidden_browser_request_header(allowed_name));
        }
    }
}
