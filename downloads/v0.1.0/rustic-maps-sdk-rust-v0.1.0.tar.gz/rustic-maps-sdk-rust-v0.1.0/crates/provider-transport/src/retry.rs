//! One bounded-retry helper for idempotent GETs, shared by every provider
//! crate.
//!
//! Providers keep their own status-to-[`SDKError`] mapping (the statuses are
//! vendor vocabulary); this module supplies the retry loop, the transient
//! classification and the back-off schedule. Only idempotent GETs may use
//! it — a POST may already have been processed when a retry fires.

use crate::{HttpRequest, HttpResponse, HttpTransport, sleep};
use geospatial_types::SDKError;
use std::time::Duration;

/// Retry backoff base; attempt `n` waits `BACKOFF_BASE_MILLIS * n`.
pub const BACKOFF_BASE_MILLIS: u64 = 200;

/// Reports whether the error may succeed when the same request repeats
/// (transport trouble or a provider-side overflow); used to bound GET
/// retries.
pub fn is_transient_error(error: &SDKError) -> bool {
    matches!(
        error,
        SDKError::NetworkRequestFailed(_) | SDKError::RateLimitExhausted
    )
}

/// Retry budget for one idempotent GET: one attempt plus this many retries
/// on transient failures.
#[derive(Debug, Clone, Copy)]
pub struct RetryPolicy {
    maximum_retry_attempts: u32,
}

impl RetryPolicy {
    /// Builds a policy with the given retry budget.
    pub const fn new(maximum_retry_attempts: u32) -> Self {
        Self {
            maximum_retry_attempts,
        }
    }

    /// The number of retries allowed after the first attempt.
    pub const fn maximum_retry_attempts(&self) -> u32 {
        self.maximum_retry_attempts
    }

    /// The total number of attempts (first attempt plus retries).
    pub const fn total_attempts(&self) -> u32 {
        self.maximum_retry_attempts.saturating_add(1)
    }
}

/// Executes one idempotent GET through `transport`, repeating it while the
/// interpreted error is transient and the retry budget allows.
///
/// `interpret_response` turns one HTTP response into the provider's typed
/// value or error; classification of that error decides whether the request
/// repeats. Transport failures are classified as
/// [`SDKError::NetworkRequestFailed`], so they retry like any other
/// transient failure.
pub async fn execute_idempotent_get<ResultValue, InterpretResponse>(
    transport: &dyn HttpTransport,
    request: &HttpRequest,
    retry_policy: RetryPolicy,
    interpret_response: InterpretResponse,
) -> Result<ResultValue, SDKError>
where
    InterpretResponse: Fn(HttpResponse) -> Result<ResultValue, SDKError>,
{
    let total_attempts = retry_policy.total_attempts();
    let mut attempt_index: u32 = 0;
    loop {
        attempt_index += 1;
        let attempt_result = execute_once(transport, request, &interpret_response).await;
        match attempt_result {
            Ok(value) => return Ok(value),
            Err(error) if attempt_index < total_attempts && is_transient_error(&error) => {
                sleep(Duration::from_millis(
                    BACKOFF_BASE_MILLIS * u64::from(attempt_index),
                ))
                .await;
            }
            Err(error) => return Err(error),
        }
    }
}

/// Executes exactly one attempt and hands the response to the interpreter.
async fn execute_once<ResultValue>(
    transport: &dyn HttpTransport,
    request: &HttpRequest,
    interpret_response: &impl Fn(HttpResponse) -> Result<ResultValue, SDKError>,
) -> Result<ResultValue, SDKError> {
    let response = transport
        .execute(request.clone())
        .await
        .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
    interpret_response(response)
}

#[cfg(test)]
mod tests {
    use super::{RetryPolicy, execute_idempotent_get, is_transient_error};
    use crate::{HttpMethod, HttpRequest, HttpResponse, HttpTransport, TransportError};
    use async_trait::async_trait;
    use geospatial_types::SDKError;
    use std::collections::VecDeque;
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// A transport replaying a scripted list of status codes and counting
    /// executions; the last scripted status repeats when the script runs dry.
    struct ScriptedStatusTransport {
        statuses: Mutex<VecDeque<u16>>,
        execution_count: AtomicUsize,
    }

    impl ScriptedStatusTransport {
        fn new(statuses: Vec<u16>) -> Self {
            Self {
                statuses: Mutex::new(statuses.into()),
                execution_count: AtomicUsize::new(0),
            }
        }

        fn execution_count(&self) -> usize {
            self.execution_count.load(Ordering::SeqCst)
        }
    }

    #[async_trait]
    impl HttpTransport for ScriptedStatusTransport {
        async fn execute(&self, _request: HttpRequest) -> Result<HttpResponse, TransportError> {
            self.execution_count.fetch_add(1, Ordering::SeqCst);
            let mut statuses = self
                .statuses
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            let status_code = if statuses.len() > 1 {
                statuses.pop_front().unwrap_or(200)
            } else {
                statuses.front().copied().unwrap_or(200)
            };
            Ok(HttpResponse {
                status_code,
                headers: Vec::new(),
                body: b"scripted".to_vec(),
            })
        }
    }

    fn get_request() -> HttpRequest {
        HttpRequest {
            method: HttpMethod::Get,
            url: "http://localhost/scripted".to_string(),
            headers: Vec::new(),
            body: None,
        }
    }

    /// 2xx returns the body; anything else is a non-transient rejection.
    fn interpret(response: HttpResponse) -> Result<Vec<u8>, SDKError> {
        if response.status_code >= 400 {
            return Err(SDKError::ProviderRequestRejected(format!(
                "scripted HTTP {}",
                response.status_code
            )));
        }
        Ok(response.body)
    }

    /// 5xx behaves like a provider-side overflow: transient and retryable.
    fn interpret_with_transient_server_errors(response: HttpResponse) -> Result<Vec<u8>, SDKError> {
        if response.status_code >= 500 {
            return Err(SDKError::NetworkRequestFailed(format!(
                "scripted HTTP {}",
                response.status_code
            )));
        }
        interpret(response)
    }

    #[test]
    fn transient_classification_matches_retry_policy() {
        assert!(is_transient_error(&SDKError::NetworkRequestFailed(
            "connection refused".to_string()
        )));
        assert!(is_transient_error(&SDKError::RateLimitExhausted));
        assert!(!is_transient_error(&SDKError::ProviderRequestRejected(
            "forbidden".to_string()
        )));
        assert!(!is_transient_error(&SDKError::ResponseParsingFailure(
            "bad json".to_string()
        )));
    }

    #[tokio::test]
    async fn transient_failure_retries_until_success() {
        let transport = ScriptedStatusTransport::new(vec![503, 200]);
        let body = execute_idempotent_get(
            &transport,
            &get_request(),
            RetryPolicy::new(2),
            interpret_with_transient_server_errors,
        )
        .await
        .unwrap();
        assert_eq!(body, b"scripted".to_vec());
        assert_eq!(transport.execution_count(), 2);
    }

    #[tokio::test]
    async fn repeated_transient_failures_stop_at_the_retry_budget() {
        let transport = ScriptedStatusTransport::new(vec![503]);
        let error = execute_idempotent_get(
            &transport,
            &get_request(),
            RetryPolicy::new(2),
            interpret_with_transient_server_errors,
        )
        .await
        .unwrap_err();
        assert!(matches!(error, SDKError::NetworkRequestFailed(_)));
        assert_eq!(transport.execution_count(), 3);
    }

    #[tokio::test]
    async fn non_transient_failure_surfaces_without_retrying() {
        let transport = ScriptedStatusTransport::new(vec![403]);
        let error =
            execute_idempotent_get(&transport, &get_request(), RetryPolicy::new(2), interpret)
                .await
                .unwrap_err();
        assert!(matches!(error, SDKError::ProviderRequestRejected(_)));
        assert_eq!(transport.execution_count(), 1);
    }
}
