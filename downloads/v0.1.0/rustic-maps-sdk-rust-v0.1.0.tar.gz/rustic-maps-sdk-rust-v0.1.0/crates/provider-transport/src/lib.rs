//! The provider HTTP transport seam: one request/response
//! vocabulary and one [`HttpTransport`] contract that provider crates use on
//! every target. Native targets get the `reqwest` implementation; the
//! browser gets a `fetch` implementation, so the same provider request,
//! parsing and error-mapping code runs in both places.
//!
//! On top of the transport the crate carries the plumbing every provider
//! shares: the [`rate_limit::TokenBucketRateLimiter`] that paces outbound
//! requests, and [`retry::execute_idempotent_get`] with its transient-error
//! classification and back-off schedule. Providers keep their own
//! status-to-[`SDKError`] maps — the statuses are vendor vocabulary.
//!
//! The seam deliberately exchanges plain owned bytes and strings — no
//! provider crate ever names a platform HTTP type.

use async_trait::async_trait;
use geospatial_types::SDKError;
use std::sync::Arc;
use std::time::Duration;

pub mod rate_limit;
pub mod retry;

#[cfg(target_arch = "wasm32")]
mod browser_transport;
#[cfg(not(target_arch = "wasm32"))]
mod native_transport;

#[cfg(target_arch = "wasm32")]
pub use browser_transport::BrowserFetchTransport;
#[cfg(not(target_arch = "wasm32"))]
pub use native_transport::ReqwestTransport;
pub use rate_limit::TokenBucketRateLimiter;
pub use retry::{RetryPolicy, execute_idempotent_get, is_transient_error};

/// The first HTTP status code that signals failure rather than content.
pub const HTTP_ERROR_STATUS_CODE_THRESHOLD: u16 = 400;

/// The HTTP methods providers use (the two the provider contracts need).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpMethod {
    Get,
    Post,
}

/// One outbound request, independent of any platform HTTP client.
#[derive(Debug, Clone)]
pub struct HttpRequest {
    /// The method the request uses.
    pub method: HttpMethod,
    /// The fully built absolute URL, query string included.
    pub url: String,
    /// Additional request headers (`(name, value)` pairs).
    pub headers: Vec<(String, String)>,
    /// An optional request body (JSON bytes for POSTs).
    pub body: Option<Vec<u8>>,
}

/// One inbound response: status, headers and the raw body bytes.
#[derive(Debug, Clone)]
pub struct HttpResponse {
    /// The HTTP status code.
    pub status_code: u16,
    /// Response headers (`(name, value)` pairs); the browser transport omits
    /// them (providers only read status and body).
    pub headers: Vec<(String, String)>,
    /// The raw response body.
    pub body: Vec<u8>,
}

/// A transport-level failure (as opposed to an HTTP status the provider maps
/// into its typed error vocabulary).
#[derive(Debug, Clone, thiserror::Error)]
pub enum TransportError {
    /// The request could not complete (DNS, TLS, connection, fetch refusal).
    #[error("network request failed: {0}")]
    Network(String),
    /// The request exceeded the transport's deadline.
    #[error("request timed out: {0}")]
    Timeout(String),
}

/// The transport contract every provider crate executes requests through.
#[async_trait]
pub trait HttpTransport: Send + Sync {
    /// Executes one request, returning status, headers and body.
    async fn execute(&self, request: HttpRequest) -> Result<HttpResponse, TransportError>;
}

/// The connect deadline the native transport applies.
#[cfg(not(target_arch = "wasm32"))]
pub const CONNECT_TIMEOUT: Duration = Duration::from_secs(10);
/// The whole-request deadline the native transport applies.
#[cfg(not(target_arch = "wasm32"))]
pub const REQUEST_TIMEOUT: Duration = Duration::from_secs(30);

/// A portable sleep used by provider retry back-off and the rate limiter:
/// `tokio::time` natively, a browser timer on wasm. The browser timer's
/// future is not `Send`, so the wait is bridged through a oneshot channel and
/// the timer callback; the awaited half stays `Send`.
pub async fn sleep(duration: Duration) {
    #[cfg(not(target_arch = "wasm32"))]
    tokio::time::sleep(duration).await;
    #[cfg(target_arch = "wasm32")]
    {
        // Browser timers take millisecond integers; clamp the value to the
        // timer's representable range.
        const MILLISECONDS_MAXIMUM: u128 = u32::MAX as u128;
        let milliseconds = duration.as_millis().min(MILLISECONDS_MAXIMUM) as u32;
        let (wake_sender, wake_receiver) = futures::channel::oneshot::channel::<()>();
        gloo_timers::callback::Timeout::new(milliseconds, move || {
            let _ = wake_sender.send(());
        })
        .forget();
        let _ = wake_receiver.await;
    }
}

/// The target's default transport: the `reqwest` implementation natively,
/// browser `fetch` on wasm.
pub fn default_transport() -> Result<Arc<dyn HttpTransport>, SDKError> {
    #[cfg(not(target_arch = "wasm32"))]
    {
        let transport = ReqwestTransport::new()
            .map_err(|error| SDKError::NetworkRequestFailed(error.to_string()))?;
        Ok(Arc::new(transport))
    }
    #[cfg(target_arch = "wasm32")]
    {
        Ok(Arc::new(BrowserFetchTransport::new()))
    }
}
